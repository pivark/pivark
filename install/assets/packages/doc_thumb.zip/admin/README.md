# doc_thumb 后台 UI（SSOT）

Vue SFC：`weapp/doc_thumb/admin/ui/`。

**零外放**：禁止 junction；glob pageMap + `/weapp/host/doc_thumb/{page}` 通用 Host 加载。路由见 `ThumbAdminSpaRoutes`。
