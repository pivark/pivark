<?php
declare(strict_types=1);

namespace weapp\doc_thumb\admin;

use app\common\service\weapp\WeappPluginGateway;
use app\common\service\weapp\WeappSiteGateway;
use app\common\service\weapp\WeappSupportGateway;
use weapp\doc_thumb\service\ThumbnailConfigService;
use app\common\contract\PluginAdminBaseTrait;
use app\common\contract\PluginAdminUsageTrait;
use think\facade\Request;
use think\Response;
use weapp\doc_thumb\service\ThumbnailService;

class AdminController
{
    use PluginAdminBaseTrait;
    use PluginAdminUsageTrait;

    public function __construct()
    {
        $this->pluginIdentifier = 'doc_thumb';
    }

    public function index(): Response
    {
        if (!$this->entitled()) {
            return $this->renderDisabled();
        }
        ThumbnailService::ensureAutoload();
        $manifest = app(WeappPluginGateway::class)->pluginReadManifest('doc_thumb') ?? [];
        $cfg = ThumbnailConfigService::all();
        $navSizes = json_decode((string) ($cfg['thumb_nav_sizes'] ?? '[]'), true);
        if (!is_array($navSizes)) {
            $navSizes = [];
        }

        return $this->renderPluginView('index', array_merge(
            $this->pluginContext($manifest),
            [
                'cfg'        => $cfg,
                'navSizes'   => ThumbnailConfigService::navSizesForAdmin($navSizes),
                'navOptions' => app(WeappSiteGateway::class)->siteNavListContentCategoryOptions(),
                'stats'      => ThumbnailService::statsAdmin(),
                'templates'  => $this->templateOptions(),
                'formats'    => $this->formatOptions(),
            ]
        ));
    }

    public function configSave(): Response
    {
        if (!Request::isPost()) {
            return app(WeappSupportGateway::class)->apiMethodNotAllowed();
        }
        if (!$this->entitled()) {
            return app(WeappSupportGateway::class)->apiFromServiceResult(app(WeappSupportGateway::class)->resultForbidden('插件未授权'));
        }
        $result = ThumbnailConfigService::saveAdmin(Request::post());
        ThumbnailService::ensureAutoload();

        return app(WeappSupportGateway::class)->apiFromServiceResult($result);
    }

    public function clearCache(): Response
    {
        if (!Request::isPost()) {
            return app(WeappSupportGateway::class)->apiMethodNotAllowed();
        }
        if (!$this->entitled()) {
            return app(WeappSupportGateway::class)->apiFromServiceResult(app(WeappSupportGateway::class)->resultForbidden('插件未授权'));
        }
        ThumbnailService::ensureAutoload();
        $navId = max(0, (int) Request::post('nav_id', 0));
        ThumbnailService::clearCache($navId > 0 ? $navId : null);

        $msg = $navId > 0 ? '已清除该栏目下文档的缩略图缓存' : '缓存已清除';

        return app(WeappSupportGateway::class)->apiFromServiceResult(app(WeappSupportGateway::class)->resultOk(null, $msg));
    }

    public function batchGenerate(): Response
    {
        if (!Request::isPost()) {
            return app(WeappSupportGateway::class)->apiMethodNotAllowed();
        }
        if (!$this->entitled()) {
            return app(WeappSupportGateway::class)->apiFromServiceResult(app(WeappSupportGateway::class)->resultForbidden('插件未授权'));
        }
        ThumbnailService::ensureAutoload();

        return app(WeappSupportGateway::class)->apiFromServiceResult(ThumbnailService::batchGenerate(
            max(1, (int) Request::post('page', 1)),
            max(0, (int) Request::post('nav_id', 0))
        ));
    }

    public function preview(): Response
    {
        if (!$this->entitled()) {
            return app(WeappSupportGateway::class)->apiFromServiceResult(app(WeappSupportGateway::class)->resultForbidden('插件未授权'));
        }
        ThumbnailService::ensureAutoload();
        $text = trim((string) Request::get('text', '预览标题'));
        $w = max(40, (int) Request::get('w', ThumbnailConfigService::runtimeConfig()['width']));
        $h = max(40, (int) Request::get('h', ThumbnailConfigService::runtimeConfig()['height']));
        $cfg = ThumbnailConfigService::runtimeConfig();
        $svg = ThumbnailService::buildSvg(
            $text !== '' ? $text : '预览标题',
            $w,
            $h,
            (string) Request::get('template', $cfg['template']),
            (int) Request::get('random', $cfg['random']),
            'preview',
            (string) Request::get('watermark', $cfg['watermark']),
            (string) Request::get('watermark_pos', $cfg['watermark_pos'])
        );

        return response($svg, 200, ['Content-Type' => 'image/svg+xml; charset=utf-8']);
    }

    /** @return list<array{value:string,label:string}> */
    private function templateOptions(): array
    {
        return [
            ['value' => ThumbnailConfigService::TEMPLATE_VIBRANT, 'label' => '炫酷'],
            ['value' => ThumbnailConfigService::TEMPLATE_GRADIENT, 'label' => '渐变'],
            ['value' => ThumbnailConfigService::TEMPLATE_MINIMAL, 'label' => '简约'],
            ['value' => ThumbnailConfigService::TEMPLATE_GEOMETRIC, 'label' => '几何'],
            ['value' => ThumbnailConfigService::TEMPLATE_GLASS, 'label' => '毛玻璃'],
        ];
    }

    /** @return list<array{value:string,label:string}> */
    private function formatOptions(): array
    {
        return [
            ['value' => ThumbnailConfigService::FORMAT_SVG, 'label' => 'SVG（推荐）'],
            ['value' => ThumbnailConfigService::FORMAT_JPEG, 'label' => 'JPEG'],
            ['value' => ThumbnailConfigService::FORMAT_WEBP, 'label' => 'WebP'],
        ];
    }
}
