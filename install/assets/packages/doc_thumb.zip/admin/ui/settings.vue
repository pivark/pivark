<script lang="ts" setup>
import { computed, onMounted, reactive, ref } from 'vue';

import { ElMessage } from 'element-plus';

import WeappPluginKpiRow from '#/components/pivark/weapp/WeappPluginKpiRow.vue';
import WeappPluginPageCard from '#/components/pivark/weapp/WeappPluginPageCard.vue';
import WeappPluginShell from '#/components/pivark/weapp/WeappPluginShell.vue';
import PvModuleSection from '#/components/pivark/shell/PvModuleSection.vue';
import {
  fetchSpaWeappPluginMetaApi,
  type ThumbNavSizeRow,
} from '#/api/pivark/core/spa';
import type { ThumbMeta } from '#/api/pivark/core/spa-meta-types';
import { useWeappPluginId } from '#/composables/use-weapp-plugin-settings';
import { pivarkMutation } from '#/api/pivark/core/mutation';

defineOptions({ name: 'WeappThumbSettings' });

const pluginId = useWeappPluginId();
const loading = ref(false);
const saving = ref(false);
const clearing = ref(false);
const warming = ref(false);
const previewText = ref('预览标题');
const previewUrl = ref('');
const warmProgress = ref('');
const warmPercent = ref(0);
const warmError = ref('');

const cfg = reactive({
  thumb_open: '1',
  thumb_width: '400',
  thumb_height: '300',
  thumb_random: '0',
  thumb_responsive: '0',
  thumb_template: 'vibrant',
  thumb_watermark: '',
  thumb_watermark_pos: 'br',
  thumb_format: 'svg',
  thumb_fallback_text: '',
  thumb_placeholder_patterns: '',
  thumb_rebuild_static: '1',
  thumb_broken_fallback: '1',
});

const stats = ref({ documents: 0, cache_files: 0 });
const rebuildDocCount = ref(0);
const templates = ref<Array<{ label: string; value: string }>>([]);
const formats = ref<Array<{ label: string; value: string }>>([]);
const navOptions = ref<Array<{ id: number; label: string; title?: string }>>([]);
const navSizes = ref<ThumbNavSizeRow[]>([]);
const formatCapabilities = ref({
  gd: false,
  imagick: false,
  raster_ready: false,
  webp: false,
});
const defaultPatterns = ref<string[]>([]);

const kpiItems = computed(() => [
  { label: '已发布文档', value: stats.value.documents },
  { label: '缓存文件', value: stats.value.cache_files },
  { label: '待重建静态页', value: rebuildDocCount.value },
]);

const watermarkPositions = [
  { label: '右下', value: 'br' },
  { label: '左下', value: 'bl' },
  { label: '右上', value: 'tr' },
  { label: '左上', value: 'tl' },
  { label: '居中', value: 'c' },
];

const rasterHint = computed(() => {
  if (cfg.thumb_format === 'svg') return '';
  if (formatCapabilities.value.raster_ready) return '';
  return '当前服务器未安装 Imagick 或 GD，保存后将自动回退为 SVG。';
});

function flagOn(
  key:
    | 'thumb_broken_fallback'
    | 'thumb_open'
    | 'thumb_random'
    | 'thumb_rebuild_static'
    | 'thumb_responsive',
) {
  return cfg[key] === '1';
}

function setFlag(
  key:
    | 'thumb_broken_fallback'
    | 'thumb_open'
    | 'thumb_random'
    | 'thumb_rebuild_static'
    | 'thumb_responsive',
  on: boolean,
) {
  cfg[key] = on ? '1' : '0';
}

function addNavSizeRow() {
  const firstNav = navOptions.value[0]?.id ?? 0;
  navSizes.value.push({ nav_id: firstNav, width: 400, height: 300 });
}

function removeNavSizeRow(index: number) {
  navSizes.value.splice(index, 1);
}

async function loadMeta() {
  loading.value = true;
  try {
    const meta = await fetchSpaWeappPluginMetaApi<ThumbMeta>(pluginId.value);
    Object.assign(cfg, meta.cfg ?? {});
    stats.value = {
      documents: meta.stats?.documents ?? 0,
      cache_files: meta.stats?.cache_files ?? 0,
    };
    rebuildDocCount.value = meta.rebuildDocCount ?? 0;
    templates.value = meta.templates ?? [];
    formats.value = meta.formats ?? [];
    navOptions.value = meta.navOptions ?? [];
    navSizes.value = [...(meta.navSizes ?? [])];
    formatCapabilities.value =
      meta.formatCapabilities ?? formatCapabilities.value;
    defaultPatterns.value = meta.defaultPlaceholderPatterns ?? [];
  } finally {
    loading.value = false;
  }
}

async function handleSave() {
  saving.value = true;
  try {
    const res = await pivarkMutation<{ msg?: string }>('/weapp/doc_thumb/configSave', {
      ...cfg,
      nav_sizes: navSizes.value,
    });
    ElMessage.success(String(res?.msg ?? '保存成功'));
    await loadMeta();
  } finally {
    saving.value = false;
  }
}

async function clearCache() {
  clearing.value = true;
  try {
    await pivarkMutation('/weapp/doc_thumb/clearCache', {});
    ElMessage.success('缓存已清除');
    await loadMeta();
  } finally {
    clearing.value = false;
  }
}

function refreshPreview() {
  const q = new URLSearchParams({
    text: previewText.value || '预览标题',
    w: String(cfg.thumb_width || '400'),
    h: String(cfg.thumb_height || '300'),
    template: cfg.thumb_template || 'vibrant',
    random: cfg.thumb_random || '0',
    watermark: cfg.thumb_watermark || '',
    watermark_pos: cfg.thumb_watermark_pos || 'br',
    _: String(Date.now()),
  });
  previewUrl.value = `/admin/weapp/doc_thumb/preview?${q.toString()}`;
}

async function batchWarm() {
  warming.value = true;
  warmProgress.value = '准备中…';
  warmPercent.value = 0;
  warmError.value = '';
  try {
    let requestPage = 1;
    let done = false;
    let generatedTotal = 0;
    let total = 0;
    while (!done && requestPage <= 50) {
      const res = await pivarkMutation<{
        page?: number;
        total?: number;
        generated?: number;
        done?: boolean;
      }>('/weapp/doc_thumb/batchGenerate', { page: requestPage, nav_id: 0 });
      total = Number(res?.total ?? total);
      generatedTotal += Number(res?.generated ?? 0);
      done = Boolean(res?.done);
      const processed = Math.min(requestPage * 100, total || requestPage * 100);
      warmPercent.value =
        total > 0 ? Math.min(100, Math.round((processed / total) * 100)) : done ? 100 : 0;
      warmProgress.value = `已预热生成 ${generatedTotal} 张 · 进度 ${processed}/${total || '…'}（第 ${requestPage} 页）`;
      // API 返回的 page = 下一页
      requestPage = Number(res?.page ?? requestPage + 1);
    }
    if (!done && total > 0) {
      warmError.value = '预热未完全结束（达到页数上限），可再次点击继续。';
      ElMessage.warning(warmError.value);
    } else {
      warmPercent.value = 100;
      ElMessage.success(warmProgress.value || '批量预热完成');
    }
    await loadMeta();
  } catch (e) {
    warmError.value = e instanceof Error ? e.message : '批量预热失败，请稍后重试';
    ElMessage.error(warmError.value);
  } finally {
    warming.value = false;
  }
}

onMounted(async () => {
  await loadMeta();
  refreshPreview();
});
</script>

<template>
  <WeappPluginShell :plugin-id="pluginId" nav-key="settings">
    <WeappPluginPageCard :loading="loading" title="基础设置">
      <template #actions>
        <el-button :loading="warming" @click="batchWarm">批量预热</el-button>
        <el-button :loading="clearing" @click="clearCache">清除缓存</el-button>
        <el-button :loading="saving" type="primary" @click="handleSave">
          保存配置
        </el-button>
      </template>

      <WeappPluginKpiRow :items="kpiItems" />
      <div v-if="warming || warmProgress || warmError" class="mb-4">
        <el-progress
          v-if="warming || warmPercent > 0"
          :percentage="warmPercent"
          :status="warmError ? 'exception' : warmPercent >= 100 ? 'success' : undefined"
        />
        <p v-if="warmProgress" class="pv-weapp-hint mt-2">{{ warmProgress }}</p>
        <el-alert
          v-if="warmError"
          class="mt-2"
          type="error"
          :closable="false"
          show-icon
          :title="warmError"
        />
      </div>

      <PvModuleSection title="实时预览">
        <div class="mb-3 flex flex-wrap items-end gap-3">
          <el-input
            v-model="previewText"
            class="max-w-xs"
            placeholder="预览标题"
            @change="refreshPreview"
          />
          <el-button @click="refreshPreview">刷新预览</el-button>
        </div>
        <img
          v-if="previewUrl"
          :src="previewUrl"
          alt="缩略图预览"
          class="max-w-full rounded border"
          style="max-height: 240px"
        />
      </PvModuleSection>

      <PvModuleSection title="功能开关">
        <el-switch
          :model-value="flagOn('thumb_open')"
          active-text="启用"
          inactive-text="关闭"
          @update:model-value="setFlag('thumb_open', !!$event)"
        />
        <p class="pv-weapp-hint mt-2">
          启用后，无封面或占位封面将按标题自动生成炫彩缩略图，列表与 API 字段自动注入。
        </p>
      </PvModuleSection>

      <PvModuleSection title="默认尺寸与风格">
        <el-form label-position="top">
          <el-form-item label="默认宽度">
            <el-input-number
              :model-value="Number(cfg.thumb_width) || 400"
              :min="40"
              :max="2000"
              @update:model-value="cfg.thumb_width = String($event ?? 400)"
            />
          </el-form-item>
          <el-form-item label="默认高度">
            <el-input-number
              :model-value="Number(cfg.thumb_height) || 300"
              :min="40"
              :max="2000"
              @update:model-value="cfg.thumb_height = String($event ?? 300)"
            />
          </el-form-item>
          <el-form-item label="模板风格">
            <el-select v-model="cfg.thumb_template" class="w-full">
              <el-option
                v-for="opt in templates"
                :key="opt.value"
                :label="opt.label"
                :value="opt.value"
              />
            </el-select>
          </el-form-item>
          <el-form-item label="输出格式">
            <el-select v-model="cfg.thumb_format" class="w-full">
              <el-option
                v-for="opt in formats"
                :key="opt.value"
                :label="opt.label"
                :value="opt.value"
              />
            </el-select>
            <p v-if="rasterHint" class="pv-weapp-hint mt-1">{{ rasterHint }}</p>
          </el-form-item>
          <el-form-item label="随机配色">
            <el-switch
              :model-value="flagOn('thumb_random')"
              @update:model-value="setFlag('thumb_random', !!$event)"
            />
          </el-form-item>
          <el-form-item label="响应式尺寸">
            <el-switch
              :model-value="flagOn('thumb_responsive')"
              @update:model-value="setFlag('thumb_responsive', !!$event)"
            />
            <p class="pv-weapp-hint mt-1">开启后 URL 参数 w/h 优先生效</p>
          </el-form-item>
        </el-form>
      </PvModuleSection>

      <PvModuleSection title="水印与占位规则">
        <el-form label-position="top">
          <el-form-item label="水印文字">
            <el-input
              v-model="cfg.thumb_watermark"
              maxlength="40"
              placeholder="可选，显示在占位图角落"
            />
          </el-form-item>
          <el-form-item label="水印位置">
            <el-select v-model="cfg.thumb_watermark_pos" class="w-full">
              <el-option
                v-for="opt in watermarkPositions"
                :key="opt.value"
                :label="opt.label"
                :value="opt.value"
              />
            </el-select>
          </el-form-item>
          <el-form-item label="占位路径规则">
            <el-input
              v-model="cfg.thumb_placeholder_patterns"
              type="textarea"
              :rows="4"
              placeholder="每行一条 URL 片段，与内置规则合并"
            />
            <p class="pv-weapp-hint mt-1">
              内置示例：{{ defaultPatterns.slice(0, 4).join('、') }}…
            </p>
          </el-form-item>
          <el-form-item label="坏链回退">
            <el-switch
              :model-value="flagOn('thumb_broken_fallback')"
              @update:model-value="setFlag('thumb_broken_fallback', !!$event)"
            />
          </el-form-item>
          <el-form-item label="保存后重建静态">
            <el-switch
              :model-value="flagOn('thumb_rebuild_static')"
              @update:model-value="setFlag('thumb_rebuild_static', !!$event)"
            />
          </el-form-item>
        </el-form>
      </PvModuleSection>

      <PvModuleSection
        v-if="!flagOn('thumb_responsive')"
        title="栏目独立尺寸"
      >
        <p class="pv-weapp-hint mb-3">
          关闭「响应式尺寸」时，可为不同网站栏目指定宽高（如产品 400×400、新闻
          320×240）。按文档主栏目命中。
        </p>
        <el-empty
          v-if="navOptions.length === 0"
          description="请先在「网站栏目」中创建内容栏目"
        />
        <div v-else class="space-y-3">
          <div
            v-for="(row, index) in navSizes"
            :key="index"
            class="flex flex-wrap items-center gap-2"
          >
            <el-select v-model="row.nav_id" style="width: 220px">
              <el-option
                v-for="n in navOptions"
                :key="n.id"
                :label="n.label || n.title"
                :value="n.id"
              />
            </el-select>
            <el-input-number v-model="row.width" :min="40" :max="2000" />
            <span class="text-muted-foreground text-sm">×</span>
            <el-input-number v-model="row.height" :min="40" :max="2000" />
            <el-button link type="danger" @click="removeNavSizeRow(index)">
              删除
            </el-button>
          </div>
          <el-button plain type="primary" @click="addNavSizeRow">
            添加栏目尺寸
          </el-button>
        </div>
      </PvModuleSection>
    </WeappPluginPageCard>
  </WeappPluginShell>
</template>
