<?php
/**
 * 元舟 PivArk — 企业全域原子化数字资产中枢
 * (c) 2024-2026 pivark.com. All rights reserved.
 * Author: Angelo
 * 未经允许，不可用于商业用途。
 */
/**
 * 动态缩略图插件权限（按 code 插入，避免 ID 冲突）
 * 用法: php devtools/daily/database/migrate_doc_thumb_plugin.php
 */
declare(strict_types=1);

require_once dirname(__DIR__, 4) . '/app/database/migrations/_migration_bootstrap.php';

$name = 'migrate_doc_thumb_plugin';

function migration_down(PDO $pdo, string $pfx, string $db): void {
    migration_remove_permission_tree($pdo, $pfx, 'admin.plugin.thumb');
}

migration_entry($name, static function (PDO $pdo, string $pfx, string $db): void {
    $permTable = "{$pfx}permissions";
    $rpTable   = "{$pfx}role_permissions";
    
    $defs = [
        ['动态缩略图', 'admin.plugin.thumb', null, 61],
        ['缩略图设置', 'admin.plugin.thumb.list', 'admin.plugin.thumb', 62],
        ['缩略图管理', 'admin.plugin.thumb.edit', 'admin.plugin.thumb', 63],
    ];
    
    $permIds = [];
    foreach ($defs as [$label, $code, $parentCode, $sort]) {
        $existing = (int) $pdo->query(
            "SELECT `id` FROM `{$permTable}` WHERE `code`=" . $pdo->quote($code) . ' LIMIT 1'
        )->fetchColumn();
        if ($existing > 0) {
            $permIds[] = $existing;
            echo "  exists: {$code}\n";
            continue;
        }
        $parentId = null;
        if ($parentCode !== null) {
            $parentId = (int) $pdo->query(
                "SELECT `id` FROM `{$permTable}` WHERE `code`=" . $pdo->quote($parentCode) . ' LIMIT 1'
            )->fetchColumn();
        }
        $stmt = $pdo->prepare("INSERT INTO `{$permTable}`
            (`name`,`code`,`parent_id`,`module`,`icon`,`sort`,`status`,`created_at`)
            VALUES (?,?,?,'admin',NULL,?,1,NOW())");
        $stmt->execute([$label, $code, $parentId > 0 ? $parentId : null, $sort]);
        $permIds[] = (int) $pdo->lastInsertId();
        echo "  insert: {$code}\n";
    }
    
    foreach ([1, 2] as $roleId) {
        foreach ($permIds as $permId) {
            $pdo->exec("INSERT IGNORE INTO `{$rpTable}` (`role_id`,`permission_id`,`created_at`) VALUES ({$roleId}, {$permId}, NOW())");
        }
    }
});
