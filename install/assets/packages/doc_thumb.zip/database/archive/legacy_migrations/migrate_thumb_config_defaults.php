<?php
/**
 * 元舟 PivArk — 企业全域原子化数字资产中枢
 * (c) 2024-2026 pivark.com. All rights reserved.
 * Author: Angelo
 * 未经允许，不可用于商业用途。
 */
/**
 * thumb 插件 v1.2 默认配置项（占位规则、静态重建、坏链回退）
 * 用法: php devtools/daily/database/migrate_doc_thumb_config_defaults.php
 */
declare(strict_types=1);

require_once dirname(__DIR__, 4) . '/app/database/migrations/_migration_bootstrap.php';

$name = 'migrate_doc_thumb_config_defaults';

function migration_down(PDO $pdo, string $pfx, string $db): void {
    // no-op structural rollback
}

migration_entry($name, static function (PDO $pdo, string $pfx, string $db): void {
    $configs = "{$pfx}configs";
    $rows    = [
        ['thumb', 'thumb_placeholder_patterns', '', 'string'],
        ['thumb', 'thumb_rebuild_static', '1', 'string'],
        ['thumb', 'thumb_broken_fallback', '1', 'string'],
    ];
    
    foreach ($rows as [$group, $key, $value, $type]) {
        $stmt = $pdo->prepare("SELECT `id` FROM `{$configs}` WHERE `key` = ? LIMIT 1");
        $stmt->execute([$key]);
        if ($stmt->fetchColumn()) {
            echo "  exists: {$key}\n";
            continue;
        }
        $pdo->prepare(
            "INSERT INTO `{$configs}` (`group`,`key`,`value`,`type`) VALUES (?,?,?,?)"
        )->execute([$group, $key, $value, $type]);
        echo "  config: {$key}\n";
    }
});
