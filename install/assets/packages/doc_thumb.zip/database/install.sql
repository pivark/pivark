-- 动态缩略图插件不创建业务表，配置存 configs.thumb_*
SELECT 1;