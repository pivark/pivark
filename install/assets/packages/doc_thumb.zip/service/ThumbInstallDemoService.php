<?php
declare(strict_types=1);

namespace weapp\doc_thumb\service;

use app\common\service\weapp\WeappConfigGateway;

/** 缩略图插件：安装向导首次装插件时的默认演示数据（带封面样例文档） */
final class ThumbInstallDemoService
{
    public static function seed(): void
    {
        $cfg = app(WeappConfigGateway::class);
        $cfg->installDemoUpsertDocument(
            'pv-demo-thumb-01',
            '列表示例：带封面缩略图',
            '演示缩略图裁剪插件所需的列表封面字段。',
            '<p>本篇为缩略图插件自带演示文档，封面可用于后台裁剪体验。</p>',
            $cfg->installDemoPreviewImage(),
        );
    }
}
