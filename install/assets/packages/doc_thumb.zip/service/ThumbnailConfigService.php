<?php
/**
 * 元舟 PivArk — 企业全域原子化数字资产中枢
 * (c) 2024-2026 pivark.com. All rights reserved.
 * Author: Angelo
 * 未经允许，不可用于商业用途。
 */
declare(strict_types=1);

namespace weapp\doc_thumb\service;


use app\common\service\weapp\WeappConfigGateway;
use app\common\service\weapp\WeappPluginGateway;
use app\common\service\weapp\WeappSupportGateway;


/** 动态缩略图插件配置（configs.thumb_*） */
class ThumbnailConfigService
{
    public const TEMPLATE_VIBRANT   = 'vibrant';
    public const TEMPLATE_GRADIENT  = 'gradient';
    public const TEMPLATE_MINIMAL   = 'minimal';
    public const TEMPLATE_GEOMETRIC  = 'geometric';
    public const TEMPLATE_GLASS     = 'glass';

    public const FORMAT_SVG  = 'svg';
    public const FORMAT_JPEG = 'jpeg';
    public const FORMAT_WEBP = 'webp';

    /** @return list<string> */
    public static function keys(): array
    {
        return [
            'thumb_open',
            'thumb_width',
            'thumb_height',
            'thumb_random',
            'thumb_responsive',
            'thumb_template',
            'thumb_watermark',
            'thumb_watermark_pos',
            'thumb_format',
            'thumb_fallback_text',
            'thumb_nav_sizes',
            'thumb_placeholder_patterns',
            'thumb_rebuild_static',
            'thumb_broken_fallback',
        ];
    }

    /** @return array<string, string> */
    public static function all(): array
    {
        $out = [];
        foreach (self::keys() as $key) {
            $out[$key] = (string) app(WeappConfigGateway::class)->configGet($key, self::defaultFor($key));
        }

        return $out;
    }

    public static function defaultFor(string $key): string
    {
        return match ($key) {
            'thumb_open'            => '1',
            'thumb_width'           => '400',
            'thumb_height'          => '300',
            'thumb_random'          => '0',
            'thumb_responsive'      => '0',
            'thumb_template'        => self::TEMPLATE_VIBRANT,
            'thumb_watermark'       => '',
            'thumb_watermark_pos'   => 'br',
            'thumb_format'          => self::FORMAT_SVG,
            'thumb_fallback_text'   => '',
            'thumb_nav_sizes'       => '[]',
            'thumb_placeholder_patterns' => '',
            'thumb_rebuild_static'  => '1',
            'thumb_broken_fallback' => '1',
            default                 => '',
        };
    }

    public static function brokenFallbackEnabled(): bool
    {
        return (string) app(WeappConfigGateway::class)->configGet('thumb_broken_fallback', '1') === '1';
    }

    /** @return array{imagick:bool,gd:bool,webp:bool,raster_ready:bool} */
    public static function formatCapabilities(): array
    {
        $imagick = class_exists('Imagick', false);
        $gd      = function_exists('imagecreatetruecolor');
        $webp    = function_exists('imagewebp');

        return [
            'imagick'      => $imagick,
            'gd'           => $gd,
            'webp'         => $webp,
            'raster_ready' => $imagick || $gd,
        ];
    }

    /** @return list<string> */
    public static function defaultPlaceholderPatterns(): array
    {
        return [
            'default_litpic',
            'not_adv',
            'placeholder',
            'no_pic',
            'nopic',
            'preview.svg',
            '/assets/preview.',
            // 插件自产 URL：须再解析为 /static/thumb/doc（勿当「真实封面」短路）
            '/api/v1/plugins/doc_thumb/',
            '/plugins/doc_thumb/',
            '/static/thumb/doc/',
        ];
    }

    /** @return list<string> */
    public static function placeholderPatterns(): array
    {
        $patterns = self::defaultPlaceholderPatterns();
        $raw      = trim((string) app(WeappConfigGateway::class)->configGet('thumb_placeholder_patterns', ''));
        if ($raw === '') {
            return $patterns;
        }
        foreach (preg_split('/\r\n|\r|\n/', $raw) ?: [] as $line) {
            $line = trim((string) $line);
            if ($line !== '') {
                $patterns[] = $line;
            }
        }

        return array_values(array_unique($patterns));
    }

    public static function isPlaceholderLitpic(string $litpic): bool
    {
        $litpic = trim($litpic);
        if ($litpic === '') {
            return true;
        }
        foreach (self::placeholderPatterns() as $pattern) {
            if ($pattern !== '' && stripos($litpic, $pattern) !== false) {
                return true;
            }
        }

        return false;
    }

    public static function isOpen(): bool
    {
        return (string) app(WeappConfigGateway::class)->configGet('thumb_open', '1') === '1';
    }

    /** @return array<string, mixed> */
    public static function runtimeConfig(): array
    {
        $raw = self::all();
        $navSizes = json_decode((string) ($raw['thumb_nav_sizes'] ?? '[]'), true);

        return [
            'width'         => max(40, (int) ($raw['thumb_width'] ?? 400)),
            'height'        => max(40, (int) ($raw['thumb_height'] ?? 300)),
            'random'        => (int) ($raw['thumb_random'] ?? 0),
            'responsive'    => (int) ($raw['thumb_responsive'] ?? 0),
            'template'      => self::normalizeTemplate((string) ($raw['thumb_template'] ?? self::TEMPLATE_VIBRANT)),
            'watermark'     => (string) ($raw['thumb_watermark'] ?? ''),
            'watermark_pos' => self::normalizeWatermarkPos((string) ($raw['thumb_watermark_pos'] ?? 'br')),
            'format'        => self::normalizeFormat((string) ($raw['thumb_format'] ?? self::FORMAT_SVG)),
            'fallback_text' => (string) ($raw['thumb_fallback_text'] ?? ''),
            'nav_sizes'     => is_array($navSizes) ? self::normalizeNavSizes($navSizes) : [],
            'placeholder_patterns' => self::placeholderPatterns(),
            'rebuild_static'=> (int) ($raw['thumb_rebuild_static'] ?? 1),
        ];
    }

    public static function normalizeTemplate(string $template): string
    {
        $allowed = [
            self::TEMPLATE_VIBRANT,
            self::TEMPLATE_GRADIENT,
            self::TEMPLATE_MINIMAL,
            self::TEMPLATE_GEOMETRIC,
            self::TEMPLATE_GLASS,
        ];

        return in_array($template, $allowed, true) ? $template : self::TEMPLATE_VIBRANT;
    }

    public static function normalizeFormat(string $format): string
    {
        return in_array($format, [self::FORMAT_SVG, self::FORMAT_JPEG, self::FORMAT_WEBP], true)
            ? $format
            : self::FORMAT_SVG;
    }

    public static function normalizeWatermarkPos(string $pos): string
    {
        return in_array($pos, ['tl', 'tr', 'bl', 'br', 'center'], true) ? $pos : 'br';
    }

    /**
     * @param list<array<string, mixed>> $rows
     * @return list<array{nav_id:int,w:int,h:int}>
     */
    public static function normalizeNavSizes(array $rows): array
    {
        $out = [];
        foreach ($rows as $row) {
            $navId = (int) ($row['nav_id'] ?? 0);
            if ($navId < 1) {
                continue;
            }
            $w = (int) ($row['w'] ?? $row['width'] ?? 400);
            $h = (int) ($row['h'] ?? $row['height'] ?? 300);
            $out[] = [
                'nav_id' => $navId,
                'w'      => max(40, $w),
                'h'      => max(40, $h),
            ];
        }

        return $out;
    }

    /**
     * 后台 SPA：width/height 字段名对齐 Vue。
     *
     * @param list<array<string, mixed>> $rows
     * @return list<array{nav_id:int,width:int,height:int}>
     */
    public static function navSizesForAdmin(array $rows): array
    {
        $out = [];
        foreach (self::normalizeNavSizes($rows) as $row) {
            $out[] = [
                'nav_id' => $row['nav_id'],
                'width'  => $row['w'],
                'height' => $row['h'],
            ];
        }

        return $out;
    }

    /**
     * @param array<string, mixed> $data
     * @return mixed
     */
    public static function saveAdmin(array $data)
    {
        $navSizesRaw = $data['nav_sizes'] ?? $data['thumb_nav_sizes'] ?? '[]';
        if (is_array($navSizesRaw)) {
            $navSizes = self::normalizeNavSizes($navSizesRaw);
        } else {
            $decoded = json_decode((string) $navSizesRaw, true);
            $navSizes = is_array($decoded) ? self::normalizeNavSizes($decoded) : [];
        }

        $payload = [
            'thumb_open'            => !empty($data['thumb_open']) ? '1' : '0',
            'thumb_width'           => (string) max(40, (int) ($data['thumb_width'] ?? 400)),
            'thumb_height'          => (string) max(40, (int) ($data['thumb_height'] ?? 300)),
            'thumb_random'          => !empty($data['thumb_random']) ? '1' : '0',
            'thumb_responsive'      => !empty($data['thumb_responsive']) ? '1' : '0',
            'thumb_template'        => self::normalizeTemplate((string) ($data['thumb_template'] ?? self::TEMPLATE_VIBRANT)),
            'thumb_watermark'       => trim((string) ($data['thumb_watermark'] ?? '')),
            'thumb_watermark_pos'   => self::normalizeWatermarkPos((string) ($data['thumb_watermark_pos'] ?? 'br')),
            'thumb_format'          => self::normalizeFormat((string) ($data['thumb_format'] ?? self::FORMAT_SVG)),
            'thumb_fallback_text'   => trim((string) ($data['thumb_fallback_text'] ?? '')),
            'thumb_nav_sizes'       => json_encode($navSizes, JSON_UNESCAPED_UNICODE),
            'thumb_placeholder_patterns' => trim((string) ($data['thumb_placeholder_patterns'] ?? '')),
            'thumb_rebuild_static'  => !empty($data['thumb_rebuild_static']) ? '1' : '0',
            'thumb_broken_fallback' => !empty($data['thumb_broken_fallback']) ? '1' : '0',
        ];

        foreach ($payload as $key => $value) {
            app(WeappConfigGateway::class)->configSet($key, $value);
        }
        // 禁兼容：退役旧 Tag 尺寸键（真删行，不留空值壳）
        app(WeappConfigGateway::class)->configDeleteKeys(['thumb_tag_sizes']);
        app(WeappConfigGateway::class)->configRefreshAllCacheFromDatabase();
        ThumbnailService::ensureAutoload();
        ThumbnailService::clearCache();
        $static = \weapp\doc_thumb\service\ThumbnailStaticService::afterConfigSave();
        app(WeappPluginGateway::class)->pluginAfterConfigSaved(
            'all'
        );

        $msg = '配置已保存';
        if (($static['msg'] ?? '') !== '') {
            $msg .= '；' . (string) $static['msg'];
        }

        return app(WeappSupportGateway::class)->resultOk(['static' => $static], $msg);
    }
}
