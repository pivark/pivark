<?php
declare(strict_types=1);

namespace weapp\doc_thumb\service;


use app\common\service\weapp\WeappConfigGateway;
use app\common\service\weapp\WeappDocumentGateway;
use app\common\service\weapp\WeappEntitlementGateway;
use app\common\service\weapp\WeappPluginGateway;
use app\common\service\weapp\WeappSupportGateway;
use weapp\doc_thumb\service\ThumbnailConfigService;
use think\facade\Cache;

/** 动态缩略图：无图时按标题/seed 生成 SVG/JPEG/WebP */
class ThumbnailService
{
    public static function ensureAutoload(): void
    {
        app(WeappPluginGateway::class)->pluginRegisterAutoloadPublic('doc_thumb');
    }

    public static function isActive(): bool
    {
        return app(WeappEntitlementGateway::class)->entitlementCan('doc_thumb') && ThumbnailConfigService::isOpen();
    }

    /**
     * @param array<string, mixed> $attrs
     * @param array<string, mixed> $pageVars
     */
    public static function renderTag(array $attrs, array $pageVars, string $tpl): string
    {
        $url = self::resolveUrlFromAttrs($attrs, $pageVars);
        $inner = trim($tpl);
        if ($inner === '') {
            return htmlspecialchars($url, ENT_QUOTES, 'UTF-8');
        }
        $chunk = $inner;
        foreach (['url', 'src'] as $key) {
            $chunk = str_replace('{$field.' . $key . '}', $url, $chunk);
        }

        return $chunk;
    }

    /**
     * @param array<string, mixed> $row 文档行（id/title/litpic/nav_id 可选）
     */
    public static function resolveForDocument(array $row, int $w = 0, int $h = 0): string
    {
        if (!self::isActive()) {
            return self::normalizeLitpic((string) ($row['litpic'] ?? ''));
        }

        return self::resolveUrl(
            (int) ($row['id'] ?? 0),
            (string) ($row['litpic'] ?? ''),
            (string) ($row['title'] ?? ''),
            (int) ($row['nav_id'] ?? 0),
            $w,
            $h
        );
    }

    public static function resolveUrl(
        int $documentId,
        string $litpic,
        string $title = '',
        int $navId = 0,
        int $w = 0,
        int $h = 0
    ): string {
        $litpic = self::normalizeLitpic($litpic);
        if ($litpic !== '' && !self::isPlaceholderLitpic($litpic)) {
            return $litpic;
        }

        if (!self::isActive()) {
            return $litpic !== '' ? $litpic : self::fallbackAssetUrl();
        }

        $seed = $documentId > 0 ? (string) $documentId : md5($title !== '' ? $title : 'pivark');
        $cfg  = ThumbnailConfigService::runtimeConfig();
        if ($w < 1) {
            $w = (int) $cfg['width'];
        }
        if ($h < 1) {
            $h = (int) $cfg['height'];
        }
        [$w, $h] = self::applyNavSizeOverride($cfg, $documentId, $navId, $w, $h);

        return self::buildPublicUrl($seed, $w, $h);
    }

    /**
     * 始终生成占位图 URL（用于坏链 onerror 回退，忽略真实 litpic）
     *
     * @param array<string, mixed> $row
     */
    public static function buildPlaceholderUrlForDocument(array $row, int $w = 0, int $h = 0): string
    {
        if (!self::isActive()) {
            return '';
        }

        $documentId = (int) ($row['id'] ?? 0);
        $title      = (string) ($row['title'] ?? '');
        $navId      = (int) ($row['nav_id'] ?? 0);
        $seed       = $documentId > 0 ? (string) $documentId : md5($title !== '' ? $title : 'pivark');
        $cfg        = ThumbnailConfigService::runtimeConfig();
        if ($w < 1) {
            $w = (int) $cfg['width'];
        }
        if ($h < 1) {
            $h = (int) $cfg['height'];
        }
        [$w, $h] = self::applyNavSizeOverride($cfg, $documentId, $navId, $w, $h);

        return self::buildPublicUrl($seed, $w, $h);
    }

    public static function buildPublicUrl(string $seed, int $w = 0, int $h = 0): string
    {
        $seed = preg_replace('/[^a-zA-Z0-9_-]/', '', $seed) ?: '0';
        $cfg  = ThumbnailConfigService::runtimeConfig();
        if ($w < 1) {
            $w = (int) $cfg['width'];
        }
        if ($h < 1) {
            $h = (int) $cfg['height'];
        }
        $format = ThumbnailConfigService::normalizeFormat((string) $cfg['format']);
        $ext    = $format === ThumbnailConfigService::FORMAT_SVG ? 'svg' : $format;
        $random = (int) ($cfg['random'] ?? 0) === 1;

        // 非随机：优先 /static/thumb/doc（IIS/Nginx 直出，避免每次 PHP 启动 ~1s）
        if (!$random) {
            $static = self::ensurePublicStaticUrl($seed, $w, $h, $format, (string) $cfg['template'], (string) $cfg['watermark'], (string) $cfg['watermark_pos']);
            if ($static !== '') {
                return $static;
            }
        }

        $query = http_build_query(array_filter([
            'w' => $w,
            'h' => $h,
        ]));

        return '/api/v1/plugins/doc_thumb/' . rawurlencode($seed) . '.' . $ext . ($query !== '' ? '?' . $query : '');
    }

    /**
     * 若 public 静态文件已存在则返回 URL（不触发生成）；供 API 302。
     */
    public static function publicStaticUrlIfExists(string $seed, int $w, int $h, string $format, string $template, string $watermark, string $watermarkPos): string
    {
        $seed = self::normalizeSeed($seed);
        if ($seed === '' || (int) (ThumbnailConfigService::runtimeConfig()['random'] ?? 0) === 1) {
            return '';
        }
        $path = self::publicStaticFilePath($seed, $w, $h, $format, $template, $watermark, $watermarkPos);
        if (!is_file($path)) {
            return '';
        }

        return self::publicStaticWebPath($seed, $w, $h, $format, $template, $watermark, $watermarkPos);
    }

    /**
     * @return array{body:string,content_type:string,cacheable:bool,etag:string}
     */
    public static function renderImageResponse(string $seed, array $query): array
    {
        $seed = self::normalizeSeed($seed);
        $cfg  = ThumbnailConfigService::runtimeConfig();
        $random = (int) ($cfg['random'] ?? 0) === 1;

        $text  = trim((string) ($query['text'] ?? ''));
        $navId = (int) ($query['nav_id'] ?? 0);
        if ($text === '' && ctype_digit($seed)) {
            $doc = self::documentMeta((int) $seed);
            if ($doc !== null) {
                $text  = (string) ($doc['title'] ?? '');
                $navId = $navId > 0 ? $navId : (int) ($doc['nav_id'] ?? 0);
                $litpic = (string) ($doc['litpic'] ?? '');
                if ($litpic !== '' && !self::isPlaceholderLitpic($litpic)) {
                    return [
                        'body'         => '',
                        'content_type' => 'redirect',
                        'cacheable'    => true,
                        'etag'         => '',
                        'redirect'     => $litpic,
                    ];
                }
            }
        }
        if ($text === '') {
            $text = (string) ($cfg['fallback_text'] ?? '');
        }
        if ($text === '') {
            $text = (string) (app(WeappConfigGateway::class)->configGet('site_name', 'PivArk') ?: 'PivArk');
        }

        $w = max(40, (int) ($query['w'] ?? 0));
        $h = max(40, (int) ($query['h'] ?? 0));
        if ($w < 1) {
            $w = (int) $cfg['width'];
        }
        if ($h < 1) {
            $h = (int) $cfg['height'];
        }

        [$w, $h] = self::applyNavSizeOverride($cfg, ctype_digit($seed) ? (int) $seed : 0, $navId, $w, $h);

        $format = ThumbnailConfigService::normalizeFormat((string) ($query['format'] ?? $cfg['format']));
        $tpl = ThumbnailConfigService::normalizeTemplate((string) ($query['template'] ?? $cfg['template']));
        $wm  = (string) ($query['wm'] ?? $cfg['watermark']);
        $wmPos = ThumbnailConfigService::normalizeWatermarkPos((string) ($query['wm_pos'] ?? $cfg['watermark_pos']));

        $cacheFile = '';
        if (!$random && $seed !== '') {
            $cacheFile = self::cacheFilePath($seed, $w, $h, $format, $tpl, $wm, $wmPos);
            if (is_file($cacheFile)) {
                $body = (string) file_get_contents($cacheFile);
                $staticUrl = self::writePublicStatic($seed, $w, $h, $format, $tpl, $wm, $wmPos, $body);

                return [
                    'body'         => $body,
                    'content_type' => self::contentTypeForFormat($format),
                    'cacheable'    => true,
                    'etag'         => md5($seed . $w . $h . $format . $tpl),
                    'static_url'   => $staticUrl,
                ];
            }
        }

        $svg = self::buildSvg($text, $w, $h, $tpl, $random ? 1 : 0, $seed, $wm, $wmPos);
        $converted = self::convertFormat($svg, $format);
        $body = (string) ($converted['data'] ?? $svg);
        $contentType = self::mapConvertedType((string) ($converted['type'] ?? 'svg+xml'));

        $staticUrl = '';
        if ($cacheFile !== '' && !$random) {
            self::ensureCacheDir();
            file_put_contents($cacheFile, $body);
            $staticUrl = self::writePublicStatic($seed, $w, $h, $format, $tpl, $wm, $wmPos, $body);
        }

        return [
            'body'         => $body,
            'content_type' => $contentType,
            'cacheable'    => !$random,
            'etag'         => md5($seed . $w . $h . $format . $tpl . $text),
            'static_url'   => $staticUrl,
        ];
    }

    public static function clearCache(?int $navId = null): void
    {
        if (!app(WeappEntitlementGateway::class)->entitlementCan('doc_thumb')) {
            return;
        }
        Cache::delete('thumb_config');
        if ($navId !== null && $navId > 0) {
            $docIds = app(WeappDocumentGateway::class)->documentIdsByNavIds([$navId]);
            foreach ($docIds as $docId) {
                self::clearCacheForDocument((int) $docId);
            }

            return;
        }

        $dir = self::cacheDir();
        if (is_dir($dir)) {
            foreach (scandir($dir) ?: [] as $name) {
                if ($name === '.' || $name === '..') {
                    continue;
                }
                $path = $dir . $name;
                if (is_file($path)) {
                    app(WeappSupportGateway::class)->localFileUnlinkIfExists($path);
                }
            }
        }
        self::clearPublicStaticDir();
    }

    public static function clearCacheForDocument(int $documentId): void
    {
        if ($documentId < 1) {
            return;
        }
        self::ensureCacheDir();
        $cfg    = ThumbnailConfigService::runtimeConfig();
        $seed   = (string) $documentId;
        $sizes  = [[(int) $cfg['width'], (int) $cfg['height']]];
        foreach ($cfg['nav_sizes'] as $item) {
            $sizes[] = [(int) ($item['w'] ?? $cfg['width']), (int) ($item['h'] ?? $cfg['height'])];
        }
        $format = ThumbnailConfigService::normalizeFormat((string) $cfg['format']);
        $tpl    = (string) $cfg['template'];
        $wm     = (string) $cfg['watermark'];
        $wmPos  = (string) $cfg['watermark_pos'];
        $seen   = [];
        foreach ($sizes as [$w, $h]) {
            $key = $w . 'x' . $h;
            if (isset($seen[$key])) {
                continue;
            }
            $seen[$key] = true;
            $path = self::cacheFilePath($seed, $w, $h, $format, $tpl, $wm, $wmPos);
            if (is_file($path)) {
                app(WeappSupportGateway::class)->localFileUnlinkIfExists($path);
            }
            $pub = self::publicStaticFilePath($seed, $w, $h, $format, $tpl, $wm, $wmPos);
            if (is_file($pub)) {
                app(WeappSupportGateway::class)->localFileUnlinkIfExists($pub);
            }
        }
        // 同 seed 其它指纹（历史尺寸/配置）一并清掉
        self::clearPublicStaticForSeed($seed);
    }

    /**
     * @return mixed
     */
    public static function batchGenerate(int $page = 1, int $navId = 0)
    {
        if (!self::isActive()) {
            return app(WeappSupportGateway::class)->resultFail('plugin_disabled');
        }

        $pageSize = 100;
        $page     = max(1, $page);
        $batch    = app(WeappDocumentGateway::class)->documentPublishedRowsPage($page, $pageSize, $navId, 'id,title,litpic');
        if ($navId > 0 && $batch['total'] === 0) {
            return app(WeappSupportGateway::class)->resultOk(['page' => $page, 'total' => 0, 'generated' => 0, 'done' => true], 'ok');
        }

        $total = (int) Cache::get('thumb_batch_total');
        if ($page === 1 || $total < 1) {
            $total = (int) $batch['total'];
            Cache::set('thumb_batch_total', $total, 3600);
        }

        $rows = $batch['rows'];

        $cfg = ThumbnailConfigService::runtimeConfig();
        $generated = 0;
        self::ensureCacheDir();

        foreach ($rows as $row) {
            $litpic = (string) ($row['litpic'] ?? '');
            if ($litpic !== '' && !self::isPlaceholderLitpic($litpic)) {
                continue;
            }
            $seed = (string) (int) ($row['id'] ?? 0);
            $w = (int) $cfg['width'];
            $h = (int) $cfg['height'];
            $format = ThumbnailConfigService::normalizeFormat((string) $cfg['format']);
            $cacheFile = self::cacheFilePath(
                $seed,
                $w,
                $h,
                $format,
                (string) $cfg['template'],
                (string) $cfg['watermark'],
                (string) $cfg['watermark_pos']
            );
            $tpl   = (string) $cfg['template'];
            $wm    = (string) $cfg['watermark'];
            $wmPos = (string) $cfg['watermark_pos'];
            if (is_file($cacheFile)) {
                self::writePublicStatic($seed, $w, $h, $format, $tpl, $wm, $wmPos, (string) file_get_contents($cacheFile));
                continue;
            }
            $svg = self::buildSvg(
                (string) ($row['title'] ?? ''),
                $w,
                $h,
                $tpl,
                0,
                $seed,
                $wm,
                $wmPos
            );
            $converted = self::convertFormat($svg, $format);
            $body = (string) ($converted['data'] ?? $svg);
            file_put_contents($cacheFile, $body);
            self::writePublicStatic($seed, $w, $h, $format, $tpl, $wm, $wmPos, $body);
            $generated++;
        }

        $processed = $page * $pageSize;

        return app(WeappSupportGateway::class)->resultOk([
                'page'      => $page + 1,
                'total'     => $total,
                'generated' => $generated,
                'done'      => $processed >= $total,
            ], 'ok');
    }

    /** @return array<string, int> */
    public static function statsAdmin(): array
    {
        $dir = self::cacheDir();
        $count = 0;
        if (is_dir($dir)) {
            foreach (scandir($dir) ?: [] as $name) {
                if ($name !== '.' && $name !== '..' && is_file($dir . $name)) {
                    $count++;
                }
            }
        }

        return [
            'documents'   => app(WeappDocumentGateway::class)->documentCountPublished(),
            'cache_files' => $count,
        ];
    }

    public static function buildSvg(
        string $text,
        int $w,
        int $h,
        string $template,
        int $random,
        string $seed,
        string $watermark = '',
        string $watermarkPos = 'br'
    ): string {
        if ($random !== 1) {
            mt_srand(crc32($seed !== '' ? $seed : $text));
        }
        $themeIdx = mt_rand(0, 5);

        $themes = [
            [330, 20,  60, 75, 55, 70],
            [20,  50,  55, 75, 45, 65],
            [140, 180, 55, 70, 45, 60],
            [190, 230, 55, 75, 40, 60],
            [250, 290, 55, 70, 45, 60],
            [0,   360, 55, 80, 45, 65],
        ];

        $t = $themes[$themeIdx];
        $hue = $t[0] <= $t[1]
            ? mt_rand($t[0], $t[1])
            : (mt_rand(0, $t[1] + 360 - $t[0]) + $t[0]) % 360;
        $sat = mt_rand(min($t[2], $t[3]), max($t[2], $t[3]));
        $light = mt_rand(min($t[4], $t[5]), max($t[4], $t[5]));
        $mainColor = "hsl({$hue},{$sat}%,{$light}%)";
        $hue2 = ($hue + mt_rand(25, 50)) % 360;
        $sat2 = min(95, $sat + mt_rand(5, 20));
        $light2 = min(80, $light + mt_rand(8, 18));
        $secondColor = "hsl({$hue2},{$sat2}%,{$light2}%)";
        $hue3 = ($hue - mt_rand(20, 40) + 360) % 360;
        $sat3 = min(80, $sat + mt_rand(0, 10));
        $light3 = min(85, $light + mt_rand(15, 25));
        $thirdColor = "hsl({$hue3},{$sat3}%,{$light3}%)";
        $textColor = $light > 55 ? '#1a1a2e' : '#ffffff';

        $bgStart = $mainColor;
        $bgEnd = $template === 'minimal' ? $mainColor : $secondColor;

        if (preg_match('/hsl\([^,]+,[^,]+%,(\d+)%\)/', $bgStart, $m)) {
            $bgLight = (int) $m[1];
            $textColor = $bgLight > 50 ? '#1a1a2e' : '#ffffff';
            if (preg_match('/hsl\([^,]+,[^,]+%,(\d+)%\)/', $bgEnd, $m2)) {
                $avgLight = ($bgLight + (int) $m2[1]) / 2;
                $textColor = $avgLight > 50 ? '#1a1a2e' : '#ffffff';
            }
        }

        $maxLen = $w < 300 ? 10 : ($w < 500 ? 18 : 28);
        $displayText = mb_strlen($text, 'UTF-8') > $maxLen
            ? mb_substr($text, 0, $maxLen, 'UTF-8') . '…'
            : $text;
        $safeText = htmlspecialchars($displayText, ENT_QUOTES, 'UTF-8');
        $fontSize = max(min((int) floor($w / 16), 26), 13);

        if ($random !== 1) {
            mt_srand(crc32($seed !== '' ? $seed : $text));
        }
        $decorations = self::buildDecorations($template, $w, $h, $mainColor, $secondColor, $thirdColor);

        $wm = '';
        if ($watermark !== '') {
            $safeWm = htmlspecialchars($watermark, ENT_QUOTES, 'UTF-8');
            $wmFontSize = max((int) floor($w / 28), 10);
            $wmOpacity = '0.25';
            switch ($watermarkPos) {
                case 'tl': $wmx = '10'; $wmy = (string) ($wmFontSize + 5); $wmanchor = 'start'; break;
                case 'tr': $wmx = (string) ($w - 5); $wmy = (string) ($wmFontSize + 5); $wmanchor = 'end'; break;
                case 'bl': $wmx = '10'; $wmy = (string) ($h - 8); $wmanchor = 'start'; break;
                case 'center': $wmx = '50%'; $wmy = '50%'; $wmanchor = 'middle'; break;
                default: $wmx = (string) ($w - 5); $wmy = (string) ($h - 8); $wmanchor = 'end'; break;
            }
            $wm = "<text x='{$wmx}' y='{$wmy}' text-anchor='{$wmanchor}' fill='#ffffff' opacity='{$wmOpacity}' font-size='{$wmFontSize}px' font-family='system-ui,sans-serif' font-weight='600'>{$safeWm}</text>";
        }

        return <<<SVG
<svg xmlns="http://www.w3.org/2000/svg" width="{$w}" height="{$h}" viewBox="0 0 {$w} {$h}"><defs><linearGradient id="bg" x1="0%" y1="0%" x2="100%" y2="100%"><stop offset="0%" stop-color="{$bgStart}"/><stop offset="100%" stop-color="{$bgEnd}"/></linearGradient></defs><rect width="{$w}" height="{$h}" fill="url(#bg)" rx="8"/>{$decorations}<text x="50%" y="48%" text-anchor="middle" dominant-baseline="central" fill="{$textColor}" font-size="{$fontSize}px" font-family="system-ui,'PingFang SC','Microsoft YaHei',sans-serif" font-weight="700" letter-spacing="1" style="text-shadow:0 2px 4px rgba(0,0,0,0.08)">{$safeText}</text>{$wm}</svg>
SVG;
    }

    /** @return array{data:string,type:string} */
    public static function convertFormat(string $svg, string $format, int $quality = 80): array
    {
        $format = ThumbnailConfigService::normalizeFormat($format);
        if ($format === ThumbnailConfigService::FORMAT_SVG) {
            return ['data' => $svg, 'type' => 'svg+xml'];
        }

        $fmt = $format === ThumbnailConfigService::FORMAT_WEBP ? 'webp' : 'jpeg';

        if (class_exists('Imagick')) {
            try {
                $img = new \Imagick();
                $img->setBackgroundColor(new \ImagickPixel('white'));
                $img->readImageBlob($svg);
                $img->setImageFormat($fmt);
                $img->setImageCompressionQuality($quality);
                if ($fmt === 'jpeg') {
                    $img->setImageAlphaChannel(\Imagick::ALPHACHANNEL_REMOVE);
                }
                $data = $img->getImageBlob();
                $img->clear();

                return ['data' => $data, 'type' => $fmt === 'webp' ? 'webp' : 'jpeg'];
            } catch (\Throwable $e) {
                app(WeappSupportGateway::class)->kernelOpsLog('thumb_render_fallback', ['msg' => $e->getMessage()]);
            }
        }

        if (function_exists('imagecreatetruecolor') && ($fmt === 'jpeg' || ($fmt === 'webp' && function_exists('imagewebp')))) {
            $converted = self::convertFormatWithGd($svg, $fmt, $quality);
            if ($converted !== null) {
                return $converted;
            }
        }

        return ['data' => $svg, 'type' => 'svg+xml'];
    }

    /**
     * @param array<string, mixed> $attrs
     * @param array<string, mixed> $pageVars
     */
    private static function resolveUrlFromAttrs(array $attrs, array $pageVars): string
    {
        $documentId = self::resolveIntAttr($attrs, $pageVars, ['id', 'aid', 'document_id']);
        $litpic     = self::resolveStringAttr($attrs, $pageVars, ['litpic', 'thumb', 'image']);
        $title      = self::resolveStringAttr($attrs, $pageVars, ['title', 'text', 'name']);
        $navId      = self::resolveIntAttr($attrs, $pageVars, ['nav_id']);
        $w          = self::resolveIntAttr($attrs, $pageVars, ['w', 'width']);
        $h          = self::resolveIntAttr($attrs, $pageVars, ['h', 'height']);
        $seed       = self::resolveStringAttr($attrs, $pageVars, ['seed']);
        if ($documentId < 1 && $seed !== '' && ctype_digit($seed)) {
            $documentId = (int) $seed;
        }
        if ($documentId > 0) {
            $doc = self::documentMeta($documentId);
            if ($doc !== null) {
                if ($title === '') {
                    $title = (string) ($doc['title'] ?? '');
                }
                if ($litpic === '') {
                    $litpic = (string) ($doc['litpic'] ?? '');
                }
                if ($navId < 1) {
                    $navId = (int) ($doc['nav_id'] ?? 0);
                }
            }
        }

        if ($documentId > 0) {
            return self::resolveUrl($documentId, $litpic, $title, $navId, $w, $h);
        }

        if (!self::isActive()) {
            return $litpic !== '' ? self::normalizeLitpic($litpic) : self::fallbackAssetUrl();
        }

        $seedKey = $seed !== '' ? $seed : ($title !== '' ? md5($title) : '0');
        $cfg = ThumbnailConfigService::runtimeConfig();
        if ($w < 1) {
            $w = (int) $cfg['width'];
        }
        if ($h < 1) {
            $h = (int) $cfg['height'];
        }

        return self::buildPublicUrl($seedKey, $w, $h);
    }

    private static function buildDecorations(
        string $template,
        int $w,
        int $h,
        string $mainColor,
        string $secondColor,
        string $thirdColor
    ): string {
        $decorations = '';
        switch ($template) {
            case ThumbnailConfigService::TEMPLATE_MINIMAL:
                break;
            case ThumbnailConfigService::TEMPLATE_GEOMETRIC:
                $cx = mt_rand(15, 85) * $w / 100;
                $cy = mt_rand(15, 85) * $h / 100;
                $size = mt_rand(20, 45) * min($w, $h) / 100;
                $decorations .= "<rect x='{$cx}' y='{$cy}' width='{$size}' height='{$size}' fill='{$thirdColor}' opacity='0.12' rx='" . ($size / 5) . "' transform='rotate(" . mt_rand(0, 45) . ",{$cx},{$cy})' />\n    ";
                $decorations .= "<polygon points='" . mt_rand(10, 90) * $w / 100 . ',' . mt_rand(10, 90) * $h / 100 . ' ' . mt_rand(10, 90) * $w / 100 . ',' . mt_rand(10, 90) * $h / 100 . ' ' . mt_rand(10, 90) * $w / 100 . ',' . mt_rand(10, 90) * $h / 100 . "' fill='{$secondColor}' opacity='0.08' />\n    ";
                break;
            case ThumbnailConfigService::TEMPLATE_GLASS:
                $decorations .= "<rect x='" . mt_rand(5, 15) * $w / 100 . "' y='" . mt_rand(5, 15) * $h / 100 . "' width='" . mt_rand(70, 90) * $w / 100 . "' height='" . mt_rand(30, 50) * $h / 100 . "' fill='rgba(255,255,255,0.06)' rx='12' />\n    ";
                $decorations .= "<rect x='" . mt_rand(30, 60) * $w / 100 . "' y='" . mt_rand(60, 80) * $h / 100 . "' width='" . mt_rand(25, 40) * $w / 100 . "' height='" . mt_rand(8, 15) * $h / 100 . "' fill='rgba(255,255,255,0.04)' rx='6' />\n    ";
                break;
            case ThumbnailConfigService::TEMPLATE_VIBRANT:
            default:
                $decorations .= "<rect x='" . mt_rand(5, 15) * $w / 100 . "' y='" . mt_rand(5, 15) * $h / 100 . "' width='" . mt_rand(70, 90) * $w / 100 . "' height='" . mt_rand(30, 50) * $h / 100 . "' fill='rgba(255,255,255,0.06)' rx='12' />\n    ";
                $cx = mt_rand(15, 85) * $w / 100;
                $cy = mt_rand(15, 85) * $h / 100;
                $rr = mt_rand(25, 50) * min($w, $h) / 100;
                $decorations .= "<circle cx='{$cx}' cy='{$cy}' r='{$rr}' fill='{$thirdColor}' opacity='0.15' />\n    ";
                $waveH = mt_rand(8, 18) * $h / 100;
                $decorations .= "<rect x='0' y='" . ($h - $waveH) . "' width='{$w}' height='{$waveH}' fill='{$secondColor}' opacity='0.1' rx='4' />\n    ";
                $arcR = mt_rand(20, 40) * min($w, $h) / 100;
                $decorations .= "<circle cx='{$w}' cy='0' r='{$arcR}' fill='{$thirdColor}' opacity='0.08' />\n    ";
                break;
        }

        return $decorations;
    }

    /** @return array{data:string,type:string}|null */
    private static function convertFormatWithGd(string $svg, string $fmt, int $quality): ?array
    {
        try {
            $text = '';
            $bgColor = '#667eea';
            if (preg_match('/stop-color="([^"]+)"/', $svg, $m)) {
                $bgColor = $m[1];
            }
            if (preg_match('/<text[^>]*>([^<]+)<\/text>/', $svg, $m)) {
                $text = strip_tags($m[1]);
            }
            if (preg_match('/width="(\d+)"/', $svg, $mw) && preg_match('/height="(\d+)"/', $svg, $mh)) {
                $w = (int) $mw[1];
                $h = (int) $mh[1];
            } else {
                $w = 400;
                $h = 300;
            }

            [$r, $g, $b] = self::colorToRgb($bgColor);
            $img = imagecreatetruecolor($w, $h);
            $bg = imagecolorallocate($img, $r, $g, $b);
            imagefill($img, 0, 0, $bg);
            if ($text !== '') {
                $txtColor = imagecolorallocate($img, 255, 255, 255);
                $fs = max((int) floor($w / 30), 3);
                $tw = strlen($text) * $fs * 0.7;
                imagestring($img, $fs > 10 ? 5 : 3, (int) max(0, ($w - $tw) / 2), (int) ($h / 2), $text, $txtColor);
            }
            ob_start();
            if ($fmt === 'webp') {
                imagewebp($img, null, $quality);
            } else {
                imagejpeg($img, null, $quality);
            }
            $data = (string) ob_get_clean();
            imagedestroy($img);

            return ['data' => $data, 'type' => $fmt];
        } catch (\Throwable $e) {
            app(WeappSupportGateway::class)->kernelOpsLog('thumb_image_encode_failed', ['msg' => $e->getMessage()]);
            return null;
        }
    }

    /** @return array{0:int,1:int,2:int} */
    private static function colorToRgb(string $color): array
    {
        if (preg_match('/hsl\((\d+),(\d+)%,(\d+)%\)/', $color, $mhsl)) {
            $h = (int) $mhsl[1];
            $s = (int) $mhsl[2] / 100;
            $l = (int) $mhsl[3] / 100;
            $c = (1 - abs(2 * $l - 1)) * $s;
            $x = $c * (1 - abs(fmod($h / 60, 2) - 1));
            $m = $l - $c / 2;
            $vals = [[$c, $x, 0], [$x, $c, 0], [0, $c, $x], [0, $x, $c], [$x, 0, $c], [$c, 0, $x]];
            $i = ((int) floor($h / 60)) % 6;

            return [
                (int) (($vals[$i][0] + $m) * 255),
                (int) (($vals[$i][1] + $m) * 255),
                (int) (($vals[$i][2] + $m) * 255),
            ];
        }
        if (preg_match('/#([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})/i', $color, $mhex)) {
            return [hexdec($mhex[1]), hexdec($mhex[2]), hexdec($mhex[3])];
        }

        return [102, 126, 234];
    }

    /** @param list<string> $keys */
    private static function resolveIntAttr(array $attrs, array $pageVars, array $keys): int
    {
        foreach ($keys as $key) {
            if (!isset($attrs[$key]) || (string) $attrs[$key] === '') {
                continue;
            }
            $raw = (string) $attrs[$key];
            if (str_starts_with($raw, '$')) {
                return max(0, (int) ($pageVars[ltrim($raw, '$')] ?? 0));
            }

            return max(0, (int) $raw);
        }

        return 0;
    }

    /** @param list<string> $keys */
    private static function resolveStringAttr(array $attrs, array $pageVars, array $keys): string
    {
        foreach ($keys as $key) {
            if (!isset($attrs[$key]) || (string) $attrs[$key] === '') {
                continue;
            }
            $raw = (string) $attrs[$key];
            if (str_starts_with($raw, '$')) {
                return (string) ($pageVars[ltrim($raw, '$')] ?? '');
            }

            return $raw;
        }

        return '';
    }

    /** @return array{title:string,litpic:string,nav_id:int}|null */
    private static function documentMeta(int $documentId): ?array
    {
        if ($documentId < 1) {
            return null;
        }
        $cacheKey = 'thumb_doc_' . $documentId;
        $cached = Cache::get($cacheKey);
        if (is_array($cached) && array_key_exists('nav_id', $cached)) {
            return $cached;
        }
        $row = app(WeappDocumentGateway::class)->documentRowById($documentId, false);
        if ($row === null) {
            return null;
        }
        $meta = [
            'title'  => (string) ($row['title'] ?? ''),
            'litpic' => (string) ($row['litpic'] ?? ''),
            'nav_id' => (int) ($row['nav_id'] ?? 0),
        ];
        if ($meta['nav_id'] < 1) {
            $meta['nav_id'] = app(WeappDocumentGateway::class)->documentPrimaryNavId($documentId);
        }
        Cache::set($cacheKey, $meta, 86400);

        return $meta;
    }

    /**
     * @param array<string, mixed> $cfg
     * @return array{0:int,1:int}
     */
    private static function applyNavSizeOverride(array $cfg, int $documentId, int $navId, int $w, int $h): array
    {
        if ((int) ($cfg['responsive'] ?? 0) === 1) {
            return [$w, $h];
        }
        if ($navId < 1 && $documentId > 0) {
            $navId = app(WeappDocumentGateway::class)->documentPrimaryNavId($documentId);
        }
        if ($navId < 1) {
            return [$w, $h];
        }
        foreach ($cfg['nav_sizes'] ?? [] as $item) {
            if ((int) ($item['nav_id'] ?? 0) === $navId) {
                return [
                    (int) ($item['w'] ?? $w),
                    (int) ($item['h'] ?? $h),
                ];
            }
        }

        return [$w, $h];
    }

    private static function normalizeSeed(string $seed): string
    {
        $seed = preg_replace('/\.(svg|jpeg|jpg|webp)$/i', '', $seed) ?? $seed;

        return preg_replace('/[^a-zA-Z0-9_-]/', '', $seed) ?: '0';
    }

    private static function normalizeLitpic(string $litpic): string
    {
        $litpic = trim($litpic);
        if ($litpic === '') {
            return '';
        }
        if (str_starts_with($litpic, '//')) {
            return 'https:' . $litpic;
        }

        return $litpic;
    }

    private static function isPlaceholderLitpic(string $litpic): bool
    {
        return ThumbnailConfigService::isPlaceholderLitpic($litpic);
    }

    public static function fallbackAssetUrl(): string
    {
        return '/weapp/doc_thumb/assets/fallback.svg';
    }

    private static function cacheDir(): string
    {
        return RUNTIME_PATH . 'thumb' . DIRECTORY_SEPARATOR;
    }

    private static function ensureCacheDir(): void
    {
        $dir = self::cacheDir();
        if (!is_dir($dir) && !mkdir($dir, 0755, true) && !is_dir($dir)) {
            throw new \RuntimeException('Cannot create thumb cache dir');
        }
    }

    private static function cacheFilePath(
        string $seed,
        int $w,
        int $h,
        string $format,
        string $template,
        string $watermark,
        string $watermarkPos
    ): string {
        $hash = md5($seed . '|' . $w . '|' . $h . '|' . $format . '|' . $template . '|' . $watermark . '|' . $watermarkPos);
        $ext = $format === ThumbnailConfigService::FORMAT_SVG ? 'svg' : $format;

        return self::cacheDir() . $hash . '.' . $ext;
    }

    /**
     * 确保 public 静态文件存在并返回 Web 路径；失败返回空串（调用方回退 API）。
     */
    private static function ensurePublicStaticUrl(
        string $seed,
        int $w,
        int $h,
        string $format,
        string $template,
        string $watermark,
        string $watermarkPos
    ): string {
        $existing = self::publicStaticUrlIfExists($seed, $w, $h, $format, $template, $watermark, $watermarkPos);
        if ($existing !== '') {
            return $existing;
        }

        // 从 runtime 缓存镜像
        $cacheFile = self::cacheFilePath($seed, $w, $h, $format, $template, $watermark, $watermarkPos);
        if (is_file($cacheFile)) {
            $url = self::writePublicStatic($seed, $w, $h, $format, $template, $watermark, $watermarkPos, (string) file_get_contents($cacheFile));

            return $url !== '' ? $url : '';
        }

        // 触发生成（写 runtime + public）
        $result = self::renderImageResponse($seed, ['w' => $w, 'h' => $h]);
        if (!empty($result['static_url']) && is_string($result['static_url'])) {
            return (string) $result['static_url'];
        }

        return self::publicStaticUrlIfExists($seed, $w, $h, $format, $template, $watermark, $watermarkPos);
    }

    private static function writePublicStatic(
        string $seed,
        int $w,
        int $h,
        string $format,
        string $template,
        string $watermark,
        string $watermarkPos,
        string $body
    ): string {
        if ($body === '' || $seed === '') {
            return '';
        }
        self::ensurePublicStaticDir();
        $path = self::publicStaticFilePath($seed, $w, $h, $format, $template, $watermark, $watermarkPos);
        if (file_put_contents($path, $body, LOCK_EX) === false) {
            return '';
        }

        return self::publicStaticWebPath($seed, $w, $h, $format, $template, $watermark, $watermarkPos);
    }

    private static function publicStaticDir(): string
    {
        $root = defined('ROOT_PATH') ? (string) ROOT_PATH : dirname(__DIR__, 3) . DIRECTORY_SEPARATOR;

        return $root . 'public' . DIRECTORY_SEPARATOR . 'static' . DIRECTORY_SEPARATOR . 'thumb' . DIRECTORY_SEPARATOR . 'doc' . DIRECTORY_SEPARATOR;
    }

    private static function ensurePublicStaticDir(): void
    {
        $dir = self::publicStaticDir();
        if (!is_dir($dir) && !mkdir($dir, 0755, true) && !is_dir($dir)) {
            throw new \RuntimeException('Cannot create public thumb static dir');
        }
    }

    private static function publicStaticCfgHash(string $format, string $template, string $watermark, string $watermarkPos): string
    {
        return substr(md5($format . '|' . $template . '|' . $watermark . '|' . $watermarkPos), 0, 12);
    }

    private static function publicStaticFilePath(
        string $seed,
        int $w,
        int $h,
        string $format,
        string $template,
        string $watermark,
        string $watermarkPos
    ): string {
        $ext = $format === ThumbnailConfigService::FORMAT_SVG ? 'svg' : $format;
        $hash = self::publicStaticCfgHash($format, $template, $watermark, $watermarkPos);

        return self::publicStaticDir() . $seed . '_' . $w . 'x' . $h . '_' . $hash . '.' . $ext;
    }

    private static function publicStaticWebPath(
        string $seed,
        int $w,
        int $h,
        string $format,
        string $template,
        string $watermark,
        string $watermarkPos
    ): string {
        $ext = $format === ThumbnailConfigService::FORMAT_SVG ? 'svg' : $format;
        $hash = self::publicStaticCfgHash($format, $template, $watermark, $watermarkPos);

        return '/static/thumb/doc/' . rawurlencode($seed) . '_' . $w . 'x' . $h . '_' . $hash . '.' . $ext;
    }

    private static function clearPublicStaticDir(): void
    {
        $dir = self::publicStaticDir();
        if (!is_dir($dir)) {
            return;
        }
        foreach (scandir($dir) ?: [] as $name) {
            if ($name === '.' || $name === '..') {
                continue;
            }
            $path = $dir . $name;
            if (is_file($path)) {
                app(WeappSupportGateway::class)->localFileUnlinkIfExists($path);
            }
        }
    }

    private static function clearPublicStaticForSeed(string $seed): void
    {
        $dir = self::publicStaticDir();
        if (!is_dir($dir) || $seed === '') {
            return;
        }
        $prefix = $seed . '_';
        foreach (scandir($dir) ?: [] as $name) {
            if ($name === '.' || $name === '..') {
                continue;
            }
            if (!str_starts_with($name, $prefix)) {
                continue;
            }
            $path = $dir . $name;
            if (is_file($path)) {
                app(WeappSupportGateway::class)->localFileUnlinkIfExists($path);
            }
        }
    }

    private static function contentTypeForFormat(string $format): string
    {
        return match (ThumbnailConfigService::normalizeFormat($format)) {
            ThumbnailConfigService::FORMAT_JPEG => 'image/jpeg',
            ThumbnailConfigService::FORMAT_WEBP => 'image/webp',
            default                           => 'image/svg+xml',
        };
    }

    private static function mapConvertedType(string $type): string
    {
        return match ($type) {
            'jpeg' => 'image/jpeg',
            'webp' => 'image/webp',
            default => 'image/svg+xml',
        };
    }
}
