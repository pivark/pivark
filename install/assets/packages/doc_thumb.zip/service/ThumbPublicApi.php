<?php
declare(strict_types=1);

namespace weapp\doc_thumb\service;

use app\common\contract\PluginApiCallableTrait;
use app\common\contract\PluginApiInterface;

/** 缩略图插件对外 API（跨插件经 PluginApiRegistry 调用） */
final class ThumbPublicApi implements PluginApiInterface
{
    use PluginApiCallableTrait;

    public function pluginIdentifier(): string
    {
        return 'doc_thumb';
    }

    public function isActive(): bool
    {
        ThumbnailService::ensureAutoload();

        return ThumbnailService::isActive();
    }

    /**
     * @param array<string, mixed> $row 文档行（id/title/litpic/nav_id 可选）
     */
    public function resolveForDocument(array $row, int $w = 0, int $h = 0): string
    {
        ThumbnailService::ensureAutoload();

        return ThumbnailService::resolveForDocument($row, $w, $h);
    }
}
