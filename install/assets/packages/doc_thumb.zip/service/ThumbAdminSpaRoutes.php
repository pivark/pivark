<?php
declare(strict_types=1);

namespace weapp\doc_thumb\service;

use app\common\service\weapp\WeappAdminGateway;

final class ThumbAdminSpaRoutes
{
    public static function register(): void
    {
        $gw = app(WeappAdminGateway::class);
        $id = 'doc_thumb';

        $gw->adminSpaHostRegisterPluginPage($id,
            'settings',
            'WeappThumbSettings',
            ['title' => '基础设置'],
        );

        foreach (['usage' => ['WeappThumbUsage', '前台调用说明', '/weapp/usage/index'], 'guide' => ['WeappThumbGuide', '功能介绍', '/weapp/guide/index']] as $seg => [$name, $title, $component]) {
            $path = $gw->adminSpaHostPath($id, $seg);
            $gw->adminSpaExplicitRouteRegister($path, [
                'name'      => $name,
                'path'      => $path,
                'component' => $component,
                'meta'      => ['pivarkWeapp' => $id, 'title' => $title],
            ]);
        }

        $gw->adminSpaRouteIconRegister($gw->adminSpaHostPath($id, 'settings'), 'lucide:image-down');
        $gw->adminWeappNavTabsRegister($id, [
            $gw->adminWeappNavTab('settings', '基础设置', 'settings'),
        ]);
    }
}
