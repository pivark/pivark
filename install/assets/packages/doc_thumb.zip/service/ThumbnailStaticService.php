<?php
declare(strict_types=1);

namespace weapp\doc_thumb\service;

use app\common\service\weapp\WeappConfigGateway;
use app\common\service\weapp\WeappDocumentGateway;
use app\common\service\weapp\WeappStaticGateway;
use app\common\service\weapp\WeappTagGateway;

/** 缩略图配置变更 → 静态 HTML 联动 */
final class ThumbnailStaticService
{
    /** @return array{queued:bool,docs:int,framework:bool,mode:string,msg:string} */
    public static function afterConfigSave(): array
    {
        if ((string) app(WeappConfigGateway::class)->configGet('thumb_rebuild_static', '1') !== '1') {
            return [
                'queued'    => false,
                'docs'      => 0,
                'framework' => false,
                'mode'      => 'off',
                'msg'       => '',
            ];
        }
        if (!app(WeappStaticGateway::class)->staticHtmlEnabled()) {
            return [
                'queued'    => false,
                'docs'      => 0,
                'framework' => false,
                'mode'      => 'static_disabled',
                'msg'       => '',
            ];
        }

        $docIds = self::documentIdsForRebuild();
        if (app(WeappStaticGateway::class)->staticBuildAsyncEnabled()) {
            app(WeappStaticGateway::class)->staticBuildSeedFramework();
            foreach ($docIds as $id) {
                app(WeappStaticGateway::class)->staticBuildEnqueueWork(['t' => 'doc', 'id' => $id], 25);
            }

            return [
                'queued'    => true,
                'docs'      => count($docIds),
                'framework' => true,
                'mode'      => 'async',
                'msg'       => '静态页已加入重建队列（首页/频道/相关文档）',
            ];
        }

        app(WeappStaticGateway::class)->staticHtmlSyncAfterNavChange();
        foreach (app(WeappTagGateway::class)->tagListAllActive() as $tag) {
            $tagId = (int) ($tag['id'] ?? 0);
            if ($tagId > 0) {
                app(WeappStaticGateway::class)->staticHtmlSyncAfterTagChange($tagId);
            }
        }
        foreach ($docIds as $id) {
            app(WeappStaticGateway::class)->staticDispatchAfterArticleChange($id, 'edit');
        }

        return [
            'queued'    => true,
            'docs'      => count($docIds),
            'framework' => true,
            'mode'      => 'sync',
            'msg'       => '已同步刷新首页与 ' . count($docIds) . ' 篇占位封面文档静态页',
        ];
    }

    /** @return list<int> */
    public static function documentIdsForRebuild(): array
    {
        ThumbnailService::ensureAutoload();
        $docGw = app(WeappDocumentGateway::class);
        $rows = $docGw->documentRowsByIds(
            $docGw->documentPublishedIds(),
            'id,litpic',
        );
        $out = [];
        foreach ($rows as $row) {
            if (!is_array($row)) {
                continue;
            }
            $litpic = trim((string) ($row['litpic'] ?? ''));
            if ($litpic !== '' && !ThumbnailConfigService::isPlaceholderLitpic($litpic)) {
                continue;
            }
            $id = (int) ($row['id'] ?? 0);
            if ($id > 0) {
                $out[] = $id;
            }
        }

        return $out;
    }
}
