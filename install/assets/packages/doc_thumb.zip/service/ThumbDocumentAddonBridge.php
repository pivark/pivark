<?php
/**
 * 元舟 PivArk — document-addon bridge handler（weapp SSOT）
 */
declare(strict_types=1);

namespace weapp\doc_thumb\service;

use app\common\contract\DocumentAddonBridgeHandlerInterface;
use app\common\contract\WeappPluginBridgeTrait;

final class ThumbDocumentAddonBridge implements DocumentAddonBridgeHandlerInterface
{
    use WeappPluginBridgeTrait;

    
    

    private static ?bool $enabledCache = null;

    public function identifier(): string
    {
        return 'doc_thumb';
    }
    /** @return array<string, mixed> */
    public function documentEditorSpaPayload(int $documentId): array
    {
        return [];
    }

    public function isEnabled(): bool
    {
        if (self::$enabledCache !== null) {
            return self::$enabledCache;
        }
        self::$enabledCache = $this->bridgeEnabled('doc_thumb');

        return self::$enabledCache;
    }

    /**
     * 列表/详情：写入 thumb_url、必要时替换 litpic、坏链回退 URL
     *
     * @param array<string, mixed> $item
     */
    public function applyToItem(array &$item): void
    {
        if (!$this->isEnabled()) {
            return;
        }

        $this->ensurePluginLoaded();
        if (!\weapp\doc_thumb\service\ThumbnailConfigService::isOpen()) {
            return;
        }

        $litpic   = trim((string) ($item['litpic'] ?? ''));
        $thumbUrl = \weapp\doc_thumb\service\ThumbnailService::resolveForDocument($item);
        $item['thumb_url'] = $thumbUrl;

        $hasRealLitpic = $litpic !== '' && !\weapp\doc_thumb\service\ThumbnailConfigService::isPlaceholderLitpic($litpic);
        if ($hasRealLitpic) {
            $fallback = \weapp\doc_thumb\service\ThumbnailService::buildPlaceholderUrlForDocument($item);
            if ($fallback !== '') {
                $item['thumb_fallback_url'] = $fallback;
            }

            return;
        }

        if ($thumbUrl !== '') {
            $item['litpic'] = $thumbUrl;
        }
    }

    /**
     * 列表模板 img 标签附加属性（坏链 onerror 回退）
     *
     * @param array<string, mixed> $row
     */
    public function imgTagExtraAttrs(array $row): string
    {
        if (!$this->isEnabled() || !\weapp\doc_thumb\service\ThumbnailConfigService::brokenFallbackEnabled()) {
            return '';
        }

        $this->ensurePluginLoaded();

        $litpic = trim((string) ($row['litpic'] ?? ''));
        if ($litpic === '' || \weapp\doc_thumb\service\ThumbnailConfigService::isPlaceholderLitpic($litpic)) {
            return '';
        }

        $fallback = trim((string) ($row['thumb_fallback_url'] ?? ''));
        if ($fallback === '') {
            $fallback = \weapp\doc_thumb\service\ThumbnailService::buildPlaceholderUrlForDocument($row);
        }
        if ($fallback === '' || $fallback === $litpic) {
            return '';
        }

        $escaped = htmlspecialchars($fallback, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');

        return ' onerror="this.onerror=null;this.src=\'' . $escaped . '\'"';
    }

    /** @return array{imagick:bool,gd:bool,webp:bool,raster_ready:bool} */
    public function formatCapabilities(): array
    {
        $this->ensurePluginLoaded();

        return \weapp\doc_thumb\service\ThumbnailConfigService::formatCapabilities();
    }

    public function resolveProductCoverUrl(string $path, string $title = ''): string
    {
        if (!$this->isEnabled()) {
            return '';
        }
        $this->ensurePluginLoaded();
        if (!\weapp\doc_thumb\service\ThumbnailService::isActive()) {
            return '';
        }

        return \weapp\doc_thumb\service\ThumbnailService::resolveUrl(0, $path, $title);
    }

    private function ensurePluginLoaded(): void
    {
        $this->registerWeappAutoload('doc_thumb');
        \weapp\doc_thumb\service\ThumbnailService::ensureAutoload();
    }
}
