<?php
declare(strict_types=1);

namespace weapp\doc_thumb\service;

use app\common\service\weapp\WeappPluginGateway;
use app\common\service\weapp\WeappSiteGateway;
use app\common\service\weapp\WeappStaticGateway;

final class ThumbAdminSpaMeta
{
    /** @param array<string, mixed> $ctx @return array<string, mixed> */
    public static function build(array $ctx): array
    {
        ThumbnailService::ensureAutoload();
        $cfg         = ThumbnailConfigService::all();
        $navSizesRaw = json_decode((string) ($cfg['thumb_nav_sizes'] ?? '[]'), true);

        return [
            'cfg'                        => $cfg,
            'navSizes'                   => ThumbnailConfigService::navSizesForAdmin(
                is_array($navSizesRaw) ? $navSizesRaw : []
            ),
            'navOptions'                 => app(WeappSiteGateway::class)->siteNavListContentCategoryOptions(),
            'stats'                      => ThumbnailService::statsAdmin(),
            'templates'                  => [
                ['value' => ThumbnailConfigService::TEMPLATE_VIBRANT, 'label' => '炫酷'],
                ['value' => ThumbnailConfigService::TEMPLATE_GRADIENT, 'label' => '渐变'],
                ['value' => ThumbnailConfigService::TEMPLATE_MINIMAL, 'label' => '简约'],
                ['value' => ThumbnailConfigService::TEMPLATE_GEOMETRIC, 'label' => '几何'],
                ['value' => ThumbnailConfigService::TEMPLATE_GLASS, 'label' => '毛玻璃'],
            ],
            'formats'                    => [
                ['value' => ThumbnailConfigService::FORMAT_SVG, 'label' => 'SVG（推荐）'],
                ['value' => ThumbnailConfigService::FORMAT_JPEG, 'label' => 'JPEG'],
                ['value' => ThumbnailConfigService::FORMAT_WEBP, 'label' => 'WebP'],
            ],
            'staticHtmlEnabled'          => app(WeappStaticGateway::class)->staticHtmlEnabled(),
            'defaultPlaceholderPatterns' => ThumbnailConfigService::defaultPlaceholderPatterns(),
            'rebuildDocCount'            => count(ThumbnailStaticService::documentIdsForRebuild()),
            'formatCapabilities'         => ThumbnailConfigService::formatCapabilities(),
            'plugin'                     => app(WeappPluginGateway::class)->pluginPresentationForAdmin('doc_thumb'),
        ];
    }
}
