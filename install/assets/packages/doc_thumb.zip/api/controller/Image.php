<?php
declare(strict_types=1);

namespace weapp\doc_thumb\api\controller;

use think\facade\Request;
use think\Response;
use weapp\doc_thumb\service\ThumbnailService;

/** 动态缩略图输出（/plugins/doc_thumb/{seed}.svg）；优先 302 到 public/static */
class Image
{
    public function render(string $seed): Response
    {
        ThumbnailService::ensureAutoload();
        if (!ThumbnailService::isActive()) {
            return redirect(ThumbnailService::fallbackAssetUrl());
        }

        $query = Request::get();
        $result = ThumbnailService::renderImageResponse($seed, $query);
        if (($result['content_type'] ?? '') === 'redirect' && !empty($result['redirect'])) {
            return redirect((string) $result['redirect']);
        }

        // 已落盘 public 时直接 302，旧 HTML 里的 API URL 第二次可走静态（仍须一次 PHP）
        $staticUrl = trim((string) ($result['static_url'] ?? ''));
        if ($staticUrl !== '' && str_starts_with($staticUrl, '/static/thumb/')) {
            return redirect($staticUrl, 302);
        }

        $headers = [
            'Content-Type'  => (string) ($result['content_type'] ?? 'image/svg+xml'),
            'Cache-Control' => !empty($result['cacheable']) ? 'public, max-age=86400' : 'no-cache, no-store, must-revalidate',
        ];
        if (!empty($result['etag'])) {
            $headers['ETag'] = '"' . $result['etag'] . '"';
        }

        return response((string) ($result['body'] ?? ''), 200, $headers);
    }
}
