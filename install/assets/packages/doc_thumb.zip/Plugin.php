<?php
declare(strict_types=1);

namespace weapp\doc_thumb;

use weapp\doc_thumb\service\ThumbAdminSpaMeta;
use app\common\service\weapp\WeappAdminGateway;
use app\common\service\weapp\WeappEntitlementGateway;
use app\common\service\weapp\WeappPluginGateway;
use app\common\service\weapp\WeappTemplateGateway;
use weapp\doc_thumb\service\ThumbnailService;
use weapp\doc_thumb\service\ThumbPublicApi;
use weapp\doc_thumb\service\ThumbAdminSpaRoutes;
use weapp\doc_thumb\service\ThumbDocumentAddonBridge;

/** 官方动态缩略图插件 */
class Plugin
{
    public function install(): void
    {
        app(WeappEntitlementGateway::class)->entitlementGrantFreeInstall('doc_thumb');
    }

    public function enable(): void
    {
    }

    public function disable(): void
    {
    }

    public function boot(): void
    {
        $admin = app(WeappAdminGateway::class);
        $plugin = app(WeappPluginGateway::class);
        $admin->adminSpaMetaRegister('doc_thumb', 'doc_thumb', [ThumbAdminSpaMeta::class, 'build']);
        ThumbAdminSpaRoutes::register();
        $perm = 'plugin.doc_thumb.use';
        $admin->adminPermissionExtensionRegisterMap('doc_thumb', [
            'index'         => $perm,
            'usage'         => $perm,
            'preview'       => $perm,
            'configsave'    => $perm,
            'clearcache'    => $perm,
            'batchgenerate' => $perm,
        ]);
        $plugin->pluginExtensionRegisterDocumentAddonBridge(
            'doc_thumb',
            new ThumbDocumentAddonBridge(),
            100,
            ['list_item_apply' => true],
        );
        ThumbnailService::ensureAutoload();
        $plugin->pluginApiRegistryRegister('ThumbPublic', new ThumbPublicApi());
        app(WeappTemplateGateway::class)->templateRegisterExtensionTag('doc_thumb', [ThumbnailService::class, 'renderTag']);
        $plugin->pluginRouteRegister(
            'get',
            'plugins/doc_thumb/:seed',
            '\\weapp\\doc_thumb\\api\\controller\\Image@render',
            ['seed' => '[\\w.-]+']
        );
        $plugin->pluginRouteRegister(
            'get',
            'api/v1/plugins/doc_thumb/:seed',
            '\\weapp\\doc_thumb\\api\\controller\\Image@render',
            ['seed' => '[\\w.-]+']
        );
    }
}
