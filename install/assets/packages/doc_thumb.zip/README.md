# 动态缩略图（`thumb`）

> **用户文档 SSOT：** 本目录 `README.md`（`## 功能介绍` · `## 使用说明` · `## 升级日志` · `## 安装与开发`） · v1.2.0 · `pivark/doc_thumb`；后台与市场直读，改完即生效。

## 功能介绍

<h3>这个插件能帮你做什么？</h3>
<p>
    当文档<strong>没有上传封面</strong>，或封面仍是主题自带的灰色占位图时，系统会按<strong>文档标题</strong>自动生成一张<strong>炫彩占位缩略图</strong>，
    让新闻列表、产品卡片、相关推荐不再出现「空白方块」。
</p>
<p class="pv-tip">与 <strong>图集（gallery）</strong> 分工：thumb 解决「列表没图」；gallery 解决「正文里多图相册」。</p>

<p><img src="guide-scenarios.svg" alt="动态缩略图四类典型场景" width="720" loading="lazy"></p>

<h3>什么时候会自动出图？</h3>
<table>
    <thead><tr><th>文档封面情况</th><th>前台表现</th></tr></thead>
    <tbody>
        <tr><td><code>litpic</code> 为空</td><td>生成彩色占位图（标题文字 + 渐变背景）</td></tr>
        <tr><td>URL 含占位规则（如 <code>preview.svg</code>、<code>no_pic</code>）</td><td>视为无效封面，生成占位图</td></tr>
        <tr><td>已上传真实封面 URL</td><td>保持原图不变</td></tr>
        <tr><td>封面 URL 已失效（404）</td><td>开启「坏链回退」后，列表图片加载失败时自动换占位图</td></tr>
    </tbody>
</table>

<h3>怎么用？（运营向四步）</h3>
<p><img src="guide-admin-flow.svg" alt="后台配置四步流程" width="720" loading="lazy"></p>
<ol>
    <li><strong>插件中心</strong>安装并授权「动态缩略图」。</li>
    <li>进入 <strong>插件 → 动态缩略图 → 基础设置</strong>，打开功能开关。</li>
    <li>选择默认宽高、模板风格（炫酷 / 渐变 / 简约 / 几何 / 毛玻璃）、输出格式（推荐 SVG）。右侧可<strong>实时预览</strong>。</li>
    <li>按需配置：水印文字、栏目独立尺寸、占位路径规则、坏链回退、保存后重建静态页 → 点击<strong>保存配置</strong>。</li>
</ol>

<p><img src="guide-styles.svg" alt="五种占位图模板风格" width="720" loading="lazy"></p>

<h3>后台还能做什么？</h3>
<ul>
    <li><strong>占位路径规则</strong>：每行一条 URL 片段，与内置规则（<code>preview.svg</code>、<code>default_litpic</code> 等）合并识别。</li>
    <li><strong>栏目独立尺寸</strong>：关闭「响应式尺寸」时，文档主栏目可指定不同宽高（如产品 400×400、新闻 320×240）。</li>
    <li><strong>缓存维护</strong>：清除全部或指定栏目下的生成缓存；批量预热无图文档（可选按栏目）。</li>
    <li><strong>静态 HTML 联动</strong>：站点开启静态页时，保存配置可自动排队重建首页、频道与占位封面文档页。</li>
    <li><strong>JPEG / WebP</strong>：需服务器安装 Imagick 或 GD；未安装时自动回退 SVG，后台会提示。</li>
</ul>

<h3>对模板作者友好</h3>
<p>
    绝大多数站点<strong>无需改模板</strong>：内核在列表、详情、相关推荐、API 输出前自动写入
    <code>litpic</code> / <code>thumb_url</code>。现有 <code>&lt;img src="{$field.litpic}"&gt;</code> 即可生效。
</p>
<p>需要自定义时可使用 <code>{pv:doc_thumb}</code>，详见本插件 Tab「前台调用说明」。</p>

## 使用说明

<h3>功能简介（前端向）</h3>
<p>
    动态缩略图由<strong>内核自动注入</strong>列表/详情字段；模板作者通常只需使用 <code>{$field.litpic}</code>。
    需要固定尺寸或直链 URL 时，可使用 <code>{pv:doc_thumb}</code> 标签或 REST 图片地址。
</p>

<p><img src="usage-list-wireframe.svg" alt="列表模板缩略图插入位置" width="640" loading="lazy"></p>
<p><img src="usage-front-mockup.svg" alt="访客看到的新闻列表示意" width="640" loading="lazy"></p>

<h3>推荐写法（零改动）</h3>
<p>频道 / 标签列表循环内：</p>
<pre class="pv-weapp-code">&lt;img src="{$field.litpic}" alt="{$field.title}" loading="lazy"&gt;</pre>
<p>文档详情页：</p>
<pre class="pv-weapp-code">{pv:if name="document_litpic"}
&lt;img src="{$document_litpic}" alt="{$document_title}" loading="lazy"&gt;
{/pv:if}</pre>
<p class="pv-tip">以上字段已由内核处理：无图 → 占位图 URL；有真实封面 → 原 URL。</p>

<h3>显式标签</h3>
<p>输出完整 <code>&lt;img&gt;</code>（属性见下表）：</p>
<pre class="pv-weapp-code">&lt;img src="{pv:doc_thumb id="$field.id" litpic="$field.litpic" title="$field.title" width="320" height="240"}" alt="{$field.title}" loading="lazy"&gt;</pre>
<p>仅输出 URL 字符串（用于背景图、JSON-LD 等）：</p>
<pre class="pv-weapp-code">{pv:doc_thumb id="$field.id" litpic="$field.litpic" title="$field.title" mode="url"}</pre>
<p><code>litpic</code> 标签别名（与 thumb 等价）：</p>
<pre class="pv-weapp-code">{pv:doc_thumb id="$field.id" litpic="$field.litpic" title="$field.title"}</pre>

<h3>标签属性</h3>
<table>
    <thead><tr><th>属性</th><th>说明</th><th>示例</th></tr></thead>
    <tbody>
        <tr><td><code>id</code> / <code>aid</code> / <code>document_id</code></td><td>文档 ID（决定 seed 与标题）</td><td><code>id="$field.id"</code></td></tr>
        <tr><td><code>litpic</code> / <code>thumb</code> / <code>image</code></td><td>库内封面 URL</td><td><code>litpic="$field.litpic"</code></td></tr>
        <tr><td><code>title</code> / <code>text</code> / <code>name</code></td><td>占位图显示文字</td><td><code>title="$field.title"</code></td></tr>
        <tr><td><code>nav_id</code></td><td>栏目 ID（命中栏目独立尺寸；省略则用文档主栏目）</td><td><code>nav_id="12"</code></td></tr>
        <tr><td><code>width</code> / <code>w</code></td><td>宽度像素</td><td><code>width="320"</code></td></tr>
        <tr><td><code>height</code> / <code>h</code></td><td>高度像素</td><td><code>height="240"</code></td></tr>
        <tr><td><code>seed</code></td><td>无文档 ID 时的自定义 seed</td><td><code>seed="custom-key"</code></td></tr>
        <tr><td><code>mode</code></td><td><code>url</code> 仅输出 URL；默认输出 img 片段</td><td><code>mode="url"</code></td></tr>
    </tbody>
</table>

<h3>列表 / API 注入字段</h3>
<p>以下字段在 <code>{pv:arclist}</code>、文档 API、相关推荐等场景自动可用：</p>
<table>
    <thead><tr><th>字段</th><th>说明</th></tr></thead>
    <tbody>
        <tr><td><code>{$field.litpic}</code></td><td>最终展示 URL（无图时为占位图）</td></tr>
        <tr><td><code>{$field.thumb_url}</code></td><td>thumb 插件解析结果（与 litpic 在无图/占位时一致）</td></tr>
        <tr><td><code>{$field.thumb_fallback_url}</code></td><td>有真实封面时：坏链回退用的占位图 URL（API/H5 可用）</td></tr>
    </tbody>
</table>

<h3>图片直链 URL</h3>
<pre class="pv-weapp-code">优先：/static/thumb/doc/{文档ID}_{w}x{h}_{cfgHash}.svg
回退：GET /api/v1/plugins/doc_thumb/{文档ID}.svg?w=400&amp;h=300
GET /plugins/doc_thumb/{文档ID}.svg?w=400&amp;h=300</pre>
<p>非随机模式下生成后会双写到 <code>public/static/thumb/doc/</code>，模板出链优先静态路径（Web 服务器直出，免 PHP 启动）。API 仍保留；命中已落盘文件时可 302 到静态。</p>
<p>Query 参数（均可选）：</p>
<table>
    <thead><tr><th>参数</th><th>说明</th></tr></thead>
    <tbody>
        <tr><td><code>w</code> / <code>h</code></td><td>宽高；开启「响应式尺寸」时 URL 参数优先生效</td></tr>
        <tr><td><code>text</code></td><td>覆盖占位图文字</td></tr>
        <tr><td><code>nav_id</code></td><td>指定栏目以命中独立尺寸</td></tr>
        <tr><td><code>template</code></td><td>临时覆盖模板：vibrant / gradient / minimal / geometric / glass</td></tr>
        <tr><td><code>format</code></td><td>svg / jpeg / webp</td></tr>
    </tbody>
</table>
<p>响应：<code>200</code> 图片二进制；若文档有有效封面则 <code>302</code> 跳转原图。</p>

<h3>文档列表 API 示例</h3>
<pre class="pv-weapp-code">GET /api/v1/documents?tag_id=1&amp;page=1</pre>
<p>JSON 每条记录含 <code>litpic</code>、<code>thumb_url</code>；有真实封面且开启坏链回退时另有 <code>thumb_fallback_url</code>。</p>

<h3>内置列表 HTML 坏链回退</h3>
<p>内核渲染的默认列表布局（如演示站 <code>demo-news</code>）在真实封面 404 时会附加 <code>onerror</code> 回退占位图；自定义模板若需同样行为，可参考：</p>
<pre class="pv-weapp-code">&lt;img src="{$field.litpic}" alt="{$field.title}"
  onerror="this.onerror=null;this.src='{$field.thumb_fallback_url}'" loading="lazy"&gt;</pre>
<p class="pv-tip">需在后台开启「坏链回退」；无真实封面时 <code>thumb_fallback_url</code> 可能为空。</p>

## 升级日志

### 1.2.1 · 2026-07-30

- 占位图双写 `public/static/thumb/doc/`，列表出链优先静态 URL；API 命中后可 302 到静态

### 1.2.0 · 2026-05-01

- SVG / JPEG / WebP 输出与栏目独立尺寸
- 按标题 seed 生成炫彩占位图，支持水印
- 批量预热缓存与后台缩略图策略配置

### 1.0.0 · 2026-01-15

- 文档无缩略图时自动生成占位图

## 安装与开发

### 禁止

- 在 `app/common/service/` 写业务 extends 壳（document-addon 桥接仅 `document/bridge/DocumentThumbService`）
- 插件内引用 `app/common/service/{Plugin}*` 业务空壳

### 做什么

文档无有效封面时，按标题 + 文档 ID 生成彩色占位图（SVG/JPEG/WebP），全站列表/详情/API 统一生效。

### 目录

```text
weapp/doc_thumb/
├── plugin.json
├── Plugin.php
├── service/
│   ├── ThumbnailService.php
│   ├── ThumbnailConfigService.php
│   └── ThumbnailStaticService.php
├── api/controller/Image.php
└── database/
```

### 标装进度

| 项 | 状态 |
|----|------|
| `service/` 业务集中 | ✅ |
| `composer.json` | ✅ `pivark/doc_thumb` |
| `PluginApiRegistry` 对外 API | ✅ `ThumbPublic`（`resolveForDocument`） |

### 内核消费

| 能力 | 说明 |
|------|------|
| `DocumentFormatService` → `DocumentThumbService` | 自动注入 `litpic` / `thumb_url` / `thumb_fallback_url` |
| `PluginApiRegistry` 对外 API | ✅ `ThumbPublic`（`resolveForDocument`） |
| 显式标签 | `{pv:doc_thumb}` |
