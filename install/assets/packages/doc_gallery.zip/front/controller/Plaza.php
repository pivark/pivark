<?php
declare(strict_types=1);

namespace weapp\doc_gallery\front\controller;

use app\home\controller\Base;
use think\facade\Request;
use think\Response;
use weapp\doc_gallery\service\GalleryPlazaService;
use weapp\doc_gallery\service\GalleryService;

class Plaza extends Base
{
    public function index(): Response
    {
        GalleryService::ensureAutoload();
        $page    = max(1, (int) Request::get('page', 1));
        $sort    = trim((string) Request::get('sort', 'hot'));
        $keyword = trim((string) Request::get('q', Request::get('keyword', '')));
        $res     = GalleryPlazaService::pageVars($page, $sort, $keyword);
        if (!$res->isOk()) {
            return $this->error($res->message() !== '' ? $res->message() : '页面不可用');
        }
        $vars = is_array($res->dataArray()['vars'] ?? null) ? $res->dataArray()['vars'] : [];

        return $this->render('view_gallery_plaza', $vars);
    }
}
