(() => {
  'use strict';

  function rowMetrics(gallery) {
    const style = getComputedStyle(gallery);
    const rowHeight = parseFloat(style.gridAutoRows);
    const gap = parseFloat(style.rowGap || style.gap);
    return {
      rowHeight: Number.isFinite(rowHeight) && rowHeight > 0 ? rowHeight : 8,
      gap: Number.isFinite(gap) && gap >= 0 ? gap : 12,
    };
  }

  function applyMasonrySpan(gallery, figure) {
    const { rowHeight, gap } = rowMetrics(gallery);
    const height = figure.getBoundingClientRect().height;
    if (height < 1) {
      return;
    }
    const span = Math.max(1, Math.ceil((height + gap) / (rowHeight + gap)));
    figure.style.gridRowEnd = `span ${span}`;
  }

  function scheduleLayout(gallery) {
    const figures = Array.from(gallery.querySelectorAll('.pv-gallery-item'));
    if (figures.length === 0) {
      return;
    }
    const run = () => {
      figures.forEach((figure) => applyMasonrySpan(gallery, figure));
    };
    run();
    requestAnimationFrame(run);
  }

  function initMasonry(root) {
    const scope = root || document;
    scope.querySelectorAll('.pv-gallery--masonry').forEach((gallery) => {
      if (gallery.dataset.pvMasonryBound === '1') return;
      gallery.dataset.pvMasonryBound = '1';

      const imgs = Array.from(gallery.querySelectorAll('.pv-gallery-item img'));
      imgs.forEach((img) => {
        const figure = img.closest('.pv-gallery-item');
        if (!figure) return;
        const onReady = () => scheduleLayout(gallery);
        if (img.complete) {
          onReady();
        } else {
          img.addEventListener('load', onReady, { once: true });
          img.addEventListener('error', onReady, { once: true });
        }
      });

      if (typeof ResizeObserver !== 'undefined') {
        const ro = new ResizeObserver(() => scheduleLayout(gallery));
        gallery.querySelectorAll('.pv-gallery-item').forEach((figure) => ro.observe(figure));
      } else {
        window.addEventListener('resize', () => scheduleLayout(gallery));
      }
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => initMasonry(document));
  } else {
    initMasonry(document);
  }
})();
