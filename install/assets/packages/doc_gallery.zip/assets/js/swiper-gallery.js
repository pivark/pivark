(() => {
  'use strict';

  function ensureSwiper() {
    return typeof window.Swiper !== 'undefined';
  }

  function collectSlides(gallery) {
    return Array.from(gallery.querySelectorAll('.pv-gallery-item')).map((figure) => {
      const link = figure.querySelector('a.pv-gallery-item__link, a[data-pv-lightbox], a[href]');
      const img = figure.querySelector('img');
      const title =
        (link && link.getAttribute('data-pv-lightbox')) ||
        (figure.querySelector('.pv-gallery-title') || {}).textContent ||
        (figure.querySelector('figcaption') || {}).textContent ||
        (img && img.getAttribute('alt')) ||
        '';
      return {
        href: (link && link.getAttribute('href')) || (img && img.getAttribute('src')) || '',
        thumb: (img && img.getAttribute('src')) || '',
        title: String(title || '').trim(),
        figure,
      };
    }).filter((s) => s.href || s.thumb);
  }

  function buildSwiperDom(slides, mode) {
    const root = document.createElement('div');
    root.className = 'swiper pv-gallery-swiper pv-gallery-swiper--' + mode;
    const wrapper = document.createElement('div');
    wrapper.className = 'swiper-wrapper';
    slides.forEach((slide) => {
      const el = document.createElement('div');
      el.className = 'swiper-slide';
      const a = document.createElement('a');
      a.className = 'pv-gallery-item__link';
      a.href = slide.href || slide.thumb;
      a.setAttribute('data-pv-lightbox', slide.title);
      const img = document.createElement('img');
      img.src = slide.thumb || slide.href;
      img.alt = slide.title;
      img.loading = 'lazy';
      a.appendChild(img);
      el.appendChild(a);
      if (slide.title && mode !== 'filmstrip') {
        const cap = document.createElement('div');
        cap.className = 'pv-gallery-swiper__caption';
        cap.textContent = slide.title;
        el.appendChild(cap);
      }
      wrapper.appendChild(el);
    });
    root.appendChild(wrapper);
    const prev = document.createElement('div');
    prev.className = 'swiper-button-prev';
    const next = document.createElement('div');
    next.className = 'swiper-button-next';
    const pag = document.createElement('div');
    pag.className = 'swiper-pagination';
    root.appendChild(prev);
    root.appendChild(next);
    root.appendChild(pag);
    return root;
  }

  function mountSwiper(gallery, mode) {
    if (gallery.dataset.pvSwiperBound === '1') return;
    if (!ensureSwiper()) return;
    const slides = collectSlides(gallery);
    if (slides.length < 1) return;

    const shell = gallery.closest('.pv-gallery-carousel-shell') || gallery.parentElement;
    const swiperEl = buildSwiperDom(slides, mode);
    gallery.dataset.pvSwiperBound = '1';
    gallery.hidden = true;
    if (shell) {
      shell.querySelectorAll('.pv-gallery-carousel-nav, .pv-gallery-carousel-dots').forEach((n) => n.remove());
      shell.appendChild(swiperEl);
    } else {
      gallery.insertAdjacentElement('afterend', swiperEl);
    }

    const opts = {
      loop: slides.length > 1,
      grabCursor: true,
      keyboard: { enabled: true },
      navigation: {
        nextEl: swiperEl.querySelector('.swiper-button-next'),
        prevEl: swiperEl.querySelector('.swiper-button-prev'),
      },
      pagination: {
        el: swiperEl.querySelector('.swiper-pagination'),
        clickable: true,
        type: 'bullets',
      },
    };

    if (mode === 'carousel' || mode === 'hero') {
      Object.assign(opts, {
        slidesPerView: 1,
        spaceBetween: 12,
        autoplay: gallery.dataset.pvCarouselAutoplay === '1'
          ? { delay: Math.max(2000, Number(gallery.dataset.pvCarouselInterval) || 5000), disableOnInteraction: true }
          : false,
      });
    } else if (mode === 'filmstrip') {
      Object.assign(opts, {
        slidesPerView: 'auto',
        spaceBetween: 10,
        freeMode: true,
        loop: false,
      });
    }

    // eslint-disable-next-line no-new
    new window.Swiper(swiperEl, opts);

    // Keep lightbox working on rebuilt slides
    if (gallery.getAttribute('data-pv-gallery-lightbox') === '1' || gallery.getAttribute('data-pv-gallery') === '1') {
      swiperEl.setAttribute('data-pv-gallery-lightbox', '1');
      swiperEl.setAttribute('data-pv-gallery', '1');
      if (typeof window.pvGalleryBindLightbox === 'function') {
        window.pvGalleryBindLightbox(swiperEl);
      }
    }
  }

  function init(root) {
    const scope = root || document;
    scope.querySelectorAll('.pv-gallery--carousel').forEach((g) => mountSwiper(g, 'carousel'));
    scope.querySelectorAll('.pv-gallery--filmstrip').forEach((g) => mountSwiper(g, 'filmstrip'));
    scope.querySelectorAll('.pv-gallery--hero').forEach((g) => mountSwiper(g, 'hero'));
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => init(document));
  } else {
    init(document);
  }
  window.pvGalleryInitSwiper = init;
})();
