(() => {
  'use strict';

  function collectLinks(gallery) {
    let links = Array.from(
      gallery.querySelectorAll('a[data-pv-lightbox], a.pv-gallery-item__link[href], a[href*="/uploads/"], a[href*="/static/"]'),
    );
    if (links.length === 0) {
      // fallback: bare images → synthetic anchors
      gallery.querySelectorAll('.pv-gallery-item img, .swiper-slide img').forEach((img) => {
        const a = document.createElement('a');
        a.href = img.currentSrc || img.src;
        a.setAttribute('data-pv-lightbox', img.alt || '');
        a.appendChild(img.cloneNode(true));
        links.push(a);
        img.style.cursor = 'zoom-in';
        img.addEventListener('click', (ev) => {
          ev.preventDefault();
          const idx = Array.from(gallery.querySelectorAll('.pv-gallery-item img, .swiper-slide img')).indexOf(img);
          openLightbox(links, Math.max(0, idx));
        });
      });
      return [];
    }
    return links;
  }

  function bindGallery(gallery) {
    if (!gallery || gallery.dataset.pvGalleryBound === '1') return;
    gallery.dataset.pvGalleryBound = '1';
    const links = collectLinks(gallery);
    links.forEach((link, index) => {
      link.addEventListener('click', (ev) => {
        ev.preventDefault();
        openLightbox(links, index);
      });
    });
  }

  function openLightbox(links, startIndex) {
    const items = links
      .map((a) => {
        const img = a.querySelector('img');
        return {
          href: a.getAttribute('href') || '',
          title: a.getAttribute('data-pv-lightbox') || '',
          thumb: img?.getAttribute('src') || '',
        };
      })
      .filter((item) => item.href);
    if (!items.length) return;

    let index = Math.max(0, Math.min(startIndex, items.length - 1));
    const overlay = document.createElement('div');
    overlay.className = 'pv-gallery-lightbox';
    overlay.innerHTML =
      '<button type="button" class="pv-gallery-lightbox__close" aria-label="关闭">&times;</button>' +
      '<div class="pv-gallery-lightbox__counter"></div>' +
      '<button type="button" class="pv-gallery-lightbox__prev" aria-label="上一张">&#8249;</button>' +
      '<figure class="pv-gallery-lightbox__figure"><img alt=""><figcaption></figcaption></figure>' +
      '<button type="button" class="pv-gallery-lightbox__next" aria-label="下一张">&#8250;</button>' +
      '<div class="pv-gallery-lightbox__thumbs"></div>';
    document.body.appendChild(overlay);
    document.body.classList.add('pv-gallery-lightbox-open');

    const img = overlay.querySelector('img');
    const cap = overlay.querySelector('figcaption');
    const counter = overlay.querySelector('.pv-gallery-lightbox__counter');
    const thumbsRoot = overlay.querySelector('.pv-gallery-lightbox__thumbs');

    if (thumbsRoot && items.length > 1) {
      items.forEach((item, i) => {
        const btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'pv-gallery-lightbox__thumb';
        btn.setAttribute('aria-label', `第 ${i + 1} 张`);
        if (item.thumb) {
          const timg = document.createElement('img');
          timg.src = item.thumb;
          timg.alt = '';
          btn.appendChild(timg);
        } else {
          btn.textContent = String(i + 1);
        }
        btn.addEventListener('click', () => {
          index = i;
          render();
        });
        thumbsRoot.appendChild(btn);
      });
    }

    function render() {
      const item = items[index];
      if (!img || !cap || !item) return;
      img.src = item.href;
      img.alt = item.title;
      cap.textContent = item.title;
      if (counter) {
        counter.textContent = `${index + 1} / ${items.length}`;
      }
      overlay.querySelectorAll('.pv-gallery-lightbox__thumb').forEach((el, i) => {
        el.classList.toggle('is-active', i === index);
      });
    }

    function close() {
      overlay.remove();
      document.body.classList.remove('pv-gallery-lightbox-open');
      document.removeEventListener('keydown', onKey);
    }

    function onKey(ev) {
      if (ev.key === 'Escape') close();
      if (ev.key === 'ArrowLeft') {
        index = (index - 1 + items.length) % items.length;
        render();
      }
      if (ev.key === 'ArrowRight') {
        index = (index + 1) % items.length;
        render();
      }
    }

    overlay.querySelector('.pv-gallery-lightbox__close')?.addEventListener('click', close);
    overlay.querySelector('.pv-gallery-lightbox__prev')?.addEventListener('click', () => {
      index = (index - 1 + items.length) % items.length;
      render();
    });
    overlay.querySelector('.pv-gallery-lightbox__next')?.addEventListener('click', () => {
      index = (index + 1) % items.length;
      render();
    });
    overlay.addEventListener('click', (ev) => {
      if (ev.target === overlay) close();
    });
    document.addEventListener('keydown', onKey);
    render();
  }

  function init(root) {
    const scope = root || document;
    scope.querySelectorAll('[data-pv-gallery-lightbox="1"], [data-pv-gallery="1"]').forEach(bindGallery);
  }

  window.pvGalleryBindLightbox = bindGallery;
  window.pvGalleryInitLightbox = init;

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => init(document));
  } else {
    init(document);
  }
})();
