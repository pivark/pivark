(() => {
  'use strict';

  function initCarousel(root) {
    const scope = root || document;
    scope.querySelectorAll('.pv-gallery-carousel-shell').forEach((shell) => {
      if (shell.dataset.pvCarouselBound === '1') return;
      shell.dataset.pvCarouselBound = '1';

      const gallery = shell.querySelector('.pv-gallery--carousel');
      if (!gallery) return;

      const prev = shell.querySelector('.pv-gallery-carousel-prev');
      const next = shell.querySelector('.pv-gallery-carousel-next');
      const items = Array.from(gallery.querySelectorAll('.pv-gallery-item'));
      if (!items.length) return;

      const autoplay = gallery.dataset.pvCarouselAutoplay === '1';
      const interval = Math.max(2000, Number(gallery.dataset.pvCarouselInterval) || 5000);
      const showDots = gallery.dataset.pvCarouselDots === '1';
      let timer = null;
      let paused = false;

      function scrollToIndex(index) {
        const item = items[index];
        if (!item) return;
        gallery.scrollTo({ left: item.offsetLeft, behavior: 'smooth' });
      }

      function currentIndex() {
        const scrollLeft = gallery.scrollLeft;
        let closest = 0;
        let minDiff = Infinity;
        items.forEach((item, index) => {
          const diff = Math.abs(item.offsetLeft - scrollLeft);
          if (diff < minDiff) {
            minDiff = diff;
            closest = index;
          }
        });
        return closest;
      }

      let dotsWrap = null;

      function setActiveDot(index) {
        if (!dotsWrap) return;
        dotsWrap.querySelectorAll('.pv-gallery-carousel-dot').forEach((dot, i) => {
          dot.classList.toggle('is-active', i === index);
          dot.setAttribute('aria-selected', i === index ? 'true' : 'false');
        });
      }

      if (showDots && items.length > 1) {
        dotsWrap = document.createElement('div');
        dotsWrap.className = 'pv-gallery-carousel-dots';
        dotsWrap.setAttribute('role', 'tablist');
        items.forEach((_, index) => {
          const dot = document.createElement('button');
          dot.type = 'button';
          dot.className = 'pv-gallery-carousel-dot' + (index === 0 ? ' is-active' : '');
          dot.setAttribute('role', 'tab');
          dot.setAttribute('aria-label', `第 ${index + 1} 张`);
          dot.setAttribute('aria-selected', index === 0 ? 'true' : 'false');
          dot.addEventListener('click', () => {
            pauseAutoplay();
            scrollToIndex(index);
          });
          dotsWrap.appendChild(dot);
        });
        shell.appendChild(dotsWrap);
      }

      function pauseAutoplay() {
        paused = true;
        if (timer) {
          clearInterval(timer);
          timer = null;
        }
      }

      function startAutoplay() {
        if (!autoplay || items.length < 2 || paused) return;
        if (timer) clearInterval(timer);
        timer = setInterval(() => {
          const index = currentIndex();
          scrollToIndex(index >= items.length - 1 ? 0 : index + 1);
        }, interval);
      }

      prev?.addEventListener('click', () => {
        pauseAutoplay();
        const index = currentIndex();
        scrollToIndex(Math.max(0, index - 1));
      });
      next?.addEventListener('click', () => {
        pauseAutoplay();
        const index = currentIndex();
        scrollToIndex(Math.min(items.length - 1, index + 1));
      });

      gallery.addEventListener(
        'scroll',
        () => {
          setActiveDot(currentIndex());
        },
        { passive: true },
      );

      gallery.addEventListener('mouseenter', pauseAutoplay);
      gallery.addEventListener('mouseleave', () => {
        if (autoplay) {
          paused = false;
          startAutoplay();
        }
      });
      gallery.addEventListener('focusin', pauseAutoplay);

      startAutoplay();
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => initCarousel(document));
  } else {
    initCarousel(document);
  }
})();
