<?php
declare(strict_types=1);

namespace weapp\doc_gallery\service;

use app\common\service\weapp\WeappConfigGateway;
use app\common\service\weapp\WeappInstallDemoService;
use think\facade\Db;

/** 图集插件：安装向导首次装插件时的默认演示数据 */
final class GalleryInstallDemoService
{
    public static function seed(): void
    {
        $cfg     = app(WeappConfigGateway::class);
        $tagSlug = 'pv-demo-gallery';
        $tagIds  = [
            $tagSlug => $cfg->installDemoUpsertTag([
                'slug'        => $tagSlug,
                'name'        => '应用案例',
                'tpl'         => 'list_document_gallery.php',

                'nav_sort'    => 6,
                'description' => '典型行业现场与项目实施图集',
                'url_path'    => 'cases',
            ]),
        ];
        $docId = $cfg->installDemoUpsertDocument(
            'pv-demo-gallery-01',
            '石化装置测控改造案例',
            '现场仪表安装与 DCS 接入示意，演示图集瀑布流展示。',
            '<p>本案例为插件自带演示数据，可在后台替换为真实项目图片。</p>',
        );
        $cfg->installDemoLinkDocumentTags($docId, [$tagSlug], $tagIds);
        $cfg->installDemoAppendContentCategoryNav('cases', '应用案例', 6);
        self::seedGalleryGroupAndItems($docId, 'masonry', '现场图集');
        $cfg->installDemoRefreshTagUseCounts();
    }

    private static function seedGalleryGroupAndItems(int $documentId, string $style, string $groupTitle): void
    {
        if ($documentId < 1) {
            return;
        }
        if (!WeappInstallDemoService::tableReady('weapp_doc_gallery_items')) {
            return;
        }
        $cfg   = app(WeappConfigGateway::class);
        $now   = WeappInstallDemoService::now();
        $style = GalleryLayoutService::normalize($style);
        $groupKey = 'default';
        $paths = [
            $cfg->installDemoPreviewImage(),
            '/uploads/demo-seed/product/01.jpg',
            '/uploads/demo-seed/product/02.jpg',
            '/uploads/demo-seed/product/03.jpg',
            '/uploads/demo-seed/gallery/01.jpg',
            '/uploads/demo-seed/gallery/02.jpg',
        ];

        if (WeappInstallDemoService::tableReady('weapp_doc_gallery_groups')) {
            Db::name('weapp_doc_gallery_groups')->where('document_id', $documentId)->delete();
            Db::name('weapp_doc_gallery_groups')->insert([
                'document_id'   => $documentId,
                'group_key'     => $groupKey,
                'title'         => $groupTitle,
                'display_style' => $style,
                'pack_download' => 0,
                'sort'          => 0,
                'status'        => 1,
                'created_at'    => $now,
                'updated_at'    => $now,
            ]);
        }

        Db::name('weapp_doc_gallery_items')->where('document_id', $documentId)->delete();
        $sort = 1;
        foreach ($paths as $path) {
            Db::name('weapp_doc_gallery_items')->insert([
                'document_id' => $documentId,
                'group_key'   => $groupKey,
                'image_path'  => $path,
                'title'       => '案例图 ' . $sort,
                'alt_text'    => '案例',
                'sort'        => $sort++,
                'status'      => 1,
                'created_at'  => $now,
                'updated_at'  => $now,
            ]);
        }
    }
}
