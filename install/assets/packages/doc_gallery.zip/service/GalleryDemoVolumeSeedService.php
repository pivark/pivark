<?php
/**
 * 元舟 PivArk — 企业全域原子化数字资产中枢
 * (c) 2024-2026 pivark.com. All rights reserved.
 * Author: Angelo
 * 未经允许，不可用于商业用途。
 *
 * 图集插件：发行演示加灌（案例频道 /cases · groups + items）
 */
declare(strict_types=1);

namespace weapp\doc_gallery\service;

use app\common\service\weapp\WeappConfigGateway;
use app\common\service\weapp\WeappInstallDemoService;
use app\common\service\weapp\WeappPluginGateway;
use think\facade\Db;

final class GalleryDemoVolumeSeedService
{
    /**
     * @return array{docs:int,wired:int}
     */
    public static function seed(): array
    {
        app(WeappPluginGateway::class)->pluginRegisterAutoloadPublic('doc_gallery');
        if (!WeappInstallDemoService::tableReady('weapp_doc_gallery_items')) {
            echo "SKIP GalleryDemoVolumeSeedService (gallery items table not ready)\n";

            return ['docs' => 0, 'wired' => 0];
        }

        $cfg = app(WeappConfigGateway::class);
        $tagSlug = 'pv-demo-gallery';
        $tagIds = [
            $tagSlug => $cfg->installDemoUpsertTag([
                'slug'        => $tagSlug,
                'name'        => '应用案例',
                'tpl'         => 'list_document_gallery.php',
                'nav_sort'    => 6,
                'description' => '典型行业现场与项目实施图集（演示加灌多布局）',
                'url_path'    => 'cases',
            ]),
        ];
        $cfg->installDemoAppendContentCategoryNav('cases', '应用案例', 6);

        $specs = [
            ['pv-demo-gallery-01', '石化装置测控改造案例', 'masonry', true],
            ['pv-demo-gallery-02', '钢铁连铸冷却回路仪表成套', 'grid', true],
            ['pv-demo-gallery-03', '2026 工博会展台与产品演示', 'hero', false],
            ['pv-demo-gallery-04', '罐区液位监测现场实施', 'justified', true],
            ['pv-demo-gallery-05', '公司研发与校准实验室', 'filmstrip', false],
            ['pv-demo-gallery-06', '膜片微距与传感器解剖', 'list', true],
            ['pv-demo-gallery-07', '市政泵站液位联锁改造', 'masonry', true],
            ['pv-demo-gallery-08', '智能工厂数据采集机柜', 'grid', false],
            ['pv-demo-gallery-09', '客户培训课堂与实操考核', 'hero', true],
            ['pv-demo-gallery-10', '分布式能源站仪表项目', 'justified', true],
            ['pv-demo-gallery-17', '制药纯化水系统压力监控改造', 'masonry', false],
            ['pv-demo-gallery-18', '冶金连铸冷却回路差压监测', 'grid', true],
            ['pv-demo-gallery-19', '城市综合管廊环境监测', 'filmstrip', false],
            ['pv-demo-gallery-20', 'LNG 接收站温度多点采集', 'masonry', true],
            ['pv-demo-gallery-21', '纸浆漂白工段液位联锁', 'grid', false],
            ['pv-demo-gallery-22', '机场加油管线压力巡检', 'justified', true],
            ['pv-demo-gallery-23', '医院洁净空调压差监测', 'list', false],
            ['pv-demo-gallery-24', '矿山选矿药剂流量计量', 'masonry', true],
        ];

        $docs = 0;
        $wired = 0;
        foreach ($specs as $idx => $spec) {
            [$html, $title, $style, $withCover] = $spec;
            $style = GalleryLayoutService::normalize((string) $style);
            // 社区种子已写好标题/正文时只挂图集表，禁止 Volume 覆盖成另一套文案
            $docId = $cfg->installDemoDocumentIdByHtml((string) $html);
            if ($docId < 1) {
                $summary = $title . ' · 现场实拍图集演示。';
                $content = '<p class="lead">' . htmlspecialchars($title, ENT_QUOTES, 'UTF-8') . '</p>'
                    . '<p>详情页以图集插件展示为主，避免重复大头图。本页用于验收布局与分组。</p>';
                $litpic = $withCover ? self::cover($idx + 1) : '';
                $docId = $cfg->installDemoUpsertDocument(
                    $html,
                    $title,
                    $summary,
                    $content,
                    $litpic,
                    $withCover ? 'has_image' : '',
                    700 + random_int(0, 1200),
                    0,
                    'view_document_gallery.php',
                );
            }
            if ($docId < 1) {
                continue;
            }
            $docs++;
            $cfg->installDemoLinkDocumentTags($docId, [$tagSlug], $tagIds);
            if (self::seedGalleryGroupAndItems($docId, $style, '现场图集', $idx)) {
                $wired++;
            }
        }
        $cfg->installDemoRefreshTagUseCounts();
        echo "OK GalleryDemoVolumeSeedService docs={$docs} wired={$wired}\n";

        return ['docs' => $docs, 'wired' => $wired];
    }

    private static function cover(int $n): string
    {
        $idx = (($n - 1) % 14) + 1;
        $rel = '/uploads/demo-seed/product/' . str_pad((string) $idx, 2, '0', STR_PAD_LEFT) . '.jpg';
        $abs = rtrim((string) ROOT_PATH, '/\\') . '/public' . $rel;

        return is_file($abs) ? $rel : '/uploads/demo-seed/product/01.jpg';
    }

    private static function seedGalleryGroupAndItems(int $documentId, string $style, string $groupTitle, int $seedIdx): bool
    {
        if ($documentId < 1 || !WeappInstallDemoService::tableReady('weapp_doc_gallery_items')) {
            return false;
        }
        $now = WeappInstallDemoService::now();
        $groupKey = 'default';
        $paths = [];
        for ($k = 0; $k < 5; $k++) {
            $paths[] = self::galleryPoolPath($seedIdx * 5 + $k);
        }

        try {
            if (WeappInstallDemoService::tableReady('weapp_doc_gallery_groups')) {
                Db::name('weapp_doc_gallery_groups')->where('document_id', $documentId)->delete();
                Db::name('weapp_doc_gallery_groups')->insert([
                    'document_id'   => $documentId,
                    'group_key'     => $groupKey,
                    'title'         => $groupTitle,
                    'display_style' => $style,
                    'pack_download' => 0,
                    'sort'          => 0,
                    'status'        => 1,
                    'created_at'    => $now,
                    'updated_at'    => $now,
                ]);
            }
            Db::name('weapp_doc_gallery_items')->where('document_id', $documentId)->delete();
            $sort = 1;
            foreach ($paths as $path) {
                Db::name('weapp_doc_gallery_items')->insert([
                    'document_id' => $documentId,
                    'group_key'   => $groupKey,
                    'image_path'  => $path,
                    'title'       => '现场实景 ' . $sort,
                    'alt_text'    => '案例',
                    'sort'        => $sort++,
                    'status'      => 1,
                    'created_at'  => $now,
                    'updated_at'  => $now,
                ]);
            }

            return true;
        } catch (\Throwable) {
            return false;
        }
    }

    private static function galleryPoolPath(int $n): string
    {
        $pool = [];
        for ($i = 1; $i <= 10; $i++) {
            $pool[] = '/uploads/demo-seed/gallery/' . str_pad((string) $i, 2, '0', STR_PAD_LEFT) . '.jpg';
            for ($j = 1; $j <= 6; $j++) {
                $pool[] = '/uploads/demo-seed/gallery/' . $i . '-' . $j . '.jpg';
            }
        }
        $rel = $pool[$n % count($pool)];
        $abs = rtrim((string) ROOT_PATH, '/\\') . '/public' . $rel;
        if (is_file($abs)) {
            return $rel;
        }

        return '/uploads/demo-seed/product/01.jpg';
    }
}
