<?php
declare(strict_types=1);

namespace weapp\doc_gallery\service;



use app\common\service\weapp\WeappDocumentGateway;
use app\common\service\weapp\WeappSupportGateway;
use app\common\service\weapp\WeappUploadGateway;
use app\common\support\ServiceResult;
use weapp\doc_gallery\model\WeappGalleryGroup;
use ZipArchive;
/** 图集分组 ↔ 打包下载 bridge（Registry 发现提供者，不写死插件 id） */
class GalleryDownloadBridgeService
{
    private const BUNDLE_SORT_BASE = 9000;

    /**
     * @return array<string, mixed>|null
     */
    private static function rowToArray(mixed $row): ?array
    {
        if ($row === null) {
            return null;
        }
        if (is_array($row)) {
            return $row;
        }
        if (is_object($row) && method_exists($row, 'toArray')) {
            $data = $row->toArray();

            return is_array($data) ? $data : null;
        }

        return null;
    }

    /** @return mixed */
    public static function syncForDocument(int $documentId)
    {
        if ($documentId < 1 || !GalleryService::isActive()) {
            return app(WeappSupportGateway::class)->resultOk(null, 'ok');
        }
        if (!self::downloadReady()) {
            self::clearAllPackBundles($documentId);

            return app(WeappSupportGateway::class)->resultOk(null, 'ok');
        }

        $bridgeId = self::packBridgeId();
        if ($bridgeId === null) {
            return app(WeappSupportGateway::class)->resultOk(null, 'ok');
        }

        if (!(bool) app(WeappDocumentGateway::class)->documentAddonBridgeInvokeOr(false, $bridgeId, 'documentEligible', [$documentId])) {
            return app(WeappSupportGateway::class)->resultFail('该文档不在 download 插件使用范围内，无法同步图集打包下载');
        }

        $groups = WeappGalleryGroup::where('document_id', $documentId)->select()->toArray();
        foreach ($groups as $group) {
            $groupId = (int) ($group['id'] ?? 0);
            $bundleId = (int) ($group['download_bundle_id'] ?? 0);
            $enabled = !empty($group['pack_download']) && (int) ($group['status'] ?? 0) === 1;

            if (!$enabled) {
                if ($bundleId > 0) {
                    app(WeappDocumentGateway::class)->documentAddonBridgeInvoke($bridgeId, 'delete', [$bundleId]);
                    WeappGalleryGroup::where('id', $groupId)->update(['download_bundle_id' => 0]);
                }
                continue;
            }

            $groupKey = GalleryService::normalizeGroupKey((string) ($group['group_key'] ?? 'default'));
            $items = GalleryService::listForDocument($documentId, true, $groupKey);
            $files = self::collectLocalFiles($items);
            if ($files === []) {
                if ($bundleId > 0) {
                    app(WeappDocumentGateway::class)->documentAddonBridgeInvoke($bridgeId, 'delete', [$bundleId]);
                    WeappGalleryGroup::where('id', $groupId)->update(['download_bundle_id' => 0]);
                }
                continue;
            }

            $zipRel = self::buildZip($documentId, $groupKey, $files);
            if ($zipRel === '') {
                return app(WeappSupportGateway::class)->resultFail('图集打包失败：无法生成 ZIP（请确认 PHP ZipArchive 可用）');
            }

            $absZip = self::publicAbsolute($zipRel);
            $zipSize = is_file($absZip) ? (int) filesize($absZip) : 0;
            $packAccess = self::packAccessFromGroup($group);
            $res = app(WeappDocumentGateway::class)->documentAddonBridgeInvoke($bridgeId, 'save', [[
                'id'               => $bundleId,
                'document_id'      => $documentId,
                'title'            => trim((string) ($group['title'] ?? '')) !== ''
                    ? trim((string) $group['title']) . ' · 原图包'
                    : '图集原图包',
                'access_mode'      => $packAccess['access_mode'],
                'member_level_id'  => $packAccess['member_level_id'],
                'points_cost'      => $packAccess['points_cost'],
                'sort'             => self::BUNDLE_SORT_BASE + (int) ($group['sort'] ?? 0),
                'status'           => 1,
                'items'            => [[
                    'source_type' => 'local',
                    'file_path'   => $zipRel,
                    'label'       => '打包下载 ZIP',
                    'file_size'   => $zipSize,
                    'sort'        => 0,
                    'status'      => 1,
                ]],
            ]]);
            if (!$res instanceof ServiceResult || !$res->isOk()) {
                return app(WeappSupportGateway::class)->resultFail($res instanceof ServiceResult ? (string) $res->message() : 'download save failed');
            }
            $newBundleId = (int) ($res['id'] ?? 0);
            if ($newBundleId > 0 && $groupId > 0) {
                WeappGalleryGroup::where('id', $groupId)->update([
                    'download_bundle_id' => $newBundleId,
                    'updated_at'         => app(WeappSupportGateway::class)->appTimeNow(),
                ]);
            }
        }

        return app(WeappSupportGateway::class)->resultOk(null, 'ok');
    }

    public static function purgeForDocument(int $documentId): void
    {
        if ($documentId < 1) {
            return;
        }
        self::clearAllPackBundles($documentId);
    }

    /**
     * @param array<string,mixed> $group
     * @return array<string, scalar>
     */
    public static function packFieldsForGroup(array $group, int $documentId): array
    {
        $enabled = !empty($group['pack_download'])
            && (int) ($group['status'] ?? 0) === 1
            && (int) ($group['download_bundle_id'] ?? 0) > 0;
        if (!$enabled || !self::downloadReady()) {
            return [
                'pack_download'            => 0,
                'pack_download_url'        => '',
                'pack_download_size_text'  => '',
                'pack_download_label'      => '',
            ];
        }

        $bundleId = (int) ($group['download_bundle_id'] ?? 0);
        $bridgeId = self::packBridgeId();
        if ($bridgeId === null) {
            return [
                'pack_download'            => 0,
                'pack_download_url'        => '',
                'pack_download_size_text'  => '',
                'pack_download_label'      => '',
            ];
        }

        $fields = app(WeappDocumentGateway::class)->documentAddonBridgeInvokeOr([], $bridgeId, 'packFieldsForGalleryBundle', [$bundleId]);

        return is_array($fields) ? $fields : [];
    }

    private static function packBridgeId(): ?string
    {
        return app(WeappDocumentGateway::class)->documentDownloadPackBridgeIdentifier();
    }

    /** 文档编辑器 / 前台：download 打包桥是否可用 */
    public static function isDownloadPluginReady(): bool
    {
        return self::downloadReady();
    }

    private static function downloadReady(): bool
    {
        $id = self::packBridgeId();

        return $id !== null && app(WeappDocumentGateway::class)->documentAddonBridgeIsEnabled($id);
    }

    private static function ensureDownloadLoaded(): void
    {
        // bridge handler 在 invoke 时自行 ensureAutoload
    }

    private static function clearAllPackBundles(int $documentId): void
    {
        if (!self::downloadReady()) {
            return;
        }
        $bridgeId = self::packBridgeId();
        if ($bridgeId === null) {
            return;
        }
        self::ensureDownloadLoaded();
        $bundleIds = WeappGalleryGroup::where('document_id', $documentId)
            ->where('download_bundle_id', '>', 0)
            ->column('download_bundle_id');
        foreach ($bundleIds as $bundleId) {
            $id = (int) $bundleId;
            if ($id > 0) {
                app(WeappDocumentGateway::class)->documentAddonBridgeInvoke($bridgeId, 'delete', [$id]);
            }
        }
        WeappGalleryGroup::where('document_id', $documentId)
            ->update(['download_bundle_id' => 0]);
    }

    /**
     * @param list<array<string,mixed>> $items
     * @return list<array{rel:string,name:string,abs:string}>
     */
    private static function collectLocalFiles(array $items): array
    {
        $out = [];
        $used = [];
        foreach ($items as $row) {
            $rel = trim((string) ($row['image_path'] ?? ''));
            if ($rel === '' || preg_match('#^https?://#i', $rel)) {
                continue;
            }
            $rel = GalleryImageService::relativeUploadPath($rel);
            if ($rel === '') {
                continue;
            }
            $abs = self::publicAbsolute($rel);
            $real = realpath($abs);
            $uploadsRoot = realpath(
                rtrim((string) (defined('ROOT_PATH') ? ROOT_PATH : ''), '/\\')
                . DIRECTORY_SEPARATOR . 'public' . DIRECTORY_SEPARATOR . 'uploads'
            );
            if ($real === false || $uploadsRoot === false || !str_starts_with($real, $uploadsRoot) || !is_file($real)) {
                continue;
            }
            $abs = $real;
            $base = basename($rel);
            $name = trim((string) ($row['title'] ?? ''));
            if ($name !== '') {
                $ext = pathinfo($base, PATHINFO_EXTENSION);
                $safe = preg_replace('/[^\p{L}\p{N}\-_\.]+/u', '-', $name) ?? $name;
                $safe = trim($safe, '-');
                if ($safe !== '') {
                    $base = $ext !== '' ? $safe . '.' . $ext : $safe;
                }
            }
            if (isset($used[$base])) {
                ++$used[$base];
                $dot = strrpos($base, '.');
                if ($dot !== false) {
                    $base = substr($base, 0, $dot) . '-' . $used[$base] . substr($base, $dot);
                } else {
                    $base .= '-' . $used[$base];
                }
            } else {
                $used[$base] = 1;
            }
            $out[] = ['rel' => $rel, 'name' => $base, 'abs' => $abs];
        }

        return $out;
    }

    /**
     * @param array<string, mixed> $group
     * @return array{access_mode:string,member_level_id:int,points_cost:int}
     */
    private static function packAccessFromGroup(array $group): array
    {
        $norm = GalleryService::normalizePackAccess([
            'pack_access_mode'     => $group['pack_access_mode'] ?? 'free',
            'pack_member_level_id' => $group['pack_member_level_id'] ?? 0,
            'pack_points_cost'     => $group['pack_points_cost'] ?? 0,
        ]);

        return [
            'access_mode'     => $norm['pack_access_mode'],
            'member_level_id' => $norm['pack_member_level_id'],
            'points_cost'     => $norm['pack_points_cost'],
        ];
    }

    /**
     * @param list<array{rel:string,name:string,abs?:string}> $files
     */
    private static function buildZip(int $documentId, string $groupKey, array $files): string
    {
        if (!class_exists(ZipArchive::class) || $files === []) {
            return '';
        }

        $tmp = rtrim(sys_get_temp_dir(), '/\\') . DIRECTORY_SEPARATOR
            . 'pivark_gallery_pack_' . $documentId . '_' . preg_replace('/[^a-zA-Z0-9_\-]+/', '_', $groupKey)
            . '_' . uniqid('', true) . '.zip';
        $zip = new ZipArchive();
        if ($zip->open($tmp, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) {
            return '';
        }
        foreach ($files as $file) {
            $path = (string) ($file['abs'] ?? '');
            if ($path === '' || !is_file($path)) {
                $path = self::publicAbsolute($file['rel']);
            }
            if (is_file($path)) {
                $zip->addFile($path, $file['name']);
            }
        }
        $zip->close();
        if (!is_file($tmp)) {
            return '';
        }

        $rel = 'uploads/doc_gallery_pack/' . $documentId . '/' . $groupKey . '.zip';
        $stored = app(WeappUploadGateway::class)->putGeneratedUnderUploads($rel, $tmp);
        @unlink($tmp);

        return $stored;
    }

    private static function publicAbsolute(string $relOrPath): string
    {
        $path = ltrim(str_replace('\\', '/', $relOrPath), '/');
        if (str_starts_with($path, 'public/')) {
            $path = substr($path, 7);
        }

        return rtrim((string) (defined('ROOT_PATH') ? ROOT_PATH : ''), '/\\')
            . DIRECTORY_SEPARATOR . 'public' . DIRECTORY_SEPARATOR
            . str_replace('/', DIRECTORY_SEPARATOR, $path);
    }
}
