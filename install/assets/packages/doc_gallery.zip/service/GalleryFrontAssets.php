<?php
declare(strict_types=1);

namespace weapp\doc_gallery\service;

use app\common\service\weapp\WeappFrontGateway;

/** 登记图集前台静态资源（默认兜底 · 随插件分发，勿复制到主题目录） */
final class GalleryFrontAssets
{
    public static function registerLayout(string $layout, bool $lightbox = false): void
    {
        $gw = app(WeappFrontGateway::class);
        $gw->frontAssetRegisterWeappStylesheet('doc_gallery', 'pv-gallery-css', 'assets/css/gallery.css');
        $style = strtolower(trim($layout));

        if (in_array($style, ['carousel', 'filmstrip', 'hero'], true)) {
            $gw->frontAssetRegisterWeappStylesheet(
                'doc_gallery',
                'pv-gallery-swiper-css',
                'assets/lib/swiper/swiper-bundle.min.css'
            );
            $gw->frontAssetRegisterWeappScript(
                'doc_gallery',
                'pv-gallery-swiper-lib',
                'assets/lib/swiper/swiper-bundle.min.js'
            );
            $gw->frontAssetRegisterWeappScript(
                'doc_gallery',
                'pv-gallery-swiper',
                'assets/js/swiper-gallery.js'
            );
        }

        if ($style === 'masonry') {
            $gw->frontAssetRegisterWeappScript('doc_gallery', 'pv-gallery-masonry', 'assets/js/masonry.js');
        }

        // 点图放大：默认随图集页加载（配置关闭时仍可按需由调用方关闭 data 属性）
        if ($lightbox || GalleryConfigService::lightboxEnabled()) {
            $gw->frontAssetRegisterWeappScript('doc_gallery', 'pv-gallery-lightbox', 'assets/js/lightbox.js');
        }
    }
}
