<?php
declare(strict_types=1);

namespace weapp\doc_gallery\service;

/** 对齐 WeappInstallDemoService 对 identifier=doc_gallery 的 DocGallery* 解析 */
final class DocGalleryInstallDemoService
{
    public static function seed(): void
    {
        GalleryInstallDemoService::seed();
    }
}
