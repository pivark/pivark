<?php
declare(strict_types=1);

namespace weapp\doc_gallery\service;


use app\common\service\weapp\WeappConfigGateway;
use app\common\service\weapp\WeappDocumentGateway;
use app\common\service\weapp\WeappEntitlementGateway;
use app\common\service\weapp\WeappPluginGateway;
use app\common\service\weapp\WeappSiteGateway;
use app\common\service\weapp\WeappSupportGateway;
use weapp\doc_gallery\model\WeappGalleryItem;

/** 文档图集 全局配置 */
class GalleryConfigService
{
    public const SCOPE_ALL = 'all';
    public const SCOPE_NAVS = 'navs';

    /** @return list<string> */
    public static function keys(): array
    {
        return [
            'gallery_open',
            'gallery_document_editor_slot',
            'gallery_nav_scope',
            'gallery_allowed_nav_ids',
            'gallery_respect_document_read',
            'gallery_min_read_level_id',
            'gallery_lightbox',
            'gallery_thumb_width',
            'gallery_default_row',
            'gallery_default_display_style',
            'gallery_srcset',
            'gallery_watermark_thumbs',
            'gallery_list_thumb_fallback',
            'gallery_litpic_from_first',
            'gallery_plaza_open',
            'gallery_carousel_autoplay',
            'gallery_carousel_interval',
            'gallery_unify_thumb_size',
            'gallery_probe_remote_size',
        ];
    }

    /** @return array<string, string> */
    public static function all(): array
    {
        $out = [];
        foreach (self::keys() as $key) {
            $out[$key] = (string) app(WeappConfigGateway::class)->configGet($key, self::defaultFor($key));
        }
        $out['gallery_document_editor_slot'] = app(WeappPluginGateway::class)->pluginEditorResolveSlot('doc_gallery');

        return $out;
    }

    public static function defaultFor(string $key): string
    {
        return match ($key) {
            'gallery_open' => '1',
            'gallery_document_editor_slot' => app(WeappPluginGateway::class)->pluginEditorManifestDefaultSlot('doc_gallery'),
            'gallery_nav_scope' => self::SCOPE_ALL,
            'gallery_allowed_nav_ids' => '[]',
            'gallery_respect_document_read' => '1',
            'gallery_min_read_level_id' => '0',
            'gallery_lightbox' => '1',
            'gallery_thumb_width' => '400',
            'gallery_default_row' => '0',
            'gallery_default_display_style' => 'grid',
            'gallery_srcset' => '1',
            'gallery_watermark_thumbs' => '0',
            'gallery_list_thumb_fallback' => '1',
            'gallery_litpic_from_first' => 'empty',
            'gallery_plaza_open' => '1',
            'gallery_carousel_autoplay' => '0',
            'gallery_carousel_interval' => '5',
            'gallery_unify_thumb_size' => '1',
            'gallery_probe_remote_size' => '1',
            default => '',
        };
    }

    public static function srcsetEnabled(): bool
    {
        return (string) app(WeappConfigGateway::class)->configGet('gallery_srcset', '1') === '1';
    }

    public static function watermarkThumbs(): bool
    {
        return (string) app(WeappConfigGateway::class)->configGet('gallery_watermark_thumbs', '0') === '1';
    }

    public static function listThumbFallback(): bool
    {
        return (string) app(WeappConfigGateway::class)->configGet('gallery_list_thumb_fallback', '1') === '1';
    }

    /** 图集首图写入文档封面：off | empty（仅无封面时）| always（始终跟图集首图） */
    public static function litpicFromFirstMode(): string
    {
        if (!self::listThumbFallback()) {
            return 'off';
        }
        $mode = strtolower(trim((string) app(WeappConfigGateway::class)->configGet('gallery_litpic_from_first', 'empty')));

        return in_array($mode, ['empty', 'always'], true) ? $mode : 'empty';
    }

    public static function shouldApplyGalleryFirstLitpic(string $currentLitpic): bool
    {
        $mode = self::litpicFromFirstMode();
        if ($mode === 'off') {
            return false;
        }
        if ($mode === 'always') {
            return true;
        }

        return trim($currentLitpic) === '';
    }

    public static function documentNeedsGalleryFirstLitpic(string $currentLitpic): bool
    {
        return self::shouldApplyGalleryFirstLitpic($currentLitpic);
    }

    public static function plazaOpen(): bool
    {
        return (string) app(WeappConfigGateway::class)->configGet('gallery_plaza_open', '1') === '1';
    }

    public static function carouselAutoplay(): bool
    {
        return (string) app(WeappConfigGateway::class)->configGet('gallery_carousel_autoplay', '0') === '1';
    }

    public static function carouselIntervalSec(): int
    {
        return max(2, min(60, (int) app(WeappConfigGateway::class)->configGet('gallery_carousel_interval', '5')));
    }

    public static function unifyThumbSize(): bool
    {
        return (string) app(WeappConfigGateway::class)->configGet('gallery_unify_thumb_size', '1') === '1';
    }

    public static function probeRemoteSize(): bool
    {
        return (string) app(WeappConfigGateway::class)->configGet('gallery_probe_remote_size', '1') === '1';
    }

    public static function effectiveThumbWidth(): int
    {
        if (self::unifyThumbSize()
            && app(WeappEntitlementGateway::class)->entitlementCan('doc_thumb')
            && is_dir(ROOT_PATH . 'weapp/doc_thumb')) {
            app(WeappPluginGateway::class)->pluginRegisterAutoloadPublic('doc_thumb');
            \weapp\doc_thumb\service\ThumbnailService::ensureAutoload();
            $cfg = \weapp\doc_thumb\service\ThumbnailConfigService::runtimeConfig();

            return max(40, (int) ($cfg['width'] ?? 400));
        }

        return self::thumbWidth();
    }

    public static function effectiveThumbHeight(): int
    {
        if (self::unifyThumbSize()
            && app(WeappEntitlementGateway::class)->entitlementCan('doc_thumb')
            && is_dir(ROOT_PATH . 'weapp/doc_thumb')) {
            app(WeappPluginGateway::class)->pluginRegisterAutoloadPublic('doc_thumb');
            \weapp\doc_thumb\service\ThumbnailService::ensureAutoload();
            $cfg = \weapp\doc_thumb\service\ThumbnailConfigService::runtimeConfig();

            return max(40, (int) ($cfg['height'] ?? 300));
        }

        return 0;
    }

    public static function isOpen(): bool
    {
        return (string) app(WeappConfigGateway::class)->configGet('gallery_open', '1') === '1';
    }

    public static function scope(): string
    {
        $scope = (string) app(WeappConfigGateway::class)->configGet('gallery_nav_scope', self::SCOPE_ALL);

        return in_array($scope, [self::SCOPE_ALL, self::SCOPE_NAVS], true)
            ? $scope
            : self::SCOPE_ALL;
    }

    /** @return list<int> */
    public static function allowedNavIds(): array
    {
        return self::decodeIdList((string) app(WeappConfigGateway::class)->configGet('gallery_allowed_nav_ids', '[]'));
    }

    /** @return list<int> 勾选栏目含子孙 */
    public static function allowedNavIdsExpanded(): array
    {
        return app(WeappSiteGateway::class)->siteNavExpandWithDescendants(self::allowedNavIds());
    }

    public static function respectDocumentRead(): bool
    {
        return (string) app(WeappConfigGateway::class)->configGet('gallery_respect_document_read', '1') === '1';
    }

    public static function minReadLevelId(): int
    {
        return max(0, (int) app(WeappConfigGateway::class)->configGet('gallery_min_read_level_id', '0'));
    }

    public static function lightboxEnabled(): bool
    {
        return (string) app(WeappConfigGateway::class)->configGet('gallery_lightbox', '1') === '1';
    }

    public static function thumbWidth(): int
    {
        return max(0, min(2000, (int) app(WeappConfigGateway::class)->configGet('gallery_thumb_width', '400')));
    }

    public static function defaultRow(): int
    {
        return max(0, min(100, (int) app(WeappConfigGateway::class)->configGet('gallery_default_row', '0')));
    }

    public static function defaultDisplayStyle(): string
    {
        return GalleryLayoutService::normalize(
            (string) app(WeappConfigGateway::class)->configGet('gallery_default_display_style', 'grid')
        );
    }

    public static function scopeLabel(): string
    {
        return match (self::scope()) {
            self::SCOPE_NAVS => '指定栏目',
            default          => '全部文档',
        };
    }

    /**
     * @param list<int> $documentIds
     * @return list<int>
     */
    public static function filterEligibleDocumentIds(array $documentIds): array
    {
        $documentIds = array_values(array_unique(array_filter(array_map('intval', $documentIds), static fn (int $id): bool => $id > 0)));
        if ($documentIds === []) {
            return [];
        }
        if (self::scope() === self::SCOPE_ALL) {
            return $documentIds;
        }

        return app(WeappDocumentGateway::class)->documentFilterIdsByPrimaryNav(
            $documentIds,
            self::allowedNavIdsExpanded()
        );
    }

    public static function documentEligible(int $documentId): bool
    {
        if ($documentId < 1) {
            return false;
        }

        if (self::scope() === self::SCOPE_ALL) {
            return true;
        }

        $navId = app(WeappDocumentGateway::class)->documentPrimaryNavId($documentId);
        if ($navId < 1) {
            return false;
        }

        return in_array($navId, self::allowedNavIdsExpanded(), true);
    }

    /** @param array<string, mixed> $post @return mixed */
    public static function saveAdmin(array $post)
    {
        app(WeappConfigGateway::class)->configSet('gallery_open', !empty($post['gallery_open']) ? '1' : '0');

        $scope = (string) ($post['gallery_nav_scope'] ?? self::SCOPE_ALL);
        if (!in_array($scope, [self::SCOPE_ALL, self::SCOPE_NAVS], true)) {
            return app(WeappSupportGateway::class)->resultFail('使用范围无效');
        }
        $navIds = self::normalizePostedIds($post['gallery_allowed_nav_ids'] ?? []);
        if ($scope === self::SCOPE_NAVS && $navIds === []) {
            return app(WeappSupportGateway::class)->resultFail('请至少选择一个网站栏目');
        }

        app(WeappConfigGateway::class)->configSet('gallery_nav_scope', $scope);
        app(WeappConfigGateway::class)->configSet('gallery_allowed_nav_ids', json_encode($navIds, JSON_UNESCAPED_UNICODE));
        // 禁兼容：退役旧 Tag 圈选键（真删行，不留空值壳）
        app(WeappConfigGateway::class)->configDeleteKeys([
            'gallery_tag_scope',
            'gallery_allowed_tag_group_ids',
            'gallery_allowed_tag_ids',
        ]);
        app(WeappConfigGateway::class)->configSet(
            'gallery_respect_document_read',
            !empty($post['gallery_respect_document_read']) ? '1' : '0'
        );
        app(WeappConfigGateway::class)->configSet(
            'gallery_min_read_level_id',
            (string) max(0, (int) ($post['gallery_min_read_level_id'] ?? 0))
        );
        app(WeappConfigGateway::class)->configSet('gallery_lightbox', !empty($post['gallery_lightbox']) ? '1' : '0');
        app(WeappConfigGateway::class)->configSet(
            'gallery_thumb_width',
            (string) max(0, min(2000, (int) ($post['gallery_thumb_width'] ?? 400)))
        );
        app(WeappConfigGateway::class)->configSet(
            'gallery_default_row',
            (string) max(0, min(100, (int) ($post['gallery_default_row'] ?? 0)))
        );
        app(WeappConfigGateway::class)->configSet(
            'gallery_default_display_style',
            GalleryLayoutService::normalize((string) ($post['gallery_default_display_style'] ?? 'grid'))
        );
        app(WeappConfigGateway::class)->configSet('gallery_srcset', !empty($post['gallery_srcset']) ? '1' : '0');
        app(WeappConfigGateway::class)->configSet(
            'gallery_watermark_thumbs',
            !empty($post['gallery_watermark_thumbs']) ? '1' : '0'
        );
        app(WeappConfigGateway::class)->configSet(
            'gallery_list_thumb_fallback',
            !empty($post['gallery_list_thumb_fallback']) ? '1' : '0'
        );
        $litpicMode = strtolower(trim((string) ($post['gallery_litpic_from_first'] ?? 'empty')));
        if (!in_array($litpicMode, ['empty', 'always'], true)) {
            $litpicMode = 'empty';
        }
        app(WeappConfigGateway::class)->configSet('gallery_litpic_from_first', $litpicMode);
        app(WeappConfigGateway::class)->configSet('gallery_plaza_open', !empty($post['gallery_plaza_open']) ? '1' : '0');
        app(WeappConfigGateway::class)->configSet(
            'gallery_carousel_autoplay',
            !empty($post['gallery_carousel_autoplay']) ? '1' : '0'
        );
        app(WeappConfigGateway::class)->configSet(
            'gallery_carousel_interval',
            (string) max(2, min(60, (int) ($post['gallery_carousel_interval'] ?? 5)))
        );
        app(WeappConfigGateway::class)->configSet(
            'gallery_unify_thumb_size',
            !empty($post['gallery_unify_thumb_size']) ? '1' : '0'
        );
        app(WeappConfigGateway::class)->configSet(
            'gallery_probe_remote_size',
            !empty($post['gallery_probe_remote_size']) ? '1' : '0'
        );

        if (array_key_exists('gallery_document_editor_slot', $post)) {
            $slotRes = app(WeappPluginGateway::class)->pluginEditorSaveSiteSlot(
                'doc_gallery',
                (string) ($post['gallery_document_editor_slot'] ?? '')
            );
            if (!$slotRes->isOk()) {
                return $slotRes;
            }
        }

        app(WeappPluginGateway::class)->pluginAfterConfigSaved('documents');

        return app(WeappSupportGateway::class)->resultOk(null, '保存成功');
    }

    /**
     * 运营完成度检查
     *
     * @return array{
     *   checks:list<array{key:string,label:string,count:int,severity:string,hint:string,route:string}>,
     *   score:int
     * }
     */
    public static function healthCheckAdmin(): array
    {
        $checks = [];
        $missingAlt = (int) WeappGalleryItem::where('status', 1)
            ->where(function ($q): void {
                $q->whereNull('alt_text')->whereOr('alt_text', '');
            })
            ->count();
        $checks[] = [
            'key'      => 'missing_alt',
            'label'    => '启用条目缺 Alt 文本',
            'count'    => $missingAlt,
            'severity' => $missingAlt > 0 ? 'warning' : 'ok',
            'hint'     => 'Alt 有助于无障碍与 SEO，请在条目管理或文档图集面板补全',
            'route'    => '/weapp/host/doc_gallery/list',
        ];

        $noTitle = (int) WeappGalleryItem::where('status', 1)
            ->where(function ($q): void {
                $q->whereNull('title')->whereOr('title', '');
            })
            ->count();
        $checks[] = [
            'key'      => 'missing_title',
            'label'    => '启用条目缺标题',
            'count'    => $noTitle,
            'severity' => $noTitle > 0 ? 'info' : 'ok',
            'hint'     => '标题会显示在 figcaption，建议填写',
            'route'    => '/weapp/host/doc_gallery/list',
        ];

        $outOfScope = 0;
        if (self::scope() !== self::SCOPE_ALL) {
            $docIds = WeappGalleryItem::distinct(true)->column('document_id');
            foreach ($docIds as $docId) {
                if (!self::documentEligible((int) $docId)) {
                    $outOfScope++;
                }
            }
        }
        $checks[] = [
            'key'      => 'out_of_scope_docs',
            'label'    => '范围外文档仍有图集',
            'count'    => $outOfScope,
            'severity' => $outOfScope > 0 ? 'warning' : 'ok',
            'hint'     => '调整使用范围或迁移图集到符合范围的文档',
            'route'    => '/weapp/host/doc_gallery/settings',
        ];

        $penalty = 0;
        foreach ($checks as $check) {
            if ($check['severity'] === 'warning') {
                $penalty += min(30, (int) $check['count'] * 5);
            } elseif ($check['severity'] === 'info' && (int) $check['count'] > 0) {
                $penalty += 5;
            }
        }

        return [
            'checks' => $checks,
            'score'  => max(0, 100 - $penalty),
        ];
    }

    /**
     * @param mixed $raw
     * @return list<int>
     */
    private static function normalizePostedIds($raw): array
    {
        if (is_string($raw) && $raw !== '') {
            $decoded = json_decode($raw, true);
            if (is_array($decoded)) {
                $raw = $decoded;
            } else {
                $raw = array_filter(array_map('trim', explode(',', $raw)));
            }
        }
        if (!is_array($raw)) {
            return [];
        }
        $out = [];
        foreach ($raw as $id) {
            $id = (int) $id;
            if ($id > 0) {
                $out[] = $id;
            }
        }

        return array_values(array_unique($out));
    }

    /** @return list<int> */
    private static function decodeIdList(string $json): array
    {
        $decoded = json_decode($json, true);

        return is_array($decoded) ? self::normalizePostedIds($decoded) : [];
    }
}
