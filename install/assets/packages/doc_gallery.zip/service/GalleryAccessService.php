<?php
declare(strict_types=1);

namespace weapp\doc_gallery\service;

use app\common\service\weapp\WeappDocumentGateway;
use app\common\service\weapp\WeappFrontGateway;
use app\common\service\weapp\WeappMemberGateway;

/** 图集前台可见性（文档阅读权限 + 可选最低会员等级） */
class GalleryAccessService
{
    /**
     * @param array<string, mixed>|null $document
     * @param array<string, mixed>|null $member
     */
    public static function canViewGallery(?array $document, ?array $member = null): bool
    {
        if (!GalleryService::isActive()) {
            return false;
        }
        if (!is_array($document) || (int) ($document['id'] ?? 0) < 1) {
            return false;
        }
        $documentId = (int) $document['id'];
        if (!GalleryConfigService::documentEligible($documentId)) {
            return false;
        }
        if (GalleryConfigService::respectDocumentRead()) {
            $member ??= app(WeappFrontGateway::class)->frontCurrent();
            if (!app(WeappMemberGateway::class)->memberLevelCanReadDocument($document, $member)) {
                return false;
            }
        }
        $minLevel = GalleryConfigService::minReadLevelId();
        if ($minLevel > 0) {
            $member ??= app(WeappFrontGateway::class)->frontCurrent();
            if ($member === null) {
                return false;
            }
            $memberLevel = (int) ($member['member_level_id'] ?? 0);
            if ($memberLevel < $minLevel) {
                return false;
            }
        }

        return true;
    }

    public static function canViewDocumentId(int $documentId): bool
    {
        if ($documentId < 1) {
            return false;
        }
        $document = GalleryService::documentToArray(app(WeappDocumentGateway::class)->documentRowById($documentId, false));

        return self::canViewGallery($document);
    }
}
