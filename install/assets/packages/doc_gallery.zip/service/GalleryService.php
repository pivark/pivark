<?php
declare(strict_types=1);

namespace weapp\doc_gallery\service;



use weapp\doc_gallery\model\WeappGalleryGroup;
use weapp\doc_gallery\model\WeappGalleryItem;
use app\common\service\weapp\WeappDocumentGateway;
use app\common\service\weapp\WeappEntitlementGateway;
use app\common\service\weapp\WeappFrontGateway;
use app\common\service\weapp\WeappPluginGateway;
use app\common\service\weapp\WeappSearchGateway;
use app\common\service\weapp\WeappSupportGateway;
use app\common\service\weapp\WeappTemplateGateway;
use think\facade\Db;

/** 文档图集 业务逻辑 */
class GalleryService
{
    public static function ensureAutoload(): void
    {
        // no-op; class loaded by Plugin::boot or bridge
    }

    /**
     * @param mixed $document Document 模型或数组行
     * @return array<string, mixed>|null
     */
    public static function documentToArray($document): ?array
    {
        if ($document === null) {
            return null;
        }
        if (is_array($document)) {
            return $document;
        }
        if (is_object($document) && method_exists($document, 'toArray')) {
            $row = $document->toArray();

            return is_array($row) ? $row : null;
        }

        return null;
    }

    public static function boot(): void
    {
        app(WeappPluginGateway::class)->pluginRouteRegister(
            'get',
            'api/v1/plugins/doc_gallery/document-items',
            '\\weapp\\doc_gallery\\api\\controller\\Gallery@documentItems'
        );
        app(WeappPluginGateway::class)->pluginRouteRegister(
            'get',
            'api/v1/plugins/doc_gallery/document-groups',
            '\\weapp\\doc_gallery\\api\\controller\\Gallery@documentGroups'
        );
        app(WeappPluginGateway::class)->pluginRouteRegister(
            'get',
            'api/v1/plugins/doc_gallery/thumb',
            '\\weapp\\doc_gallery\\api\\controller\\Gallery@thumb'
        );
        app(WeappPluginGateway::class)->pluginRouteRegister(
            'get',
            'api/v1/plugins/doc_gallery/plaza',
            '\\weapp\\doc_gallery\\api\\controller\\Gallery@plaza'
        );
    }

    private static bool $schemaApplied = false;

    public static function ensureSchema(): void
    {
        if (self::$schemaApplied) {
            return;
        }
        app(WeappPluginGateway::class)->weappSchemaApply('doc_gallery');
        self::$schemaApplied = true;
    }

    public static function isActive(): bool
    {
        return app(WeappEntitlementGateway::class)->entitlementCan('doc_gallery') && GalleryConfigService::isOpen();
    }

    /**
     * @param array<string, mixed> $attrs
     * @param array<string, mixed> $pageVars
     */
    public static function resolveDocumentId(array $attrs, array $pageVars): int
    {
        return (int) ($attrs['id'] ?? $attrs['aid'] ?? $attrs['document_id'] ?? $pageVars['document_id'] ?? 0);
    }

    /** @param array<string,mixed> $attrs */
    public static function resolveGroupKey(array $attrs): string
    {
        $raw = trim((string) ($attrs['group'] ?? $attrs['group_key'] ?? 'default'));
        if ($raw === '' || $raw === 'all') {
            return $raw === 'all' ? 'all' : 'default';
        }

        return self::normalizeGroupKey($raw);
    }

    public static function normalizeGroupKey(string $key): string
    {
        $key = strtolower(trim($key));
        $key = preg_replace('/[^a-z0-9_-]+/', '-', $key) ?? '';
        $key = trim($key, '-');

        return $key !== '' ? $key : 'default';
    }

    /**
     * @return array{groups:list<array<string,mixed>>,items:list<array<string,mixed>>}
     */
    public static function payloadForDocument(int $documentId, bool $publicOnly = false): array
    {
        return [
            'groups' => self::listGroupsForDocument($documentId, $publicOnly),
            'items'  => self::listForDocument($documentId, $publicOnly, null),
        ];
    }

    /**
     * 前台有启用图集分组的文档 ID（arclist has=doc_gallery）。
     *
     * @return list<int>
     */
    public static function documentIdsWithPublicAvailability(): array
    {
        if (!self::isActive()) {
            return [];
        }
        try {
            $ids = WeappGalleryGroup::where('status', 1)
                ->where('document_id', '>', 0)
                ->distinct(true)
                ->column('document_id');
        } catch (\Throwable $e) {
            app(WeappSupportGateway::class)->kernelOpsLog('gallery_document_ids_availability_failed', [
                'msg' => $e->getMessage(),
            ]);

            return [];
        }

        return array_values(array_unique(array_filter(array_map('intval', $ids ?: []), static fn (int $id): bool => $id > 0)));
    }

    /** @return list<array<string,mixed>> */
    public static function listGroupsForDocument(int $documentId, bool $publicOnly = true): array
    {
        if (!self::isActive() || $documentId < 1) {
            return [];
        }
        $query = WeappGalleryGroup::where('document_id', $documentId);
        if ($publicOnly) {
            $query->where('status', 1);
        }

        $rows = $query->order(['sort' => 'asc', 'id' => 'asc'])->select()->toArray();
        foreach ($rows as &$row) {
            $style = trim((string) ($row['display_style'] ?? ''));
            $row['display_style'] = $style !== ''
                ? GalleryLayoutService::normalize($style)
                : GalleryConfigService::defaultDisplayStyle();
            $row['display_style_label'] = GalleryLayoutService::label($row['display_style']);
        }
        unset($row);
        if ($rows === [] && self::documentHasGalleryItems($documentId, $publicOnly)) {
            return [[
                'id'            => 0,
                'document_id'   => $documentId,
                'group_key'     => 'default',
                'title'         => '默认图集',
                'display_style' => GalleryConfigService::defaultDisplayStyle(),
                'sort'          => 0,
                'status'        => 1,
            ]];
        }

        return array_values($rows);
    }

    /** 勿调用 listForDocument，避免与 enabledGroupKeys 循环 */
    private static function documentHasGalleryItems(int $documentId, bool $publicOnly): bool
    {
        if ($documentId < 1) {
            return false;
        }
        $query = WeappGalleryItem::where('document_id', $documentId);
        if ($publicOnly) {
            $query->where('status', 1);
        }

        return (int) $query->limit(1)->value('id') > 0;
    }

    /** @return list<array<string,mixed>> */
    public static function listForDocument(int $documentId, bool $publicOnly = true, ?string $groupKey = null): array
    {
        if (!self::isActive() || $documentId < 1) {
            return [];
        }
        if (!GalleryConfigService::documentEligible($documentId)) {
            return [];
        }

        $query = WeappGalleryItem::where('document_id', $documentId);
        if ($publicOnly) {
            $query->where('status', 1);
            $enabledKeys = self::enabledGroupKeys($documentId);
            if ($enabledKeys !== []) {
                $query->whereIn('group_key', $enabledKeys);
            }
        }
        if ($groupKey !== null && $groupKey !== 'all') {
            $normalizedKey = self::normalizeGroupKey($groupKey);
            if ($publicOnly) {
                $enabledKeys = self::enabledGroupKeys($documentId);
                if ($enabledKeys !== [] && !in_array($normalizedKey, $enabledKeys, true)) {
                    return [];
                }
            }
            $query->where('group_key', $normalizedKey);

            return array_values($query->order(['sort' => 'asc', 'id' => 'asc'])->select()->toArray());
        }

        return array_values($query->order(['sort' => 'asc', 'id' => 'asc'])->select()->toArray());
    }

    /** @return list<string> */
    private static function enabledGroupKeys(int $documentId): array
    {
        $groups = self::listGroupsForDocument($documentId, true);
        if ($groups === []) {
            return ['default'];
        }

        return array_map(
            static fn (array $row): string => self::normalizeGroupKey((string) ($row['group_key'] ?? 'default')),
            $groups
        );
    }

    public static function firstListThumbForDocument(int $documentId): string
    {
        if ($documentId < 1) {
            return '';
        }
        $map = self::firstListThumbsForDocuments([$documentId]);

        return $map[$documentId] ?? '';
    }

    /**
     * 图集首张原图 URL（写入 documents.litpic 用）
     */
    public static function firstImagePublicPathForDocument(int $documentId): string
    {
        if ($documentId < 1) {
            return '';
        }
        $map = self::firstImagePublicPathsForDocuments([$documentId]);

        return $map[$documentId] ?? '';
    }

    /**
     * @param list<int> $documentIds
     * @return array<int, string> document_id => public image url
     */
    public static function firstImagePublicPathsForDocuments(array $documentIds): array
    {
        return self::firstImagePathMapForDocuments($documentIds, false);
    }

    /**
     * 列表缩略图回退：按文档 ID 批量取各文档首图（避免 N 次 listForDocument）
     *
     * @param list<int> $documentIds
     * @return array<int, string> document_id => thumb url
     */
    public static function firstListThumbsForDocuments(array $documentIds): array
    {
        return self::firstImagePathMapForDocuments($documentIds, true);
    }

    /**
     * @param list<int> $documentIds
     * @return array<int, string>
     */
    private static function firstImagePathMapForDocuments(array $documentIds, bool $asThumbUrl): array
    {
        $documentIds = array_values(array_unique(array_filter(array_map('intval', $documentIds), static fn (int $id): bool => $id > 0)));
        if ($documentIds === [] || !self::isActive() || !GalleryConfigService::listThumbFallback()) {
            return [];
        }

        $eligible = GalleryConfigService::filterEligibleDocumentIds($documentIds);
        if ($eligible === []) {
            return [];
        }

        self::ensureSchema();
        $rows = WeappGalleryItem::whereIn('document_id', $eligible)
            ->where('status', 1)
            ->field('document_id,image_path')
            ->order(['document_id' => 'asc', 'sort' => 'asc', 'id' => 'asc'])
            ->select()
            ->toArray();

        $out = [];
        foreach ($rows as $row) {
            $docId = (int) ($row['document_id'] ?? 0);
            if ($docId < 1 || isset($out[$docId])) {
                continue;
            }
            $path = trim((string) $row['image_path']);
            if ($path === '') {
                continue;
            }
            $public = self::publicUrl($path);
            $out[$docId] = $asThumbUrl ? self::thumbUrl($public) : $public;
        }

        return $out;
    }

    /** 保存图集后，将首图同步到 documents.litpic（受 gallery_litpic_from_first 控制） */
    public static function syncDocumentLitpicFromFirst(int $documentId): void
    {
        if ($documentId < 1 || !self::isActive() || !GalleryConfigService::listThumbFallback()) {
            return;
        }
        $document = self::documentToArray(app(WeappDocumentGateway::class)->documentRowById($documentId, false));
        if ($document === null) {
            return;
        }
        $current = trim((string) ($document['litpic'] ?? ''));
        if (!GalleryConfigService::shouldApplyGalleryFirstLitpic($current)) {
            return;
        }
        $path = self::firstImagePublicPathForDocument($documentId);
        if ($path === '' || $path === $current) {
            return;
        }
        $attrFlags = app(WeappDocumentGateway::class)->documentMergeAttrHasImage(
            (string) ($document['attr_flags'] ?? ''),
            $path
        );
        app(WeappDocumentGateway::class)->documentPatchLitpic($documentId, $path, $attrFlags);
        app(WeappFrontGateway::class)->frontCacheInvalidateDocuments();
    }

    /**
     * @return list<array<string, mixed>>
     */
    public static function listPublicForDocument(int $documentId, int $limit = 0, string $groupKey = 'default'): array
    {
        if (!GalleryAccessService::canViewDocumentId($documentId)) {
            return [];
        }
        $normalized = self::normalizeGroupKey($groupKey);
        $rows = self::listForDocument(
            $documentId,
            true,
            $normalized === 'all' ? 'all' : $normalized
        );
        if ($limit < 1 && GalleryConfigService::defaultRow() > 0) {
            $limit = GalleryConfigService::defaultRow();
        }
        if ($limit > 0) {
            $rows = array_slice($rows, 0, $limit);
        }
        $rows = self::attachGroupTitles($documentId, $rows);

        return array_map(static fn (array $row): array => self::formatPublic($row), $rows);
    }

    /**
     * @param list<array<string, mixed>> $rows
     * @return list<array<string, mixed>>
     */
    private static function attachGroupTitles(int $documentId, array $rows): array
    {
        if ($rows === []) {
            return [];
        }
        $titles = [];
        foreach (self::listGroupsForDocument($documentId, false) as $group) {
            $titles[(string) ($group['group_key'] ?? '')] = (string) ($group['title'] ?? '');
        }
        foreach ($rows as &$row) {
            $key = self::normalizeGroupKey((string) ($row['group_key'] ?? 'default'));
            $row['group_title'] = $titles[$key] ?? $key;
        }
        unset($row);

        return $rows;
    }

    /**
     * @param array<string, mixed> $attrs
     * @param array<string, mixed> $pageVars
     */
    public static function renderTag(array $attrs, array $pageVars, string $tpl): string
    {
        if (!self::isActive()) {
            return '';
        }
        $documentId = self::resolveDocumentId($attrs, $pageVars);
        if ($documentId < 1) {
            return '';
        }
        $document = self::documentToArray(app(WeappDocumentGateway::class)->documentRowById($documentId, false));
        if ($document === null || !GalleryAccessService::canViewGallery($document, app(WeappFrontGateway::class)->frontCurrent())) {
            return '';
        }

        $groupKey = self::resolveGroupKey($attrs);
        $groupFilter = $groupKey === 'all' ? 'all' : $groupKey;
        $rows = self::listForDocument($documentId, true, $groupFilter);
        if ($rows === [] && $groupFilter === 'default') {
            $rows = self::listForDocument($documentId, true, 'all');
            $groupKey = 'all';
        }
        if ($rows === []) {
            return '';
        }

        $rowLimit = (int) ($attrs['row'] ?? $attrs['limit'] ?? 0);
        if ($rowLimit < 1) {
            $rowLimit = GalleryConfigService::defaultRow();
        }
        if ($rowLimit > 0) {
            $rows = array_slice($rows, 0, $rowLimit);
        }

        $defaultTpl = self::defaultItemTemplate();
        $tpl = trim($tpl) !== '' ? $tpl : $defaultTpl;
        $items = [];
        foreach ($rows as $row) {
            $row = self::attachGroupTitles($documentId, [$row])[0] ?? $row;
            $items[] = self::formatPublic($row);
        }
        $out = app(WeappTemplateGateway::class)->templateRenderItemLoop($tpl, $items, $pageVars);

        if ($out === '') {
            return '';
        }

        $displayStyle = GalleryLayoutService::resolve(
            $attrs,
            $documentId,
            $groupKey === 'all' ? 'default' : $groupKey
        );
        $normalizedStyle = GalleryLayoutService::normalize($displayStyle);
        $lightboxOn = GalleryConfigService::lightboxEnabled();
        $wrapperClass = 'pv-gallery pv-gallery--' . htmlspecialchars($normalizedStyle, ENT_QUOTES, 'UTF-8');
        if ($lightboxOn) {
            $wrapperClass .= ' pv-gallery--lightbox';
        }
        $dataAttrs = ' data-pv-gallery-layout="' . htmlspecialchars($normalizedStyle, ENT_QUOTES, 'UTF-8') . '"';
        if ($lightboxOn) {
            $dataAttrs .= ' data-pv-gallery-lightbox="1" data-pv-gallery="1"';
        }
        $swiperStyles = [
            GalleryLayoutService::STYLE_CAROUSEL,
            GalleryLayoutService::STYLE_FILMSTRIP,
            GalleryLayoutService::STYLE_HERO,
        ];
        if (in_array($normalizedStyle, $swiperStyles, true)) {
            if ($normalizedStyle === GalleryLayoutService::STYLE_CAROUSEL && GalleryConfigService::carouselAutoplay()) {
                $dataAttrs .= ' data-pv-carousel-autoplay="1" data-pv-carousel-interval="'
                    . (GalleryConfigService::carouselIntervalSec() * 1000) . '"';
            }
            $dataAttrs .= ' data-pv-carousel-dots="1"';
            $out = '<div class="pv-gallery-carousel-shell" data-pv-gallery-shell="'
                . htmlspecialchars($normalizedStyle, ENT_QUOTES, 'UTF-8') . '">'
                . '<div class="' . $wrapperClass . '"' . $dataAttrs . '>' . $out . '</div>'
                . self::carouselControlsHtml()
                . '</div>';
        } else {
            $out = '<div class="' . $wrapperClass . '"' . $dataAttrs . '>' . $out . '</div>';
        }
        app(WeappFrontGateway::class)->frontAssetDispatchPlugin('doc_gallery', 'layout', $normalizedStyle, true);

        return $out;
    }

    /**
     * @param array<string, mixed> $attrs
     * @param array<string, mixed> $pageVars
     */
    public static function renderGroupsTag(array $attrs, array $pageVars, string $tpl): string
    {
        if (!self::isActive()) {
            return '';
        }
        $documentId = self::resolveDocumentId($attrs, $pageVars);
        if ($documentId < 1) {
            return '';
        }
        $document = self::documentToArray(app(WeappDocumentGateway::class)->documentRowById($documentId, false));
        if ($document === null || !GalleryAccessService::canViewGallery($document, app(WeappFrontGateway::class)->frontCurrent())) {
            return '';
        }

        $groups = self::listGroupsForDocument($documentId, true);
        if ($groups === []) {
            return '';
        }

        $tpl = trim($tpl);
        if ($tpl === '') {
            $tpl = '<section class="pv-gallery-group-block" data-group="{$field.group_key}">'
                . '<h3 class="pv-gallery-group-title">{$field.title}</h3>{gallery}</section>';
        }

        $out = '';
        foreach ($groups as $group) {
            $field = self::formatGroupPublic($group, $documentId);
            $chunk = app(WeappTemplateGateway::class)->templateRenderItemLoop($tpl, [$field], $pageVars);
            if (str_contains($chunk, '{gallery}')) {
                $galleryHtml = self::renderTag(
                    array_merge($attrs, ['group' => (string) $field['group_key']]),
                    $pageVars,
                    ''
                );
                $chunk = str_replace('{gallery}', $galleryHtml, $chunk);
            }
            $out .= $chunk;
        }

        return $out;
    }

    /**
     * @param array<string, mixed> $group
     * @return array<string, mixed>
     */
    public static function formatGroupPublic(array $group, int $documentId): array
    {
        $key = self::normalizeGroupKey((string) ($group['group_key'] ?? 'default'));
        $style = GalleryLayoutService::normalize((string) ($group['display_style'] ?? ''));
        $items = self::listForDocument($documentId, true, $key);
        $cover = '';
        if ($items !== []) {
            $cover = self::thumbUrl(self::publicUrl((string) $items[0]['image_path']));
        }

        return array_merge([
            'group_key'           => $key,
            'title'               => (string) ($group['title'] ?? $key),
            'display_style'       => $style,
            'display_style_label' => GalleryLayoutService::label($style),
            'sort'                => (int) ($group['sort'] ?? 0),
            'item_count'          => count($items),
            'cover_url'           => $cover,
        ], GalleryDownloadBridgeService::packFieldsForGroup($group, $documentId));
    }

    private static function carouselControlsHtml(): string
    {
        return '<div class="pv-gallery-carousel-nav" aria-hidden="true">'
            . '<button type="button" class="pv-gallery-carousel-prev" aria-label="上一张">&#8249;</button>'
            . '<button type="button" class="pv-gallery-carousel-next" aria-label="下一张">&#8250;</button>'
            . '</div>';
    }

    /** 标签未写循环体时的默认 figure 项（与 07-模板标签/标签/gallery.md 一致） */
    private static function defaultItemTemplate(): string
    {
        return '<figure class="pv-gallery-item">'
            . '<a class="pv-gallery-item__link" href="{$field.image_url}" data-pv-lightbox="{$field.title}">'
            . '<img src="{$field.image_url}" alt="{$field.alt}" loading="lazy">'
            . '</a>'
            . '<figcaption class="pv-gallery-caption"><span class="pv-gallery-title">{$field.title}</span></figcaption>'
            . '</figure>';
    }

    /**
     * @param array<string, mixed> $row
     * @return array<string, mixed>
     */
    public static function formatPublic(array $row): array
    {
        $imageUrl = self::publicUrl((string) $row['image_path']);
        $thumbUrl = self::thumbUrl($imageUrl);
        $groupKey = self::normalizeGroupKey((string) ($row['group_key'] ?? 'default'));
        $width = (int) ($row['image_width'] ?? 0);
        $height = (int) ($row['image_height'] ?? 0);
        $aspect = $width > 0 && $height > 0
            ? number_format($width / $height, 4, '.', '')
            : '';

        return [
            'id'            => (int) ($row['id'] ?? 0),
            'image_url'     => $imageUrl,
            'thumb_url'     => $thumbUrl,
            'srcset'        => GalleryImageService::buildSrcset($imageUrl),
            'title'         => (string) ($row['title'] ?? ''),
            'alt'           => (string) ($row['alt_text'] ?? ''),
            'sort'          => (int) ($row['sort'] ?? 0),
            'group_key'     => $groupKey,
            'group_title'   => (string) ($row['group_title'] ?? ''),
            'image_width'   => $width,
            'image_height'  => $height,
            'aspect_ratio'  => $aspect,
            'link_url'      => (string) ($row['link_url'] ?? ''),
            'description'   => (string) ($row['description'] ?? ''),
            'shot_info'     => (string) ($row['shot_info'] ?? ''),
        ];
    }

    public static function thumbUrl(string $imageUrl): string
    {
        $width = GalleryConfigService::effectiveThumbWidth();
        $height = GalleryConfigService::effectiveThumbHeight();
        if ($width < 1 || $imageUrl === '') {
            return $imageUrl;
        }

        return GalleryImageService::publicThumbUrl($imageUrl, $width, $height);
    }

    public static function publicUrl(string $path): string
    {
        $path = trim($path);
        if ($path === '') {
            return '';
        }
        if (str_starts_with($path, 'http://') || str_starts_with($path, 'https://') || str_starts_with($path, '//')) {
            return $path;
        }

        if (str_starts_with($path, '/')) {
            return $path;
        }
        if (str_starts_with($path, 'uploads/')) {
            return '/' . $path;
        }

        return '/uploads/' . ltrim($path, '/');
    }

    /** @return array{0:int,1:int} */
    private static function probeImageSize(string $imagePath): array
    {
        return GalleryImageService::probeDimensions($imagePath);
    }

    /** @return array{total:int,enabled:int,documents:int,scope_label:string} */
    public static function statsAdmin(): array
    {
        if (!app(WeappEntitlementGateway::class)->entitlementCan('doc_gallery')) {
            return ['total' => 0, 'enabled' => 0, 'documents' => 0, 'scope_label' => ''];
        }
        $total = (int) WeappGalleryItem::count();
        $enabled = (int) WeappGalleryItem::where('status', 1)->count();
        $documents = (int) WeappGalleryItem::distinct(true)->count('document_id');
        $groups = 0;
        try {
            $groups = (int) WeappGalleryGroup::count();
        } catch (\Throwable $e) {
            app(WeappSupportGateway::class)->kernelOpsLog('gallery_group_count_failed', ['msg' => $e->getMessage()]);
        }

        return [
            'total'       => $total,
            'enabled'     => $enabled,
            'documents'   => $documents,
            'groups'      => $groups,
            'scope_label' => GalleryConfigService::scopeLabel(),
        ];
    }

    /** @param array<string,mixed> $filters */
    public static function listAdmin(array $filters = [], int $page = 1, int $pageSize = 20)
    {
        if (!app(WeappEntitlementGateway::class)->entitlementCan('doc_gallery')) {
            return app(WeappSupportGateway::class)->resultFail('plugin_disabled');
        }
        $page = max(1, $page);
        $pageSize = max(10, min(100, $pageSize));
        $query = WeappGalleryItem::with(['document' => static function ($documentQuery): void {
            $documentQuery->field('id,title');
        }]);
        $documentId = (int) ($filters['document_id'] ?? 0);
        if ($documentId > 0) {
            $query->where('document_id', $documentId);
        }
        $status = $filters['status'] ?? '';
        if ($status !== '') {
            $query->where('status', (int) $status);
        }
        $keyword = trim((string) ($filters['keyword'] ?? ''));
        if ($keyword !== '') {
            $query->whereLike('title|alt_text', app(WeappSearchGateway::class)->searchLikePattern($keyword));
        }
        $groupKey = trim((string) ($filters['group_key'] ?? ''));
        if ($groupKey !== '') {
            $query->where('group_key', self::normalizeGroupKey($groupKey));
        }
        $total = (int) (clone $query)->count();
        $rows  = app(WeappSupportGateway::class)->modelRelationMapBelongsTo(
            $query->order('id', 'desc')->page($page, $pageSize)->select(),
            'document',
            ['title' => 'document_title'],
        );
        foreach ($rows as &$row) {
            $row['status_label'] = (int) ($row['status'] ?? 0) === 1 ? '启用' : '禁用';
            $row['image_url'] = self::publicUrl((string) $row['image_path']);
            $row['in_scope'] = GalleryConfigService::documentEligible((int) ($row['document_id'] ?? 0)) ? 1 : 0;
        }
        unset($row);

        return app(WeappSupportGateway::class)->resultList($rows, $total);
    }

    /** @param array<string,mixed> $data */
    public static function saveAdmin(array $data)
    {
        if (!app(WeappEntitlementGateway::class)->entitlementCan('doc_gallery')) {
            return app(WeappSupportGateway::class)->resultFail('plugin_disabled');
        }
        $id = (int) ($data['id'] ?? 0);
        $documentId = (int) ($data['document_id'] ?? 0);
        if ($documentId < 1) {
            return app(WeappSupportGateway::class)->resultFail('请填写文档 ID');
        }
        if (!GalleryConfigService::documentEligible($documentId)) {
            return app(WeappSupportGateway::class)->resultFail('该文档不在图集使用范围内');
        }
        $payload = [
            'document_id' => $documentId,
            'group_key'   => self::normalizeGroupKey((string) ($data['group_key'] ?? 'default')),
            'image_path'  => GalleryImageService::relativeUploadPath(trim((string) ($data['image_path'] ?? ''))),
            'title'       => trim((string) ($data['title'] ?? '')),
            'alt_text'    => trim((string) ($data['alt_text'] ?? '')),
            'link_url'    => trim((string) ($data['link_url'] ?? '')),
            'description' => trim((string) ($data['description'] ?? '')),
            'shot_info'   => trim((string) ($data['shot_info'] ?? '')),
            'sort'        => (int) ($data['sort'] ?? 0),
            'status'      => !empty($data['status']) ? 1 : 0,
            'updated_at'  => app(WeappSupportGateway::class)->appTimeNow(),
        ];
        if ($payload['image_path'] === '') {
            return app(WeappSupportGateway::class)->resultFail('请填写合法图片路径（uploads/ 下，禁止 ..）');
        }
        [$imageWidth, $imageHeight] = self::probeImageSize($payload['image_path']);
        $payload['image_width'] = $imageWidth;
        $payload['image_height'] = $imageHeight;

        if ($id > 0) {
            WeappGalleryItem::where('id', $id)->update($payload);

            return app(WeappSupportGateway::class)->resultOk(['id' => $id], '更新成功');
        }
        $payload['created_at'] = app(WeappSupportGateway::class)->appTimeNow();
        $newId = (int) WeappGalleryItem::insertGetId($payload);

        return app(WeappSupportGateway::class)->resultOk(['id' => $newId], '添加成功');
    }

    public static function deleteAdmin(int $id)
    {
        if (!app(WeappEntitlementGateway::class)->entitlementCan('doc_gallery') || $id < 1) {
            return app(WeappSupportGateway::class)->resultFail('invalid_id');
        }
        WeappGalleryItem::where('id', $id)->delete();

        return app(WeappSupportGateway::class)->resultOk(null, 'ok');
    }

    public static function statusAdmin(int $id, int $status)
    {
        if (!app(WeappEntitlementGateway::class)->entitlementCan('doc_gallery') || $id < 1) {
            return app(WeappSupportGateway::class)->resultFail('invalid_id');
        }
        WeappGalleryItem::where('id', $id)->update([
            'status'     => $status === 1 ? 1 : 0,
            'updated_at' => app(WeappSupportGateway::class)->appTimeNow(),
        ]);

        return app(WeappSupportGateway::class)->resultOk(null, 'ok');
    }

    public static function sortAdmin(int $id, int $sort)
    {
        if (!app(WeappEntitlementGateway::class)->entitlementCan('doc_gallery') || $id < 1) {
            return app(WeappSupportGateway::class)->resultFail('invalid_id');
        }
        WeappGalleryItem::where('id', $id)->update([
            'sort'       => $sort,
            'updated_at' => app(WeappSupportGateway::class)->appTimeNow(),
        ]);

        return app(WeappSupportGateway::class)->resultOk(null, 'ok');
    }

    /**
     * @param array<string, mixed> $paths
     */
    public static function batchImportAdmin(int $documentId, array $paths, string $groupKey = 'default')
    {
        if (!app(WeappEntitlementGateway::class)->entitlementCan('doc_gallery') || $documentId < 1) {
            return app(WeappSupportGateway::class)->resultFail('参数错误');
        }
        if (!GalleryConfigService::documentEligible($documentId)) {
            return app(WeappSupportGateway::class)->resultFail('该文档不在图集使用范围内');
        }
        $maxSort = (int) WeappGalleryItem::where('document_id', $documentId)->max('sort');
        $added = 0;
        foreach ($paths as $path) {
            $path = trim((string) $path);
            if ($path === '') {
                continue;
            }
            ++$maxSort;
            $res = self::saveAdmin([
                'document_id' => $documentId,
                'group_key'   => $groupKey,
                'image_path'  => $path,
                'title'       => '',
                'alt_text'    => '',
                'sort'        => $maxSort,
                'status'      => 1,
            ]);
            if ($res->isOk()) {
                ++$added;
            }
        }
        if ($added < 1) {
            return app(WeappSupportGateway::class)->resultFail('没有有效的图片路径');
        }

        return app(WeappSupportGateway::class)->resultOk(['added' => $added], '已导入 ' . $added . ' 张');
    }

    /**
     * @param array<int|string, mixed> $payload
     * @return array{groups:list<array<string,mixed>>,items:list<array<string,mixed>>}
     */
    public static function normalizeSyncPayload(array $payload): array
    {
        if (isset($payload['items']) && is_array($payload['items'])) {
            $groups = is_array($payload['groups'] ?? null) ? $payload['groups'] : [];
            $items  = array_values(array_filter($payload['items'], 'is_array'));
            if ($groups === []) {
                $groups = self::deriveGroupsFromItems($items);
            }

            return [
                'groups' => array_values(array_filter($groups, 'is_array')),
                'items'  => $items,
            ];
        }
        if ($payload !== [] && array_is_list($payload)) {
            $items = array_values(array_filter($payload, 'is_array'));

            return [
                'groups' => self::deriveGroupsFromItems($items),
                'items'  => $items,
            ];
        }

        return ['groups' => [], 'items' => []];
    }

    /**
     * 文档 Tab 只导出扁平 items：从每行的 display_style / group_title 还原分组。
     *
     * @param list<array<string, mixed>> $items
     * @return list<array<string, mixed>>
     */
    private static function deriveGroupsFromItems(array $items): array
    {
        $byKey = [];
        foreach ($items as $row) {
            $key = self::normalizeGroupKey((string) ($row['group_key'] ?? 'default'));
            if (isset($byKey[$key])) {
                if (!empty($row['pack_download'])) {
                    $byKey[$key]['pack_download'] = 1;
                }
                self::mergePackAccessIntoGroup($byKey[$key], $row);
                continue;
            }
            $style = trim((string) ($row['display_style'] ?? ''));
            $title = trim((string) ($row['group_title'] ?? ''));
            $byKey[$key] = [
                'group_key'     => $key,
                'title'         => $title,
                'display_style' => $style !== ''
                    ? GalleryLayoutService::normalize($style)
                    : GalleryConfigService::defaultDisplayStyle(),
                'pack_download' => !empty($row['pack_download']) ? 1 : 0,
                'sort'          => count($byKey),
                'status'        => 1,
            ];
            self::mergePackAccessIntoGroup($byKey[$key], $row);
        }

        return array_values($byKey);
    }

    /** @param list<array<string, mixed>> $groups */
    private static function syncGroupsForDocument(int $documentId, array $groups)
    {
        self::ensureSchema();
        $keepIds = [];
        $sort = 0;
        if ($groups === []) {
            $groups = [[
                'group_key'     => 'default',
                'title'         => '默认图集',
                'display_style' => GalleryConfigService::defaultDisplayStyle(),
                'sort'          => 0,
                'status'        => 1,
            ]];
        }
        foreach ($groups as $row) {
            $key = self::normalizeGroupKey((string) ($row['group_key'] ?? 'default'));
            $packAccess = self::normalizePackAccess($row);
            $payload = [
                'document_id'          => $documentId,
                'group_key'            => $key,
                'title'                => trim((string) ($row['title'] ?? '')),
                'display_style'        => trim((string) ($row['display_style'] ?? '')) !== ''
                    ? GalleryLayoutService::normalize((string) $row['display_style'])
                    : GalleryConfigService::defaultDisplayStyle(),
                'pack_download'        => !empty($row['pack_download']) ? 1 : 0,
                'pack_access_mode'     => $packAccess['pack_access_mode'],
                'pack_member_level_id' => $packAccess['pack_member_level_id'],
                'pack_points_cost'     => $packAccess['pack_points_cost'],
                'sort'                 => (int) ($row['sort'] ?? $sort),
                'status'               => array_key_exists('status', $row) ? (!empty($row['status']) ? 1 : 0) : 1,
                'updated_at'           => app(WeappSupportGateway::class)->appTimeNow(),
            ];
            if ($payload['title'] === '') {
                $payload['title'] = $key === 'default' ? '默认图集' : $key;
            }
            $existing = WeappGalleryGroup::where('document_id', $documentId)
                ->where('group_key', $key)
                ->find();
            $existingRow = self::documentToArray($existing);
            if ($existingRow !== null) {
                WeappGalleryGroup::where('id', (int) $existingRow['id'])->update($payload);
                $keepIds[] = (int) $existingRow['id'];
            } else {
                $payload['created_at'] = app(WeappSupportGateway::class)->appTimeNow();
                $keepIds[] = (int) WeappGalleryGroup::insertGetId($payload);
            }
            $sort++;
        }
        WeappGalleryGroup::where('document_id', $documentId)
            ->whereNotIn('id', $keepIds)
            ->delete();

        // 写口收口：条目 group_key 必须落在现存分组；禁读路径「空则回 default」双读
        $validKeys = [];
        foreach ($groups as $row) {
            $validKeys[] = self::normalizeGroupKey((string) ($row['group_key'] ?? 'default'));
        }
        $validKeys = array_values(array_unique($validKeys));
        if ($validKeys === []) {
            $validKeys = ['default'];
        }
        $remapTo = in_array('default', $validKeys, true) ? 'default' : $validKeys[0];
        WeappGalleryItem::where('document_id', $documentId)
            ->whereNotIn('group_key', $validKeys)
            ->update([
                'group_key'  => $remapTo,
                'updated_at' => app(WeappSupportGateway::class)->appTimeNow(),
            ]);

        return app(WeappSupportGateway::class)->resultOk(null, 'ok');
    }

    /** @param list<array<string, mixed>>|array<string,mixed> $payload @return mixed */
    public static function syncForDocument(int $documentId, array $payload)
    {
        if (!app(WeappEntitlementGateway::class)->entitlementCan('doc_gallery') || $documentId < 1) {
            return app(WeappSupportGateway::class)->resultFail('参数错误');
        }
        if (!GalleryConfigService::documentEligible($documentId)) {
            return app(WeappSupportGateway::class)->resultFail('该文档不在图集使用范围内');
        }
        self::ensureSchema();
        $normalized = self::normalizeSyncPayload($payload);

        Db::startTrans();
        try {
            $groupRes = self::syncGroupsForDocument($documentId, $normalized['groups']);
            if (!$groupRes->isOk()) {
                Db::rollback();

                return $groupRes;
            }

            $keepIds = [];
            $sort    = 0;
            $anySaved = false;
            foreach ($normalized['items'] as $row) {
                $imagePath = trim((string) $row['image_path']);
                if ($imagePath === '') {
                    continue;
                }
                $res = self::saveAdmin([
                    'id'          => (int) ($row['id'] ?? 0),
                    'document_id' => $documentId,
                    'group_key'   => (string) ($row['group_key'] ?? 'default'),
                    'image_path'  => $imagePath,
                    'title'       => trim((string) ($row['title'] ?? '')),
                    'alt_text'    => trim((string) ($row['alt_text'] ?? ($row['alt'] ?? ''))),
                    'link_url'    => trim((string) ($row['link_url'] ?? '')),
                    'description' => trim((string) ($row['description'] ?? '')),
                    'shot_info'   => trim((string) ($row['shot_info'] ?? '')),
                    'sort'        => (int) ($row['sort'] ?? $sort),
                    'status'      => array_key_exists('status', $row) ? (!empty($row['status']) ? 1 : 0) : 1,
                ]);
                if (!$res->isOk()) {
                    Db::rollback();

                    return app(WeappSupportGateway::class)->resultFail((string) $res->message());
                }
                $newId = (int) ($res['id'] ?? 0);
                if ($newId > 0) {
                    $keepIds[] = $newId;
                    $anySaved = true;
                }
                $sort++;
            }
            if (!$anySaved) {
                WeappGalleryItem::where('document_id', $documentId)->delete();
            } else {
                WeappGalleryItem::where('document_id', $documentId)
                    ->whereNotIn('id', $keepIds)
                    ->delete();
            }

            $packRes = GalleryDownloadBridgeService::syncForDocument($documentId);
            if (!$packRes->isOk()) {
                Db::rollback();

                return app(WeappSupportGateway::class)->resultFail((string) $packRes->message());
            }

            self::syncDocumentLitpicFromFirst($documentId);
            Db::commit();
        } catch (\Throwable $e) {
            Db::rollback();
            app(WeappSupportGateway::class)->kernelOpsLog('gallery_sync_for_document_failed', [
                'document_id' => $documentId,
                'msg'         => $e->getMessage(),
            ]);

            return app(WeappSupportGateway::class)->resultFail('同步失败');
        }

        return app(WeappSupportGateway::class)->resultOk(null, 'ok');
    }

    public static function purgeForDocument(int $documentId): void
    {
        if ($documentId < 1) {
            return;
        }
        Db::startTrans();
        try {
            GalleryDownloadBridgeService::purgeForDocument($documentId);
            WeappGalleryItem::where('document_id', $documentId)->delete();
            WeappGalleryGroup::where('document_id', $documentId)->delete();
            Db::commit();
        } catch (\Throwable $e) {
            Db::rollback();
            app(WeappSupportGateway::class)->kernelOpsLog('gallery_purge_for_document_failed', [
                'document_id' => $documentId,
                'msg'         => $e->getMessage(),
            ]);
        }
    }

    /**
     * @param array<string, mixed> $group
     * @param array<string, mixed> $row
     */
    private static function mergePackAccessIntoGroup(array &$group, array $row): void
    {
        $norm = self::normalizePackAccess($row);
        $group['pack_access_mode'] = $norm['pack_access_mode'];
        $group['pack_member_level_id'] = $norm['pack_member_level_id'];
        $group['pack_points_cost'] = $norm['pack_points_cost'];
    }

    /**
     * @param array<string, mixed> $row
     * @return array{pack_access_mode:string,pack_member_level_id:int,pack_points_cost:int}
     */
    public static function normalizePackAccess(array $row): array
    {
        $mode = strtolower(trim((string) ($row['pack_access_mode'] ?? 'free')));
        if (!in_array($mode, ['free', 'login', 'member', 'points'], true)) {
            $mode = 'free';
        }
        $levelId = max(0, (int) ($row['pack_member_level_id'] ?? 0));
        $points = max(0, (int) ($row['pack_points_cost'] ?? 0));
        if ($mode === 'member' && $levelId < 1) {
            $mode = 'login';
            $levelId = 0;
        }
        if ($mode !== 'member') {
            $levelId = 0;
        }
        if ($mode === 'points') {
            $points = max(1, $points);
        } else {
            $points = 0;
        }

        return [
            'pack_access_mode'     => $mode,
            'pack_member_level_id' => $levelId,
            'pack_points_cost'     => $points,
        ];
    }
}
