<?php
declare(strict_types=1);

namespace weapp\doc_gallery\service;

use weapp\doc_gallery\model\WeappGalleryGroup;

/** 图集前台展现样式（SSOT） */
class GalleryLayoutService
{
    public const STYLE_GRID = 'grid';
    public const STYLE_MASONRY = 'masonry';
    public const STYLE_CAROUSEL = 'carousel';
    public const STYLE_FILMSTRIP = 'filmstrip';
    public const STYLE_LIST = 'list';
    public const STYLE_JUSTIFIED = 'justified';
    public const STYLE_HERO = 'hero';

    /** @return list<string> */
    public static function keys(): array
    {
        return [
            self::STYLE_GRID,
            self::STYLE_MASONRY,
            self::STYLE_CAROUSEL,
            self::STYLE_FILMSTRIP,
            self::STYLE_LIST,
            self::STYLE_JUSTIFIED,
            self::STYLE_HERO,
        ];
    }

    public static function normalize(string $style): string
    {
        $style = strtolower(trim($style));

        return in_array($style, self::keys(), true) ? $style : self::STYLE_GRID;
    }

    /**
     * @return list<array{id:string,label:string,desc:string,needs_js:bool}>
     */
    public static function catalogAdmin(): array
    {
        $out = [];
        foreach (self::definitions() as $id => $def) {
            $out[] = [
                'id'       => $id,
                'label'    => (string) $def['label'],
                'desc'     => (string) $def['desc'],
                'needs_js' => !empty($def['needs_js']),
            ];
        }

        return $out;
    }

    public static function label(string $style): string
    {
        $style = self::normalize($style);
        $def   = self::definitions()[$style] ?? [];

        return (string) ($def['label'] ?? $style);
    }

    public static function needsJs(string $style): bool
    {
        $style = self::normalize($style);
        $def   = self::definitions()[$style] ?? [];

        return !empty($def['needs_js']);
    }

    /**
     * @param array<string, mixed> $attrs
     */
    public static function resolve(array $attrs, int $documentId, string $groupKey): string
    {
        foreach (['style', 'layout', 'display_style'] as $key) {
            if (!empty($attrs[$key])) {
                return self::normalize((string) $attrs[$key]);
            }
        }
        if ($documentId > 0 && $groupKey !== '' && $groupKey !== 'all') {
            $fromGroup = self::groupStyle($documentId, $groupKey);
            if ($fromGroup !== '') {
                return $fromGroup;
            }
        }

        return self::normalize(GalleryConfigService::defaultDisplayStyle());
    }

    public static function groupStyle(int $documentId, string $groupKey): string
    {
        if ($documentId < 1) {
            return '';
        }
        GalleryService::ensureSchema();
        $groupKey = GalleryService::normalizeGroupKey($groupKey);
        $style = WeappGalleryGroup::where('document_id', $documentId)
            ->where('group_key', $groupKey)
            ->value('display_style');

        return is_string($style) && $style !== '' ? self::normalize($style) : '';
    }

    /** @return array<string, array{label:string,desc:string,needs_js?:bool}> */
    private static function definitions(): array
    {
        return [
            self::STYLE_GRID => [
                'label' => '响应式网格',
                'desc'  => '多列自适应方格，通用默认样式',
            ],
            self::STYLE_MASONRY => [
                'label' => '瀑布流',
                'desc'  => '不等高瀑布排列，适合竖图混排',
            ],
            self::STYLE_CAROUSEL => [
                'label' => '轮播滑动',
                'desc'  => '横向滑动大图，带左右切换按钮',
                'needs_js' => true,
            ],
            self::STYLE_FILMSTRIP => [
                'label' => '胶片条',
                'desc'  => '横向缩略图条，可快速浏览',
            ],
            self::STYLE_LIST => [
                'label' => '竖向列表',
                'desc'  => '大图逐条展示，适合步骤说明',
            ],
            self::STYLE_JUSTIFIED => [
                'label' => '等高铺满',
                'desc'  => '统一高度裁切，视觉整齐',
            ],
            self::STYLE_HERO => [
                'label' => '首图突出',
                'desc'  => '第一张大图 + 其余小图网格',
            ],
        ];
    }
}
