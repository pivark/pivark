<?php
declare(strict_types=1);

namespace weapp\doc_gallery\service;

use app\common\contract\PluginApiCallableTrait;
use app\common\contract\PluginApiInterface;

/** 图集插件对外 API（跨插件经 PluginApiRegistry 调用） */
final class GalleryPublicApi implements PluginApiInterface
{
    use PluginApiCallableTrait;

    public function pluginIdentifier(): string
    {
        return 'doc_gallery';
    }

    public function isActive(): bool
    {
        GalleryService::ensureAutoload();

        return GalleryService::isActive();
    }

    /**
     * @return list<array<string, mixed>>
     */
    public function listPublicForDocument(int $documentId, int $limit = 0, string $groupKey = 'default'): array
    {
        GalleryService::ensureAutoload();

        return GalleryService::listPublicForDocument($documentId, $limit, $groupKey);
    }
}
