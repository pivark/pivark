<?php
/**
 * 元舟 PivArk — document-addon bridge handler（weapp SSOT）
 */
declare(strict_types=1);

namespace weapp\doc_gallery\service;

use app\common\contract\DocumentAddonBridgeHandlerInterface;
use app\common\contract\WeappPluginBridgeTrait;
use app\common\service\weapp\WeappMemberGateway;
use app\common\service\weapp\WeappSupportGateway;


final class GalleryDocumentAddonBridge implements DocumentAddonBridgeHandlerInterface
{
    use WeappPluginBridgeTrait;

    
    

    public function isEnabled(): bool
    {
        return $this->bridgeEnabled('doc_gallery');
    }

    public function identifier(): string
    {
        return 'doc_gallery';
    }
    /** @return array<string, mixed> */
    public function documentEditorSpaPayload(int $documentId): array
    {
        $this->ensurePluginLoaded();

        return [
            'save_field'            => 'gallery_json',
            'items'                 => $documentId > 0
                ? \weapp\doc_gallery\service\GalleryService::listForDocument($documentId, false)
                : [],
            'groups'                => $documentId > 0
                ? \weapp\doc_gallery\service\GalleryService::listGroupsForDocument($documentId, false)
                : [],
            'layouts'               => \weapp\doc_gallery\service\GalleryLayoutService::catalogAdmin(),
            'memberLevels'          => app(WeappMemberGateway::class)->memberLevelsActive(),
            'download_plugin_ready' => \weapp\doc_gallery\service\GalleryDownloadBridgeService::isDownloadPluginReady(),
        ];
    }

    /** @return list<array<string, mixed>> */
    public function listForDocument(int $documentId): array
    {
        if (!$this->isEnabled() || $documentId < 1) {
            return [];
        }
        $this->ensurePluginLoaded();

        return \weapp\doc_gallery\service\GalleryService::listForDocument($documentId);
    }

    /** @return list<array<string, mixed>> */
    public function payloadForDocument(int $documentId, bool $publicOnly = false): array
    {
        if (!$this->isEnabled() || $documentId < 1) {
            return ['groups' => []];
        }
        $this->ensurePluginLoaded();

        return \weapp\doc_gallery\service\GalleryService::payloadForDocument($documentId, $publicOnly);
    }

    public function hasRenderableForDocument(int $documentId): bool
    {
        if (!$this->isEnabled() || $documentId < 1) {
            return false;
        }
        $this->ensurePluginLoaded();

        return \weapp\doc_gallery\service\GalleryService::listForDocument($documentId, true, 'all') !== [];
    }

    /** 模板 flag document_has_doc_gallery（按文档是否有可展示分组） */
    public function hasAvailabilityForDocument(int $documentId): bool
    {
        if (!$this->isEnabled() || $documentId < 1) {
            return false;
        }
        $this->ensurePluginLoaded();
        $payload = \weapp\doc_gallery\service\GalleryService::payloadForDocument($documentId, true);
        $groups  = is_array($payload['groups'] ?? null) ? $payload['groups'] : [];

        return $groups !== [];
    }

    /**
     * arclist has/nohas：有前台可展示图集的文档 ID。
     *
     * @return list<int>
     */
    public function documentIdsWithAvailability(): array
    {
        if (!$this->isEnabled()) {
            return [];
        }
        $this->ensurePluginLoaded();

        return \weapp\doc_gallery\service\GalleryService::documentIdsWithPublicAvailability();
    }

    /**
     * @param list<array<string, mixed>> $items
     * @return mixed
     */
    public function syncForDocument(int $documentId, array $items)
    {
        if (!$this->isEnabled() || $documentId < 1) {
            return app(WeappSupportGateway::class)->resultFail('参数错误');
        }
        $this->ensurePluginLoaded();

        return \weapp\doc_gallery\service\GalleryService::syncForDocument($documentId, $items);
    }

    public function purgeForDocument(int $documentId): void
    {
        if (!$this->isEnabled() || $documentId < 1) {
            return;
        }
        $this->ensurePluginLoaded();
        \weapp\doc_gallery\service\GalleryService::purgeForDocument($documentId);
    }

    private function ensurePluginLoaded(): void
    {
        $this->registerWeappAutoload('doc_gallery');
        \weapp\doc_gallery\service\GalleryService::ensureAutoload();
    }
}
