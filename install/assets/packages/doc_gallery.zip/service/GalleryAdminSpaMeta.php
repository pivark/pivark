<?php
declare(strict_types=1);

namespace weapp\doc_gallery\service;

use app\common\service\weapp\WeappMemberGateway;
use app\common\service\weapp\WeappPluginGateway;
use app\common\service\weapp\WeappSiteGateway;

final class GalleryAdminSpaMeta
{
    /** @param array<string, mixed> $ctx @return array<string, mixed> */
    public static function build(array $ctx): array
    {
        GalleryService::ensureAutoload();

        return [
            'cfg'          => GalleryConfigService::all(),
            'stats'        => GalleryService::statsAdmin(),
            'health'       => GalleryConfigService::healthCheckAdmin(),
            'layouts'      => GalleryLayoutService::catalogAdmin(),
            'navOptions'   => app(WeappSiteGateway::class)->siteNavListContentCategoryOptions(),
            'memberLevels' => app(WeappMemberGateway::class)->memberLevelsActive(),
            'slotCards'    => app(WeappPluginGateway::class)->pluginEditorSurfaceSlotCards('doc_gallery'),
            'editorSlot'   => app(WeappPluginGateway::class)->pluginEditorResolveSlot('doc_gallery'),
            'plugin'       => app(WeappPluginGateway::class)->pluginPresentationForAdmin('doc_gallery'),
        ];
    }
}
