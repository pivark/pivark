<?php
declare(strict_types=1);

namespace weapp\doc_gallery\service;

use app\common\service\weapp\WeappDocumentGateway;
use app\common\service\weapp\WeappPaginationGateway;
use app\common\service\weapp\WeappPluginGateway;
use app\common\service\weapp\WeappSearchGateway;
use app\common\service\weapp\WeappSupportGateway;
use weapp\doc_gallery\model\WeappGalleryItem;

/** 图集广场：带图集的文档聚合列表 */
class GalleryPlazaService
{
    public static function boot(): void
    {
        app(WeappPluginGateway::class)->pluginRouteRegister('get', 'doc_gallery', '\\weapp\\doc_gallery\\front\\controller\\Plaza@index');
        app(WeappPluginGateway::class)->pluginRouteRegister('get', 'doc_gallery/plaza', '\\weapp\\doc_gallery\\front\\controller\\Plaza@index');
    }

    /**
     * @return mixed
     */
    public static function listPublic(int $page = 1, int $limit = 24, string $sort = 'hot', string $keyword = '')
    {
        if (!GalleryService::isActive()) {
            return app(WeappSupportGateway::class)->resultFail('图集功能未开启');
        }
        $page  = max(1, $page);
        $limit = min(48, max(6, $limit));
        $sort  = strtolower(trim($sort));
        $kw    = trim($keyword);

        // 候选上限：无关键词时按热度/id 截断，避免广场随全站图集无限膨胀
        $candidateCap = max(120, $page * $limit * 8);
        $countQuery = WeappGalleryItem::where('status', 1)
            ->field('document_id, COUNT(*) AS image_count')
            ->group('document_id');
        if ($kw === '') {
            if ($sort === 'new') {
                $countQuery->order('document_id', 'desc');
            } else {
                $countQuery->order('image_count', 'desc')->order('document_id', 'desc');
            }
            $countQuery->limit($candidateCap);
        }
        $countRows = $countQuery->select()->toArray();
        $countMap = [];
        foreach ($countRows as $row) {
            if (!is_array($row)) {
                continue;
            }
            $documentId = (int) ($row['document_id'] ?? 0);
            if ($documentId > 0) {
                $countMap[$documentId] = (int) ($row['image_count'] ?? 0);
            }
        }
        if ($countMap === []) {
            return app(WeappSupportGateway::class)->resultOk([
                'list'  => [],
                'total' => 0,
                'page'  => $page,
                'pages' => 1,
                'limit' => $limit,
            ], '');
        }

        $docGw = app(WeappDocumentGateway::class);
        $searchGw = app(WeappSearchGateway::class);
        $docRows = $docGw->documentRowsByIds(array_keys($countMap), 'id,title,summary,litpic,published_at,status');
        $filtered = [];
        foreach ($docRows as $row) {
            if (!is_array($row)) {
                continue;
            }
            if ((int) ($row['status'] ?? 0) !== 1) {
                continue;
            }
            if ($kw !== '') {
                $pattern = $searchGw->searchLikePattern($kw);
                $needle  = trim(str_replace('%', '', $pattern));
                $hay     = (string) ($row['title'] ?? '') . (string) ($row['summary'] ?? '');
                if ($needle !== '' && !str_contains(mb_strtolower($hay), mb_strtolower($needle))) {
                    continue;
                }
            }
            $documentId = (int) ($row['id'] ?? 0);
            if ($documentId < 1 || !GalleryConfigService::documentEligible($documentId)) {
                continue;
            }
            if (!GalleryAccessService::canViewDocumentId($documentId)) {
                continue;
            }
            $filtered[] = [
                'document_id'  => $documentId,
                'title'        => (string) ($row['title'] ?? ''),
                'summary'      => self::excerpt((string) ($row['summary'] ?? '')),
                'cover_url'    => trim((string) ($row['litpic'] ?? '')),
                'image_count'  => $countMap[$documentId] ?? 0,
                'document_url' => $docGw->documentFormatPublicUrl($row),
                'published_at' => (string) ($row['published_at'] ?? ''),
            ];
        }

        if ($sort === 'new') {
            usort($filtered, static fn (array $a, array $b): int => strcmp($b['published_at'], $a['published_at']) ?: $b['document_id'] <=> $a['document_id']);
        } else {
            usort($filtered, static fn (array $a, array $b): int => $b['image_count'] <=> $a['image_count'] ?: $b['document_id'] <=> $a['document_id']);
        }

        $total = count($filtered);
        $offset = ($page - 1) * $limit;
        $list = array_values(array_slice($filtered, $offset, $limit));
        $pages = max(1, (int) ceil($total / $limit));

        // 封面回退仅对本页批量查，禁止全量 N+1
        $needThumb = [];
        foreach ($list as $i => $row) {
            if (($row['cover_url'] ?? '') === '') {
                $needThumb[] = (int) ($row['document_id'] ?? 0);
            }
        }
        if ($needThumb !== []) {
            $thumbs = GalleryService::firstListThumbsForDocuments($needThumb);
            foreach ($list as $i => $row) {
                $id = (int) ($row['document_id'] ?? 0);
                if (($row['cover_url'] ?? '') === '' && isset($thumbs[$id]) && $thumbs[$id] !== '') {
                    $list[$i]['cover_url'] = $thumbs[$id];
                }
            }
        }

        return app(WeappSupportGateway::class)->resultOk([
            'list'  => $list,
            'total' => $total,
            'page'  => $page,
            'pages' => $pages,
            'limit' => $limit,
        ], '');
    }

    /**
     * @return mixed
     */
    public static function pageVars(int $page = 1, string $sort = 'hot', string $keyword = '')
    {
        if (!GalleryConfigService::plazaOpen()) {
            return app(WeappSupportGateway::class)->resultFail('图集广场未开启');
        }
        $res = self::listPublic($page, 24, $sort, $keyword);
        if (!$res->isOk()) {
            return app(WeappSupportGateway::class)->resultFail((string) $res->message());
        }

        $sortLabel = match (strtolower(trim($sort))) {
            'new' => '最新发布',
            default => '图片最多',
        };
        $pageNum = (int) ($res['page'] ?? 1);
        $total   = (int) ($res['total'] ?? 0);
        $limit   = (int) ($res['limit'] ?? 24);
        $sortKey = strtolower(trim($sort)) ?: 'hot';
        $kwEnc   = rawurlencode(trim($keyword));
        $query   = static function (int $p) use ($sortKey, $kwEnc): string {
            $q = '/doc_gallery?page=' . $p . '&sort=' . rawurlencode($sortKey);
            if ($kwEnc !== '') {
                $q .= '&q=' . $kwEnc;
            }

            return $q;
        };

        return app(WeappSupportGateway::class)->resultOk(['vars' => array_merge([
                'seo_title'        => '图集广场 · 案例相册',
                'seo_description'  => '浏览全部带图集的文档与案例相册',
                'page_title'       => '图集广场',
                'plaza_sort'       => $sortKey,
                'plaza_sort_label' => $sortLabel,
                'plaza_keyword'    => trim($keyword),
                'plaza_list'       => $res['list'],
                'plaza_total'      => $total,
                'plaza_page'       => $pageNum,
                'plaza_pages'      => (int) ($res['pages'] ?? 1),
                'plaza_empty'      => $res['list'] === [] ? 1 : 0,
            ], app(WeappPaginationGateway::class)->paginationBuild($pageNum, $total, $limit, $query))], '');
    }

    private static function excerpt(string $text, int $max = 120): string
    {
        $text = trim(strip_tags($text));
        if ($text === '') {
            return '';
        }
        if (mb_strlen($text) <= $max) {
            return $text;
        }

        return mb_substr($text, 0, $max) . '…';
    }
}
