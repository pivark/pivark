<?php
declare(strict_types=1);

namespace weapp\doc_gallery\service;

use app\common\service\weapp\WeappSupportGateway;

/** document_save manifest handler（文档 Tab POST → 图集同步） */
final class GalleryDocumentAddonSync
{
    /** @param list<array<string, mixed>> $rows */
    public static function syncForDocument(int $documentId, array $rows)
    {
        $bridge = new GalleryDocumentAddonBridge();
        if (!$bridge->isEnabled()) {
            return app(WeappSupportGateway::class)->resultOk(null, 'ok');
        }

        return $bridge->syncForDocument($documentId, $rows);
    }
}
