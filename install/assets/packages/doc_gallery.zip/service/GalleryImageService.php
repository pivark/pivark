<?php
declare(strict_types=1);

namespace weapp\doc_gallery\service;


use app\common\service\weapp\WeappFrontGateway;
use app\common\service\weapp\WeappSupportGateway;

/** 图集缩略图：GD 裁切 + 可选水印 + 文件缓存 */
class GalleryImageService
{
    /** @var list<string> */
    private const IMAGE_EXTS = ['jpg', 'jpeg', 'png', 'gif', 'webp'];

    public static function publicThumbUrl(string $imageUrl, int $width, int $height = 0): string
    {
        if ($width < 1 || $imageUrl === '') {
            return $imageUrl;
        }
        $rel = self::relativeUploadPath($imageUrl);
        if ($rel === '') {
            return $imageUrl;
        }
        $token = rtrim(strtr(base64_encode($rel), '+/', '-_'), '=');
        $query = 'p=' . rawurlencode($token) . '&w=' . $width;
        if ($height > 0) {
            $query .= '&h=' . $height;
        }

        return '/api/v1/plugins/doc_gallery/thumb?' . $query;
    }

    /** @return list<int> */
    public static function srcsetWidths(int $baseWidth): array
    {
        if ($baseWidth < 1) {
            return [];
        }
        $widths = array_values(array_unique([$baseWidth, (int) round($baseWidth * 1.5), $baseWidth * 2]));
        sort($widths);

        return array_values(array_filter($widths, static fn (int $w): bool => $w <= 2000));
    }

    public static function buildSrcset(string $imageUrl): string
    {
        if (!GalleryConfigService::srcsetEnabled()) {
            return '';
        }
        $base = GalleryConfigService::effectiveThumbWidth();
        if ($base < 1) {
            return '';
        }
        $parts = [];
        foreach (self::srcsetWidths($base) as $w) {
            $parts[] = self::publicThumbUrl($imageUrl, $w) . ' ' . $w . 'w';
        }

        return implode(', ', $parts);
    }

    /**
     * @return mixed
     */
    public static function serve(string $token, int $width, int $height = 0)
    {
        if (!GalleryGateService::publicSurfaceOpen()) {
            return app(WeappSupportGateway::class)->resultFail('unavailable');
        }
        $width = max(16, min(2000, $width));
        $height = $height > 0 ? max(16, min(2000, $height)) : 0;
        $rel = self::decodeToken($token);
        if ($rel === '') {
            return app(WeappSupportGateway::class)->resultFail('invalid_path');
        }
        $abs = self::absoluteUploadPath($rel);
        if ($abs === null || !is_file($abs)) {
            return app(WeappSupportGateway::class)->resultFail('not_found');
        }

        $cacheFile = self::cachePath($rel, $width, $height);
        if (is_file($cacheFile) && filemtime($cacheFile) >= filemtime($abs)) {
            return app(WeappSupportGateway::class)->resultOk(['body' => (string) file_get_contents($cacheFile), 'mime' => self::mimeForPath($cacheFile), 'cache' => true], '');
        }

        if (!extension_loaded('gd')) {
            $body = (string) file_get_contents($abs);

            return app(WeappSupportGateway::class)->resultOk(['body' => $body, 'mime' => self::mimeForPath($abs)], '');
        }

        $ext = strtolower(pathinfo($abs, PATHINFO_EXTENSION));
        if ($ext === 'jpeg') {
            $ext = 'jpg';
        }
        if (!in_array($ext, self::IMAGE_EXTS, true)) {
            return app(WeappSupportGateway::class)->resultFail('unsupported');
        }

        $img = self::loadImage($abs, $ext);
        if ($img === null) {
            return app(WeappSupportGateway::class)->resultFail('load_failed');
        }

        $srcW = imagesx($img);
        $srcH = imagesy($img);

        if ($height < 1) {
            $height = (int) max(1, round($srcH * ($width / $srcW)));
        }
        $thumbHeight = max(1, $height);

        $thumb = imagecreatetruecolor($width, $thumbHeight);
        if ($ext === 'png' || $ext === 'gif') {
            imagealphablending($thumb, false);
            imagesavealpha($thumb, true);
            $transparent = imagecolorallocatealpha($thumb, 0, 0, 0, 127);
            if ($transparent !== false) {
                imagefilledrectangle($thumb, 0, 0, $width, $thumbHeight, $transparent);
            }
        }
        imagecopyresampled($thumb, $img, 0, 0, 0, 0, $width, $thumbHeight, $srcW, $srcH);
        imagedestroy($img);

        $dir = dirname($cacheFile);
        if (!is_dir($dir)) {
            mkdir($dir, 0755, true);
        }
        self::saveImage($thumb, $cacheFile, 'jpg', 85);
        imagedestroy($thumb);

        if (GalleryConfigService::watermarkThumbs()) {
            app(WeappFrontGateway::class)->watermarkMaybeApply($cacheFile, 'jpg');
        }

        return app(WeappSupportGateway::class)->resultOk(['body' => (string) file_get_contents($cacheFile), 'mime' => 'image/jpeg'], '');
    }

    private static function decodeToken(string $token): string
    {
        $token = trim($token);
        if ($token === '') {
            return '';
        }
        $pad = strlen($token) % 4;
        if ($pad > 0) {
            $token .= str_repeat('=', 4 - $pad);
        }
        $decoded = base64_decode(strtr($token, '-_', '+/'), true);

        return is_string($decoded) ? self::sanitizeRelativePath($decoded) : '';
    }

    public static function relativeUploadPath(string $urlOrPath): string
    {
        $path = trim($urlOrPath);
        if ($path === '') {
            return '';
        }
        if (str_starts_with($path, 'http://') || str_starts_with($path, 'https://')) {
            $parsed = parse_url($path, PHP_URL_PATH);
            $path = is_string($parsed) ? $parsed : '';
        }
        $path = ltrim($path, '/');
        if (str_starts_with($path, 'uploads/')) {
            return self::sanitizeRelativePath($path);
        }

        return '';
    }

    private static function sanitizeRelativePath(string $path): string
    {
        $path = str_replace('\\', '/', $path);
        $path = preg_replace('#/+#', '/', $path) ?? $path;
        if ($path === '' || str_contains($path, '..')) {
            return '';
        }
        if (!str_starts_with($path, 'uploads/')) {
            return '';
        }

        return $path;
    }

    private static function absoluteUploadPath(string $rel): ?string
    {
        $root = rtrim((string) (defined('ROOT_PATH') ? ROOT_PATH : ''), '/\\') . DIRECTORY_SEPARATOR . 'public' . DIRECTORY_SEPARATOR;
        $full = $root . str_replace('/', DIRECTORY_SEPARATOR, $rel);
        $real = realpath($full);
        $uploadsRoot = realpath($root . 'uploads');
        if ($real === false || $uploadsRoot === false || !str_starts_with($real, $uploadsRoot)) {
            return null;
        }

        return $real;
    }

    private static function cachePath(string $rel, int $w, int $h): string
    {
        $root = rtrim(app(WeappSupportGateway::class)->projectPathsRuntimeDir(), '/\\');
        $hash = md5($rel . '|' . $w . 'x' . $h);

        return $root . DIRECTORY_SEPARATOR . 'gallery_thumb'
            . DIRECTORY_SEPARATOR . substr($hash, 0, 2) . DIRECTORY_SEPARATOR . $hash . '.jpg';
    }

    /**
     * @return \GdImage|null
     */
    private static function loadImage(string $path, string $ext): ?\GdImage
    {
        return match ($ext) {
            'jpg'   => @imagecreatefromjpeg($path) ?: null,
            'png'   => @imagecreatefrompng($path) ?: null,
            'gif'   => @imagecreatefromgif($path) ?: null,
            'webp'  => function_exists('imagecreatefromwebp') ? (@imagecreatefromwebp($path) ?: null) : null,
            default => null,
        };
    }

    private static function saveImage(\GdImage $img, string $path, string $ext, int $quality): void
    {
        match ($ext) {
            'jpg'  => imagejpeg($img, $path, $quality),
            'png'  => imagepng($img, $path, (int) round((100 - $quality) / 10)),
            'gif'  => imagegif($img, $path),
            'webp' => function_exists('imagewebp') ? imagewebp($img, $path, $quality) : null,
            default => null,
        };
    }

    private static function mimeForPath(string $path): string
    {
        return match (strtolower(pathinfo($path, PATHINFO_EXTENSION))) {
            'png'  => 'image/png',
            'gif'  => 'image/gif',
            'webp' => 'image/webp',
            default => 'image/jpeg',
        };
    }

    /** @return array{0:int,1:int} */
    public static function probeDimensions(string $urlOrPath): array
    {
        $path = trim($urlOrPath);
        if ($path === '') {
            return [0, 0];
        }

        $rel = self::relativeUploadPath($path);
        if ($rel !== '') {
            $abs = self::absoluteUploadPath($rel);
            if ($abs !== null && is_file($abs)) {
                $info = @getimagesize($abs);

                return is_array($info)
                    ? [(int) $info[0], (int) $info[1]]
                    : [0, 0];
            }
        }

        if (str_starts_with($path, '/')) {
            $root = rtrim((string) (defined('ROOT_PATH') ? ROOT_PATH : ''), '/\\');
            $local = $root . DIRECTORY_SEPARATOR . 'public' . str_replace('/', DIRECTORY_SEPARATOR, $path);
            if (is_file($local)) {
                $info = @getimagesize($local);

                return is_array($info)
                    ? [(int) $info[0], (int) $info[1]]
                    : [0, 0];
            }
        }

        if (!GalleryConfigService::probeRemoteSize()) {
            return [0, 0];
        }

        $url = $path;
        if (!preg_match('#^https?://#i', $url)) {
            if (str_starts_with($path, 'uploads/')) {
                $url = '/' . ltrim($path, '/');
            } else {
                return [0, 0];
            }
        }

        if (!preg_match('#^https?://#i', $url)) {
            return [0, 0];
        }

        $ctx = stream_context_create([
            'http' => [
                'timeout'     => 5,
                'user_agent'  => 'PivarkGallery/1.0',
                'follow_location' => 1,
            ],
            'ssl' => [
                'verify_peer'      => true,
                'verify_peer_name' => true,
            ],
        ]);
        $data = app(WeappSupportGateway::class)->localFileGetContents($url, false, $ctx);
        if ($data === null || $data === '') {
            return [0, 0];
        }
        $info = getimagesizefromstring($data);

        return is_array($info)
            ? [(int) $info[0], (int) $info[1]]
            : [0, 0];
    }
}
