<?php
declare(strict_types=1);

namespace weapp\doc_gallery\service;

use app\common\service\weapp\WeappAdminGateway;

final class GalleryAdminSpaRoutes
{
    public static function register(): void
    {
        $gw = app(WeappAdminGateway::class);
        $id = 'doc_gallery';

        $gw->adminSpaHostRegisterPluginPage($id,
            'settings',
            'WeappDocGallerySettings',
            ['title' => '基础设置'],
        );
        $gw->adminSpaHostRegisterPluginPage($id,
            'list',
            'WeappDocGalleryList',
            ['title' => '条目管理'],
        );

        foreach (['usage' => ['WeappGalleryUsage', '前台调用说明', '/weapp/usage/index'], 'guide' => ['WeappGalleryGuide', '功能介绍', '/weapp/guide/index']] as $seg => [$name, $title, $component]) {
            $path = $gw->adminSpaHostPath($id, $seg);
            $gw->adminSpaExplicitRouteRegister($path, [
                'name'      => $name,
                'path'      => $path,
                'component' => $component,
                'meta'      => ['pivarkWeapp' => $id, 'title' => $title],
            ]);
        }

        $gw->adminSpaRouteIconRegister($gw->adminSpaHostPath($id, 'settings'), 'lucide:images');
        $gw->adminSpaRouteIconRegister($gw->adminSpaHostPath($id, 'list'), 'lucide:list');
        $gw->adminWeappNavTabsRegister($id, [
            $gw->adminWeappNavTab('settings', '基础设置', 'settings'),
            $gw->adminWeappNavTab('list', '条目管理', 'list'),
        ]);
    }
}
