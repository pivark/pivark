<?php
declare(strict_types=1);

namespace weapp\doc_gallery\service;

use app\common\service\weapp\WeappEntitlementGateway;
use app\common\service\weapp\WeappSupportGateway;
use app\common\service\weapp\WeappUploadGateway;
use ZipArchive;

/**
 * 图集 ZIP 导入：解压图片到 uploads，返回公开路径（按文件名排序）
 * 落盘经 WeappUploadGateway::putContentsUnderUploads；不平行自写 uploads。
 */
final class GalleryZipImportService
{
    private const MAX_ZIP_BYTES = 52428800; // 50MB
    private const MAX_FILES = 100;

    /** @var list<string> */
    private const IMAGE_EXTS = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'avif', 'bmp'];

    /**
     * @return mixed ServiceResult data: items[{image_path,title}], count
     */
    public static function extractToUploads(int $documentId, string $tmpZipPath, string $originalName = '')
    {
        if (!app(WeappEntitlementGateway::class)->entitlementCan('doc_gallery')) {
            return app(WeappSupportGateway::class)->resultFail('插件未授权');
        }
        if (!is_file($tmpZipPath)) {
            return app(WeappSupportGateway::class)->resultFail('上传文件无效');
        }
        $size = (int) filesize($tmpZipPath);
        if ($size < 1 || $size > self::MAX_ZIP_BYTES) {
            return app(WeappSupportGateway::class)->resultFail('ZIP 过大或为空（上限 50MB）');
        }
        if (!class_exists(ZipArchive::class)) {
            return app(WeappSupportGateway::class)->resultFail('服务器未启用 ZipArchive，无法解压');
        }

        $zip = new ZipArchive();
        if ($zip->open($tmpZipPath) !== true) {
            return app(WeappSupportGateway::class)->resultFail('无法打开 ZIP（文件可能损坏）');
        }

        $docSeg = $documentId > 0 ? (string) $documentId : 'draft';
        $relDir = 'uploads/doc_gallery/' . $docSeg . '/' . date('YmdHis') . '_' . substr(bin2hex(random_bytes(4)), 0, 8);
        $uploadGw = app(WeappUploadGateway::class);

        /** @var list<array{image_path:string,title:string,sort_key:string}> $collected */
        $collected = [];
        /** @var list<string> $usedBases */
        $usedBases = [];
        try {
            for ($i = 0; $i < $zip->numFiles; $i++) {
                if (count($collected) >= self::MAX_FILES) {
                    break;
                }
                $stat = $zip->statIndex($i);
                if (!is_array($stat)) {
                    continue;
                }
                $name = str_replace('\\', '/', (string) $stat['name']);
                if ($name === '' || str_ends_with($name, '/')) {
                    continue;
                }
                if (str_contains($name, '..') || str_starts_with($name, '/') || preg_match('#(^|/)\.#', $name) === 1) {
                    continue;
                }
                if (str_contains($name, '__MACOSX/') || str_contains($name, '.DS_Store')) {
                    continue;
                }
                $base = basename($name);
                $ext = strtolower(pathinfo($base, PATHINFO_EXTENSION));
                if (!in_array($ext, self::IMAGE_EXTS, true)) {
                    continue;
                }
                $safeBase = self::safeFilename($base, $ext);
                $n = 1;
                while (in_array($safeBase, $usedBases, true)) {
                    $safeBase = pathinfo(self::safeFilename($base, $ext), PATHINFO_FILENAME)
                        . '_' . $n . '.' . $ext;
                    ++$n;
                }
                $stream = $zip->getStream($name);
                if ($stream === false) {
                    continue;
                }
                $binary = stream_get_contents($stream) ?: '';
                fclose($stream);
                if ($binary === '') {
                    continue;
                }
                $rel = $uploadGw->putContentsUnderUploads($relDir . '/' . $safeBase, $binary);
                if ($rel === '') {
                    continue;
                }
                $usedBases[] = $safeBase;
                $public = '/' . $rel;
                $title = pathinfo($base, PATHINFO_FILENAME);
                $collected[] = [
                    'image_path' => $public,
                    'title'      => $title,
                    'sort_key'   => mb_strtolower($base),
                ];
            }
        } finally {
            $zip->close();
        }

        if ($collected === []) {
            return app(WeappSupportGateway::class)->resultFail('ZIP 内未找到可用图片（jpg/png/gif/webp 等）');
        }

        usort($collected, static fn (array $a, array $b): int => strcmp($a['sort_key'], $b['sort_key']));
        $items = [];
        foreach ($collected as $row) {
            $items[] = [
                'image_path' => $row['image_path'],
                'title'      => $row['title'],
            ];
        }

        $hint = $originalName !== '' ? '（' . $originalName . '）' : '';

        return app(WeappSupportGateway::class)->resultOk(
            ['items' => $items, 'count' => count($items), 'dir' => '/' . $relDir],
            '已解压 ' . count($items) . ' 张' . $hint . '，请保存文档写入图集'
        );
    }

    private static function safeFilename(string $base, string $ext): string
    {
        $stem = pathinfo($base, PATHINFO_FILENAME);
        $stem = preg_replace('/[^\w\x{4e00}-\x{9fff}\-_.]+/u', '_', $stem) ?? 'img';
        $stem = trim($stem, '._') ?: 'img';
        $stem = mb_substr($stem, 0, 80);

        return $stem . '.' . $ext;
    }
}
