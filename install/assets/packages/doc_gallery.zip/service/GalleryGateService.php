<?php
declare(strict_types=1);

namespace weapp\doc_gallery\service;

use app\common\service\weapp\WeappEntitlementGateway;
use app\common\service\weapp\WeappSupportGateway;
use app\common\support\ServiceResult;

/** 图集插件：授权与 gallery_open 门禁 */
final class GalleryGateService
{
    public static function entitled(): bool
    {
        return app(WeappEntitlementGateway::class)->entitlementCan('doc_gallery');
    }

    public static function publicSurfaceOpen(): bool
    {
        return self::entitled() && GalleryConfigService::isOpen();
    }

    /**
     * @return ServiceResult|null null 表示通过
     */
    public static function requirePublicApi(): ?ServiceResult
    {
        if (!self::entitled()) {
            return app(WeappSupportGateway::class)->resultFail('图集插件未授权');
        }
        if (!GalleryConfigService::isOpen()) {
            return app(WeappSupportGateway::class)->resultFail('图集已关闭');
        }

        return null;
    }
}
