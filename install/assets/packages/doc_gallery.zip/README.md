# 文档图集（`gallery`）

> **用户文档 SSOT：** 本目录 `README.md`（`## 功能介绍` · `## 使用说明` · `## 升级日志` · `## 安装与开发`） · v1.0.0 · `pivark/doc_gallery`；后台与市场直读，改完即生效。

## 功能介绍

<h3>这个插件能帮你做什么？</h3>
<p>产品案例、教程步骤、活动照片要挂在文章里，却不想把 HTML 写死？图集插件帮你在后台维护<strong>分组相册</strong>，前台一行标签输出轮播、网格或瀑布流，还支持灯箱浏览与图集广场。</p>
<p class="pv-tip">适合产品图集、案例截图、教程分步图、摄影作品集；与 thumb 占位图插件互补——gallery 管正文内相册，thumb 管列表无封面时的占位。</p>

<h3>典型场景</h3>
<figure class="pv-guide-figure">
    <img src="guide-scenarios.svg" alt="产品图集、案例、教程、图集广场" loading="lazy" width="720" />
</figure>

<h3>使用范围</h3>
<figure class="pv-guide-figure">
    <img src="guide-scope.svg" alt="全部文档、指定栏目、会员可见" loading="lazy" width="720" />
</figure>
<ul>
    <li><strong>发布页</strong>：独立 Tab 或嵌入正文，可拖动与同形态插件排序；</li>
    <li><strong>使用范围</strong>：全部文档 / 指定栏目；</li>
    <li><strong>批量维护</strong>：文档面板批量选图 + 全站条目列表。</li>
</ul>

<h3>发布页编辑</h3>
<figure class="pv-guide-figure">
    <img src="guide-editor.svg" alt="文档图集分组与拖拽排序" loading="lazy" width="640" />
</figure>

<h3>站长怎么用？</h3>
<ol>
    <li>启用「图集」插件，打开「<strong>基础设置</strong>」：配置开关、发布页展现与使用范围，保存。</li>
    <li>编辑文档时打开「文档图集」Tab：先点选<strong>展现样式</strong>（网格 / 瀑布流 / 轮播等 7 种）；图片以<strong>表格列表</strong>维护（文件名 / 缩略图悬停预览·点击素材库 / 路径 / 设为封面 / 上移下移 / 删除）；也可上传、ZIP 解压或空白处 Ctrl+V 粘贴路径。</li>
    <li>详情模板加入 <code>{pv:doc_gallery}</code> 或分组标签（见前台调用说明）。</li>
</ol>

<h3>常见问题</h3>
<ul>
    <li><strong>前台无图？</strong> 检查文档是否有条目、模板 group 是否匹配、主栏目是否在使用范围内。</li>
    <li><strong>与 thumb 区别？</strong> thumb 自动替换列表/正文坏链占位；gallery 是主动维护的相册内容。</li>
</ul>

## 使用说明

<h3>功能简介（前端向）</h3>
<p>为文档挂载图片相册，支持多分组、多种展现样式；前台通过模板标签或 REST API 输出。</p>

<figure class="pv-guide-figure">
    <img src="usage-template-wireframe.svg" alt="详情页图集区块位置" loading="lazy" width="640" />
</figure>

<h3>后台配置</h3>
<ol>
    <li>「<strong>基础设置</strong>」：插件开关、发布页展现、使用范围（全部文档 / 指定栏目）。</li>
    <li>文档发布页「图集」面板：分组与展现样式、条目路径/说明、上移/下移/「设为封面」、<strong>上传 ZIP 解压</strong>（jpg/png/gif/webp 等，按文件名排序入列表）、粘贴路径加图；分组可开启打包下载（需 download 插件）。</li>
    <li>「<strong>条目管理</strong>」：按文档 ID、分组标识、状态、关键词筛选；健康检查提示缺 Alt、缺标题等待办；可改 sort 数字。</li>
    <li>「<strong>基础设置</strong>」：可配置图集第 1 张写入文档封面（仅空 / 始终跟随）。</li>
</ol>

<h3>前台模板</h3>
<p>单分组输出：</p>
<pre class="pv-weapp-code">{pv:doc_gallery id="$document_id" group="case"}</pre>
<p>循环全部分组（标签内 <code>{gallery}</code> 占位输出该组图集）：</p>
<pre class="pv-weapp-code">{pv:doc_gallery_groups id="$document_id"}
&lt;section class="pv-gallery-group-block"&gt;
  &lt;h3&gt;{$field.title}&lt;/h3&gt;
  {gallery}
&lt;/section&gt;
{/pv:doc_gallery_groups}</pre>
<p>临时覆盖展现样式：</p>
<pre class="pv-weapp-code">{pv:doc_gallery id="$document_id" group="case" style="carousel"}</pre>

<h3>分组循环字段（gallery_groups）</h3>
<table>
    <thead><tr><th>字段</th><th>说明</th></tr></thead>
    <tbody>
        <tr><td><code>{$field.group_key}</code></td><td>分组标识</td></tr>
        <tr><td><code>{$field.title}</code></td><td>分组标题</td></tr>
        <tr><td><code>{$field.display_style}</code></td><td>展现样式 id</td></tr>
        <tr><td><code>{$field.item_count}</code></td><td>启用条目数</td></tr>
        <tr><td><code>{$field.pack_download_url}</code></td><td>打包下载 ZIP（需分组开启且 download 插件可用）</td></tr>
        <tr><td><code>{$field.cover_url}</code></td><td>首张缩略图</td></tr>
    </tbody>
</table>

<h3>图片循环字段（gallery）</h3>
<table>
    <thead><tr><th>字段</th><th>说明</th></tr></thead>
    <tbody>
        <tr><td><code>{$field.image_url}</code></td><td>原图 URL</td></tr>
        <tr><td><code>{$field.thumb_url}</code></td><td>缩略图 URL</td></tr>
        <tr><td><code>{$field.srcset}</code></td><td>响应式 srcset</td></tr>
        <tr><td><code>{$field.title}</code> / <code>{$field.alt}</code></td><td>标题 / Alt</td></tr>
        <tr><td><code>{$field.link_url}</code> / <code>{$field.description}</code> / <code>{$field.shot_info}</code></td><td>外链 / 说明 / 拍摄信息</td></tr>
        <tr><td><code>{$field.aspect_ratio}</code></td><td>宽高比（瀑布流优化）</td></tr>
    </tbody>
</table>

<h3>REST API</h3>
<pre class="pv-weapp-code">GET /api/v1/plugins/doc_gallery/document-items?document_id=123&amp;group_key=case
GET /api/v1/plugins/doc_gallery/document-groups?document_id=123
GET /api/v1/plugins/doc_gallery/plaza?page=1&amp;sort=hot&amp;q=关键词</pre>

<p>图集广场页面：<code>/doc_gallery</code>（需在设置中开启「图集广场」）。</p>

<h3>前台静态资源（weapp 真源 · 默认兜底）</h3>
<p>轮播 / 瀑布流 / 灯箱的 <strong>默认样式与脚本</strong> 打包在 <code>weapp/doc_gallery/assets/</code>，随插件安装即可用，不依赖主题是否单独维护图集 CSS/JS。渲染 <code>{pv:doc_gallery}</code> 时由 <code>GalleryFrontAssets</code> 登记，<code>{pv:frontassets /}</code> 按需输出；URL 形如 <code>/weapp/doc_gallery/assets/css/gallery.css</code>、<code>/weapp/doc_gallery/assets/js/lightbox.js</code>。</p>
<p><strong>主题分工：</strong>站点主题（<code>template/*/assets</code>）只允许用 SCSS <strong>覆盖皮肤</strong>（配色、圆角、卡片阴影等），结构布局与灯箱/轮播交互以插件资源为准。<strong>禁止</strong>把下列文件复制到 <code>public/static/common/</code> 或主题 <code>assets/js|css/</code> 充当第二套真源。</p>
<ul>
    <li><code>assets/css/gallery.css</code> — 全布局 + 灯箱默认兜底</li>
    <li><code>assets/js/carousel.js</code> · <code>masonry.js</code> · <code>lightbox.js</code>（按布局与灯箱开关按需加载）</li>
</ul>

<h3>前台效果示意</h3>
<figure class="pv-guide-figure">
    <img src="usage-front-mockup.svg" alt="访客端相册与灯箱浏览" loading="lazy" width="640" />
</figure>

<p class="pv-tip">静态资源含灯箱与轮播脚本，按所选展现样式按需加载。</p>

## 升级日志

### 1.0.x · 2026-07-16

- 文档发布页专用壳：7 种展现样式 chip 可选；主图路径置顶；更多设置折叠；Ctrl+V 粘贴路径加图
- 样式区「前台开大示意」live mock + SVG 缩略图，点选即切换
- 保存时由条目带回 `display_style` 写入分组，前台布局立即生效

### 1.0.0 · 2026-01-15

- 文档图片相册后台管理与排序
- 文档编辑器 inline 图集 Tab
- 前台 `{pv:doc_gallery}` 标签展示

## 安装与开发

### 目录

```text
weapp/doc_gallery/
├── plugin.json
├── Plugin.php
├── service/
│   ├── GalleryService.php
│   ├── GalleryConfigService.php
│   ├── GalleryLayoutService.php      # 7 种展现样式 SSOT
│   ├── GalleryImageService.php
│   ├── GalleryPlazaService.php
│   ├── GalleryAccessService.php
│   └── GalleryGateService.php
├── api/controller/Gallery.php
├── admin/
└── database/
```

### 能力摘要

| 模块 | 说明 |
|------|------|
| 文档编辑 | 发布页专用壳：7 种样式 chip、主图路径、粘贴加图；批量仍可走条目列表 |
| 后台 | 设置、专用条目列表（文档 ID / 分组筛选）、guide/usage |
| 前台 | `{pv:doc_gallery}` · `{pv:doc_gallery_groups}` · 7 种 layout · 灯箱 · 轮播指示点/自动播放 |
| API | `document-items` · `document-groups` · `thumb` · `plaza` |
| `PluginApiRegistry` 对外 API | ✅ `GalleryPublic`（`listPublicForDocument`） |
| 广场 | `/doc_gallery` 带图集文档聚合（`gallery_plaza_open`） |
| 联动 | `gallery_list_thumb_fallback` · `gallery_unify_thumb_size`（thumb 插件）· `pack_download`（download ZIP） |

### 标装进度

| 项 | 状态 |
|----|------|
| `service/` 业务集中 | ✅ |
| `composer.json` | ✅ `pivark/doc_gallery` |
| `PluginApiRegistry` 对外 API | ✅ `GalleryPublic`（`listPublicForDocument`） |

### 展现样式

`grid` · `masonry` · `carousel` · `filmstrip` · `list` · `justified` · `hero` — 分组级 `display_style`，发布页可选，标签可 `style=` 覆盖。

### 超级搜索

文档保存后图集元数据进入 `documents.search_text`（Core `DocumentAddonSearchRegistry` 桥接）。手册：[docs/06-插件/文档扩展插件-超级搜索接入.md](../../docs/06-插件/文档扩展插件-超级搜索接入.md)

### 禁止

- 在 `app/common/service/` 写业务 extends 壳（document-addon 桥接仅 `document/bridge/Document*Service`）
- 插件内引用 `app/common/service/{Plugin}*` 业务空壳
