<?php
declare(strict_types=1);

namespace weapp\doc_gallery\api\controller;

use app\common\service\weapp\WeappSupportGateway;
use app\common\support\ApiResponse;
use think\facade\Request;
use think\Response;
use weapp\doc_gallery\service\GalleryGateService;
use weapp\doc_gallery\service\GalleryConfigService;
use weapp\doc_gallery\service\GalleryImageService;
use weapp\doc_gallery\service\GalleryService;

class Gallery
{
    public function documentItems()
    {
        $blocked = GalleryGateService::requirePublicApi();
        if ($blocked !== null) {
            return app(WeappSupportGateway::class)->apiFromServiceResult($blocked);
        }

        GalleryService::ensureAutoload();
        GalleryService::ensureSchema();
        $documentId = (int) Request::get('document_id', 0);
        if ($documentId < 1) {
            return ApiResponse::fail('document_id 无效');
        }
        $limit = max(0, min(100, (int) Request::get('limit', 0)));
        $groupKey = trim((string) Request::get('group_key', Request::get('group', 'default')));

        return ApiResponse::success(GalleryService::listPublicForDocument($documentId, $limit, $groupKey));
    }

    public function documentGroups()
    {
        $blocked = GalleryGateService::requirePublicApi();
        if ($blocked !== null) {
            return app(WeappSupportGateway::class)->apiFromServiceResult($blocked);
        }

        GalleryService::ensureAutoload();
        GalleryService::ensureSchema();
        $documentId = (int) Request::get('document_id', 0);
        if ($documentId < 1) {
            return ApiResponse::fail('document_id 无效');
        }
        if (!\weapp\doc_gallery\service\GalleryAccessService::canViewDocumentId($documentId)) {
            return ApiResponse::success([]);
        }
        $groups = GalleryService::listGroupsForDocument($documentId, true);
        $out = [];
        foreach ($groups as $group) {
            $key = (string) ($group['group_key'] ?? 'default');
            $out[] = [
                'group_key'     => $key,
                'title'         => (string) ($group['title'] ?? $key),
                'display_style' => (string) ($group['display_style'] ?? GalleryConfigService::defaultDisplayStyle()),
                'display_style_label' => (string) ($group['display_style_label'] ?? ''),
                'sort'          => (int) ($group['sort'] ?? 0),
                'item_count'    => count(GalleryService::listForDocument($documentId, true, $key)),
            ];
        }

        return ApiResponse::success($out);
    }

    public function thumb(): Response
    {
        GalleryService::ensureAutoload();
        $token = trim((string) Request::get('p', ''));
        $width = max(16, min(2000, (int) Request::get('w', 400)));
        $height = max(0, min(2000, (int) Request::get('h', 0)));
        $result = GalleryImageService::serve($token, $width, $height);
        if (!$result->isOk()) {
            return Response::create($result->message() !== '' ? $result->message() : 'error', 'html', 404);
        }
        $payload = $result->dataArray();

        return Response::create((string) ($payload['body'] ?? ''), 'html', 200, [
            'Content-Type'              => (string) ($payload['mime'] ?? 'image/jpeg'),
            'Cache-Control'             => 'public, max-age=86400',
            'X-Content-Type-Options'  => 'nosniff',
        ]);
    }

    public function plaza()
    {
        $blocked = GalleryGateService::requirePublicApi();
        if ($blocked !== null) {
            return app(WeappSupportGateway::class)->apiFromServiceResult($blocked);
        }

        GalleryService::ensureAutoload();
        if (!GalleryConfigService::plazaOpen()) {
            return ApiResponse::fail('图集广场未开启');
        }

        $page = max(1, (int) Request::get('page', 1));
        $limit = max(6, min(48, (int) Request::get('limit', 24)));
        $sort = trim((string) Request::get('sort', 'hot'));
        $keyword = trim((string) Request::get('q', Request::get('keyword', '')));

        return ApiResponse::success(
            \weapp\doc_gallery\service\GalleryPlazaService::listPublic($page, $limit, $sort, $keyword)
        );
    }
}
