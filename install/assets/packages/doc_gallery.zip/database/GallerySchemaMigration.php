<?php
declare(strict_types=1);

namespace weapp\doc_gallery\database;

use app\common\contract\WeappSchemaMigration;
use think\facade\Db;

/** doc_gallery schema 台阶（SSOT：database/install.sql + 增量列） */
final class GallerySchemaMigration extends WeappSchemaMigration
{
    public static function identifier(): string
    {
        return 'doc_gallery';
    }

    public static function version(): int
    {
        return 2;
    }

    public static function up(): void
    {
        $table = self::prefix() . 'weapp_doc_gallery_groups';
        self::ensureColumn(
            $table,
            'pack_access_mode',
            "ALTER TABLE `{$table}` ADD COLUMN `pack_access_mode` varchar(32) NOT NULL DEFAULT 'free' COMMENT '打包下载权限 free/login/member/points' AFTER `pack_download`"
        );
        self::ensureColumn(
            $table,
            'pack_member_level_id',
            "ALTER TABLE `{$table}` ADD COLUMN `pack_member_level_id` int unsigned NOT NULL DEFAULT 0 COMMENT '会员等级门槛（access=member）' AFTER `pack_access_mode`"
        );
        self::ensureColumn(
            $table,
            'pack_points_cost',
            "ALTER TABLE `{$table}` ADD COLUMN `pack_points_cost` int unsigned NOT NULL DEFAULT 0 COMMENT '积分消耗（access=points）' AFTER `pack_member_level_id`"
        );
    }

    private static function ensureColumn(string $table, string $column, string $alterSql): void
    {
        $safeCol = str_replace(['\\', "'", '%', '_'], ['\\\\', "\\'", '\\%', '\\_'], $column);
        $rows = Db::query("SHOW COLUMNS FROM `{$table}` LIKE '{$safeCol}'");
        if ($rows !== []) {
            return;
        }
        Db::execute($alterSql);
    }
}
