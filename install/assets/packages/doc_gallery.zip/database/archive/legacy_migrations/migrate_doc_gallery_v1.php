<?php
/**
 * 元舟 PivArk — 企业全域原子化数字资产中枢
 * (c) 2024-2026 pivark.com. All rights reserved.
 * Author: Angelo
 * 未经允许，不可用于商业用途。
 */
declare(strict_types=1);

require_once dirname(__DIR__, 4) . '/app/database/migrations/_migration_bootstrap.php';

$name = 'migrate_doc_gallery_v1';

function migration_down(PDO $pdo, string $pfx, string $db): void
{
    // schema v1 幂等 up；不回滚分组列扩展
}

migration_entry($name, static function (PDO $pdo, string $pfx, string $db): void {
    \weapp\doc_gallery\database\GallerySchemaMigration::up();
    echo "  GallerySchemaMigration::up() done\n";
});
