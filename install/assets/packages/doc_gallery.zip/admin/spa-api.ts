import { fetchSpaWeappPluginMetaApi } from '#/api/pivark/core/spa';
import type { WeappDocGalleryMeta } from '#/api/pivark/core/spa-meta-types';

export const GALLERY_PLUGIN_ID = 'doc_gallery' as const;

export function fetchGalleryPluginMetaApi() {
  return fetchSpaWeappPluginMetaApi<WeappDocGalleryMeta>(GALLERY_PLUGIN_ID);
}
