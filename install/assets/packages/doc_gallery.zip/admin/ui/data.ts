import type { GalleryListRow } from '@weapp-doc-gallery/api/gallery';

import type { PvFormSchema } from '#/adapter/form';
import type {
  OnActionClickFn,
  VxeTableGridColumns,
} from '#/adapter/vxe-table';

import { fetchGalleryListApi } from '@weapp-doc-gallery/api/gallery';
import {
  PV_COL_FLAG,
  PV_COL_ID,
  PV_COL_NUM,
  PV_COL_OPS,
  PV_COL_TEXT,
} from '#/composables/pv-admin-list-column-presets';
import { usePvAdminListSearchFormOptions } from '#/composables/pv-admin-list-form-layout';

export type { GalleryListRow };

const GALLERY_STATUS_OPTIONS = [
  { label: '启用', value: '1' },
  { label: '禁用', value: '0' },
];

export function useGalleryGridFormSchema(): PvFormSchema[] {
  return [
    {
      component: 'Input',
      fieldName: 'keyword',
      label: '关键词',
      componentProps: {
        clearable: true,
        placeholder: '标题 / Alt',
      },
    },
    {
      component: 'Input',
      fieldName: 'group_key',
      label: '分组标识',
      componentProps: {
        clearable: true,
        placeholder: 'group_key',
      },
    },
    {
      component: 'Input',
      fieldName: 'document_id',
      label: '文档 ID',
      componentProps: {
        clearable: true,
        placeholder: '文档 ID',
      },
    },
    {
      component: 'Select',
      fieldName: 'status',
      label: '状态',
      componentProps: {
        clearable: true,
        options: GALLERY_STATUS_OPTIONS,
        placeholder: '全部',
      },
    },
  ];
}

export function useDocGalleryListGridFormOptions() {
  return usePvAdminListSearchFormOptions(useGalleryGridFormSchema());
}

export function mapGalleryListQueryParams(formValues: Record<string, unknown>) {
  const docRaw = String(formValues.document_id ?? '').trim();
  const docId = Number.parseInt(docRaw, 10);
  const status = formValues.status;
  return {
    document_id: docId > 0 ? docId : undefined,
    group_key: String(formValues.group_key ?? '').trim() || undefined,
    keyword: String(formValues.keyword ?? '').trim() || undefined,
    status:
      status === '' || status === null || status === undefined
        ? undefined
        : String(status),
  };
}

export function useGalleryGridColumns(
  onActionClick: OnActionClickFn<GalleryListRow>,
  onStatusChange?: (
    newStatus: number,
    row: GalleryListRow,
  ) => PromiseLike<boolean | undefined>,
): VxeTableGridColumns<GalleryListRow> {
  return [
    {
      field: 'id',
      title: 'ID',
      width: 72,
      ...PV_COL_ID,
    },
    {
      field: 'document_id',
      title: '文档 ID',
      width: 88,
      ...PV_COL_ID,
    },
    {
      field: 'document_title',
      title: '文档',
      minWidth: 140,
      ...PV_COL_TEXT,
      formatter: ({ row }) =>
        String(row.document_title ?? '').trim() ||
        (row.document_id ? `#${row.document_id}` : '—'),
    },
    {
      field: 'group_key',
      title: '分组',
      width: 120,
      ...PV_COL_TEXT,
    },
    {
      field: 'title',
      title: '标题',
      minWidth: 140,
      ...PV_COL_TEXT,
    },
    {
      field: 'image_path',
      title: '图片路径',
      minWidth: 180,
      ...PV_COL_TEXT,
    },
    {
      field: 'sort',
      title: '排序',
      width: 88,
      ...PV_COL_NUM,
      fixed: 'right',
      slots: { default: 'sort' },
    },
    {
      field: 'status',
      title: '状态',
      width: 88,
      ...PV_COL_FLAG,
      fixed: 'right',
      cellRender: {
        attrs: { beforeChange: onStatusChange },
        name: 'CellSwitch',
      },
    },
    {
      ...PV_COL_OPS,
      cellRender: {
        attrs: {
          nameField: 'title',
          nameTitle: '图集条目',
          onClick: onActionClick,
          skipDeleteConfirm: true,
          variant: 'capsule',
        },
        name: 'CellOperation',
        options: ['delete'],
      },
      field: 'operation',
      fixed: 'right',
      showOverflow: false,
      title: '操作',
      width: 100,
    },
  ];
}

export async function fetchGalleryListPage(
  page: { currentPage: number; pageSize: number },
  formValues: Record<string, unknown>,
) {
  const result = await fetchGalleryListApi({
    ...mapGalleryListQueryParams(formValues),
    page: page.currentPage,
    pageSize: page.pageSize,
  });
  return {
    items: result.list,
    total: result.total,
  };
}
