<script lang="ts" setup>
import type { GalleryListRow } from './data';

import PvAdminGridLoadingSkeleton from '#/components/pivark/PvAdminGridLoadingSkeleton.vue';
import WeappPluginShell from '#/components/pivark/weapp/WeappPluginShell.vue';

import { useDocGalleryList } from './list/use-gallery-list';

defineOptions({ name: 'WeappDocGalleryList' });

const { Grid, saveSort } = useDocGalleryList();
</script>

<template>
  <WeappPluginShell plugin-id="doc_gallery" nav-key="list">
    <Grid table-title="条目管理">
      <template #loading>
        <PvAdminGridLoadingSkeleton fill />
      </template>
      <template #sort="{ row }">
        <el-input-number
          v-if="row"
          v-model="(row as GalleryListRow).sort"
          :controls="false"
          size="small"
          class="!w-[72px]"
          @change="saveSort(row as GalleryListRow)"
        />
      </template>
    </Grid>
  </WeappPluginShell>
</template>
