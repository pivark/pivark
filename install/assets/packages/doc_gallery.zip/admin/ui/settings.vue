<script lang="ts" setup>
import { computed, onMounted, ref } from 'vue';
import { useRouter } from 'vue-router';

import { ElMessage } from 'element-plus';

import WeappPluginKpiRow from '#/components/pivark/weapp/WeappPluginKpiRow.vue';
import WeappPluginPageCard from '#/components/pivark/weapp/WeappPluginPageCard.vue';
import WeappPluginShell from '#/components/pivark/weapp/WeappPluginShell.vue';
import WeappPluginSlotCards from '#/components/pivark/weapp/WeappPluginSlotCards.vue';
import PvModuleSection from '#/components/pivark/shell/PvModuleSection.vue';
import { fetchGalleryPluginMetaApi } from '@weapp-doc-gallery/spa-api';
import { pivarkMutation } from '#/api/pivark/core/mutation';

import {
  cfgFlag,
  cfgString,
  useWeappPluginDisabledCount,
  useWeappSettingsLoading,
  type WeappSlotCard,
} from '#/composables/use-weapp-plugin-settings';

defineOptions({ name: 'WeappDocGallerySettings' });

type NavOption = {
  id: number;
  label: string;
  title?: string;
  content_kind?: string;
};

type HealthCheck = {
  count?: number;
  hint?: string;
  key?: string;
  label?: string;
  route?: string;
  severity?: string;
};

const router = useRouter();
const { loading, saving, withLoading, withSaving } = useWeappSettingsLoading();
const galleryOpen = ref(true);
const scope = ref('all');
const editorSlot = ref('inline');
const listThumbFallback = ref(true);
const litpicFromFirst = ref<'empty' | 'always'>('empty');
const lightbox = ref(false);
const plazaOpen = ref(true);
const carouselAutoplay = ref(false);
const defaultDisplayStyle = ref('grid');
const cfgSnapshot = ref<Record<string, unknown>>({});
const navIds = ref<number[]>([]);
const navOptions = ref<NavOption[]>([]);
const slotCards = ref<WeappSlotCard[]>([]);
const stats = ref({ total: 0, enabled: 0 });
const healthChecks = ref<HealthCheck[]>([]);
const healthScore = ref(0);

const disabledCount = useWeappPluginDisabledCount(stats);

const kpiItems = computed(() => [
  { label: '图集条目', value: stats.value.total },
  { label: '已启用', value: stats.value.enabled },
  { label: '已停用', value: disabledCount.value },
]);

const healthAttentionCount = computed(() =>
  healthChecks.value.filter((item) => {
    const count = Number(item.count ?? 0);
    const severity = String(item.severity ?? '');
    return count > 0 && severity !== 'ok';
  }).length,
);

const healthScoreTagType = computed(() => {
  if (healthScore.value >= 90) return 'success';
  if (healthScore.value >= 70) return 'warning';
  return 'danger';
});

function healthItemStatus(item: HealthCheck): 'info' | 'ok' | 'warn' {
  const count = Number(item.count ?? 0);
  if (count <= 0) return 'ok';
  return String(item.severity ?? '') === 'info' ? 'info' : 'warn';
}

function healthCountTagType(
  item: HealthCheck,
): 'danger' | 'info' | 'success' | 'warning' {
  const status = healthItemStatus(item);
  if (status === 'ok') return 'success';
  if (status === 'info') return 'info';
  return 'warning';
}

function goHealthRoute(route?: string) {
  const path = String(route ?? '').trim();
  if (path) router.push(path);
}

function parseIdJson(raw: unknown): number[] {
  const text = String(raw ?? '').trim();
  if (text === '') return [];
  try {
    const parsed = JSON.parse(text);
    if (!Array.isArray(parsed)) return [];
    return parsed
      .map((v) => Number(v))
      .filter((n) => Number.isFinite(n) && n > 0);
  } catch {
    return [];
  }
}

async function loadMeta() {
  await withLoading(async () => {
    const meta = await fetchGalleryPluginMetaApi();
    const cfg = meta.cfg ?? {};
    cfgSnapshot.value = { ...cfg };
    galleryOpen.value = cfgFlag(cfg, 'gallery_open');
    scope.value = cfgString(cfg, 'gallery_nav_scope', 'all');
    if (scope.value !== 'all' && scope.value !== 'navs') {
      scope.value = 'all';
    }
    editorSlot.value = cfgString(
      cfg,
      'gallery_document_editor_slot',
      String(meta.editorSlot ?? 'inline'),
    );
    listThumbFallback.value = cfgFlag(cfg, 'gallery_list_thumb_fallback');
    const litpicMode = cfgString(cfg, 'gallery_litpic_from_first', 'empty');
    litpicFromFirst.value = litpicMode === 'always' ? 'always' : 'empty';
    lightbox.value = cfgFlag(cfg, 'gallery_lightbox', false);
    plazaOpen.value = cfgFlag(cfg, 'gallery_plaza_open', true);
    carouselAutoplay.value = cfgFlag(cfg, 'gallery_carousel_autoplay', false);
    defaultDisplayStyle.value = cfgString(cfg, 'gallery_default_display_style', 'grid');
    navIds.value = parseIdJson(cfg.gallery_allowed_nav_ids);
    navOptions.value = meta.navOptions ?? [];
    slotCards.value = meta.slotCards ?? [];
    stats.value = {
      total: meta.stats?.total ?? 0,
      enabled: meta.stats?.enabled ?? 0,
    };
    healthChecks.value = meta.health?.checks ?? [];
    healthScore.value = meta.health?.score ?? 0;
  });
}

async function handleSave() {
  await withSaving(async () => {
    await pivarkMutation('/weapp/doc_gallery/configSave', {
      ...cfgSnapshot.value,
      gallery_open: galleryOpen.value ? '1' : '0',
      gallery_document_editor_slot: editorSlot.value,
      gallery_nav_scope: scope.value,
      gallery_allowed_nav_ids: JSON.stringify(navIds.value),
      gallery_list_thumb_fallback: listThumbFallback.value ? '1' : '0',
      gallery_litpic_from_first: litpicFromFirst.value,
      gallery_lightbox: lightbox.value ? '1' : '0',
      gallery_plaza_open: plazaOpen.value ? '1' : '0',
      gallery_carousel_autoplay: carouselAutoplay.value ? '1' : '0',
      gallery_default_display_style: defaultDisplayStyle.value,
    });
    ElMessage.success('保存成功');
    await loadMeta();
  });
}

function goList() {
  router.push('/weapp/host/doc_gallery/list');
}

onMounted(loadMeta);
</script>

<template>
  <WeappPluginShell nav-key="settings">
    <WeappPluginPageCard :loading="loading" title="基础设置">
      <template #actions>
        <el-button @click="goList">条目管理</el-button>
        <el-button :loading="saving" type="primary" @click="handleSave">
          保存配置
        </el-button>
      </template>

      <WeappPluginKpiRow :items="kpiItems" />

      <PvModuleSection title="功能开关">
        <el-switch v-model="galleryOpen" active-text="启用" inactive-text="关闭" />
        <p class="pv-weapp-hint mt-2">
          关闭后前台不渲染图集标签，文档编辑器图集面板也会隐藏。
        </p>
      </PvModuleSection>

      <PvModuleSection title="发布页展现">
        <p class="pv-weapp-hint mb-3">
          控制文档发布页中「图集」面板出现的位置，保存后全站生效。
        </p>
        <WeappPluginSlotCards v-model="editorSlot" :cards="slotCards" />
      </PvModuleSection>

      <PvModuleSection title="文档封面（缩略图）">
        <el-switch
          v-model="listThumbFallback"
          active-text="允许图集首图参与列表缩略"
          inactive-text="关闭"
        />
        <p class="pv-weapp-hint mt-2 mb-3">
          开启后，可按下面规则把图集排序第 1 张写入文档封面（列表缩略图）。文档 Tab
          里「设为封面」= 把该图移到第 1。
        </p>
        <el-radio-group
          v-model="litpicFromFirst"
          :disabled="!listThumbFallback"
        >
          <el-radio value="empty">仅无封面时写入</el-radio>
          <el-radio value="always">始终跟随图集第 1 张</el-radio>
        </el-radio-group>
      </PvModuleSection>

      <PvModuleSection title="前台体验">
        <el-switch
          v-model="lightbox"
          active-text="点击图片开大预览（灯箱）"
          inactive-text="关闭灯箱"
        />
        <el-switch
          v-model="plazaOpen"
          class="mt-3"
          active-text="开放图集广场"
          inactive-text="关闭广场"
        />
        <el-switch
          v-model="carouselAutoplay"
          class="mt-3"
          active-text="轮播样式自动播放"
          inactive-text="轮播手动切换"
        />
        <p class="pv-weapp-hint mt-3 mb-2">新建图集默认展现样式</p>
        <el-select v-model="defaultDisplayStyle" style="max-width: 280px">
          <el-option label="响应式网格" value="grid" />
          <el-option label="瀑布流" value="masonry" />
          <el-option label="轮播" value="carousel" />
          <el-option label="胶片条" value="filmstrip" />
          <el-option label="列表" value="list" />
          <el-option label="两端对齐" value="justified" />
          <el-option label="主图+缩略" value="hero" />
        </el-select>
      </PvModuleSection>

      <PvModuleSection title="使用范围">
        <el-radio-group v-model="scope" class="pv-weapp-scope-radios">
          <el-radio value="all">全部文档</el-radio>
          <el-radio value="navs">指定栏目</el-radio>
        </el-radio-group>
        <p class="pv-weapp-hint mt-2">
          仅主栏目在圈选范围内的文档可配置图集并在前台渲染
          <code v-pre>{pv:doc_gallery}</code>
          。勾选父栏目时含子栏目。
        </p>
      </PvModuleSection>

      <PvModuleSection v-show="scope === 'navs'" title="可用栏目">
        <el-empty
          v-if="navOptions.length === 0"
          description="请先在「网站栏目」中创建内容栏目"
        />
        <el-checkbox-group
          v-else
          v-model="navIds"
          class="pv-weapp-check-grid"
        >
          <el-checkbox v-for="n in navOptions" :key="n.id" :value="n.id">
            {{ n.label || n.title }}
          </el-checkbox>
        </el-checkbox-group>
      </PvModuleSection>

      <PvModuleSection v-if="healthChecks.length > 0" title="健康检查">
        <template #tools>
          <el-tag
            :type="healthScoreTagType"
            effect="plain"
            round
            size="small"
          >
            {{ healthScore }} 分
          </el-tag>
          <span
            v-if="healthAttentionCount > 0"
            class="text-muted-foreground text-xs"
          >
            {{ healthAttentionCount }} 项待关注
          </span>
          <span v-else class="text-muted-foreground text-xs">全部正常</span>
        </template>
        <ul class="pv-weapp-health-list">
          <li
            v-for="item in healthChecks"
            :key="item.key || item.label"
            class="pv-weapp-health-item"
            :class="`is-${healthItemStatus(item)}`"
          >
            <span class="pv-weapp-health-item__dot" aria-hidden="true" />
            <div class="pv-weapp-health-item__main">
              <div class="pv-weapp-health-item__top">
                <span class="pv-weapp-health-item__label">{{
                  item.label
                }}</span>
                <div class="pv-weapp-health-item__actions">
                  <el-tag
                    :type="healthCountTagType(item)"
                    effect="plain"
                    round
                    size="small"
                  >
                    {{ item.count ?? 0 }}
                  </el-tag>
                  <el-button
                    v-if="item.route && Number(item.count ?? 0) > 0"
                    link
                    size="small"
                    type="primary"
                    @click="goHealthRoute(item.route)"
                  >
                    去处理
                  </el-button>
                </div>
              </div>
              <p v-if="item.hint" class="pv-weapp-health-item__hint">
                {{ item.hint }}
              </p>
            </div>
          </li>
        </ul>
      </PvModuleSection>
    </WeappPluginPageCard>
  </WeappPluginShell>
</template>
