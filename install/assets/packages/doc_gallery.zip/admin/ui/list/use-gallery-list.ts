import type { GalleryListRow } from '../data';

import type { VxeTableGridOptions } from '#/adapter/vxe-table';

import { shallowRef } from 'vue';

import { ElMessage } from 'element-plus';

import { pivarkMutation } from '#/api/pivark/core/mutation';
import { confirmAdminRowDelete } from '#/composables/use-admin-batch-actions';
import {
  PV_ADMIN_LIST_GRID_CLASS,
  PV_ADMIN_LIST_GRID_OPTIONS,
  usePvAdminListGrid,
} from '#/composables/use-pv-admin-list-grid';

import {
  fetchGalleryListPage,
  useGalleryGridColumns,
  useDocGalleryListGridFormOptions,
} from '../data';

const deleteUrl = '/weapp/doc_gallery/delete';
const statusUrl = '/weapp/doc_gallery/status';
const sortUrl = '/weapp/doc_gallery/sort';

export function useDocGalleryList() {
  const gridApiRef = shallowRef<
    ReturnType<typeof usePvAdminListGrid<GalleryListRow>>['gridApi'] | null
  >(null);

  function getGridApi() {
    return gridApiRef.value!;
  }

  async function refreshGrid() {
    await getGridApi().query();
  }

  async function onStatusChange(newStatus: number, row: GalleryListRow) {
    const id = Number(row.id ?? 0);
    if (id < 1) {
      return false;
    }
    try {
      await pivarkMutation(statusUrl, { id, status: newStatus });
      ElMessage.success('状态已更新');
      row.status = newStatus;
      return true;
    } catch {
      return false;
    }
  }

  async function saveSort(row: GalleryListRow) {
    const id = Number(row.id ?? 0);
    if (id < 1) {
      return;
    }
    await pivarkMutation(sortUrl, {
      id,
      sort: Number(row.sort ?? 0),
    });
    ElMessage.success('排序已更新');
  }

  async function handleDelete(row: GalleryListRow) {
    await confirmAdminRowDelete({
      message: '确定删除该图集条目？',
      title: '删除',
      action: async () => {
        await pivarkMutation(deleteUrl, { id: Number(row.id) });
        await refreshGrid();
      },
      successMessage: '已删除',
    });
  }

  function onActionClick(e: { code: string; row: GalleryListRow }) {
    if (e.code === 'delete') {
      void handleDelete(e.row);
    }
  }

  const { Grid, gridApi } = usePvAdminListGrid<GalleryListRow>(() => ({
    formOptions: useDocGalleryListGridFormOptions(),
    gridClass: PV_ADMIN_LIST_GRID_CLASS,
    gridOptions: {
      ...PV_ADMIN_LIST_GRID_OPTIONS,
      columns: useGalleryGridColumns(onActionClick, onStatusChange),
      proxyConfig: {
        ...PV_ADMIN_LIST_GRID_OPTIONS.proxyConfig,
        ajax: {
          query: async ({ page }, formValues) => {
            const result = await fetchGalleryListPage(page, formValues ?? {});
            return {
              items: result.items,
              total: result.total,
            };
          },
        },
      },
      rowConfig: {
        keyField: 'id',
      },
    } as VxeTableGridOptions,
  }));
  gridApiRef.value = gridApi;

  return {
    Grid,
    refreshGrid,
    saveSort,
  };
}
