<?php
declare(strict_types=1);

namespace weapp\doc_gallery\admin;

use app\common\service\weapp\WeappPluginGateway;
use app\common\service\weapp\WeappSupportGateway;
use app\common\contract\PluginAdminBaseTrait;
use app\common\contract\PluginAdminUsageTrait;
use think\facade\Request;
use think\Response;
use weapp\doc_gallery\service\GalleryService;
use weapp\doc_gallery\service\GalleryConfigService;
use weapp\doc_gallery\service\GalleryZipImportService;

/** 文档图集 后台 */
class AdminController
{
    use PluginAdminBaseTrait;
    use PluginAdminUsageTrait;

    public function __construct()
    {
        $this->pluginIdentifier = 'doc_gallery';
    }

    public function index(): Response
    {
        if (!$this->entitled()) {
            return $this->renderDisabled();
        }
        GalleryService::ensureAutoload();
        $manifest = app(WeappPluginGateway::class)->pluginReadManifest('doc_gallery') ?? [];

        return $this->renderPluginView('index', array_merge(
            $this->pluginContext($manifest),
            [
                'cfg'   => GalleryConfigService::all(),
                'stats' => GalleryService::statsAdmin(),
            ]
        ));
    }

    public function list(): Response
    {
        if (!$this->entitled()) {
            return $this->renderDisabled();
        }
        GalleryService::ensureAutoload();
        $manifest = app(WeappPluginGateway::class)->pluginReadManifest('doc_gallery') ?? [];
        if (Request::isAjax()) {
            $page = max(1, (int) Request::get('page', 1));
            $filters = [
                'status'      => Request::get('status', ''),
                'document_id' => (int) Request::get('document_id', 0),
                'keyword'     => (string) Request::get('keyword', ''),
                'group_key'   => (string) Request::get('group_key', ''),
            ];

            return app(WeappSupportGateway::class)->apiFromServiceResult(GalleryService::listAdmin($filters, $page));
        }

        return $this->renderPluginView('list', array_merge(
            $this->pluginContext($manifest, 'items'),
            ['stats' => GalleryService::statsAdmin()]
        ));
    }

    public function configSave(): Response
    {
        if (!Request::isPost()) {
            return app(WeappSupportGateway::class)->apiMethodNotAllowed();
        }
        if (!$this->entitled()) {
            return app(WeappSupportGateway::class)->apiFromServiceResult(app(WeappSupportGateway::class)->resultForbidden('插件未授权'));
        }

        return app(WeappSupportGateway::class)->apiFromServiceResult(GalleryConfigService::saveAdmin(Request::post()));
    }

    public function save(): Response
    {
        if (!Request::isPost()) {
            return app(WeappSupportGateway::class)->apiMethodNotAllowed();
        }
        GalleryService::ensureAutoload();

        return app(WeappSupportGateway::class)->apiFromServiceResult(GalleryService::saveAdmin(Request::post()));
    }

    public function delete(): Response
    {
        if (!Request::isPost()) {
            return app(WeappSupportGateway::class)->apiMethodNotAllowed();
        }
        GalleryService::ensureAutoload();

        return app(WeappSupportGateway::class)->apiFromServiceResult(GalleryService::deleteAdmin((int) Request::post('id', 0)));
    }

    public function status(): Response
    {
        if (!Request::isPost()) {
            return app(WeappSupportGateway::class)->apiMethodNotAllowed();
        }
        GalleryService::ensureAutoload();

        return app(WeappSupportGateway::class)->apiFromServiceResult(GalleryService::statusAdmin((int) Request::post('id', 0), (int) Request::post('status', 1)));
    }

    public function sort(): Response
    {
        if (!Request::isPost()) {
            return app(WeappSupportGateway::class)->apiMethodNotAllowed();
        }
        GalleryService::ensureAutoload();

        return app(WeappSupportGateway::class)->apiFromServiceResult(GalleryService::sortAdmin((int) Request::post('id', 0), (int) Request::post('sort', 0)));
    }

    public function batchImport(): Response
    {
        if (!Request::isPost()) {
            return app(WeappSupportGateway::class)->apiMethodNotAllowed();
        }
        GalleryService::ensureAutoload();
        $documentId = (int) Request::post('document_id', 0);
        $paths = Request::post('image_paths', []);
        if (is_string($paths) && $paths !== '') {
            $decoded = json_decode($paths, true);
            $paths = is_array($decoded) ? $decoded : (preg_split('/[\r\n|]+/', $paths) ?: []);
        }

        return app(WeappSupportGateway::class)->apiFromServiceResult(GalleryService::batchImportAdmin(
            $documentId,
            is_array($paths) ? $paths : [],
            (string) Request::post('group_key', 'default')
        ));
    }

    /** 上传图片 ZIP → 解压到 uploads，返回路径列表（文档 Tab 写入本地条目后随文档保存） */
    public function importZip(): Response
    {
        if (!Request::isPost()) {
            return app(WeappSupportGateway::class)->apiMethodNotAllowed();
        }
        if (!$this->entitled()) {
            return app(WeappSupportGateway::class)->apiFromServiceResult(
                app(WeappSupportGateway::class)->resultForbidden('插件未授权')
            );
        }
        GalleryService::ensureAutoload();

        $uploadFile = request()->file('file');
        if (!$uploadFile instanceof \think\file\UploadedFile) {
            return app(WeappSupportGateway::class)->apiFromServiceResult(
                app(WeappSupportGateway::class)->resultFail('请选择 ZIP 文件')
            );
        }
        $ext = strtolower(pathinfo((string) $uploadFile->getOriginalName(), PATHINFO_EXTENSION));
        if ($ext !== 'zip') {
            return app(WeappSupportGateway::class)->apiFromServiceResult(
                app(WeappSupportGateway::class)->resultFail('仅支持 .zip')
            );
        }

        $tmp = sys_get_temp_dir() . DIRECTORY_SEPARATOR . 'doc_gallery_zip_' . uniqid('', true) . '.zip';
        if (!@copy($uploadFile->getPathname(), $tmp)) {
            return app(WeappSupportGateway::class)->apiFromServiceResult(
                app(WeappSupportGateway::class)->resultFail('上传失败')
            );
        }

        try {
            $result = GalleryZipImportService::extractToUploads(
                (int) Request::post('document_id', 0),
                $tmp,
                (string) $uploadFile->getOriginalName()
            );
        } finally {
            app(WeappSupportGateway::class)->localFileUnlinkQuiet($tmp, 'doc_gallery_zip');
        }

        return app(WeappSupportGateway::class)->apiFromServiceResult($result);
    }
}
