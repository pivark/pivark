/** SSOT: doc_gallery document-editor.html（文档 Tab：展现样式 + 图片表格列表 + 素材库） */
export function buildGalleryDocumentEditorHtml() {
  return `<!DOCTYPE html>
<html lang="zh-CN" data-iframe-theme="light">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>文档图集 · 文档编辑</title>
  <style>
    :root {
      font-family: var(--pv-font-family, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif);
      font-size: var(--pv-font-size, 14px);
      --pv-radius-base: 4px;
      --pv-radius-lg: calc(var(--pv-radius-base) + 4px);
      --pv-primary: rgb(64, 158, 255);
      --pv-primary-soft: rgb(236, 245, 255);
      --pv-primary-border: rgb(179, 216, 255);
      --pv-primary-hover: rgb(102, 177, 255);
      --pv-danger: rgb(245, 108, 108);
      --pv-danger-soft: rgb(254, 240, 240);
      --pv-danger-border: rgb(251, 196, 196);
      --pv-card-bg: rgb(255, 255, 255);
      --pv-fill: rgb(245, 247, 250);
      --pv-border: rgb(228, 231, 237);
      --pv-text: rgb(48, 49, 51);
      --pv-text-secondary: rgb(144, 147, 153);
      --pv-input-bg: rgb(255, 255, 255);
    }
    html[data-iframe-theme='light'] {
      color-scheme: light;
      --pv-primary-soft: color-mix(in srgb, var(--pv-primary) 12%, var(--pv-card-bg));
      --pv-primary-border: color-mix(in srgb, var(--pv-primary) 35%, var(--pv-border));
      --pv-primary-hover: color-mix(in srgb, var(--pv-primary) 88%, #000);
      --pv-danger-soft: color-mix(in srgb, var(--pv-danger) 12%, var(--pv-card-bg));
      --pv-danger-border: color-mix(in srgb, var(--pv-danger) 40%, var(--pv-border));
    }
    html[data-iframe-theme='dark'] {
      color-scheme: dark;
      --pv-danger-soft: color-mix(in srgb, var(--pv-danger) 16%, var(--pv-card-bg));
      --pv-danger-border: color-mix(in srgb, var(--pv-danger) 40%, var(--pv-border));
      --pv-primary-soft: color-mix(in srgb, var(--pv-primary) 14%, var(--pv-card-bg));
      --pv-primary-border: color-mix(in srgb, var(--pv-primary) 35%, var(--pv-border));
      --pv-primary-hover: color-mix(in srgb, var(--pv-primary) 82%, #fff);
    }
    body { margin: 0; padding: 8px 4px 12px; background: transparent; color: var(--pv-text); font-size: inherit; }
    body.embed-tab { padding: 14px 20px 28px; box-sizing: border-box; overflow: auto; background: transparent; }
    html.embed-tab, body.embed-tab { min-height: 100%; height: auto; }
    .hint { color: var(--pv-text-secondary); margin: 0 0 12px; line-height: 1.5; font-size: 0.857em; }
    .hint.err { color: var(--pv-danger); font-weight: 500; }
    .actions { display: flex; gap: 10px; flex-wrap: wrap; margin-bottom: 12px; align-items: center; }
    button {
      padding: var(--pv-btn-padding, 8px 15px); border-radius: var(--pv-radius-base);
      border: 1px solid var(--pv-border); background: var(--pv-card-bg); color: var(--pv-text);
      cursor: pointer; font-size: inherit; line-height: 1.4;
    }
    button:hover { background: var(--pv-fill); }
    button.primary { background: var(--pv-primary); color: #fff; border-color: var(--pv-primary); }
    button.primary:hover { background: var(--pv-primary-hover); border-color: var(--pv-primary-hover); }
    button:disabled { opacity: 0.55; cursor: not-allowed; }
    button.danger { color: var(--pv-danger); border-color: var(--pv-danger-border); background: var(--pv-danger-soft); }
    button.plain { color: var(--pv-primary); border-color: var(--pv-primary-border); background: var(--pv-primary-soft); }
    button.linkish { border: none; background: transparent; color: var(--pv-primary); padding: 2px 6px; }
    a { color: var(--pv-primary); font-size: inherit; text-decoration: none; }
    a:hover { opacity: 0.85; }
    .is-hidden { display: none !important; }
    input[type="text"], input[type="number"], select {
      box-sizing: border-box; padding: var(--pv-input-padding, 7px 11px);
      border: 1px solid var(--pv-border); border-radius: var(--pv-radius-base); font-size: inherit;
      background: var(--pv-input-bg, var(--pv-card-bg)); color: var(--pv-text); width: 100%;
    }
    input[type="checkbox"] { accent-color: var(--pv-primary); width: auto; }
    input[type="text"]:focus, input[type="number"]:focus, select:focus {
      outline: none; border-color: var(--pv-primary);
      box-shadow: 0 0 0 2px color-mix(in srgb, var(--pv-primary) 18%, transparent);
    }
    label.lbl { font-size: 0.857em; color: var(--pv-text-secondary); font-weight: 500; display: block; margin-bottom: 4px; }
    .style-panel {
      border: 1px solid var(--pv-border); border-radius: var(--pv-radius-lg);
      background: var(--pv-card-bg); margin-bottom: 16px;
      box-shadow: 0 1px 2px color-mix(in srgb, var(--pv-text) 6%, transparent);
      overflow: hidden;
    }
    html[data-iframe-theme='dark'] .style-panel { box-shadow: none; }
    .style-panel-body { padding: 0; }
    .style-meta {
      display: grid; grid-template-columns: minmax(0, 1.4fr) minmax(0, 1fr);
      gap: 12px 20px; align-items: end;
      padding: 14px 16px; border-bottom: 1px solid var(--pv-border);
    }
    @media (max-width: 640px) { .style-meta { grid-template-columns: 1fr; } }
    .style-section {
      padding: 12px 16px 14px;
    }
    .style-section-head {
      display: flex; align-items: baseline; justify-content: space-between; gap: 10px; flex-wrap: wrap;
      margin-bottom: 10px;
    }
    .style-panel-title { font-weight: 600; margin: 0; font-size: 0.929em; }
    .style-panel-hint { margin: 0; font-size: 0.786em; color: var(--pv-text-secondary); }
    .chip-row { display: flex; flex-wrap: wrap; gap: 8px; }
    .chip-row button {
      display: inline-flex; flex-direction: column; align-items: center; gap: 5px;
      padding: 8px 8px 7px; border-radius: 8px; font-size: 0.786em;
      border: 1px solid var(--pv-border); background: var(--pv-fill); min-width: 76px;
    }
    .chip-row button.is-active {
      background: var(--pv-primary-soft); border-color: var(--pv-primary-border);
      color: var(--pv-primary); font-weight: 600;
      box-shadow: 0 0 0 1px color-mix(in srgb, var(--pv-primary) 25%, transparent);
    }
    .chip-thumb {
      width: 56px; height: 32px; object-fit: cover; border-radius: 4px;
      border: 1px solid var(--pv-border); background: var(--pv-card-bg); display: block;
    }
    .style-desc {
      margin: 10px 0 0; font-size: 0.857em; color: var(--pv-text-secondary); line-height: 1.5;
      padding: 8px 10px; border-radius: var(--pv-radius-base); background: var(--pv-fill);
      border: 1px solid transparent;
    }
    .style-desc strong { color: var(--pv-text); font-weight: 600; }
    .style-live {
      margin-top: 10px;
      padding: 10px;
      border-radius: var(--pv-radius-base);
      background: var(--pv-fill);
      border: 1px solid var(--pv-border);
    }
    .style-live-label {
      display: block; font-size: 0.786em; color: var(--pv-text-secondary); margin-bottom: 8px;
    }
    .style-live-stage {
      width: 100%; min-height: 72px;
    }
    .style-live-stage img {
      display: block; width: 100%; height: 100%; object-fit: cover;
      border-radius: 4px; border: 1px solid var(--pv-border); background: var(--pv-card-bg);
    }
    /* grid */
    .style-live-stage.is-grid {
      display: grid; grid-template-columns: repeat(4, 1fr); gap: 6px;
    }
    .style-live-stage.is-grid img { aspect-ratio: 4 / 3; }
    /* masonry — uneven heights */
    .style-live-stage.is-masonry {
      display: grid; grid-template-columns: repeat(4, 1fr); gap: 6px; align-items: start;
    }
    .style-live-stage.is-masonry img:nth-child(4n + 1) { height: 48px; }
    .style-live-stage.is-masonry img:nth-child(4n + 2) { height: 72px; }
    .style-live-stage.is-masonry img:nth-child(4n + 3) { height: 56px; }
    .style-live-stage.is-masonry img:nth-child(4n + 4) { height: 64px; }
    /* carousel — one large + hint strip */
    .style-live-stage.is-carousel {
      display: flex; gap: 8px; align-items: stretch; overflow: hidden;
    }
    .style-live-stage.is-carousel img {
      flex: 0 0 62%; height: 88px; object-fit: cover;
    }
    .style-live-stage.is-carousel img:not(:first-child) {
      flex: 0 0 28%; height: 88px; opacity: 0.55;
    }
    /* filmstrip */
    .style-live-stage.is-filmstrip {
      display: flex; gap: 6px; overflow-x: auto; padding: 6px 0;
      border-top: 1px solid var(--pv-border); border-bottom: 1px solid var(--pv-border);
    }
    .style-live-stage.is-filmstrip img {
      flex: 0 0 56px; width: 56px; height: 40px; border-radius: 2px;
    }
    /* list */
    .style-live-stage.is-list {
      display: flex; flex-direction: column; gap: 8px;
    }
    .style-live-stage.is-list .live-list-row {
      display: grid; grid-template-columns: 88px 1fr; gap: 10px; align-items: center;
    }
    .style-live-stage.is-list .live-list-row img {
      width: 88px; height: 56px; object-fit: cover;
    }
    .style-live-stage.is-list .live-list-cap {
      font-size: 0.786em; color: var(--pv-text-secondary); line-height: 1.35;
      overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
    }
    /* justified — equal height strip */
    .style-live-stage.is-justified {
      display: flex; gap: 4px; height: 64px;
    }
    .style-live-stage.is-justified img {
      flex: 1 1 0; height: 64px; border-radius: 2px;
    }
    /* hero — first large, rest small */
    .style-live-stage.is-hero {
      display: grid; grid-template-columns: repeat(4, 1fr); gap: 6px;
    }
    .style-live-stage.is-hero img:first-child {
      grid-column: 1 / -1; height: 84px;
    }
    .style-live-stage.is-hero img:not(:first-child) {
      height: 44px;
    }
    .field-soft { margin-top: 10px; }
    .pack-access-row { display: flex; flex-wrap: wrap; gap: 8px; align-items: center; margin-top: 8px; }
    .pack-access-row select { width: auto; min-width: 140px; flex: 1 1 140px; }
    .pack-access-row input[type="number"] { width: 88px; flex: 0 0 88px; }
    .pack-field {
      display: flex; align-items: center; gap: 8px; min-height: 34px; font-size: 0.929em;
    }
    .progress-bar { height: 6px; border-radius: 3px; background: var(--pv-border); margin: 0 0 6px; overflow: hidden; }
    .progress-bar-fill { height: 100%; width: 0%; background: var(--pv-primary); transition: width .12s linear; }
    .progress-bar.is-indeterminate .progress-bar-fill {
      width: 35% !important;
      animation: pv-progress-slide 1.1s ease-in-out infinite;
    }
    @keyframes pv-progress-slide {
      0% { transform: translateX(-120%); }
      100% { transform: translateX(320%); }
    }
    .progress-label {
      margin: 0 0 10px; font-size: 0.786em; color: var(--pv-text-secondary); min-height: 1.2em;
    }
    .item-table-wrap {
      border: none; background: transparent; overflow: auto; padding: 2px 0 8px;
    }
    table.item-table {
      width: 100%; border-collapse: separate; border-spacing: 0 10px; min-width: 720px;
    }
    table.item-table th, table.item-table td {
      padding: 16px 14px; vertical-align: middle; text-align: left;
    }
    table.item-table th {
      font-size: 0.786em; color: var(--pv-text-secondary); font-weight: 600;
      background: transparent; white-space: nowrap; border: none; padding-top: 0; padding-bottom: 2px;
    }
    table.item-table tbody tr.item-row td {
      background: var(--pv-card-bg);
      border-top: 1px solid var(--pv-border);
      border-bottom: 1px solid var(--pv-border);
      box-shadow: 0 1px 2px color-mix(in srgb, var(--pv-text) 5%, transparent);
    }
    table.item-table tbody tr.item-row td:first-child {
      border-left: 1px solid var(--pv-border);
      border-radius: 10px 0 0 10px;
    }
    table.item-table tbody tr.item-row td:last-child {
      border-right: 1px solid var(--pv-border);
      border-radius: 0 10px 10px 0;
    }
    table.item-table tbody tr.item-row.is-alt td {
      background: color-mix(in srgb, var(--pv-fill) 75%, var(--pv-card-bg));
    }
    table.item-table tbody tr.item-row:hover td {
      background: color-mix(in srgb, var(--pv-primary) 8%, var(--pv-card-bg));
      border-color: color-mix(in srgb, var(--pv-primary) 28%, var(--pv-border));
    }
    table.item-table tbody tr.item-row.is-cover td {
      background: color-mix(in srgb, var(--pv-primary) 11%, var(--pv-card-bg));
      border-color: color-mix(in srgb, var(--pv-primary) 35%, var(--pv-border));
    }
    table.item-table tbody tr.item-row.is-cover td:first-child {
      box-shadow: inset 4px 0 0 var(--pv-primary);
    }
    table.item-table tbody tr.item-row.is-cover.is-alt td {
      background: color-mix(in srgb, var(--pv-primary) 14%, var(--pv-fill));
    }
    .col-name { width: 160px; min-width: 120px; }
    .col-thumb { width: 88px; }
    .col-path { min-width: 220px; }
    .col-cover { width: 88px; white-space: nowrap; }
    .col-sort { width: 110px; white-space: nowrap; }
    .col-del { width: 72px; white-space: nowrap; }
    .name-inp { font-weight: 500; }
    .url-main { width: 100%; box-sizing: border-box; padding: 7px 10px; font-size: 0.929em; }
    .link-row { margin-top: 8px; display: flex; align-items: center; gap: 8px; }
    .link-row .lbl { margin: 0; flex: 0 0 auto; white-space: nowrap; }
    .link-row input { flex: 1 1 auto; }
    .thumb-cell {
      width: 64px; height: 64px; border-radius: var(--pv-radius-base);
      border: 1px solid var(--pv-border); background: var(--pv-fill);
      overflow: hidden; cursor: pointer; display: flex; align-items: center; justify-content: center;
      position: relative;
    }
    .thumb-cell img { width: 100%; height: 100%; object-fit: cover; display: block; }
    .thumb-cell .thumb-placeholder {
      font-size: 0.714em; color: var(--pv-text-secondary); text-align: center; padding: 4px; line-height: 1.3;
    }
    .thumb-cell:hover { border-color: var(--pv-primary); box-shadow: 0 0 0 2px color-mix(in srgb, var(--pv-primary) 18%, transparent); }
    .thumb-hover-preview {
      position: fixed; z-index: 9999; pointer-events: none; border: 1px solid var(--pv-border);
      border-radius: var(--pv-radius-lg); background: var(--pv-card-bg);
      box-shadow: 0 8px 24px color-mix(in srgb, var(--pv-text) 18%, transparent);
      max-width: min(360px, 42vw); max-height: min(360px, 42vh); overflow: hidden;
    }
    .thumb-hover-preview img { display: block; max-width: 100%; max-height: 100%; object-fit: contain; }
    .sort-btns { display: inline-flex; gap: 4px; }
    .sort-btns button { padding: 3px 8px; font-size: 0.786em; }
    .cover-btn { color: var(--pv-primary); border-color: var(--pv-primary-border); background: var(--pv-primary-soft); padding: 3px 8px; font-size: 0.786em; }
    .cover-badge {
      display: inline-block; font-size: 0.714em; font-weight: 700; color: #fff;
      background: var(--pv-primary); border-radius: 999px; padding: 1px 7px; margin-left: 6px;
      vertical-align: middle;
    }
    .empty-tip {
      border: 1px dashed var(--pv-border); border-radius: var(--pv-radius-lg);
      padding: 28px 16px; text-align: center; color: var(--pv-text-secondary); background: var(--pv-fill);
    }
    .empty-tip p { margin: 0 0 14px; line-height: 1.55; }
    .empty-cta { display: flex; flex-wrap: wrap; gap: 10px; justify-content: center; }
    .group-tabs {
      display: flex; flex-wrap: wrap; gap: 8px; align-items: center;
      margin-bottom: 12px; padding: 0 2px;
    }
    .group-tabs button {
      padding: 5px 12px; font-size: 0.857em; border-radius: 999px;
    }
    .group-tabs button.is-active {
      background: var(--pv-primary-soft); border-color: var(--pv-primary-border);
      color: var(--pv-primary); font-weight: 600;
    }
    .group-tabs .group-add { color: var(--pv-primary); border-style: dashed; }
    .pack-hint {
      margin: 6px 0 0; font-size: 0.786em; color: var(--pv-danger); line-height: 1.4;
    }
    .pack-hint.ok { color: var(--pv-text-secondary); }
    .batch-bar {
      display: flex; flex-wrap: wrap; gap: 8px; align-items: center;
      margin: 0 0 8px; font-size: 0.857em; color: var(--pv-text-secondary);
    }
    .col-check { width: 36px; text-align: center !important; }
    .col-ord { width: 56px; }
    .ord-inp { width: 48px; padding: 4px 6px; text-align: center; }
    .col-drag { width: 28px; color: var(--pv-text-secondary); cursor: grab; user-select: none; text-align: center !important; }
    tr.item-row.is-dragging { opacity: 0.55; }
    tr.item-row.drag-over td { outline: 2px dashed var(--pv-primary); outline-offset: -2px; }
    @media (max-width: 640px) {
      body.embed-tab { padding: 10px 12px 20px; }
    }
  </style>
</head>
<body>
  <p class="hint" id="status">加载中…</p>
  <div class="progress-bar is-hidden" id="progress-wrap"><div class="progress-bar-fill" id="progress-fill"></div></div>
  <p class="progress-label is-hidden" id="progress-label"></p>
  <div class="actions" id="toolbar">
    <button type="button" class="primary" id="add-img">+ 添加图片</button>
    <button type="button" id="pick-media">素材库</button>
    <button type="button" id="upload-imgs" title="上传后进入素材库（uploads，scene=general）">上传图片</button>
    <button type="button" class="danger is-hidden" id="batch-del">批量删除</button>
    <input type="file" id="img-file" accept="image/*" multiple hidden />
    <button type="button" class="plain is-hidden" id="upload-cancel">取消上传</button>
    <button type="button" id="zip-import">上传 ZIP 解压</button>
    <input type="file" id="zip-file" accept=".zip,application/zip" hidden />
    <a href="/admin#/weapp/host/doc_gallery/settings" target="_blank" rel="noopener">插件设置</a>
  </div>
  <div id="style-wrap"></div>
  <div id="root"></div>
  <div class="thumb-hover-preview is-hidden" id="hover-preview"></div>
  <script>
    const PLUGIN_ID = 'doc_gallery';
    const PREPARE = 'pivark:document-editor-prepare-save';
    const EXPORT = 'pivark:document-editor-export';
    const PREFILL = 'pivark:document-editor-prefill';
    const INIT = 'pivark:document-editor-init';
    const THEME = 'pivark:document-editor-theme';
    const RESIZE = 'pivark:document-editor-resize';
    const PICK_MEDIA = 'pivark:document-editor-pick-media';
    const PICK_MEDIA_RESULT = 'pivark:document-editor-pick-media-result';
    const DEFAULT_LAYOUTS = [
      { id: 'grid', label: '响应式网格', desc: '多列自适应方格，通用默认样式' },
      { id: 'masonry', label: '瀑布流', desc: '不等高瀑布排列，适合竖图混排' },
      { id: 'carousel', label: '轮播滑动', desc: '横向滑动大图，带左右切换按钮' },
      { id: 'filmstrip', label: '胶片条', desc: '横向缩略图条，可快速浏览' },
      { id: 'list', label: '竖向列表', desc: '大图逐条展示，适合步骤说明' },
      { id: 'justified', label: '等高铺满', desc: '统一高度裁切，视觉整齐' },
      { id: 'hero', label: '首图突出', desc: '第一张大图 + 其余小图网格' },
    ];

    const params = new URLSearchParams(location.search);
    const editorSlot = String(params.get('slot') || '');
    let documentId = Number(params.get('document_id') || 0);
    let layouts = DEFAULT_LAYOUTS.slice();
    let memberLevels = [];
    let groups = [defaultGroup()];
    let group = groups[0];
    let items = [];
    let selected = {};
    let downloadPluginReady = false;
    let dragFrom = -1;
    let dataReady = false;
    let dataDirty = false;
    let loadSeq = 0;
    let uploadAbort = null;
    let pickSeq = 0;
    const pendingPicks = {};

    const statusEl = document.getElementById('status');
    const rootEl = document.getElementById('root');
    const styleWrap = document.getElementById('style-wrap');
    const addBtn = document.getElementById('add-img');
    const pickMediaBtn = document.getElementById('pick-media');
    const uploadBtn = document.getElementById('upload-imgs');
    const batchDelBtn = document.getElementById('batch-del');
    const uploadCancelBtn = document.getElementById('upload-cancel');
    const imgFileInput = document.getElementById('img-file');
    const zipImportBtn = document.getElementById('zip-import');
    const zipFileInput = document.getElementById('zip-file');
    const hoverPreviewEl = document.getElementById('hover-preview');
    const progressWrap = document.getElementById('progress-wrap');
    const progressFill = document.getElementById('progress-fill');
    const progressLabel = document.getElementById('progress-label');

    if (editorSlot === 'tab') {
      document.documentElement.classList.add('embed-tab');
      document.body.classList.add('embed-tab');
    }

    function defaultGroup() {
      return {
        group_key: 'default',
        title: '默认图集',
        display_style: 'grid',
        pack_download: 0,
        pack_access_mode: 'free',
        pack_member_level_id: 0,
        pack_points_cost: 0,
      };
    }

    function normalizeGroupKey(raw) {
      let key = String(raw || '').toLowerCase().trim();
      key = key.replace(/[^a-z0-9_-]+/g, '-').replace(/^-+|-+$/g, '');
      return key || 'default';
    }

    function syncActiveGroupRef() {
      const key = normalizeGroupKey(group && group.group_key);
      let found = null;
      for (let i = 0; i < groups.length; i++) {
        if (normalizeGroupKey(groups[i].group_key) === key) {
          found = groups[i];
          break;
        }
      }
      if (!found) {
        found = groups[0] || defaultGroup();
        if (!groups.length) groups = [found];
      }
      group = found;
      group.group_key = normalizeGroupKey(group.group_key);
    }

    function activeGroupKey() {
      syncActiveGroupRef();
      return normalizeGroupKey(group.group_key);
    }

    function groupRows() {
      const key = activeGroupKey();
      const rows = [];
      items.forEach(function (it, index) {
        if (normalizeGroupKey(it.group_key) === key) rows.push({ it: it, index: index });
      });
      return rows;
    }

    function updateBatchBar() {
      if (!batchDelBtn) return;
      let n = 0;
      Object.keys(selected).forEach(function (k) { if (selected[k]) n += 1; });
      if (n > 0) {
        batchDelBtn.classList.remove('is-hidden');
        batchDelBtn.textContent = '批量删除（' + n + '）';
      } else {
        batchDelBtn.classList.add('is-hidden');
        batchDelBtn.textContent = '批量删除';
      }
    }

    function defaultItem() {
      return {
        id: 0,
        group_key: activeGroupKey(),
        title: '',
        image_path: '',
        alt_text: '',
        link_url: '',
        description: '',
        status: 1,
      };
    }

    function layoutOf(id) {
      const key = String(id || 'grid');
      for (let i = 0; i < layouts.length; i++) {
        if (layouts[i].id === key) return layouts[i];
      }
      return layouts[0] || { id: 'grid', label: '响应式网格', desc: '' };
    }

    function restOk(body) {
      if (!body || typeof body !== 'object') return false;
      if (body.error) return false;
      return true;
    }

    async function api(path) {
      const url = '/api/v1/admin/' + String(path || '').replace(/^\\/+/, '');
      const res = await fetch(url, { credentials: 'same-origin', headers: { Accept: 'application/json' } });
      const text = await res.text();
      let body = null;
      try { body = JSON.parse(text); } catch (e) { body = null; }
      if (!body || typeof body !== 'object') {
        const looksHtml = new RegExp('^\\\\s*<').test(text) || /<!doctype/i.test(text);
        throw new Error(looksHtml ? '接口非 JSON（可能缓存了旧壳）' : '接口非 JSON');
      }
      return body;
    }

    async function fetchCsrf() {
      const body = await api('session/bootstrap');
      const data = body && body.data ? body.data : body;
      return {
        field: String((data && data.csrf_field) || '__token'),
        token: String((data && data.csrf_token) || ''),
      };
    }

    async function uploadFile(file, signal) {
      const csrf = await fetchCsrf();
      const fd = new FormData();
      fd.append('file', file);
      fd.append('scene', 'general');
      if (csrf.token) fd.append(csrf.field, csrf.token);
      try {
        if (window.crypto && window.crypto.subtle && file && file.arrayBuffer) {
          const buf = await file.arrayBuffer();
          const digest = await window.crypto.subtle.digest('SHA-256', buf);
          const hex = Array.from(new Uint8Array(digest)).map(function (b) {
            return b.toString(16).padStart(2, '0');
          }).join('');
          fd.append('content_hash', hex);
          fd.append('file_size', String(file.size || 0));
        }
      } catch (e) { /* optional dedupe */ }
      const headers = { 'X-Requested-With': 'XMLHttpRequest', Accept: 'application/json' };
      if (csrf.token) headers['X-CSRF-Token'] = csrf.token;
      const res = await fetch('/api/v1/admin/upload/image', {
        method: 'POST',
        credentials: 'same-origin',
        headers: headers,
        body: fd,
        signal: signal,
      });
      const text = await res.text();
      let body = null;
      try { body = JSON.parse(text); } catch (e) { body = null; }
      if (!body || typeof body !== 'object') throw new Error('上传接口非 JSON');
      if (body.error) throw new Error((body.error && body.error.message) || '上传失败');
      const data = body.data || {};
      return String(data.path || data.url || '').trim();
    }

    async function uploadZipFile(file, onProgress) {
      const csrf = await fetchCsrf();
      if (!csrf.token) throw new Error('无法获取 CSRF');
      const fd = new FormData();
      fd.append('file', file, file.name || 'gallery.zip');
      fd.append('document_id', String(documentId || 0));
      fd.append(csrf.field, csrf.token);
      return new Promise(function (resolve, reject) {
        const xhr = new XMLHttpRequest();
        xhr.open('POST', '/api/v1/admin/weapp/doc_gallery/importZip');
        xhr.withCredentials = true;
        xhr.setRequestHeader('Accept', 'application/json');
        xhr.setRequestHeader('X-CSRF-Token', csrf.token);
        xhr.upload.onprogress = function (ev) {
          if (!ev.lengthComputable) return;
          const pct = Math.max(1, Math.min(90, Math.round((ev.loaded / ev.total) * 90)));
          if (typeof onProgress === 'function') onProgress(pct, 'upload');
        };
        xhr.upload.onload = function () {
          if (typeof onProgress === 'function') onProgress(92, 'extract');
        };
        xhr.onerror = function () {
          reject(new Error('网络错误，ZIP 上传失败'));
        };
        xhr.onabort = function () {
          reject(new Error('已取消 ZIP 上传'));
        };
        xhr.onload = function () {
          if (typeof onProgress === 'function') onProgress(98, 'extract');
          let body = null;
          try { body = JSON.parse(xhr.responseText || ''); } catch (e) { body = null; }
          if (!body || typeof body !== 'object') {
            reject(new Error('解压接口非 JSON'));
            return;
          }
          if (typeof onProgress === 'function') onProgress(100, 'done');
          resolve(body);
        };
        xhr.send(fd);
      });
    }

    function applyMemberLevels(raw) {
      if (!Array.isArray(raw)) return;
      memberLevels = raw.map(function (row) {
        return { id: Number(row.id || 0), name: String(row.name || row.label || '') };
      }).filter(function (row) { return row.id > 0 && row.name; });
    }

    function extractPayload(data) {
      const surfaces = data && data.document_editor_surfaces;
      if (!surfaces) return null;
      const rows = [].concat(surfaces.tabs || [], surfaces.inlines || []);
      for (let i = 0; i < rows.length; i++) {
        if (String(rows[i].identifier || '').toLowerCase() === PLUGIN_ID) {
          return rows[i].payload || null;
        }
      }
      return null;
    }

    function applyPayload(payload) {
      dataReady = true;
      selected = {};
      if (Array.isArray(payload && payload.memberLevels)) applyMemberLevels(payload.memberLevels);
      if (!payload || typeof payload !== 'object') {
        groups = [defaultGroup()];
        group = groups[0];
        items = [];
        downloadPluginReady = false;
        render();
        return;
      }
      downloadPluginReady = !!payload.download_plugin_ready;
      if (Array.isArray(payload.layouts) && payload.layouts.length) {
        layouts = payload.layouts.map(function (row) {
          return {
            id: String(row.id || 'grid'),
            label: String(row.label || row.id || ''),
            desc: String(row.desc || ''),
          };
        });
      }
      const rawGroups = Array.isArray(payload.groups) ? payload.groups : [];
      if (rawGroups.length) {
        groups = rawGroups.map(function (g0) {
          return {
            group_key: normalizeGroupKey(g0.group_key || 'default'),
            title: String(g0.title || '默认图集'),
            display_style: String(g0.display_style || 'grid'),
            pack_download: g0.pack_download ? 1 : 0,
            pack_access_mode: String(g0.pack_access_mode || 'free'),
            pack_member_level_id: Number(g0.pack_member_level_id || 0),
            pack_points_cost: Math.max(0, Number(g0.pack_points_cost || 0)),
          };
        });
      } else {
        groups = [defaultGroup()];
      }
      group = groups[0];
      const list = Array.isArray(payload.items) ? payload.items : [];
      items = list.map(function (raw) {
        return {
          id: Number(raw.id || 0),
          group_key: normalizeGroupKey(raw.group_key || group.group_key || 'default'),
          title: String(raw.title || ''),
          image_path: String(raw.image_path || ''),
          alt_text: String(raw.alt_text || raw.alt || ''),
          link_url: String(raw.link_url || ''),
          description: String(raw.description || ''),
          status: Number(raw.status) ? 1 : 1,
        };
      });
      if (!group.display_style && items.length) {
        group.display_style = String(items[0].display_style || 'grid');
      }
      syncActiveGroupRef();
      render();
    }

    function applyInitPayload(payload) {
      applyPayload(payload || {});
    }

    function packAccessValue() {
      if (group.pack_access_mode === 'login') return 'login';
      if (group.pack_access_mode === 'points') return 'points';
      if (group.pack_access_mode === 'member' && group.pack_member_level_id > 0) {
        return 'level:' + group.pack_member_level_id;
      }
      return '0';
    }

    function applyPackAccessValue(val) {
      if (val === 'login') {
        group.pack_access_mode = 'login';
        group.pack_member_level_id = 0;
        group.pack_points_cost = 0;
        return;
      }
      if (val === 'points') {
        group.pack_access_mode = 'points';
        group.pack_member_level_id = 0;
        if (group.pack_points_cost < 1) group.pack_points_cost = 1;
        return;
      }
      if (String(val).indexOf('level:') === 0) {
        group.pack_access_mode = 'member';
        group.pack_member_level_id = parseInt(String(val).slice(6), 10) || 0;
        group.pack_points_cost = 0;
        return;
      }
      group.pack_access_mode = 'free';
      group.pack_member_level_id = 0;
      group.pack_points_cost = 0;
    }

    function fillPackAccessSelect(sel) {
      sel.innerHTML = '';
      const free = document.createElement('option');
      free.value = '0';
      free.textContent = '免费';
      sel.appendChild(free);
      const login = document.createElement('option');
      login.value = 'login';
      login.textContent = '须登录';
      sel.appendChild(login);
      memberLevels.forEach(function (lv) {
        const opt = document.createElement('option');
        opt.value = 'level:' + lv.id;
        opt.textContent = lv.name + '及以上';
        sel.appendChild(opt);
      });
      const points = document.createElement('option');
      points.value = 'points';
      points.textContent = '积分（可选）';
      sel.appendChild(points);
      sel.value = packAccessValue();
    }

    function setUploadProgress(done, total, label, mode) {
      if (progressLabel) {
        if (label) {
          progressLabel.textContent = label;
          progressLabel.classList.remove('is-hidden');
        } else {
          progressLabel.textContent = '';
          progressLabel.classList.add('is-hidden');
        }
      }
      if (total > 0 || mode === 'indeterminate') {
        progressWrap.classList.remove('is-hidden');
        if (mode === 'indeterminate') {
          progressWrap.classList.add('is-indeterminate');
          progressFill.style.width = '35%';
        } else {
          progressWrap.classList.remove('is-indeterminate');
          progressFill.style.width = Math.round((done / total) * 100) + '%';
        }
      } else {
        progressWrap.classList.add('is-hidden');
        progressWrap.classList.remove('is-indeterminate');
        progressFill.style.width = '0%';
      }
    }

    function updateStatus(extra) {
      const key = activeGroupKey();
      const n = items.filter(function (it) {
        return normalizeGroupKey(it.group_key) === key && String(it.image_path || '').trim() !== '';
      }).length;
      let text = (documentId > 0 ? '文档 #' + documentId + ' · ' : '新建文档 · ')
        + '分组「' + (group.title || key) + '」· 图片 ' + n + ' 张 · ' + layoutOf(group.display_style).label;
      if (extra) text += ' · ' + extra;
      statusEl.textContent = text;
      statusEl.className = 'hint';
      updateBatchBar();
    }

    function switchGroup(key) {
      const nk = normalizeGroupKey(key);
      for (let i = 0; i < groups.length; i++) {
        if (normalizeGroupKey(groups[i].group_key) === nk) {
          group = groups[i];
          selected = {};
          render();
          return;
        }
      }
    }

    function addGroup() {
      dataDirty = true;
      let key = 'g' + Date.now().toString(36);
      key = normalizeGroupKey(key);
      const g = defaultGroup();
      g.group_key = key;
      g.title = '分组 ' + (groups.length + 1);
      groups.push(g);
      group = g;
      selected = {};
      render();
      updateStatus('已新增分组');
    }

    function removeActiveGroup() {
      if (groups.length <= 1) {
        statusEl.textContent = '至少保留一个分组';
        statusEl.className = 'hint err';
        return;
      }
      const key = activeGroupKey();
      dataDirty = true;
      items = items.filter(function (it) { return normalizeGroupKey(it.group_key) !== key; });
      groups = groups.filter(function (g) { return normalizeGroupKey(g.group_key) !== key; });
      group = groups[0];
      selected = {};
      render();
      updateStatus('已删除分组');
    }

    function renderStylePanel() {
      styleWrap.innerHTML = '';
      syncActiveGroupRef();

      const tabs = document.createElement('div');
      tabs.className = 'group-tabs';
      tabs.setAttribute('data-group-tabs', '1');
      groups.forEach(function (g) {
        const btn = document.createElement('button');
        btn.type = 'button';
        btn.textContent = g.title || g.group_key;
        if (normalizeGroupKey(g.group_key) === activeGroupKey()) btn.className = 'is-active';
        btn.addEventListener('click', function () { switchGroup(g.group_key); });
        tabs.appendChild(btn);
      });
      const addG = document.createElement('button');
      addG.type = 'button';
      addG.className = 'group-add';
      addG.textContent = '+ 分组';
      addG.addEventListener('click', addGroup);
      tabs.appendChild(addG);
      if (groups.length > 1) {
        const delG = document.createElement('button');
        delG.type = 'button';
        delG.className = 'danger';
        delG.textContent = '删除当前分组';
        delG.addEventListener('click', removeActiveGroup);
        tabs.appendChild(delG);
      }
      styleWrap.appendChild(tabs);

      const panel = document.createElement('div');
      panel.className = 'style-panel';
      const body = document.createElement('div');
      body.className = 'style-panel-body';

      const meta = document.createElement('div');
      meta.className = 'style-meta';
      const titleField = document.createElement('div');
      const lab = document.createElement('label');
      lab.className = 'lbl';
      lab.textContent = '图集标题';
      const inp = document.createElement('input');
      inp.type = 'text';
      inp.value = group.title || '';
      inp.placeholder = '默认图集';
      inp.addEventListener('input', function () {
        dataDirty = true;
        group.title = inp.value;
        updateStatus();
      });
      titleField.appendChild(lab);
      titleField.appendChild(inp);
      meta.appendChild(titleField);

      const packBox = document.createElement('div');
      const packField = document.createElement('label');
      packField.className = 'pack-field';
      const packCb = document.createElement('input');
      packCb.type = 'checkbox';
      packCb.checked = !!group.pack_download;
      const packAccessWrap = document.createElement('div');
      packAccessWrap.className = 'pack-access-row';
      packAccessWrap.style.display = packCb.checked ? 'flex' : 'none';
      const packSel = document.createElement('select');
      packSel.id = 'pack-access';
      fillPackAccessSelect(packSel);
      const packPoints = document.createElement('input');
      packPoints.type = 'number';
      packPoints.min = '1';
      packPoints.placeholder = '积分';
      packPoints.value = String(Math.max(1, Number(group.pack_points_cost || 1)));
      packPoints.style.display = group.pack_access_mode === 'points' ? 'block' : 'none';
      packSel.addEventListener('change', function () {
        dataDirty = true;
        applyPackAccessValue(packSel.value);
        packPoints.style.display = group.pack_access_mode === 'points' ? 'block' : 'none';
      });
      packPoints.addEventListener('input', function () {
        dataDirty = true;
        group.pack_points_cost = Math.max(0, Number(packPoints.value || 0));
      });
      packAccessWrap.appendChild(packSel);
      packAccessWrap.appendChild(packPoints);
      packCb.addEventListener('change', function () {
        dataDirty = true;
        group.pack_download = packCb.checked ? 1 : 0;
        packAccessWrap.style.display = packCb.checked ? 'flex' : 'none';
        syncPackHint();
      });
      const packTxt = document.createElement('span');
      packTxt.textContent = '打包本分组图片供访客下载';
      packField.appendChild(packCb);
      packField.appendChild(packTxt);
      packBox.appendChild(packField);
      packBox.appendChild(packAccessWrap);
      const packHelp = document.createElement('p');
      packHelp.className = 'pack-hint ok';
      packHelp.setAttribute('data-pack-help', '1');
      packHelp.textContent = '勾选后：保存文档时把本分组图片打成 ZIP，挂到该文的「下载附件」里（需应用中心已安装并启用「下载附件」插件，旧名 download）。';
      packBox.appendChild(packHelp);
      const packHint = document.createElement('p');
      packHint.setAttribute('data-pack-hint', '1');
      function syncPackHint() {
        if (packCb.checked && !downloadPluginReady) {
          packHint.className = 'pack-hint';
          packHint.textContent = '当前站未启用「下载附件」插件，勾选无效。请到应用中心安装/开通后再开。';
          packHint.classList.remove('is-hidden');
        } else {
          packHint.className = 'pack-hint is-hidden';
          packHint.textContent = '';
        }
      }
      syncPackHint();
      packBox.appendChild(packHint);
      meta.appendChild(packBox);
      body.appendChild(meta);

      const section = document.createElement('div');
      section.className = 'style-section';
      const head = document.createElement('div');
      head.className = 'style-section-head';
      const h = document.createElement('p');
      h.className = 'style-panel-title';
      h.textContent = '前台展现样式';
      const hint = document.createElement('p');
      hint.className = 'style-panel-hint';
      hint.textContent = '影响前台排版；本分组第 1 张可作文档封面';
      head.appendChild(h);
      head.appendChild(hint);
      section.appendChild(head);

      const chips = document.createElement('div');
      chips.className = 'chip-row';
      chips.setAttribute('data-style-chips', '1');
      layouts.forEach(function (lay) {
        const btn = document.createElement('button');
        btn.type = 'button';
        btn.setAttribute('data-style-id', lay.id);
        const thumb = document.createElement('img');
        thumb.className = 'chip-thumb';
        thumb.alt = '';
        thumb.src = '/weapp/doc_gallery/assets/guide/layouts/' + lay.id + '.svg';
        thumb.onerror = function () { thumb.style.display = 'none'; };
        const chipLab = document.createElement('span');
        chipLab.textContent = lay.label;
        btn.appendChild(thumb);
        btn.appendChild(chipLab);
        if (String(group.display_style || 'grid') === lay.id) btn.className = 'is-active';
        btn.addEventListener('click', function () {
          dataDirty = true;
          group.display_style = lay.id;
          render();
        });
        chips.appendChild(btn);
      });
      section.appendChild(chips);

      const lay = layoutOf(group.display_style);
      const desc = document.createElement('p');
      desc.className = 'style-desc';
      desc.setAttribute('data-style-preview', lay.id);
      desc.innerHTML = '<strong>' + (lay.label || '') + '</strong> · ' + (lay.desc || '');
      section.appendChild(desc);

      const liveRows = groupRows().map(function (row) {
        return {
          src: String(row.it.image_path || '').trim(),
          title: String(row.it.title || ''),
        };
      }).filter(function (row) { return row.src !== ''; }).slice(0, 6);
      if (liveRows.length) {
        const styleId = String(group.display_style || 'grid');
        const live = document.createElement('div');
        live.className = 'style-live';
        live.setAttribute('data-style-live', styleId);
        const liveLab = document.createElement('span');
        liveLab.className = 'style-live-label';
        liveLab.textContent = '前台示意（随样式切换）· ' + (lay.label || styleId);
        live.appendChild(liveLab);
        const stage = document.createElement('div');
        stage.className = 'style-live-stage is-' + styleId;
        stage.setAttribute('data-style-stage', styleId);
        if (styleId === 'list') {
          liveRows.slice(0, 3).forEach(function (row, i) {
            const line = document.createElement('div');
            line.className = 'live-list-row';
            const img = document.createElement('img');
            img.src = row.src;
            img.alt = '';
            img.onerror = function () { img.style.display = 'none'; };
            const cap = document.createElement('div');
            cap.className = 'live-list-cap';
            cap.textContent = row.title || ('图片 ' + (i + 1));
            line.appendChild(img);
            line.appendChild(cap);
            stage.appendChild(line);
          });
        } else {
          liveRows.forEach(function (row) {
            const img = document.createElement('img');
            img.src = row.src;
            img.alt = '';
            img.onerror = function () { img.style.display = 'none'; };
            stage.appendChild(img);
          });
        }
        live.appendChild(stage);
        section.appendChild(live);
      }

      body.appendChild(section);
      panel.appendChild(body);
      styleWrap.appendChild(panel);
    }

    function showHoverPreview(src, x, y) {
      if (!src) return;
      hoverPreviewEl.innerHTML = '';
      const img = document.createElement('img');
      img.src = src;
      img.alt = '';
      hoverPreviewEl.appendChild(img);
      hoverPreviewEl.classList.remove('is-hidden');
      hoverPreviewEl.style.left = Math.min(x + 16, window.innerWidth - 380) + 'px';
      hoverPreviewEl.style.top = Math.min(y + 16, window.innerHeight - 380) + 'px';
    }

    function hideHoverPreview() {
      hoverPreviewEl.classList.add('is-hidden');
      hoverPreviewEl.innerHTML = '';
    }

    function requestMediaPick(index) {
      const requestId = 'g' + (++pickSeq) + '_' + Date.now();
      pendingPicks[requestId] = { index: index };
      try {
        parent.postMessage({
          type: PICK_MEDIA,
          identifier: PLUGIN_ID,
          requestId: requestId,
          kind: 'image',
          index: index,
          title: index >= 0 ? '更换图片' : '从素材库添加',
        }, '*');
      } catch (e) {
        statusEl.textContent = '无法打开素材库（父页桥接失败）';
        statusEl.className = 'hint err';
      }
    }

    function applyMediaPickResult(data) {
      const requestId = String(data.requestId || '');
      const pending = pendingPicks[requestId];
      delete pendingPicks[requestId];
      const url = String(data.url || '').trim();
      if (!url) return;
      dataDirty = true;
      let index = pending ? Number(pending.index) : Number(data.index);
      if (index >= 0 && index < items.length) {
        items[index].image_path = url;
        if (!String(items[index].title || '').trim()) {
          const base = url.split('/').pop() || '';
          items[index].title = decodeURIComponent(base.replace(/\\?.*$/, ''));
        }
      } else {
        const it = defaultItem();
        it.image_path = url;
        const base = url.split('/').pop() || '';
        it.title = decodeURIComponent(base.replace(/\\?.*$/, ''));
        items.push(it);
        index = items.length - 1;
      }
      render();
      updateStatus('已从素材库选图');
      setTimeout(function () {
        const el = document.querySelector('[data-focus-url="n' + index + '"]');
        if (el) el.focus();
      }, 30);
    }

    function moveItem(from, to) {
      if (from === to || from < 0 || to < 0 || from >= items.length || to >= items.length) return;
      if (normalizeGroupKey(items[from].group_key) !== normalizeGroupKey(items[to].group_key)) return;
      dataDirty = true;
      const row = items.splice(from, 1)[0];
      items.splice(to, 0, row);
      selected = {};
      render();
    }

    function moveWithinGroup(fromLocal, toLocal) {
      const rows = groupRows();
      if (fromLocal < 0 || toLocal < 0 || fromLocal >= rows.length || toLocal >= rows.length) return;
      if (fromLocal === toLocal) return;
      const order = [];
      for (let i = 0; i < rows.length; i++) {
        if (i === fromLocal) continue;
        order.push(i);
      }
      order.splice(toLocal, 0, fromLocal);
      reorderActiveByLocalOrder(order);
    }

    function reorderActiveByLocalOrder(localOrder) {
      const rows = groupRows();
      if (localOrder.length !== rows.length) return;
      const reordered = localOrder.map(function (li) { return rows[li].it; });
      const key = activeGroupKey();
      const next = [];
      let ri = 0;
      items.forEach(function (it) {
        if (normalizeGroupKey(it.group_key) === key) next.push(reordered[ri++]);
        else next.push(it);
      });
      dataDirty = true;
      items = next;
      selected = {};
      render();
    }

    function applyOrdinal(localIndex, newOrd) {
      const rows = groupRows();
      const target = Math.max(1, Math.min(rows.length, Number(newOrd) || 1)) - 1;
      if (localIndex === target) return;
      const order = rows.map(function (_, i) { return i; });
      order.splice(localIndex, 1);
      order.splice(target, 0, localIndex);
      reorderActiveByLocalOrder(order);
    }

    function renderItemTable(focusIndex) {
      rootEl.innerHTML = '';
      const rows = groupRows();
      const bar = document.createElement('div');
      bar.className = 'batch-bar';
      bar.textContent = '提示：拖拽左侧手柄可排序；勾选后点工具栏「批量删除」。当前分组 ' + rows.length + ' 张。';
      rootEl.appendChild(bar);

      const wrap = document.createElement('div');
      wrap.className = 'item-table-wrap';
      const table = document.createElement('table');
      table.className = 'item-table';
      table.setAttribute('data-gallery-table', '1');
      const thead = document.createElement('thead');
      thead.innerHTML = '<tr>'
        + '<th class="col-check"><input type="checkbox" id="check-all" title="全选本分组" /></th>'
        + '<th class="col-drag"></th>'
        + '<th class="col-ord">序号</th>'
        + '<th class="col-name">文件名</th>'
        + '<th class="col-thumb">图片</th>'
        + '<th class="col-path">图片地址</th>'
        + '<th class="col-cover">封面</th>'
        + '<th class="col-sort">排序</th>'
        + '<th class="col-del">操作</th>'
        + '</tr>';
      table.appendChild(thead);
      const tbody = document.createElement('tbody');

      rows.forEach(function (row, localIndex) {
        const it = row.it;
        const index = row.index;
        const tr = document.createElement('tr');
        tr.className = 'item-row';
        tr.draggable = true;
        tr.setAttribute('data-local', String(localIndex));
        tr.setAttribute('data-index', String(index));
        if (localIndex % 2 === 1) tr.classList.add('is-alt');
        if (localIndex === 0 && String(it.image_path || '').trim()) tr.classList.add('is-cover');
        const key = 'n' + index;

        const tdCheck = document.createElement('td');
        tdCheck.className = 'col-check';
        const cb = document.createElement('input');
        cb.type = 'checkbox';
        cb.checked = !!selected[index];
        cb.addEventListener('change', function () {
          if (cb.checked) selected[index] = true;
          else delete selected[index];
          updateBatchBar();
        });
        tdCheck.appendChild(cb);
        tr.appendChild(tdCheck);

        const tdDrag = document.createElement('td');
        tdDrag.className = 'col-drag';
        tdDrag.title = '拖拽排序';
        tdDrag.textContent = '⋮⋮';
        tr.appendChild(tdDrag);

        const tdOrd = document.createElement('td');
        tdOrd.className = 'col-ord';
        const ordInp = document.createElement('input');
        ordInp.type = 'number';
        ordInp.className = 'ord-inp';
        ordInp.min = '1';
        ordInp.value = String(localIndex + 1);
        ordInp.title = '输入序号后回车调整位置';
        ordInp.addEventListener('change', function () {
          applyOrdinal(localIndex, ordInp.value);
        });
        tdOrd.appendChild(ordInp);
        tr.appendChild(tdOrd);

        tr.addEventListener('dragstart', function (ev) {
          dragFrom = localIndex;
          tr.classList.add('is-dragging');
          try { ev.dataTransfer.setData('text/plain', String(localIndex)); } catch (e) {}
          try { ev.dataTransfer.effectAllowed = 'move'; } catch (e2) {}
        });
        tr.addEventListener('dragend', function () {
          dragFrom = -1;
          tr.classList.remove('is-dragging');
          tbody.querySelectorAll('.drag-over').forEach(function (el) { el.classList.remove('drag-over'); });
        });
        tr.addEventListener('dragover', function (ev) {
          ev.preventDefault();
          tr.classList.add('drag-over');
        });
        tr.addEventListener('dragleave', function () { tr.classList.remove('drag-over'); });
        tr.addEventListener('drop', function (ev) {
          ev.preventDefault();
          tr.classList.remove('drag-over');
          const from = dragFrom;
          const to = localIndex;
          if (from < 0 || from === to) return;
          moveWithinGroup(from, to);
        });

        const tdName = document.createElement('td');
        tdName.className = 'col-name';
        const nameInp = document.createElement('input');
        nameInp.type = 'text';
        nameInp.className = 'name-inp';
        nameInp.value = it.title || '';
        nameInp.placeholder = '图片 ' + (localIndex + 1);
        nameInp.addEventListener('input', function () {
          dataDirty = true;
          it.title = nameInp.value;
          updateStatus();
        });
        tdName.appendChild(nameInp);
        if (localIndex === 0 && String(it.image_path || '').trim()) {
          const badge = document.createElement('span');
          badge.className = 'cover-badge';
          badge.textContent = '封面';
          tdName.appendChild(badge);
        }
        tr.appendChild(tdName);

        const tdThumb = document.createElement('td');
        tdThumb.className = 'col-thumb';
        const thumb = document.createElement('div');
        thumb.className = 'thumb-cell';
        thumb.title = '悬停预览 · 点击打开素材库';
        const path = String(it.image_path || '').trim();
        if (path) {
          const img = document.createElement('img');
          img.src = path;
          img.alt = '';
          img.onerror = function () { img.style.display = 'none'; };
          thumb.appendChild(img);
          thumb.addEventListener('mouseenter', function (ev) { showHoverPreview(path, ev.clientX, ev.clientY); });
          thumb.addEventListener('mousemove', function (ev) {
            if (!hoverPreviewEl.classList.contains('is-hidden')) {
              hoverPreviewEl.style.left = Math.min(ev.clientX + 16, window.innerWidth - 380) + 'px';
              hoverPreviewEl.style.top = Math.min(ev.clientY + 16, window.innerHeight - 380) + 'px';
            }
          });
          thumb.addEventListener('mouseleave', hideHoverPreview);
        } else {
          const ph = document.createElement('div');
          ph.className = 'thumb-placeholder';
          ph.textContent = '点选素材';
          thumb.appendChild(ph);
        }
        thumb.addEventListener('click', function () {
          hideHoverPreview();
          requestMediaPick(index);
        });
        tdThumb.appendChild(thumb);
        tr.appendChild(tdThumb);

        const tdPath = document.createElement('td');
        tdPath.className = 'col-path';
        const urlInp = document.createElement('input');
        urlInp.type = 'text';
        urlInp.className = 'url-main';
        urlInp.setAttribute('data-focus-url', key);
        urlInp.placeholder = '粘贴 /uploads/... 或完整 URL';
        urlInp.value = it.image_path || '';
        urlInp.addEventListener('input', function () {
          dataDirty = true;
          it.image_path = urlInp.value;
          updateStatus();
        });
        urlInp.addEventListener('paste', function () {
          setTimeout(function () {
            dataDirty = true;
            it.image_path = urlInp.value.trim();
            render();
          }, 0);
        });
        tdPath.appendChild(urlInp);
        const linkRow = document.createElement('div');
        linkRow.className = 'link-row';
        const linkLab = document.createElement('label');
        linkLab.className = 'lbl';
        linkLab.textContent = '点击跳转';
        const linkInp = document.createElement('input');
        linkInp.type = 'text';
        linkInp.className = 'link-url';
        linkInp.placeholder = 'https://…（可选）';
        linkInp.value = it.link_url || '';
        linkInp.addEventListener('input', function () {
          dataDirty = true;
          it.link_url = linkInp.value;
        });
        linkRow.appendChild(linkLab);
        linkRow.appendChild(linkInp);
        tdPath.appendChild(linkRow);
        tr.appendChild(tdPath);

        const tdCover = document.createElement('td');
        tdCover.className = 'col-cover';
        if (localIndex > 0) {
          const coverBtn = document.createElement('button');
          coverBtn.type = 'button';
          coverBtn.className = 'cover-btn';
          coverBtn.textContent = '设为封面';
          coverBtn.title = '移到本分组第 1 张；保存后按图集设置可写入文档封面';
          coverBtn.addEventListener('click', function () { moveWithinGroup(localIndex, 0); });
          tdCover.appendChild(coverBtn);
        } else {
          tdCover.textContent = '—';
        }
        tr.appendChild(tdCover);

        const tdSort = document.createElement('td');
        tdSort.className = 'col-sort';
        const sortBtns = document.createElement('div');
        sortBtns.className = 'sort-btns';
        const up = document.createElement('button');
        up.type = 'button';
        up.textContent = '上移';
        up.disabled = localIndex === 0;
        up.addEventListener('click', function () { moveWithinGroup(localIndex, localIndex - 1); });
        const down = document.createElement('button');
        down.type = 'button';
        down.textContent = '下移';
        down.disabled = localIndex >= rows.length - 1;
        down.addEventListener('click', function () { moveWithinGroup(localIndex, localIndex + 1); });
        sortBtns.appendChild(up);
        sortBtns.appendChild(down);
        tdSort.appendChild(sortBtns);
        tr.appendChild(tdSort);

        const tdDel = document.createElement('td');
        tdDel.className = 'col-del';
        const del = document.createElement('button');
        del.type = 'button';
        del.className = 'danger';
        del.textContent = '删除';
        del.addEventListener('click', function () {
          dataDirty = true;
          items.splice(index, 1);
          selected = {};
          render();
        });
        tdDel.appendChild(del);
        tr.appendChild(tdDel);
        tbody.appendChild(tr);
      });

      table.appendChild(tbody);
      wrap.appendChild(table);
      rootEl.appendChild(wrap);

      const checkAll = table.querySelector('#check-all');
      if (checkAll) {
        checkAll.addEventListener('change', function () {
          rows.forEach(function (row) {
            if (checkAll.checked) selected[row.index] = true;
            else delete selected[row.index];
          });
          renderItemTable(focusIndex);
          updateStatus();
        });
      }

      if (focusIndex != null && focusIndex >= 0) {
        setTimeout(function () {
          const el = document.querySelector('[data-focus-url="n' + focusIndex + '"]');
          if (el) { el.focus(); if (items[focusIndex] && items[focusIndex].image_path) el.select(); }
        }, 30);
      }
    }

    function render(focusIndex) {
      renderStylePanel();
      updateStatus();
      const rows = groupRows();
      if (!rows.length) {
        rootEl.innerHTML = '';
        const empty = document.createElement('div');
        empty.className = 'empty-tip';
        const p = document.createElement('p');
        p.innerHTML = '本分组暂无图片。可用下方按钮添加，或在页面空白处 <strong>Ctrl+V 粘贴路径</strong>。<br>第 1 张可作文档封面（插件设置里可开关）。';
        empty.appendChild(p);
        const cta = document.createElement('div');
        cta.className = 'empty-cta';
        const b1 = document.createElement('button');
        b1.type = 'button';
        b1.className = 'primary';
        b1.textContent = '从素材库添加';
        b1.addEventListener('click', function () { requestMediaPick(-1); });
        const b2 = document.createElement('button');
        b2.type = 'button';
        b2.textContent = '上传图片（进素材库）';
        b2.addEventListener('click', function () {
          if (imgFileInput) { imgFileInput.value = ''; imgFileInput.click(); }
        });
        const b3 = document.createElement('button');
        b3.type = 'button';
        b3.textContent = '上传 ZIP 解压';
        b3.addEventListener('click', function () {
          if (zipFileInput) { zipFileInput.value = ''; zipFileInput.click(); }
        });
        cta.appendChild(b1);
        cta.appendChild(b2);
        cta.appendChild(b3);
        empty.appendChild(cta);
        rootEl.appendChild(empty);
      } else {
        renderItemTable(focusIndex);
      }
      notifyParentHeight();
    }

    function exportRows() {
      const rows = [];
      let sort = 0;
      groups.forEach(function (g) {
        const gkey = normalizeGroupKey(g.group_key);
        const gtitle = String(g.title || '默认图集');
        const style = String(g.display_style || 'grid');
        const pack = g.pack_download ? 1 : 0;
        const packMode = String(g.pack_access_mode || 'free');
        const packLevel = Number(g.pack_member_level_id || 0);
        const packPoints = Math.max(0, Number(g.pack_points_cost || 0));
        const gItems = items.filter(function (it) {
          return normalizeGroupKey(it.group_key) === gkey;
        });
        if (!gItems.length) {
          rows.push({
            id: 0,
            group_key: gkey,
            group_title: gtitle,
            display_style: style,
            pack_download: pack,
            pack_access_mode: packMode,
            pack_member_level_id: packLevel,
            pack_points_cost: packPoints,
            title: '',
            image_path: '',
            alt_text: '',
            link_url: '',
            description: '',
            sort: sort++,
            status: 1,
          });
          return;
        }
        gItems.forEach(function (it) {
          rows.push({
            id: Number(it.id || 0),
            group_key: gkey,
            group_title: gtitle,
            display_style: style,
            pack_download: pack,
            pack_access_mode: packMode,
            pack_member_level_id: packLevel,
            pack_points_cost: packPoints,
            title: String(it.title || ''),
            image_path: String(it.image_path || '').trim(),
            alt_text: String(it.alt_text || ''),
            link_url: String(it.link_url || ''),
            description: String(it.description || ''),
            sort: sort++,
            status: 1,
          });
        });
      });
      return rows;
    }

    function themePreset(mode) {
      if (mode === 'dark') {
        return { contentTheme: 'dark', card: 'rgb(24,24,27)', fill: 'rgb(39,39,42)', border: 'rgb(63,63,70)', text: 'rgb(228,228,231)', textSecondary: 'rgb(161,161,170)', inputBg: 'rgb(24,24,27)' };
      }
      return { contentTheme: 'light', card: 'rgb(255,255,255)', fill: 'rgb(245,247,250)', border: 'rgb(228,231,237)', text: 'rgb(48,49,51)', textSecondary: 'rgb(144,147,153)', inputBg: 'rgb(255,255,255)' };
    }

    function applyThemeTokens(theme) {
      if (!theme || typeof theme !== 'object') return;
      const root = document.documentElement;
      const st = root.style;
      const mode = theme.contentTheme === 'dark' ? 'dark' : 'light';
      const preset = themePreset(mode);
      root.setAttribute('data-iframe-theme', mode);
      const set = function (k, v) { if (v) st.setProperty(k, String(v)); };
      set('--pv-card-bg', theme.card || preset.card);
      set('--pv-fill', theme.fill || preset.fill);
      set('--pv-border', theme.border || preset.border);
      set('--pv-text', theme.text || preset.text);
      set('--pv-text-secondary', theme.textSecondary || preset.textSecondary);
      set('--pv-input-bg', theme.inputBg || preset.inputBg);
      set('--pv-primary', theme.primary);
      set('--pv-primary-soft', theme.primarySoft);
      set('--pv-primary-border', theme.primaryBorder);
      set('--pv-danger', theme.danger);
      set('--pv-danger-soft', theme.dangerSoft);
      set('--pv-danger-border', theme.dangerBorder);
      set('--pv-font-family', theme.fontFamily);
      set('--pv-font-size', theme.fontSize);
      set('--pv-radius-base', theme.radiusBase);
      set('--pv-btn-padding', theme.btnPadding);
      set('--pv-input-padding', theme.inputPadding);
    }

    function notifyParentHeight() {
      if (editorSlot !== 'tab') return;
      const h = Math.max(document.documentElement.scrollHeight, document.body.scrollHeight, 120);
      try { parent.postMessage({ type: RESIZE, identifier: PLUGIN_ID, height: h }, '*'); } catch (e) {}
    }

    async function load() {
      const seq = ++loadSeq;
      if (documentId < 1) {
        dataReady = true;
        render();
        return;
      }
      statusEl.textContent = '正在同步…';
      statusEl.className = 'hint';
      try {
        const data = await api('meta/documents/form?id=' + encodeURIComponent(String(documentId)));
        if (seq !== loadSeq || dataDirty) return;
        if (!restOk(data)) {
          statusEl.textContent = (data.error && data.error.message) || '加载失败';
          statusEl.className = 'hint err';
          return;
        }
        const formData = data.data || {};
        if (Array.isArray(formData.memberLevels)) applyMemberLevels(formData.memberLevels);
        applyPayload(extractPayload(formData) || {});
      } catch (e) {
        if (seq !== loadSeq || dataDirty) return;
        statusEl.textContent = '加载失败';
        statusEl.className = 'hint err';
        render();
      }
    }

    function addItemFromPath(path, focus) {
      dataDirty = true;
      const it = defaultItem();
      it.image_path = String(path || '').trim();
      items.push(it);
      const idx = items.length - 1;
      render(focus !== false ? idx : undefined);
    }

    async function uploadManyFiles(fileList) {
      const files = Array.from(fileList || []).filter(function (f) { return f && (f.name || f.size > 0); });
      if (!files.length) return;
      uploadAbort = new AbortController();
      uploadBtn.disabled = true;
      zipImportBtn.disabled = true;
      uploadCancelBtn.classList.remove('is-hidden');
      let done = 0;
      let added = 0;
      try {
        for (let i = 0; i < files.length; i++) {
          if (uploadAbort.signal.aborted) break;
          const file = files[i];
          statusEl.textContent = '上传中 ' + (done + 1) + '/' + files.length + '：' + (file.name || '图片');
          statusEl.className = 'hint';
          const path = await uploadFile(file, uploadAbort.signal);
          if (path) {
            const it = defaultItem();
            it.image_path = path;
            it.title = String(file.name || '').replace(/\\.[^.]+$/, '');
            items.push(it);
            added += 1;
            dataDirty = true;
          }
          done += 1;
          setUploadProgress(done, files.length);
        }
        render();
        if (uploadAbort.signal.aborted) updateStatus('已取消上传');
        else updateStatus('已上传 ' + added + ' 张（已进素材库）');
      } catch (e) {
        if (uploadAbort && uploadAbort.signal.aborted) updateStatus('已取消上传');
        else {
          statusEl.textContent = (e && e.message) ? e.message : '上传失败';
          statusEl.className = 'hint err';
        }
        render();
      } finally {
        uploadAbort = null;
        uploadBtn.disabled = false;
        zipImportBtn.disabled = false;
        uploadCancelBtn.classList.add('is-hidden');
        setUploadProgress(0, 0);
        updateStatus();
      }
    }

    function looksLikeImagePath(text) {
      const t = String(text || '').trim();
      if (!t) return false;
      if (new RegExp('^https?://', 'i').test(t)) {
        return new RegExp('\\\\.(jpe?g|png|gif|webp|avif|bmp|svg)(\\\\?|$)', 'i').test(t) || t.length > 12;
      }
      return t.indexOf('/uploads/') === 0 || t.indexOf('/static/') === 0 || new RegExp('\\\\.(jpe?g|png|gif|webp|avif|bmp|svg)$', 'i').test(t);
    }

    if (batchDelBtn) {
      batchDelBtn.addEventListener('click', function () {
        const keys = Object.keys(selected).map(Number).filter(function (i) {
          return selected[i] && i >= 0 && i < items.length;
        }).sort(function (a, b) { return b - a; });
        if (!keys.length) return;
        dataDirty = true;
        keys.forEach(function (i) { items.splice(i, 1); });
        selected = {};
        render();
        updateStatus('已批量删除 ' + keys.length + ' 张');
      });
    }

    addBtn.addEventListener('click', function () {
      addItemFromPath('', true);
    });

    if (pickMediaBtn) {
      pickMediaBtn.addEventListener('click', function () {
        requestMediaPick(-1);
      });
    }

    if (uploadBtn && imgFileInput) {
      uploadBtn.addEventListener('click', function () {
        imgFileInput.value = '';
        imgFileInput.click();
      });
      imgFileInput.addEventListener('change', function () {
        const files = imgFileInput.files;
        imgFileInput.value = '';
        if (files && files.length) uploadManyFiles(files);
      });
    }

    if (uploadCancelBtn) {
      uploadCancelBtn.addEventListener('click', function () {
        if (uploadAbort) uploadAbort.abort();
      });
    }

    if (zipImportBtn && zipFileInput) {
      zipImportBtn.addEventListener('click', function () {
        zipFileInput.value = '';
        zipFileInput.click();
      });
      zipFileInput.addEventListener('change', async function () {
        const file = zipFileInput.files && zipFileInput.files[0];
        if (!file) return;
        const sizeMb = (Number(file.size || 0) / (1024 * 1024)).toFixed(1);
        statusEl.textContent = '正在上传 ZIP（' + sizeMb + ' MB）…';
        statusEl.className = 'hint';
        zipImportBtn.disabled = true;
        uploadBtn.disabled = true;
        setUploadProgress(1, 100, '上传 ZIP 0%', 'determinate');
        try {
          const body = await uploadZipFile(file, function (pct, phase) {
            if (phase === 'upload') {
              setUploadProgress(pct, 100, '上传 ZIP ' + pct + '%');
              statusEl.textContent = '正在上传 ZIP… ' + pct + '%';
            } else if (phase === 'extract') {
              setUploadProgress(pct, 100, '服务端解压中…', pct >= 95 ? 'indeterminate' : 'determinate');
              statusEl.textContent = '正在解压图片…';
            } else {
              setUploadProgress(100, 100, '完成');
            }
          });
          if (!restOk(body)) {
            statusEl.textContent = (body.error && body.error.message) || '解压失败';
            statusEl.className = 'hint err';
            return;
          }
          const payload = body.data || {};
          const rows = Array.isArray(payload.items) ? payload.items : [];
          if (!rows.length) {
            statusEl.textContent = 'ZIP 内无图片';
            statusEl.className = 'hint err';
            return;
          }
          rows.forEach(function (row) {
            const it = defaultItem();
            it.image_path = String(row.image_path || '').trim();
            it.title = String(row.title || '');
            items.push(it);
          });
          dataDirty = true;
          render();
          statusEl.textContent = (body.meta && body.meta.message) || ('已加入 ' + rows.length + ' 张，请保存文档');
          statusEl.className = 'hint';
        } catch (e) {
          statusEl.textContent = (e && e.message) ? e.message : '解压失败';
          statusEl.className = 'hint err';
        } finally {
          zipImportBtn.disabled = false;
          uploadBtn.disabled = false;
          setUploadProgress(0, 0, '');
        }
      });
    }

    document.addEventListener('paste', function (ev) {
      const tag = (ev.target && ev.target.tagName) ? ev.target.tagName.toLowerCase() : '';
      if (tag === 'input' || tag === 'textarea' || tag === 'select') return;
      const text = (ev.clipboardData && ev.clipboardData.getData('text')) || '';
      if (!looksLikeImagePath(text)) return;
      ev.preventDefault();
      addItemFromPath(text.trim(), true);
    });

    window.addEventListener('message', function (ev) {
      const data = ev.data || {};
      if (data.type === INIT && String(data.identifier || '').toLowerCase() === PLUGIN_ID) {
        if (Array.isArray(data.payload && data.payload.memberLevels)) applyMemberLevels(data.payload.memberLevels);
        applyInitPayload(data.payload || {});
        return;
      }
      if (data.type === THEME && String(data.identifier || '').toLowerCase() === PLUGIN_ID) {
        applyThemeTokens(data.theme || {});
        return;
      }
      if (data.type === PREFILL && String(data.identifier || '').toLowerCase() === PLUGIN_ID) {
        const row = data.item || data.payload || {};
        if (row.image_path || row.url || row.path) {
          addItemFromPath(row.image_path || row.url || row.path, true);
        }
        return;
      }
      if (data.type === PICK_MEDIA_RESULT && String(data.identifier || '').toLowerCase() === PLUGIN_ID) {
        applyMediaPickResult(data);
        return;
      }
      if (data.type === PREPARE && String(data.identifier || '').toLowerCase() === PLUGIN_ID) {
        try {
          parent.postMessage({
            type: EXPORT,
            identifier: PLUGIN_ID,
            fields: { gallery_json: JSON.stringify(exportRows()) },
          }, '*');
        } catch (e) {}
      }
    });

    if (documentId > 0) {
      statusEl.textContent = '正在就绪…';
      setTimeout(function () { if (!dataReady && !dataDirty) load(); }, 160);
    } else {
      load();
    }
  </script>
</body>
</html>`;
}
