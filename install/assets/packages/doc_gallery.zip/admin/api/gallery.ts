import {
  pivarkRestListPayload,
  type PivarkRestEnvelope,
} from '#/api/pivark-rest';
import { resolveAdminRestUrl } from '#/api/admin-rest-url';
import {requestClient} from '#/api/request';

export type GalleryListRow = Record<string, unknown> & {
  document_id?: number;
  document_title?: string;
  group_key?: string;
  id?: number;
  image_path?: string;
  sort?: number;
  status?: number;
  title?: string;
};

export async function fetchGalleryListApi(params: {
  document_id?: number;
  group_key?: string;
  keyword?: string;
  page?: number;
  pageSize?: number;
  status?: string;
} = {}) {
  const body = await requestClient.get<PivarkRestEnvelope>(resolveAdminRestUrl('/weapp/doc_gallery/list'), {
      params: {
        page: params.page ?? 1,
        limit: params.pageSize ?? 20,
        keyword: params.keyword || undefined,
        group_key: params.group_key || undefined,
        document_id: params.document_id || undefined,
        status: params.status ?? '',
      },
      responseReturn: 'body',
      withCredentials: true,
    },
  );

  const payload = pivarkRestListPayload(body);
  return {
    list: payload.list as GalleryListRow[],
    total: payload.total,
  };
}
