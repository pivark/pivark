<?php
declare(strict_types=1);

namespace weapp\doc_gallery;

use weapp\doc_gallery\service\GalleryAdminSpaMeta;
use app\common\service\weapp\WeappAdminGateway;
use app\common\service\weapp\WeappEntitlementGateway;
use app\common\service\weapp\WeappFrontGateway;
use app\common\service\weapp\WeappPluginGateway;
use app\common\service\weapp\WeappTemplateGateway;
use weapp\doc_gallery\service\GalleryPublicApi;
use weapp\doc_gallery\service\GalleryFrontAssets;
use weapp\doc_gallery\service\GalleryService;
use weapp\doc_gallery\service\GalleryPlazaService;
use weapp\doc_gallery\service\GalleryAdminSpaRoutes;
use weapp\doc_gallery\service\GalleryDocumentAddonBridge;

/** 官方 文档图集 插件 */
class Plugin
{
    public function install(): void
    {
        app(WeappEntitlementGateway::class)->entitlementGrantFreeInstall('doc_gallery');
        GalleryService::ensureSchema();
    }

    public function enable(): void
    {
    }

    public function disable(): void
    {
    }

    public function boot(): void
    {
        $admin = app(WeappAdminGateway::class);
        $plugin = app(WeappPluginGateway::class);
        $front = app(WeappFrontGateway::class);
        $admin->adminSpaMetaRegister('doc_gallery', 'doc_gallery', [GalleryAdminSpaMeta::class, 'build']);
        $plugin->pluginLogicalTableRegister('doc_gallery', [
            'items' => 'weapp_doc_gallery_items',
        ]);
        $admin->adminPermissionExtensionRegisterMap('doc_gallery', [
            'index'        => 'plugin.doc_gallery.use',
            'list'         => 'plugin.doc_gallery.use',
            'usage'        => 'plugin.doc_gallery.use',
            'configsave'   => 'plugin.doc_gallery.use',
            'save'         => 'plugin.doc_gallery.use',
            'delete'       => 'plugin.doc_gallery.use',
            'status'       => 'plugin.doc_gallery.use',
            'sort'         => 'plugin.doc_gallery.use',
            'batchimport'  => 'plugin.doc_gallery.use',
            'importzip'    => 'plugin.doc_gallery.use',
        ]);
        GalleryAdminSpaRoutes::register();
        $front->frontScriptUrlRegisterCore('doc_gallery', '/doc_gallery');
        $plugin->pluginExtensionRegisterDocumentAddonBridge(
            'doc_gallery',
            new GalleryDocumentAddonBridge(),
            100,
            [
                'document_availability' => 'doc_gallery',
                'document_groups'       => true,
                'document_renderable'   => true,
                'dashboard_overview'    => [
                    'key'            => 'gallery',
                    'logical_table'  => 'items',
                    'title'          => '图集',
                    'unit'           => '条',
                    'defaultVisible' => false,
                ],
            ],
        );
        $front->frontAssetHandlerRegister('doc_gallery', 'layout', [GalleryFrontAssets::class, 'registerLayout']);
        GalleryService::ensureAutoload();
        $plugin->pluginApiRegistryRegister('GalleryPublic', new GalleryPublicApi());
        GalleryService::ensureSchema();
        GalleryService::boot();
        GalleryPlazaService::boot();
        app(WeappTemplateGateway::class)->templateRegisterExtensionTag('doc_gallery', [GalleryService::class, 'renderTag']);
        app(WeappTemplateGateway::class)->templateRegisterExtensionTag('doc_gallery_groups', [GalleryService::class, 'renderGroupsTag']);
    }
}
