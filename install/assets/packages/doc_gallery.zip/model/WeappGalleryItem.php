<?php
/**
 * 元舟 PivArk — 企业全域原子化数字资产中枢
 * (c) 2024-2026 pivark.com. All rights reserved.
 * Author: Angelo
 * 未经允许，不可用于商业用途。
 */
declare(strict_types=1);

namespace weapp\doc_gallery\model;


use app\common\model\Document;
use think\Model;
use think\model\relation\BelongsTo;

/**
 * Class weapp\doc_gallery\model\WeappGalleryItem
 *
 * @property int $document_id 关联文档 ID
 * @property int $id 主键
 * @property int $image_height 原图高 px
 * @property int $image_width 原图宽 px
 * @property int $sort 排序
 * @property int $status 状态：0禁用 1启用
 * @property string $alt_text 替代文本
 * @property string $created_at 创建时间
 * @property string $description 说明
 * @property string $group_key 分组标识
 * @property string $image_path 图片路径
 * @property string $link_url 外链
 * @property string $shot_info 拍摄信息
 * @property string $title 标题
 * @property string $updated_at 更新时间
 *  */
class WeappGalleryItem extends Model
{
    protected $name = 'weapp_doc_gallery_items';

        protected $type = [
        'document_id' => 'integer',
        'id' => 'integer',
        'image_height' => 'integer',
        'image_width' => 'integer',
        'sort' => 'integer',
        'status' => 'integer',
    ];

    protected $autoWriteTimestamp = false;

    public function document(): BelongsTo
    {
        return $this->belongsTo(Document::class, 'document_id');
    }
}
