<?php
/**
 * 元舟 PivArk — 企业全域原子化数字资产中枢
 * (c) 2024-2026 pivark.com. All rights reserved.
 * Author: Angelo
 * 未经允许，不可用于商业用途。
 */
declare(strict_types=1);

namespace weapp\doc_gallery\model;


use think\Model;
use think\model\relation\BelongsTo;

/**
 * Class weapp\doc_gallery\model\WeappGalleryGroup
 *
 * @property int $document_id 文档 ID
 * @property int $download_bundle_id 关联 download 资源包 ID
 * @property int $id 主键
 * @property int $pack_download 1=同步打包到下载区
 * @property string $pack_access_mode 打包下载权限
 * @property int $pack_member_level_id 会员等级门槛
 * @property int $pack_points_cost 积分消耗
 * @property int $sort 排序
 * @property int $status 0禁用 1启用
 * @property string $created_at 创建时间
 * @property string $display_style 展现样式
 * @property string $group_key 分组标识 slug
 * @property string $title 分组标题
 * @property string $updated_at 更新时间
 *  */
class WeappGalleryGroup extends Model
{
    protected $name = 'weapp_doc_gallery_groups';

        protected $type = [
        'document_id' => 'integer',
        'download_bundle_id' => 'integer',
        'id' => 'integer',
        'pack_download' => 'integer',
        'pack_member_level_id' => 'integer',
        'pack_points_cost' => 'integer',
        'sort' => 'integer',
        'status' => 'integer',
    ];

    protected $autoWriteTimestamp = false;
}
