<?php
/**
 * 元舟 PivArk — 企业全域原子化数字资产中枢
 * (c) 2024-2026 pivark.com. All rights reserved.
 * Author: Angelo
 * 未经允许，不可用于商业用途。
 */
declare(strict_types=1);

namespace weapp\doc_vod\model;


use think\Model;
use think\model\relation\BelongsTo;

/**
 * Class weapp\doc_vod\model\WeappVideoWatchProgress
 *
 * @property int $episode_id episode ID
 * @property int $id 主键
 * @property int $position_sec 字段：position_sec
 * @property int $user_id 用户 ID
 * @property string $updated_at 更新时间
 *  * @property-read \weapp\doc_vod\model\WeappVideoEpisode $episode
 */
class WeappVideoWatchProgress extends Model
{
    protected $name = 'weapp_doc_vod_watch_progress';

        protected $type = [
        'episode_id' => 'integer',
        'id' => 'integer',
        'position_sec' => 'integer',
        'user_id' => 'integer',
    ];

    protected $autoWriteTimestamp = false;
    public function episode(): BelongsTo
    {
        return $this->belongsTo(WeappVideoEpisode::class, 'episode_id');
    }
}
