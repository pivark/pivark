<?php
/**
 * 元舟 PivArk — 企业全域原子化数字资产中枢
 * (c) 2024-2026 pivark.com. All rights reserved.
 * Author: Angelo
 * 未经允许，不可用于商业用途。
 */
declare(strict_types=1);

namespace weapp\doc_vod\model;


use app\common\model\Document;
use think\Model;
use think\model\relation\BelongsTo;

/**
 * Class weapp\doc_vod\model\WeappVideoItem
 *
 * @property int $document_id 关联文档 ID
 * @property int $id 主键
 * @property int $sort 排序
 * @property int $status 状态：0禁用 1启用
 * @property string $cover_path 封面图
 * @property string $created_at 创建时间
 * @property string $provider 来源：embed/local
 * @property string $title 标题
 * @property string $updated_at 更新时间
 * @property string $video_url 视频地址或嵌入代码 URL
 *  */
class WeappVideoItem extends Model
{
    protected $name = 'weapp_doc_vod_items';

        protected $type = [
        'document_id' => 'integer',
        'id' => 'integer',
        'sort' => 'integer',
        'status' => 'integer',
    ];

    protected $autoWriteTimestamp = false;

    public function document(): BelongsTo
    {
        return $this->belongsTo(Document::class, 'document_id');
    }
}
