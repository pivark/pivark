<?php
/**
 * 元舟 PivArk — 企业全域原子化数字资产中枢
 * (c) 2024-2026 pivark.com. All rights reserved.
 * Author: Angelo
 * 未经允许，不可用于商业用途。
 */
declare(strict_types=1);

namespace weapp\doc_vod\model;


use app\common\model\MemberLevel;
use think\Model;
use think\model\relation\BelongsTo;

/**
 * Class weapp\doc_vod\model\WeappVideoEpisode
 *
 * @property float $price 单集售价
 * @property int $document_id 文档 ID
 * @property int $duration_sec 字段：duration_sec
 * @property int $ep_no 单号
 * @property int $id 主键
 * @property int $play_count 播放次数
 * @property int $read_level_id read_level ID
 * @property int $series_id series ID
 * @property int $sort 排序
 * @property int $status 状态
 * @property int $trial_preview_sec 单集试看秒(0=继承剧集)
 * @property string $access_mode 空=继承剧集
 * @property string $ad_cues_json 广告点 JSON
 * @property string $cover_path 字段：cover_path
 * @property string $created_at 创建时间
 * @property string $title 标题
 * @property string $updated_at 更新时间
 *  *  * @property-read \weapp\doc_vod\model\WeappVideoSeries $series
 */
class WeappVideoEpisode extends Model
{
    protected $name = 'weapp_doc_vod_episodes';

        protected $type = [
        'document_id' => 'integer',
        'duration_sec' => 'integer',
        'ep_no' => 'integer',
        'id' => 'integer',
        'play_count' => 'integer',
        'price' => 'float',
        'read_level_id' => 'integer',
        'series_id' => 'integer',
        'sort' => 'integer',
        'status' => 'integer',
        'trial_preview_sec' => 'integer',
    ];

    protected $autoWriteTimestamp = false;
public function readLevel(): BelongsTo
    {
        return $this->belongsTo(MemberLevel::class, 'read_level_id');
    }

    public function series(): BelongsTo
    {
        return $this->belongsTo(WeappVideoSeries::class, 'series_id');
    }

    public function sources(): HasMany
    {
        return $this->hasMany(WeappVideoSource::class, 'episode_id');
    }

    public function watchProgress(): HasMany
    {
        return $this->hasMany(WeappVideoWatchProgress::class, 'episode_id');
    }

}
