<?php
/**
 * 元舟 PivArk — 企业全域原子化数字资产中枢
 * (c) 2024-2026 pivark.com. All rights reserved.
 * Author: Angelo
 * 未经允许，不可用于商业用途。
 */
declare(strict_types=1);

namespace weapp\doc_vod\model;


use think\Model;

/**
 * Class weapp\doc_vod\model\WeappVideoParseLog
 *
 * @property int $duration_ms 字段：duration_ms
 * @property int $id 主键
 * @property int $success 字段：success
 * @property string $created_at 创建时间
 * @property string $msg 字段：msg
 * @property string $platform 字段：platform
 * @property string $url 字段：url
 */
class WeappVideoParseLog extends Model
{
    protected $name = 'weapp_doc_vod_parse_log';

        protected $type = [
        'duration_ms' => 'integer',
        'id' => 'integer',
        'success' => 'integer',
    ];

    protected $autoWriteTimestamp = false;
}
