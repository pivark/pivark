<?php
/**
 * 元舟 PivArk — 企业全域原子化数字资产中枢
 * (c) 2024-2026 pivark.com. All rights reserved.
 * Author: Angelo
 * 未经允许，不可用于商业用途。
 */
declare(strict_types=1);

namespace weapp\doc_vod\model;


use app\common\model\MemberLevel;
use think\Model;
use think\model\relation\BelongsTo;
use think\model\relation\HasMany;

/**
 * Class weapp\doc_vod\model\WeappVideoSeries
 *
 * @property float $price 全集售价
 * @property int $free_ep_count 前N集免费(0=关)
 * @property int $id 主键
 * @property int $read_level_id read_level ID
 * @property int $sort 排序
 * @property int $status 状态
 * @property int $trial_preview_sec 试看秒数(0=关)
 * @property string $access_mode free|login|level|paid_series
 * @property string $cover_path 字段：cover_path
 * @property string $created_at 创建时间
 * @property string $slug URL/API标识
 * @property string $summary 字段：summary
 * @property string $title 标题
 * @property string $updated_at 更新时间
 *  * @property-read \weapp\doc_vod\model\WeappVideoEpisode[] $episodes
 */
class WeappVideoSeries extends Model
{
    protected $name = 'weapp_doc_vod_series';

        protected $type = [
        'free_ep_count' => 'integer',
        'id' => 'integer',
        'price' => 'float',
        'read_level_id' => 'integer',
        'sort' => 'integer',
        'status' => 'integer',
        'trial_preview_sec' => 'integer',
    ];

    protected $autoWriteTimestamp = false;
    public function readLevel(): BelongsTo
    {
        return $this->belongsTo(MemberLevel::class, 'read_level_id');
    }

    public function episodes(): HasMany
    {
        return $this->hasMany(WeappVideoEpisode::class, 'series_id');
    }

}
