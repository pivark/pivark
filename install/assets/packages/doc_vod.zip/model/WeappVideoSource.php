<?php
/**
 * 元舟 PivArk — 企业全域原子化数字资产中枢
 * (c) 2024-2026 pivark.com. All rights reserved.
 * Author: Angelo
 * 未经允许，不可用于商业用途。
 */
declare(strict_types=1);

namespace weapp\doc_vod\model;


use think\Model;
use think\model\relation\BelongsTo;

/**
 * Class weapp\doc_vod\model\WeappVideoSource
 *
 * @property int $episode_id episode ID
 * @property int $id 主键
 * @property int $priority 字段：priority
 * @property int $status 状态
 * @property string $config_json JSON扩展
 * @property string $created_at 创建时间
 * @property string $play_url URL
 * @property string $provider 字段：provider
 * @property string $updated_at 更新时间
 * @property-read \weapp\doc_vod\model\WeappVideoEpisode $episode
 */
class WeappVideoSource extends Model
{
    protected $name = 'weapp_doc_vod_sources';

        protected $type = [
        'episode_id' => 'integer',
        'id' => 'integer',
        'priority' => 'integer',
        'status' => 'integer',
    ];

    protected $autoWriteTimestamp = false;
    public function episode(): BelongsTo
    {
        return $this->belongsTo(WeappVideoEpisode::class, 'episode_id');
    }

}
