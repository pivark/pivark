<?php
/**
 * 元舟 PivArk — 企业全域原子化数字资产中枢
 * (c) 2024-2026 pivark.com. All rights reserved.
 * Author: Angelo
 * 未经允许，不可用于商业用途。
 */
declare(strict_types=1);

namespace weapp\doc_vod\model;


use think\Model;

/**
 * Class weapp\doc_vod\model\WeappVideoPlayDaily
 *
 * @property int $buy_click_hits 购买点击次数
 * @property int $play_hits 播放次数(增量)
 * @property int $trial_end_hits 试看结束次数
 * @property string $stat_date 统计日
 * @property string $updated_at 更新时间
 */
class WeappVideoPlayDaily extends Model
{
    protected $name = 'weapp_doc_vod_play_daily';

        protected $type = [
        'buy_click_hits' => 'integer',
        'play_hits' => 'integer',
        'trial_end_hits' => 'integer',
    ];

    protected $autoWriteTimestamp = false;
}
