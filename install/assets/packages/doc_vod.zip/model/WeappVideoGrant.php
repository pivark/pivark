<?php
/**
 * 元舟 PivArk — 企业全域原子化数字资产中枢
 * (c) 2024-2026 pivark.com. All rights reserved.
 * Author: Angelo
 * 未经允许，不可用于商业用途。
 */
declare(strict_types=1);

namespace weapp\doc_vod\model;


use think\Model;
use think\model\relation\BelongsTo;

/**
 * Class weapp\doc_vod\model\WeappVideoGrant
 *
 * @property float $amount 字段：amount
 * @property int $id 主键
 * @property int $ref_id ref ID
 * @property int $user_id 用户 ID
 * @property string $created_at 创建时间
 * @property string $grant_type episode|series
 * @property string $payment_order_no 单号
 *  */
class WeappVideoGrant extends Model
{
    protected $name = 'weapp_doc_vod_grants';

        protected $type = [
        'amount' => 'float',
        'id' => 'integer',
        'ref_id' => 'integer',
        'user_id' => 'integer',
    ];

    protected $autoWriteTimestamp = false;
}
