<?php
/**
 * 元舟 PivArk — 企业全域原子化数字资产中枢
 * (c) 2024-2026 pivark.com. All rights reserved.
 * Author: Angelo
 * 未经允许，不可用于商业用途。
 */
declare(strict_types=1);

namespace weapp\doc_vod\model;


use think\Model;
use think\model\relation\BelongsTo;

/**
 * Class weapp\doc_vod\model\WeappVideoEpisodePlayDaily
 *
 * @property int $episode_id 单集ID
 * @property int $play_hits 播放次数
 * @property int $series_id 剧集ID
 * @property string $stat_date 统计日
 * @property string $updated_at 更新时间
 * @property-read \weapp\doc_vod\model\WeappVideoEpisode $episode
 * @property-read \weapp\doc_vod\model\WeappVideoSeries $series
 */
class WeappVideoEpisodePlayDaily extends Model
{
    protected $name = 'weapp_doc_vod_episode_play_daily';

        protected $type = [
        'episode_id' => 'integer',
        'play_hits' => 'integer',
        'series_id' => 'integer',
    ];

    protected $autoWriteTimestamp = false;
    public function episode(): BelongsTo
    {
        return $this->belongsTo(WeappVideoEpisode::class, 'episode_id');
    }

    public function series(): BelongsTo
    {
        return $this->belongsTo(WeappVideoSeries::class, 'series_id');
    }

}
