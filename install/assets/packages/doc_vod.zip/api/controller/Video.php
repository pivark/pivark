<?php
declare(strict_types=1);

namespace weapp\doc_vod\api\controller;

use think\facade\Request;
use think\Response;
use think\response\Json;
use weapp\doc_vod\service\VideoFunnelService;
use weapp\doc_vod\service\VideoPlaybackService;
use weapp\doc_vod\service\VideoPurchaseService;
use weapp\doc_vod\service\VideoService;
use weapp\doc_vod\service\VideoStreamProxyService;
use weapp\doc_vod\service\VideoWatchProgressService;
use app\common\service\weapp\WeappFrontGateway;
use app\common\service\weapp\WeappSupportGateway;

class Video
{
    public function play(): Json
    {
        VideoService::ensureAutoload();
        $episodeId = (int) Request::get('episode_id', 0);
        $member    = app(WeappFrontGateway::class)->frontCurrent();

        return app(WeappSupportGateway::class)->apiFromServiceResult(VideoPlaybackService::playPayload($member, $episodeId));
    }

    public function checkoutEpisode(): Json
    {
        VideoService::ensureAutoload();
        if (!Request::isPost()) {
            return app(WeappSupportGateway::class)->apiMethodNotAllowed();
        }
        if (!app(WeappFrontGateway::class)->frontCsrfValidateRequest(
            (string) Request::post(app(WeappFrontGateway::class)->frontCsrfFieldName(), ''),
            Request::header('X-CSRF-Token')
        )) {
            return app(WeappSupportGateway::class)->apiCsrfExpired('表单已过期');
        }
        $member = app(WeappFrontGateway::class)->frontCurrent();
        if ($member === null) {
            return ApiResponse::authRequired();
        }
        $result = VideoPurchaseService::checkoutEpisode(
            (int) $member['id'],
            (int) Request::post('episode_id', 0),
            (string) Request::post('channel', 'alipay')
        );
        if ($result->isOk()) {
            app(WeappFrontGateway::class)->frontCsrfRotateAfterSuccess();
        }

        return app(WeappSupportGateway::class)->apiFromServiceResult($result);
    }

    public function checkoutSeries(): Json
    {
        VideoService::ensureAutoload();
        if (!Request::isPost()) {
            return app(WeappSupportGateway::class)->apiMethodNotAllowed();
        }
        if (!app(WeappFrontGateway::class)->frontCsrfValidateRequest(
            (string) Request::post(app(WeappFrontGateway::class)->frontCsrfFieldName(), ''),
            Request::header('X-CSRF-Token')
        )) {
            return app(WeappSupportGateway::class)->apiCsrfExpired('表单已过期');
        }
        $member = app(WeappFrontGateway::class)->frontCurrent();
        if ($member === null) {
            return ApiResponse::authRequired();
        }
        $result = VideoPurchaseService::checkoutSeries(
            (int) $member['id'],
            (int) Request::post('series_id', 0),
            (string) Request::post('channel', 'alipay')
        );
        if ($result->isOk()) {
            app(WeappFrontGateway::class)->frontCsrfRotateAfterSuccess();
        }

        return app(WeappSupportGateway::class)->apiFromServiceResult($result);
    }

    public function grants(): Json
    {
        VideoService::ensureAutoload();
        $member = app(WeappFrontGateway::class)->frontCurrent();
        if ($member === null) {
            return ApiResponse::authRequired();
        }
        $page = max(1, (int) Request::get('page', 1));

        return app(WeappSupportGateway::class)->apiFromServiceResult(VideoPurchaseService::listGrantsForMember((int) $member['id'], $page));
    }

    public function saveProgress(): Json
    {
        VideoService::ensureAutoload();
        if (!Request::isPost()) {
            return app(WeappSupportGateway::class)->apiMethodNotAllowed();
        }
        if (!app(WeappFrontGateway::class)->frontCsrfValidateRequest(
            (string) Request::post(app(WeappFrontGateway::class)->frontCsrfFieldName(), ''),
            Request::header('X-CSRF-Token')
        )) {
            return app(WeappSupportGateway::class)->apiCsrfExpired('表单已过期');
        }
        $member = app(WeappFrontGateway::class)->frontCurrent();
        if ($member === null) {
            return ApiResponse::authRequired();
        }

        return app(WeappSupportGateway::class)->apiFromServiceResult(VideoWatchProgressService::save(
            (int) $member['id'],
            (int) Request::post('episode_id', 0),
            (int) Request::post('position_sec', 0)
        ));
    }

    public function getProgress(): Json
    {
        VideoService::ensureAutoload();
        $member = app(WeappFrontGateway::class)->frontCurrent();
        if ($member === null) {
            return ApiResponse::authRequired();
        }

        return app(WeappSupportGateway::class)->apiFromServiceResult(VideoWatchProgressService::getForUser(
            (int) $member['id'],
            (int) Request::get('episode_id', 0)
        ));
    }

    public function track(): Json
    {
        VideoService::ensureAutoload();
        if (!Request::isPost()) {
            return app(WeappSupportGateway::class)->apiMethodNotAllowed();
        }

        return app(WeappSupportGateway::class)->apiFromServiceResult(VideoFunnelService::track(
            (int) Request::post('episode_id', 0),
            (string) Request::post('event', '')
        ));
    }

    public function hlsProxy(): Response
    {
        VideoService::ensureAutoload();

        return VideoStreamProxyService::proxyResponse((string) Request::get('url', ''));
    }
}
