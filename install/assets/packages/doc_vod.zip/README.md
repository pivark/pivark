# 文档视频（`video`）

> **用户文档 SSOT：** 本目录 `README.md`（`## 功能介绍` · `## 使用说明` · `## 升级日志` · `## 安装与开发`） · v1.0.0 · `pivark/doc_vod`；后台与市场直读，改完即生效。

## 功能介绍

<h3>文档视频是做什么的？</h3>
<p>为文章挂载<strong>可播放的视频</strong>：支持多条外链嵌入，也支持<strong>点播剧集</strong>（选集、试看、付费、多线路、续播）。前台用 <code>{pv:doc_vod}</code> 一块输出，模板怎么写请看「前台调用说明」Tab。</p>
<p class="pv-tip">适合教程站、影视解说、付费课程、企业宣传片等需要在正文旁展示视频的场景。</p>

<h3>核心能力</h3>
<ul>
    <li><strong>嵌入条目</strong>：粘贴 B 站 / YouTube / mp4 等地址，自动 16:9 播放器；</li>
    <li><strong>点播剧集</strong>：剧集 + 单集 + 多线路；登录/等级/单集付费/全集付费；</li>
    <li><strong>试看与转化</strong>：可设试看秒数，结束引导登录或购买；</li>
    <li><strong>会员观影</strong>：「我的观影」续播；「我的购买」查视频订单；</li>
    <li><strong>智能粘贴</strong>：发布页粘贴视频页 URL，可走插件解析（与内核剪贴板引导配合）。</li>
</ul>

<h3>典型场景</h3>
<figure class="pv-guide-figure">
    <img src="guide-scenarios.svg" alt="嵌入条目与点播剧集两种用法" loading="lazy" />
    <figcaption>左：轻量外链列表；右：连载课程 / 付费剧。</figcaption>
</figure>

<h3>站长怎么用（建议 5 步）</h3>
<figure class="pv-guide-figure">
    <img src="guide-admin-flow.svg" alt="基础设置、维护视频、点播、验收" loading="lazy" width="720" />
</figure>
<ol>
    <li>在「<strong>基础设置</strong>」打开插件，配置影视会员等级、外置解析 API（按需）、平台 Cookie（番剧等）。</li>
    <li>「<strong>发布页展现</strong>」选独立 Tab 或嵌入正文；在文章发布页的「文档视频」面板维护内容。</li>
    <li><strong>嵌入模式</strong>：在「嵌入条目」或发布面板添加播放地址与封面。</li>
    <li><strong>点播模式</strong>：在文档发布页「文档视频」Tab 粘贴主播放地址即可；也可空白处 Ctrl+V 快速加集。权限/试看/备用线路收在「更多设置」。复杂批量仍可去插件中心「点播剧集」。</li>
    <li>确认主题详情页已放 <code>{pv:doc_vod}</code>，用有数据 / 无数据各测一篇；窄屏看 16:9 是否正常。</li>
</ol>

<h3>双轨怎么选？</h3>
<table>
    <thead><tr><th>方式</th><th>后台入口</th><th>适合</th></tr></thead>
    <tbody>
        <tr><td>嵌入条目</td><td>嵌入条目 / 发布页多条 URL</td><td>单篇几个外链，不涉及付费选集</td></tr>
        <tr><td>点播剧集</td><td>点播剧集 → 单集</td><td>连载、试看、付费、多线路、续播</td></tr>
    </tbody>
</table>
<p class="pv-tip">同一文档若绑定了<strong>启用中的点播单集</strong>，前台 <code>{pv:doc_vod}</code> 会<strong>优先点播 UI</strong>；否则显示嵌入列表。</p>

<h3>访客在前台看到什么？</h3>
<ul>
    <li>嵌入：每条视频 16:9 画面 + 标题；</li>
    <li>点播：选集列表，点击后加载播放器；可切换线路、试看提示、登录/购买按钮；</li>
    <li>登录用户：可从上次进度续播（会员中心「我的观影」也有入口）；</li>
    <li>未配置 / 插件关闭 / 无数据：<strong>整块不出现</strong>。</li>
</ul>

<h3>运营与维护</h3>
<ul>
    <li>「<strong>运营统计</strong>」查看播放趋势、热门单集、解析失败；</li>
    <li>解析平台规则变更时，在「解析平台自检」中排查并更新 Cookie / API 配置。</li>
</ul>

<h3>常见问题（站长视角）</h3>
<ul>
    <li><strong>为什么前台没有视频？</strong> 检查插件开关、文章是否有关联条目或单集、单集是否启用。</li>
    <li><strong>为什么还是外链列表而不是选集？</strong> 单集需填写「文档 ID」且状态启用；迁移后确认 <code>document_id</code> 正确。</li>
    <li><strong>试看结束不能播？</strong> 属预期，需登录或购买；可在单集/剧集设置价格与试看秒数。</li>
    <li><strong>手机端播放器变形？</strong> 使用默认模板或保留 <code>pv-vod-embed-ratio</code> / <code>pv-video-embed</code> 结构，勿给 iframe 写死宽高。</li>
</ul>

## 使用说明

<h3>写给主题 / 前端</h3>
<p>在<strong>文章详情页模板</strong>插入 <code>{pv:doc_vod}</code>。插件会按数据自动选择<strong>点播 UI</strong>或<strong>嵌入列表</strong>，并加载 16:9 播放器样式。下文讲模板写法与字段。</p>

<h3>开始之前</h3>
<ul>
    <li>插件已安装并<strong>启用</strong>；</li>
    <li>测试文已在后台配置嵌入条目或点播单集；</li>
    <li>点播能力需在后台「点播剧集」中维护剧集与单集。</li>
</ul>

<h3>放在模板的什么位置？</h3>
<figure class="pv-guide-figure">
    <img src="usage-template-wireframe.svg" alt="详情页正文下方插入视频区块" loading="lazy" />
    <figcaption>推荐放在 <code>{$document_content}</code> 之后，外层用 <code>section.pv-doc-video</code>。</figcaption>
</figure>

<h3>最简写法</h3>
<pre class="pv-weapp-code">{pv:doc_vod id="{$document_id}"}</pre>
<p>不写内部 HTML 时使用插件默认结构：嵌入为 <code>pv-video-item</code>；点播为 <strong>B 站式</strong> <code>pv-vod-layout</code>（左播放、右选集与权限标签）。</p>

<h3>默认模板（推荐，已自适应）</h3>
<p><strong>嵌入列表</strong>（无点播单集时）：</p>
<pre class="pv-weapp-code">{pv:doc_vod id="{$document_id}"}
&lt;article class="pv-video-item"&gt;
  &lt;div class="pv-video-embed" role="group" aria-label="视频播放"&gt;{$field.embed_html}&lt;/div&gt;
  &lt;p class="pv-video-title"&gt;{$field.title}&lt;/p&gt;
&lt;/article&gt;
{/pv:doc_vod}</pre>
<p><strong>点播选集</strong>：默认请保持空标签，由插件输出 <code>pv-vod-layout</code>（左 <code>data-pv-vod-player</code>，右选集含 <code>{$field.badge_text}</code> / <code>{$field.price_text}</code> 等）。自定义内层模板时走旧版竖排 <code>pv-vod-list--legacy</code>。</p>
<pre class="pv-weapp-code">{pv:doc_vod id="{$document_id}"}</pre>
<p>并自动登记 <code>weapp/doc_vod/assets/css/vod.css</code>、<code>weapp/doc_vod/assets/js/player.js</code>，由页脚 <code>{pv:frontassets /}</code> 输出。</p>

<h3>标签属性</h3>
<table>
    <thead><tr><th>属性</th><th>说明</th></tr></thead>
    <tbody>
        <tr><td><code>id</code> / <code>document_id</code> / <code>aid</code></td><td>文章 ID，详情页必填其一</td></tr>
        <tr><td>（不写）</td><td>自动取当前页 <code>document_id</code>（仅详情页）</td></tr>
    </tbody>
</table>

<h3>循环变量 · 嵌入条目</h3>
<table>
    <thead><tr><th>变量</th><th>含义</th><th>说明</th></tr></thead>
    <tbody>
        <tr><td><code>{$field.title}</code></td><td>标题</td><td>纯文本，需自行转义时勿重复包 HTML</td></tr>
        <tr><td><code>{$field.embed_html}</code></td><td>播放器 HTML</td><td>已含 <code>pv-vod-embed-ratio</code> 16:9 容器，<strong>原样输出</strong></td></tr>
        <tr><td><code>{$field.video_url}</code></td><td>播放页 URL</td><td>直链或平台页</td></tr>
        <tr><td><code>{$field.cover_url}</code></td><td>封面</td><td>绝对 URL</td></tr>
        <tr><td><code>{$field.provider}</code></td><td>来源</td><td>如 embed</td></tr>
    </tbody>
</table>

<h3>循环变量 · 点播单集</h3>
<table>
    <thead><tr><th>变量</th><th>含义</th></tr></thead>
    <tbody>
        <tr><td><code>{$field.id}</code></td><td>单集 ID（<code>data-episode-id</code>）</td></tr>
        <tr><td><code>{$field.series_id}</code></td><td>剧集 ID</td></tr>
        <tr><td><code>{$field.title}</code> / <code>{$field.ep_no}</code></td><td>标题 / 集号</td></tr>
        <tr><td><code>{$field.need_label}</code></td><td>权限提示文案（如试看、购买）</td></tr>
        <tr><td><code>{$field.allowed}</code></td><td>是否已允许播放（0/1，列表态）</td></tr>
        <tr><td><code>{$field.cover_url}</code></td><td>封面 URL（可选展示）</td></tr>
    </tbody>
</table>
<p>实际片源、线路、试看、广告点由脚本请求播放 API 后注入，<strong>不要</strong>在模板里写死 <code>&lt;video src&gt;</code>。</p>

<h3>前台效果示意</h3>
<figure class="pv-guide-figure">
    <img src="usage-front-mockup.svg" alt="手机端选集与多线路示意" loading="lazy" />
    <figcaption>点播：选集 + 线路切换 + 16:9 播放器；样式可用主题 CSS 覆盖。</figcaption>
</figure>

<h3>播放相关 API（自建 UI 时用）</h3>
<table>
    <thead><tr><th>方法</th><th>路径</th><th>说明</th></tr></thead>
    <tbody>
        <tr><td>GET</td><td><code>/api/v1/plugins/doc_vod/play?episode_id=</code></td><td>鉴权后的播放 payload（sources、试看、进度、广告点）</td></tr>
        <tr><td>POST</td><td><code>/api/v1/plugins/doc_vod/progress</code></td><td>保存续播位置（需登录 + CSRF）</td></tr>
        <tr><td>POST</td><td><code>/api/v1/plugins/doc_vod/checkout/episode</code></td><td>单集下单</td></tr>
        <tr><td>POST</td><td><code>/api/v1/plugins/doc_vod/checkout/series</code></td><td>全集下单</td></tr>
        <tr><td>GET</td><td><code>/api/v1/plugins/doc_vod/grants</code></td><td>我的授权列表</td></tr>
    </tbody>
</table>

<h3>HLS 多清晰度</h3>
<ul>
    <li>播放地址请使用 <strong>master.m3u8</strong>（主清单，内含多码率子流）；单条 media m3u8 仅一路清晰度。</li>
    <li><strong>跨域：</strong>Chrome/Edge 用 hls.js 拉流，片源 CDN 须返回 <code>Access-Control-Allow-Origin</code>（或走同源代理）。无 CORS 的测试流（如 Apple BipBop）在浏览器会报「HLS 播放失败」。</li>
    <li><strong>CSP：</strong>前台若自定义安全头，须含 <code>connect-src</code>、<code>media-src https:</code>、<code>worker-src blob:</code>（hls.js 解复用 Worker）。内核默认已在 <code>app/home/controller/Base.php</code> 配置。</li>
    <li>Chrome / Edge / Firefox（hls.js）：解析成功后显示 <code>自动 / 1080p / 720p …</code> 按钮组（class <code>pv-vod-quality</code>）。</li>
    <li>Safari 系统播放器：可播 HLS，但通常不展示清晰度切换（依赖系统自适应）。</li>
</ul>
<p><strong>多片源：</strong>同一单集可添加多条线路（爱奇艺 / 哔哩哔哩 / 本地等），填写「显示名」与链接；前台右侧「片源」区切换，选集行显示「N 源」。验收 fixture 第 1 集自带 <strong>B站 + 直链</strong> 双线路，灌数后即可对照切换。</p>
<p class="pv-tip"><strong>爱奇艺 / 优酷 / 腾讯：</strong>普通播放页（<code>iqiyi.com/v_…</code>）<strong>不能</strong>像 B 站 BV 一样直接嵌；须在视频页点「分享」复制<strong>通用代码</strong>里的 <code>iframe src=…open.iqiyi.com…</code> 填到线路。否则前台会提示「前往爱奇艺观看」。</p>
<p class="pv-tip"><strong>没有自有片源时（验收用）：</strong>后台单集线路可暂时填下面任一公开测试地址，仅用于确认清晰度按钮，与卖刀等业务无关。</p>
<pre class="pv-weapp-code">https://storage.googleapis.com/shaka-demo-assets/angel-one-hls/hls.m3u8</pre>
<p class="text-muted-foreground small">CLI 多码率自检（无 CORS，勿用于浏览器）：<code>https://devstreaming-cdn.apple.com/videos/streaming/examples/img_bipbop_adv_example_ts/master.m3u8</code> · <code>php devtools/daily/scripts/verify_video_hls_master_cli.php</code></p>

<h3>样式钩子（自适应）</h3>
<p>样式由插件登记至 <code>{pv:frontassets /}</code>（路径 <code>/weapp/doc_vod/assets/css/vod.css</code>）。主题覆盖示例：</p>
<pre class="pv-weapp-code">/* 整块宽度 */
.pv-doc-video__list { max-width: 960px; margin-inline: auto; }
/* 嵌入 16:9（勿去掉内层 ratio） */
.pv-video-embed .pv-vod-embed-ratio { border-radius: 12px; }
/* 点播选集 */
.pv-vod-ep--active { border-color: var(--theme-primary); }
/* 窄屏线路按钮全宽 */
@media (max-width: 576px) {
  .pv-vod-sources .btn { width: 100%; }
}</pre>
<p class="pv-tip"><strong>禁止</strong>给 <code>{$field.embed_html}</code> 内 iframe 写死 <code>width/height</code> 像素值，否则会破坏 16:9。</p>

<h3>什么时候整段不输出？</h3>
<ul>
    <li>插件未启用或未安装；</li>
    <li>该文无嵌入条目且无启用中的点播单集；</li>
    <li><code>id</code> 无效。</li>
</ul>

<h3>自检清单</h3>
<ol>
    <li>仅有嵌入条目的文章 → 多条 16:9，手机竖屏不变形；</li>
    <li>绑定点播单集的文章 → 出现选集，点击能播、可切线路；</li>
    <li>无视频的文章 → 无空白占位；</li>
    <li>付费/试看单集 → 拒绝态或试看结束出现登录/购买按钮。</li>
</ol>

## 升级日志

### 1.0.x · 2026-07-17

- 文档发布页 Tab：粘贴链接自动识别 B站 / 爱奇艺 / 优酷 / 腾讯 / YouTube / 直链；爱奇艺页链即时提示须用分享 iframe
- 片源下拉补爱奇艺 / 优酷 / 腾讯；顶栏引导 tip
- 验收 fixture 第 1 集：B站样例 + mp4 直链双线路，前台可切「N 源」

### 1.0.x · 2026-07-16

- 文档发布页 Tab：主播放址置顶；权限/试看/备用线路折叠；Ctrl+V 粘贴链接快速加集
- 本剧默认权限 chip 化；去掉「剧集管理」外链（批量仍走插件中心）
- 修复：模板字符串吞掉正则 `\/\/` 导致 Tab 一直「加载中」

### 1.0.0 · 2026-01-15

- 文档挂载视频条目，封面与外联/嵌入地址
- 文档编辑器 inline 视频 Tab 与 `{pv:doc_vod}` 标签
- 会员中心「我的观影」已购授权入口

## 安装与开发

### 禁止

- 在 `app/common/service/` 写业务 extends 壳（document-addon 桥接在插件内 `VideoDocumentAddonBridge`，内核经 `DocumentAddonBridgeAccess` / `WeappCoreGateway` 发现）
- 插件内引用 `app/common/service/{Plugin}*` 业务空壳

### 目录

```text
weapp/doc_vod/
├── plugin.json
├── Plugin.php
├── service/              # 业务 ONLY HERE
│   ├── parser/           # 链接解析驱动（常改）
│   ├── VideoAccessService.php
│   ├── VideoPlaybackService.php
│   ├── VideoCatalogService.php
│   ├── VideoLinkParserService.php
│   ├── VideoWatchProgressService.php
│   ├── VideoStatsService.php
│   └── ...
├── api/controller/Video.php
├── admin/AdminController.php
└── database/install.sql
```

### 标装进度

| 项 | 状态 |
|----|------|
| `service/` 业务集中 | ✅ |
| `composer.json` | ✅ `pivark/doc_vod` |
| `PluginApiRegistry` 对外 API | ✅ `VideoPublic` |

### 双轨模型

| 轨道 | 表/入口 | 适用 |
|------|---------|------|
| **嵌入** | `weapp_doc_vod_items` · `/admin/doc_vod/list` | 单条外链/iframe，无付费选集 |
| **点播** | `series/episodes/sources` · `/admin/doc_vod/series` | 选集、试看、付费、续播 |

文档 `{pv:doc_vod}`：**有关联点播单集时优先点播 UI**，否则回退嵌入列表。

**剧集广场：** `/doc_vod/plaza`（勿占用 `/video`，留给 TAG 自定义路径如「产品视频」）· 开关 `doc_vod_plaza_open` · 全部上架剧集卡片、搜索、分页。

**剧集频道页（一剧一页）：** `/doc_vod/series/{slug}` · 开关 `doc_vod_series_channel_open` · 适合 20+ 集不必每集建文档。

迁移嵌入→点播（可选）：`php devtools/daily/scripts/migrate_doc_vod_items_to_vod.php`

**全功能验收（推荐发版前）：** `php devtools/daily/scripts/verify_video_full_cli.php` 或 `npm run test:doc_vod-full`  
报告：`devtools/reports/video-full-test-last.json` · 浏览器页见报告内 `browser.url`

### 后台

| 路由 | 说明 |
|------|------|
| `/admin/doc_vod/index` | 基础设置、影视等级、解析 API、平台开关 |
| `/admin/doc_vod/series` | 剧集/单集 · 复制季 · CSV 导入 · 线路探测 |
| `/admin/doc_vod/stats` | 播放与转化统计 · 热力图下钻 |
| `/admin/doc_vod/parseLink` | 单链解析 |
| `/admin/doc_vod/parseLinks` | 多行批量 |

### 禁止

- `app/common/service/` 下 extends 业务（内核不保留 `Video*` 业务壳；桥接 SSOT 在 `weapp/doc_vod/service/VideoDocumentAddonBridge.php`）
- 插件内引用 `app/common/service/Video*` 业务空壳
- 在**内核**写 B 站/优酷解析规则

### 超级搜索

嵌入/点播标题与简介写入文档 `search_text`（`VideoDocumentAddonBridge` 经 Registry 同步）。见 [文档扩展插件-超级搜索接入.md](../../docs/06-插件/文档扩展插件-超级搜索接入.md)
