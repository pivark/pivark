/** PivArk weapp — video vod player
 * @namespace PV.modules.videoPlayer
 */
(function (PV, pvUrl) {
  'use strict';
  PV = PV || {};
  PV.modules = PV.modules || {};

/**
 * 文档视频点播：选集、多线路、HLS（本地优先）、16:9 embed、试看 CTA、续播、广告点
 */
(function () {
    'use strict';

    var API_PLAY = pvUrl('apiVideoPlay', '/api/v1/plugins/doc_vod/play');
    var API_PROGRESS = pvUrl('apiVideoProgress', '/api/v1/plugins/doc_vod/progress');
    var API_EPISODE = pvUrl('apiVideoCheckoutEpisode', '/api/v1/plugins/doc_vod/checkout/episode');
    var API_SERIES = pvUrl('apiVideoCheckoutSeries', '/api/v1/plugins/doc_vod/checkout/series');
    var API_TRACK = pvUrl('apiVideoTrack', '/api/v1/plugins/doc_vod/track');
    var HLS_LOCAL = '/weapp/doc_vod/assets/js/hls.min.js';
    var activeEpisodeId = 0;
    var HLS_CDN = 'https://cdn.jsdelivr.net/npm/hls.js@1.5.7/dist/hls.min.js';
    var hlsLoadPromise = null;

    function qs(sel, root) {
        return (root || document).querySelector(sel);
    }

    function qsa(sel, root) {
        return Array.prototype.slice.call((root || document).querySelectorAll(sel));
    }

    function csrfToken() {
        var el = document.getElementById('pv-front-csrf-token')
            || document.getElementById('pv-member-csrf-token');
        return el ? String(el.value || '') : '';
    }

    function restData(body) {
        if (!body || typeof body !== 'object') {
            return {};
        }
        if (body.error) {
            return body;
        }
        if (Object.prototype.hasOwnProperty.call(body, 'data')) {
            var d = body.data;
            return d && typeof d === 'object' && !Array.isArray(d) ? d : {};
        }
        return body;
    }

    function restMsg(body, fallback) {
        if (body && body.error && body.error.message) {
            return String(body.error.message);
        }
        if (body && body.meta && body.meta.message) {
            return String(body.meta.message);
        }
        return fallback || '';
    }

    function fetchJson(url, options) {
        return fetch(url, Object.assign({
            credentials: 'same-origin',
            headers: {
                Accept: 'application/json',
                'X-Requested-With': 'XMLHttpRequest',
            },
        }, options || {})).then(function (res) {
            return res.json().then(function (body) {
                return { ok: res.ok, body: body };
            });
        });
    }

    function escapeHtml(s) {
        return String(s)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;');
    }

    function paymentChannels(body) {
        if (body && Array.isArray(body.payment_channels)) {
            return body.payment_channels;
        }
        return [];
    }

    function payChannelVisible(body, channel) {
        return paymentChannels(body).indexOf(channel) >= 0;
    }

    function trackEvent(episodeId, event) {
        if (!episodeId || !event) {
            return;
        }
        var fd = new FormData();
        fd.append('episode_id', String(episodeId));
        fd.append('event', event);
        fetch(API_TRACK, { method: 'POST', credentials: 'same-origin', body: fd }).catch(function () {});
    }

    function showPlayerSkeleton(host) {
        host.innerHTML = '<div class="pv-vod-skeleton" aria-busy="true">'
            + '<div class="pv-vod-skeleton__bar"></div>'
            + '<p class="text-muted small mb-0 mt-2">正在加载播放器…</p></div>';
    }

    function showPlayerError(host, msg, episodeId) {
        host.innerHTML = '<div class="pv-vod-error alert alert-danger py-2 small mb-0">'
            + escapeHtml(msg || '加载失败')
            + ' <button type="button" class="btn btn-sm btn-outline-danger ms-1 pv-vod-retry">重试</button></div>';
        var btn = qs('.pv-vod-retry', host);
        if (btn && episodeId) {
            btn.addEventListener('click', function () {
                var list = host.closest('[data-pv-vod-list]');
                var ep = list ? qs('.pv-vod-ep--active', list) : host.closest('.pv-vod-ep');
                if (list && ep) {
                    loadEpisode(list, episodeId, ep);
                } else if (ep) {
                    loadEpisode(ep, episodeId);
                }
            });
        }
    }

    function vodListRoot(el) {
        return el && el.closest ? el.closest('[data-pv-vod-list]') : null;
    }

    function sharedPlayerHost(list) {
        if (!list) {
            return null;
        }
        var host = qs('[data-pv-vod-player]', list);
        if (host && !host.closest('.pv-vod-ep')) {
            return host;
        }
        return null;
    }

    function updatePlayingTitle(list, epEl) {
        if (!list || !epEl) {
            return;
        }
        var titleEl = qs('[data-pv-vod-playing-title]', list);
        if (!titleEl) {
            return;
        }
        var t = epEl.getAttribute('data-ep-title') || '';
        if (!t) {
            var node = qs('.pv-vod-ep__title', epEl);
            t = node ? node.textContent : '';
        }
        titleEl.textContent = (t || '').trim();
    }

    function showUnlockToast() {
        var box = document.createElement('div');
        box.className = 'alert alert-success pv-vod-unlock-toast shadow-sm';
        box.setAttribute('role', 'status');
        box.textContent = '购买成功，已解锁观看';
        document.body.appendChild(box);
        setTimeout(function () {
            if (box.parentNode) {
                box.parentNode.removeChild(box);
            }
        }, 4500);
    }

    function handleUnlockFromUrl() {
        var params = new URLSearchParams(window.location.search);
        var unlockId = parseInt(params.get('video_unlock') || '0', 10);
        if (!unlockId) {
            return;
        }
        params.delete('video_unlock');
        var qstr = params.toString();
        var next = window.location.pathname + (qstr ? '?' + qstr : '') + window.location.hash;
        window.history.replaceState({}, '', next);
        showUnlockToast();
        var list = document.querySelector('[data-pv-vod-list]');
        if (!list) {
            return;
        }
        var target = null;
        qsa('.pv-vod-ep', list).forEach(function (el) {
            if (parseInt(el.getAttribute('data-episode-id'), 10) === unlockId) {
                target = el;
            }
        });
        if (target) {
            qsa('.pv-vod-ep', list).forEach(function (el) {
                el.classList.remove('pv-vod-ep--active');
            });
            target.classList.add('pv-vod-ep--active');
            loadEpisode(list, unlockId, target);
            target.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        }
    }

    function preferredSourceIndex(episodeId, count) {
        if (!episodeId || count < 2) {
            return 0;
        }
        try {
            var raw = localStorage.getItem('pv_vod_src_idx_' + episodeId);
            var idx = parseInt(raw, 10);
            if (!isNaN(idx) && idx >= 0 && idx < count) {
                return idx;
            }
        } catch (e) { /* ignore */ }
        return 0;
    }

    function rememberSourceIndex(episodeId, idx) {
        if (!episodeId) {
            return;
        }
        try {
            localStorage.setItem('pv_vod_src_idx_' + String(episodeId), String(idx));
        } catch (e) { /* ignore */ }
    }

    function showNextEpisodeBar(host, body) {
        var nextId = parseInt(body.next_episode_id, 10) || 0;
        if (!nextId) {
            return;
        }
        qsa('.pv-vod-next-ep', host).forEach(function (el) {
            el.parentNode.removeChild(el);
        });
        var list = host.closest('[data-pv-vod-list]');
        var autoSec = list ? parseInt(list.getAttribute('data-auto-next-sec'), 10) || 0 : 0;
        var bar = document.createElement('div');
        bar.className = 'pv-vod-next-ep alert alert-info py-2 small mb-2 d-flex flex-wrap align-items-center gap-2';
        var hint = document.createElement('span');
        hint.textContent = autoSec > 0 ? ('本集已结束，' + autoSec + ' 秒后播放下一集…') : '本集已结束';
        var btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'btn btn-sm btn-primary';
        btn.textContent = '播放下一集';
        bar.appendChild(hint);
        bar.appendChild(btn);
        function playNext() {
            var ep = list ? qs('.pv-vod-ep[data-episode-id="' + nextId + '"]', list) : null;
            if (ep) {
                ep.click();
            }
        }
        btn.addEventListener('click', playNext);
        host.appendChild(bar);
        if (autoSec > 0) {
            var left = autoSec;
            var timer = setInterval(function () {
                left -= 1;
                if (left <= 0) {
                    clearInterval(timer);
                    playNext();
                    return;
                }
                hint.textContent = '本集已结束，' + left + ' 秒后播放下一集…';
            }, 1000);
        }
    }

    function bindKeyboard(videoEl) {
        if (!videoEl || videoEl._pvVodKeys) {
            return;
        }
        videoEl._pvVodKeys = true;
        document.addEventListener('keydown', function (ev) {
            if (!activeEpisodeId || document.activeElement !== videoEl) {
                return;
            }
            if (ev.key === ' ' || ev.code === 'Space') {
                ev.preventDefault();
                if (videoEl.paused) {
                    videoEl.play();
                } else {
                    videoEl.pause();
                }
            }
            if (ev.key === 'ArrowRight') {
                videoEl.currentTime = Math.min((videoEl.duration || 0), videoEl.currentTime + 5);
            }
            if (ev.key === 'ArrowLeft') {
                videoEl.currentTime = Math.max(0, videoEl.currentTime - 5);
            }
        });
    }

    function loadScript(src) {
        return new Promise(function (resolve, reject) {
            var s = document.createElement('script');
            s.src = src;
            s.async = true;
            s.onload = function () { resolve(); };
            s.onerror = function () { reject(new Error('script load failed: ' + src)); };
            document.head.appendChild(s);
        });
    }

    function loadHlsJs() {
        if (window.Hls) {
            return Promise.resolve(window.Hls);
        }
        if (hlsLoadPromise) {
            return hlsLoadPromise;
        }
        hlsLoadPromise = loadScript(HLS_LOCAL)
            .catch(function () { return loadScript(HLS_CDN); })
            .then(function () {
                if (!window.Hls) {
                    throw new Error('hls.js unavailable');
                }
                return window.Hls;
            });
        return hlsLoadPromise;
    }

    function wrapEmbedHtml(html) {
        if (!html || html.indexOf('pv-vod-embed-ratio') >= 0) {
            return html;
        }
        if (/<iframe/i.test(html)) {
            return '<div class="pv-vod-embed-ratio">' + html + '</div>';
        }
        return html;
    }

    function playerShell(host) {
        var layout = host.closest('.pv-vod-layout');
        if (layout) {
            var wrap = qs('.pv-vod-layout__player-wrap', layout);
            if (wrap) {
                return wrap;
            }
        }
        var ep = host.closest('.pv-vod-ep');
        if (ep) {
            var shell = qs('.pv-vod-player-shell', ep);
            if (shell) {
                return shell;
            }
        }
        return host;
    }

    function hlsPlayerHost(videoEl) {
        return videoEl.closest('.pv-vod-player')
            || videoEl.closest('.pv-vod-player-inner')
            || videoEl.parentElement;
    }

    function destroyHls(videoEl) {
        if (!videoEl || !videoEl._pvHls) {
            return;
        }
        try {
            videoEl._pvHls.destroy();
        } catch (e) { /* ignore */ }
        videoEl._pvHls = null;
    }

    function removeQualityNav(host) {
        if (!host) {
            return;
        }
        qsa('.pv-vod-quality, .pv-vod-hls-native-hint', host).forEach(function (el) {
            if (el.parentNode) {
                el.parentNode.removeChild(el);
            }
        });
    }

    function formatHlsLevelLabel(level, idx) {
        if (!level) {
            return '清晰度 ' + (idx + 1);
        }
        if (level.height >= 2160) {
            return '4K';
        }
        if (level.height >= 1440) {
            return '2K';
        }
        if (level.height > 0) {
            return level.height + 'p';
        }
        if (level.bitrate > 0) {
            return Math.round(level.bitrate / 1000) + 'K';
        }

        return '清晰度 ' + (idx + 1);
    }

    function setQualityActive(nav, levelIndex) {
        qsa('button[data-level]', nav).forEach(function (btn) {
            var lv = btn.getAttribute('data-level');
            var on = (lv === 'auto' && levelIndex === -1) || String(levelIndex) === lv;
            btn.classList.toggle('active', on);
        });
    }

    function renderQualitySwitcher(host, Hls, hls, videoEl) {
        removeQualityNav(host);
        var levels = hls.levels || [];
        if (levels.length < 2) {
            return;
        }
        var nav = document.createElement('div');
        nav.className = 'pv-vod-quality btn-group btn-group-sm mb-2 flex-wrap';
        nav.setAttribute('role', 'group');
        nav.setAttribute('aria-label', '清晰度');

        var autoBtn = document.createElement('button');
        autoBtn.type = 'button';
        autoBtn.className = 'btn btn-outline-secondary active';
        autoBtn.setAttribute('data-level', 'auto');
        autoBtn.textContent = '自动';
        autoBtn.addEventListener('click', function () {
            hls.currentLevel = -1;
            setQualityActive(nav, -1);
        });
        nav.appendChild(autoBtn);

        levels.forEach(function (level, idx) {
            var btn = document.createElement('button');
            btn.type = 'button';
            btn.className = 'btn btn-outline-secondary';
            btn.setAttribute('data-level', String(idx));
            btn.textContent = formatHlsLevelLabel(level, idx);
            btn.addEventListener('click', function () {
                hls.currentLevel = idx;
                setQualityActive(nav, idx);
            });
            nav.appendChild(btn);
        });

        var inner = qs('.pv-vod-player-inner', host);
        if (inner) {
            host.insertBefore(nav, inner);
        } else {
            host.insertBefore(nav, videoEl);
        }

        hls.on(Hls.Events.LEVEL_SWITCHED, function (_ev, data) {
            setQualityActive(nav, typeof data.level === 'number' ? data.level : -1);
        });
    }

    function mountHls(videoEl) {
        var src = videoEl.getAttribute('data-pv-hls');
        if (!src) {
            return;
        }
        var host = hlsPlayerHost(videoEl);
        destroyHls(videoEl);
        removeQualityNav(host);

        loadHlsJs().then(function (Hls) {
            if (Hls && Hls.isSupported()) {
                var hls = new Hls({ capLevelToPlayerSize: true });
                videoEl._pvHls = hls;
                hls.loadSource(src);
                hls.attachMedia(videoEl);
                hls.on(Hls.Events.MANIFEST_PARSED, function () {
                    renderQualitySwitcher(host, Hls, hls, videoEl);
                });
                hls.on(Hls.Events.ERROR, function (_ev, data) {
                    if (!data.fatal) {
                        return;
                    }
                    var errType = data.type || '';
                    var errDetail = (data.details || '').toString();
                    var corsHint = errType === Hls.ErrorTypes.NETWORK_ERROR
                        || /cors|levelLoadError|manifestLoadError/i.test(errDetail);
                    destroyHls(videoEl);
                    removeQualityNav(host);
                    if (corsHint && videoEl.canPlayType('application/vnd.apple.mpegurl')) {
                        videoEl.src = src;
                        var hint = document.createElement('p');
                        hint.className = 'text-muted small mt-1 mb-0';
                        hint.textContent = '跨域受限，已切换系统 HLS 播放（清晰度切换可能不可用）';
                        if (host) {
                            host.appendChild(hint);
                        }
                        return;
                    }
                    var msg = corsHint
                        ? 'HLS 播放失败：片源未允许跨域（CDN 需 Access-Control-Allow-Origin），请换线路或联系运维'
                        : 'HLS 播放失败，请换线路或刷新';
                    videoEl.insertAdjacentHTML(
                        'afterend',
                        '<p class="text-danger small pv-vod-hls-err">' + msg + '</p>'
                    );
                });
                return;
            }
            if (videoEl.canPlayType('application/vnd.apple.mpegurl')) {
                videoEl.src = src;
                var hint = document.createElement('p');
                hint.className = 'text-muted small mt-1 mb-0 pv-vod-hls-native-hint';
                hint.textContent = '系统播放器模式：多清晰度需 master.m3u8，推荐 Chrome/Edge 获得清晰度切换';
                if (host) {
                    host.appendChild(hint);
                }
                return;
            }
            videoEl.insertAdjacentHTML(
                'afterend',
                '<p class="text-muted small p-2">当前浏览器不支持 HLS 播放</p>'
            );
        }).catch(function () {
            videoEl.insertAdjacentHTML(
                'afterend',
                '<p class="text-danger small">HLS 加载失败，请刷新重试</p>'
            );
        });
    }

    function buildTrialOverlay(body, trialSec) {
        var overlay = document.createElement('div');
        overlay.className = 'pv-vod-trial-overlay';
        var msg = escapeHtml(body.msg || restMsg(body, '') || ('试看已结束（' + trialSec + ' 秒）'));
        var html = '<p class="mb-0">' + msg + '</p><div class="d-flex flex-wrap gap-2 justify-content-center">';
        if (body.login_url) {
            html += '<a href="' + escapeHtml(body.login_url) + '" class="btn btn-light btn-sm">登录观看</a>';
        }
        if (body.cta_url && body.cta_label) {
            html += '<a href="' + escapeHtml(body.cta_url) + '" class="btn btn-primary btn-sm">'
                + escapeHtml(body.cta_label) + '</a>';
        }
        if (body.need === 'pay_episode' || body.need === 'pay_series') {
            var epId = body.episode_id || 0;
            var seriesId = body.series_id || 0;
            if (body.need === 'pay_episode' && epId) {
                if (payChannelVisible(body, 'alipay')) {
                    html += '<button type="button" class="btn btn-outline-light btn-sm pv-vod-buy-episode" data-episode-id="'
                        + epId + '">支付宝购买</button>';
                }
                if (payChannelVisible(body, 'wechat')) {
                    html += '<button type="button" class="btn btn-outline-success btn-sm pv-vod-buy-episode-wechat" data-episode-id="'
                        + epId + '">微信购买</button>';
                }
            }
            if (body.need === 'pay_series' && seriesId && payChannelVisible(body, 'alipay')) {
                html += '<button type="button" class="btn btn-outline-light btn-sm pv-vod-buy-series" data-series-id="'
                    + seriesId + '">购买全集</button>';
            }
        }
        if (body.need === 'points' && body.cta_url) {
            html += '<a href="' + escapeHtml(body.cta_url) + '" class="btn btn-primary btn-sm">'
                + escapeHtml(body.cta_label || '积分兑换') + '</a>';
        }
        html += '</div>';
        overlay.innerHTML = html;
        bindPayButtons(overlay);
        return overlay;
    }

    function applyTrial(videoEl, trialSec, host, body) {
        if (!trialSec || trialSec < 1 || !videoEl) {
            return;
        }
        var stopped = false;
        var shell = playerShell(host);
        function onTime() {
            if (stopped || videoEl.currentTime < trialSec) {
                return;
            }
            stopped = true;
            videoEl.pause();
            trackEvent(parseInt(body.episode_id, 10) || activeEpisodeId, 'trial_end');
            qsa('.pv-vod-trial-overlay', shell).forEach(function (el) {
                el.parentNode.removeChild(el);
            });
            var overlay = buildTrialOverlay(
                Object.assign({}, body, {
                    msg: '试看结束，购买或登录后可完整观看',
                    need: body.need || 'pay_episode',
                }),
                trialSec
            );
            shell.appendChild(overlay);
        }
        videoEl.addEventListener('timeupdate', onTime);
    }

    function bindAdCues(videoEl, host, cues) {
        if (!videoEl || !cues || !cues.length) {
            return;
        }
        var fired = {};
        videoEl.addEventListener('timeupdate', function () {
            var t = Math.floor(videoEl.currentTime || 0);
            cues.forEach(function (cue) {
                var at = parseInt(cue.at_sec, 10) || 0;
                if (t < at || t > at + 2 || fired[at]) {
                    return;
                }
                fired[at] = true;
                var box = document.createElement('div');
                box.className = 'pv-vod-ad-cue border rounded p-2 mb-2 small bg-light';
                var inner = '';
                if (cue.type === 'image' && cue.content) {
                    inner = '<img src="' + escapeHtml(cue.content) + '" alt="" class="img-fluid" style="max-height:120px">';
                } else if (cue.content) {
                    inner = escapeHtml(cue.content);
                }
                if (cue.link) {
                    inner = '<a href="' + escapeHtml(cue.link) + '" target="_blank" rel="noopener">' + inner + '</a>';
                }
                box.innerHTML = inner;
                host.insertBefore(box, host.firstChild);
                setTimeout(function () {
                    if (box.parentNode) {
                        box.parentNode.removeChild(box);
                    }
                }, 8000);
            });
        });
    }

    function saveProgress(episodeId, sec) {
        if (!episodeId || sec < 5 || !csrfToken()) {
            return;
        }
        var fd = new FormData();
        fd.append('episode_id', String(episodeId));
        fd.append('position_sec', String(Math.floor(sec)));
        fd.append('__token', csrfToken());
        fetch(API_PROGRESS, {
            method: 'POST',
            credentials: 'same-origin',
            body: fd,
            headers: { 'X-CSRF-Token': csrfToken() },
        }).catch(function () {});
    }

    function bindProgress(videoEl, episodeId, startSec, forceStart) {
        if (!videoEl || !episodeId) {
            return;
        }
        var lastSave = 0;
        var applySeek = function () {
            if (startSec > 0 && startSec < (videoEl.duration || Infinity) - 10) {
                try {
                    videoEl.currentTime = startSec;
                } catch (e) { /* ignore */ }
            }
        };
        videoEl.addEventListener('loadedmetadata', function () {
            if (forceStart !== false) {
                applySeek();
            }
        });
        bindKeyboard(videoEl);
        videoEl.addEventListener('ended', function () {
            var host = videoEl.closest('.pv-vod-player');
            if (host && host._pvNextBody) {
                showNextEpisodeBar(host, host._pvNextBody);
            }
        });
        videoEl.addEventListener('timeupdate', function () {
            var now = Date.now();
            if (now - lastSave < 15000) {
                return;
            }
            lastSave = now;
            saveProgress(episodeId, videoEl.currentTime || 0);
        });
    }

    function bindEmbedVideos(playerBox, meta) {
        qsa('video[data-pv-hls], video.pv-video-native', playerBox).forEach(function (v) {
            if (v.getAttribute('data-pv-hls')) {
                mountHls(v);
            }
            if (meta && meta.episodeId) {
                bindProgress(v, meta.episodeId, meta.progressSec || 0);
                applyTrial(v, meta.trialSec || 0, playerBox, meta.deniedBody || {});
                bindAdCues(v, meta.host || playerBox, meta.adCues || []);
            }
        });
    }

    function sourceDisplayLabel(src, idx) {
        if (src && src.label) {
            return String(src.label);
        }
        var map = {
            bilibili: '哔哩哔哩',
            iqiyi: '爱奇艺',
            youku: '优酷',
            tencent: '腾讯视频',
            youtube: 'YouTube',
            local: '本地播放',
            file: '本地文件',
            remote_url: '直链/HLS',
            parse_url: '解析',
            embed: '外链',
        };
        var p = (src && src.provider) ? String(src.provider).toLowerCase() : '';
        if (p && map[p]) {
            return map[p];
        }
        return '片源' + ((idx || 0) + 1);
    }

    function clearSourceSwitcherHosts(list) {
        if (!list) {
            return;
        }
        qsa('[data-pv-vod-sources-slot], .pv-vod-player .pv-vod-sources', list).forEach(function (el) {
            el.innerHTML = '';
        });
    }

    function renderSourceSwitcher(host, sources, onPick, list, activeIdx) {
        activeIdx = typeof activeIdx === 'number' ? activeIdx : 0;
        if (!host) {
            return;
        }
        host.innerHTML = '';
        if (!sources || !sources.length) {
            host.innerHTML = '<p class="text-muted small mb-0">暂无片源</p>';
            return;
        }
        var inSidebar = host.hasAttribute('data-pv-vod-sources-slot');
        var nav = document.createElement('div');
        nav.className = 'pv-vod-sources' + (inSidebar ? ' pv-vod-sources--sidebar' : ' btn-group btn-group-sm mb-2 flex-wrap');
        if (sources.length < 2 && inSidebar) {
            var only = document.createElement('p');
            only.className = 'pv-vod-sources__single small mb-0';
            only.textContent = sourceDisplayLabel(sources[0], 0);
            host.appendChild(only);
            return;
        }
        if (sources.length < 2) {
            return;
        }
        sources.forEach(function (src, idx) {
            var btn = document.createElement('button');
            btn.type = 'button';
            btn.className = (inSidebar ? 'pv-vod-sources__btn' : 'btn btn-outline-secondary')
                + (idx === activeIdx ? ' active' : '');
            btn.textContent = sourceDisplayLabel(src, idx);
            btn.setAttribute('title', (src.play_url || '').slice(0, 120));
            btn.addEventListener('click', function () {
                qsa('button', nav).forEach(function (b) { b.classList.remove('active'); });
                btn.classList.add('active');
                if (activeEpisodeId) {
                    rememberSourceIndex(activeEpisodeId, idx);
                }
                onPick(src, idx);
            });
            nav.appendChild(btn);
        });
        host.appendChild(nav);
    }

    function renderPlayer(host, play, meta) {
        if (!host) {
            return;
        }
        var playerBox = qs('.pv-vod-player-inner', host) || host;
        if (!play || play.type === 'none') {
            qsa('video', playerBox).forEach(destroyHls);
            removeQualityNav(host);
            playerBox.innerHTML = '<p class="text-muted small mb-0">暂无可用片源</p>';
            return;
        }
        qsa('video', playerBox).forEach(destroyHls);
        removeQualityNav(host);
        playerBox.innerHTML = '';
        if (play.embed_html) {
            playerBox.innerHTML = wrapEmbedHtml(play.embed_html);
            bindEmbedVideos(playerBox, Object.assign({}, meta, { host: host }));
            return;
        }
        if (play.play_url) {
            if (play.type === 'video' || play.type === 'hls') {
                var html = '<video class="pv-video-native w-100" controls playsinline';
                if (play.type === 'hls') {
                    html += ' data-pv-hls="' + escapeHtml(play.play_url) + '"';
                } else {
                    html += ' src="' + escapeHtml(play.play_url) + '"';
                }
                html += '></video>';
                playerBox.innerHTML = html;
                var v = qs('video', playerBox);
                if (v && play.type === 'hls') {
                    mountHls(v);
                }
                if (v && meta && meta.episodeId) {
                    bindProgress(v, meta.episodeId, meta.progressSec || 0);
                    applyTrial(v, meta.trialSec || 0, host, meta.deniedBody || {});
                    bindAdCues(v, host, meta.adCues || []);
                }
                return;
            }
            playerBox.innerHTML =
                '<a href="' + escapeHtml(play.play_url) + '" class="btn btn-sm btn-primary" target="_blank" rel="noopener">打开播放</a>';
        }
    }

    function renderDenied(host, data, rawBody) {
        if (!host) {
            return;
        }
        var box = qs('.pv-vod-denied', host);
        if (!box) {
            box = document.createElement('div');
            box.className = 'pv-vod-denied';
            host.appendChild(box);
        }
        data = data || {};
        rawBody = rawBody || {};
        var msg = escapeHtml(data.message || restMsg(rawBody, '无权观看'));
        var html = '<div class="alert alert-warning mb-2 py-2 small">' + msg + '</div><div class="d-flex flex-wrap gap-2">';
        if (data.login_url) {
            html += '<a href="' + escapeHtml(data.login_url) + '" class="btn btn-sm btn-outline-secondary">登录观看</a>';
        }
        if (data.recharge_url && data.need === 'level') {
            html += '<a href="' + escapeHtml(data.recharge_url) + '" class="btn btn-sm btn-warning">升级会员</a>';
        }
        if (data.price_text && (data.need === 'pay_episode' || data.need === 'pay_series')) {
            html += '<span class="badge text-bg-light border align-self-center">' + escapeHtml(data.price_text) + '</span>';
        }
        if (data.cta_url && data.cta_label) {
            html += '<a href="' + escapeHtml(data.cta_url) + '" class="btn btn-sm btn-primary">'
                + escapeHtml(data.cta_label) + '</a>';
        }
        if (data.need === 'pay_episode' || data.need === 'pay_series') {
            var epId = data.episode_id || 0;
            var seriesId = data.series_id || 0;
            if (data.need === 'pay_episode' && epId) {
                if (payChannelVisible(data, 'alipay')) {
                    html += '<button type="button" class="btn btn-sm btn-outline-primary pv-vod-buy-episode" data-episode-id="'
                        + epId + '">支付宝购买</button>';
                }
                if (payChannelVisible(data, 'wechat')) {
                    html += '<button type="button" class="btn btn-sm btn-outline-success pv-vod-buy-episode-wechat" data-episode-id="'
                        + epId + '">微信购买</button>';
                }
            }
            if (data.need === 'pay_series' && seriesId) {
                html += '<button type="button" class="btn btn-sm btn-outline-secondary pv-vod-buy-series" data-series-id="'
                    + seriesId + '">购买全集</button>';
            }
        }
        if (data.need === 'points') {
            if (data.price_text) {
                html += '<span class="badge text-bg-light border align-self-center">' + escapeHtml(data.price_text) + '</span>';
            }
            if (data.cta_url && data.cta_label) {
                // already added above via generic cta
            } else if (data.cta_url) {
                html += '<a href="' + escapeHtml(data.cta_url) + '" class="btn btn-sm btn-primary">积分兑换</a>';
            }
        }
        html += '</div>';
        box.innerHTML = html;
        bindPayButtons(box);
    }

    function bindPayButtons(host) {
        qsa('.pv-vod-buy-episode', host).forEach(function (btn) {
            btn.addEventListener('click', function () {
                var epId = parseInt(btn.getAttribute('data-episode-id'), 10) || 0;
                trackEvent(epId, 'buy_click');
                checkoutEpisode(epId, 'alipay');
            });
        });
        qsa('.pv-vod-buy-episode-wechat', host).forEach(function (btn) {
            btn.addEventListener('click', function () {
                var epId = parseInt(btn.getAttribute('data-episode-id'), 10) || 0;
                trackEvent(epId, 'buy_click');
                checkoutEpisode(epId, 'wechat');
            });
        });
        qsa('.pv-vod-buy-series', host).forEach(function (btn) {
            btn.addEventListener('click', function () {
                trackEvent(activeEpisodeId, 'buy_click');
                checkoutSeries(parseInt(btn.getAttribute('data-series-id'), 10) || 0, 'alipay');
            });
        });
    }

    function checkoutEpisode(episodeId, channel) {
        if (!episodeId) {
            return;
        }
        var fd = new FormData();
        fd.append('episode_id', String(episodeId));
        fd.append('channel', channel || 'alipay');
        fd.append('__token', csrfToken());
        fetchJson(API_EPISODE, {
            method: 'POST',
            body: fd,
            headers: { 'X-CSRF-Token': csrfToken() },
        }).then(function (res) {
            handlePayResult(res.body);
        });
    }

    function checkoutSeries(seriesId, channel) {
        if (!seriesId) {
            return;
        }
        var fd = new FormData();
        fd.append('series_id', String(seriesId));
        fd.append('channel', channel || 'alipay');
        fd.append('__token', csrfToken());
        fetchJson(API_SERIES, {
            method: 'POST',
            body: fd,
            headers: { 'X-CSRF-Token': csrfToken() },
        }).then(function (res) {
            handlePayResult(res.body);
        });
    }

    function handlePayResult(body) {
        if (!body || body.error) {
            alert(restMsg(body, '下单失败'));
            return;
        }
        var data = restData(body);
        if (body.redirect && !data.redirect) {
            data.redirect = body.redirect;
        }
        if (data.redirect) {
            window.location.href = data.redirect;
            return;
        }
        if (data.form_html) {
            var wrap = document.createElement('div');
            wrap.innerHTML = data.form_html;
            document.body.appendChild(wrap);
            var form = wrap.querySelector('form');
            if (form) {
                form.submit();
            }
            return;
        }
        if (data.order_no) {
            window.location.href = pvPayReturn(data.order_no);
        }
    }

    function startPlayWithMeta(host, body, episodeId, meta) {
        host._pvNextBody = body;
        var list = vodListRoot(host);
        var sourceSlot = list ? qs('[data-pv-vod-sources-slot]', list) : null;
        clearSourceSwitcherHosts(list);
        var sources = meta.sources && meta.sources.length ? meta.sources : [];
        var prefIdx = preferredSourceIndex(episodeId, sources.length);
        var onPick = function (src, idx) {
            if (typeof idx === 'number') {
                rememberSourceIndex(episodeId, idx);
            }
            renderPlayer(host, src, meta);
        };
        if (sourceSlot) {
            renderSourceSwitcher(sourceSlot, sources, onPick, list, prefIdx);
        } else {
            renderSourceSwitcher(host, sources, onPick, list, prefIdx);
        }
        renderPlayer(host, sources[prefIdx] || sources[0] || {}, meta);
        if (body.trial_mode && body.trial_sec) {
            var hint = document.createElement('p');
            hint.className = 'pv-vod-trial-banner mb-1';
            hint.textContent = '试看 ' + body.trial_sec + ' 秒，结束后可购买或登录继续观看';
            var inner = qs('.pv-vod-player-inner', host);
            if (inner) {
                host.insertBefore(hint, inner);
            }
        }
    }

    function showPlay(host, body, episodeId) {
        activeEpisodeId = episodeId;
        var sources = body.sources && body.sources.length ? body.sources : [body.play];
        var startSec = body.progress_sec || 0;
        var meta = {
            episodeId: episodeId,
            progressSec: startSec,
            trialSec: body.trial_mode ? (body.trial_sec || 0) : 0,
            adCues: body.ad_cues || [],
            deniedBody: body,
            sources: sources,
        };
        host.innerHTML = '<div class="pv-vod-player-inner"></div><div class="pv-vod-denied"></div>';
        var inner = qs('.pv-vod-player-inner', host);

        function go(resume) {
            qsa('.pv-vod-resume-choose', host).forEach(function (el) {
                el.parentNode.removeChild(el);
            });
            meta.progressSec = resume ? startSec : 0;
            if (resume && body.resume_hint) {
                var resumeHint = document.createElement('p');
                resumeHint.className = 'pv-vod-resume-hint mb-1';
                resumeHint.textContent = body.resume_hint;
                if (inner) {
                    host.insertBefore(resumeHint, inner);
                }
            }
            startPlayWithMeta(host, body, episodeId, meta);
        }

        if (body.resume_choose && startSec > 30) {
            var choose = document.createElement('div');
            choose.className = 'pv-vod-resume-choose alert alert-secondary py-2 small mb-2';
            choose.innerHTML = '<span class="me-2">' + escapeHtml(body.resume_hint || '检测到观看进度') + '</span>'
                + '<button type="button" class="btn btn-sm btn-primary me-1 pv-vod-resume-yes">继续</button>'
                + '<button type="button" class="btn btn-sm btn-outline-secondary pv-vod-resume-no">从头</button>';
            host.insertBefore(choose, inner);
            choose.querySelector('.pv-vod-resume-yes').addEventListener('click', function () {
                go(true);
            });
            choose.querySelector('.pv-vod-resume-no').addEventListener('click', function () {
                go(false);
            });
            return;
        }
        if (body.resume_hint && startSec > 0) {
            var resume = document.createElement('p');
            resume.className = 'pv-vod-resume-hint mb-1';
            resume.textContent = body.resume_hint;
            host.insertBefore(resume, inner);
        }
        startPlayWithMeta(host, body, episodeId, meta);
    }

    function loadEpisode(listOrEp, episodeId, activeEp) {
        var list = null;
        var epEl = null;
        var host = null;
        if (listOrEp && listOrEp.getAttribute && listOrEp.getAttribute('data-pv-vod-list') !== null) {
            list = listOrEp;
            epEl = activeEp || null;
            host = sharedPlayerHost(list);
        } else {
            epEl = listOrEp;
            list = vodListRoot(epEl);
            host = sharedPlayerHost(list) || (epEl ? qs('[data-pv-vod-player]', epEl) : null);
        }
        if (!host || !episodeId) {
            return;
        }
        if (epEl) {
            updatePlayingTitle(list, epEl);
        }
        if (list) {
            clearSourceSwitcherHosts(list);
        }
        showPlayerSkeleton(host);
        fetchJson(API_PLAY + '?episode_id=' + encodeURIComponent(String(episodeId)))
            .then(function (res) {
                var body = res.body || {};
                var data = restData(body);
                if (!body.error && data.allowed === 1) {
                    showPlay(host, data, episodeId);
                    return;
                }
                host.innerHTML = '<div class="pv-vod-player-inner"></div><div class="pv-vod-denied"></div>';
                renderDenied(host, data, body);
            })
            .catch(function () {
                showPlayerError(host, '播放请求失败，请检查网络', episodeId);
            });
    }

    function bindEpisodeFilter(list) {
        var input = qs('[data-pv-vod-ep-filter]', list);
        if (!input) {
            return;
        }
        input.addEventListener('input', function () {
            var q = String(input.value || '').trim().toLowerCase();
            qsa('.pv-vod-ep', list).forEach(function (ep) {
                var title = (ep.getAttribute('data-ep-title') || '').toLowerCase();
                var no = String(ep.getAttribute('data-ep-no') || '');
                var show = q === '' || title.indexOf(q) >= 0 || no.indexOf(q) >= 0;
                ep.style.display = show ? '' : 'none';
            });
        });
    }

    function initList(list) {
        var episodes = qsa('.pv-vod-ep', list);
        if (!episodes.length) {
            return;
        }
        bindEpisodeFilter(list);
        var shared = !!sharedPlayerHost(list);
        episodes.forEach(function (ep) {
            ep.addEventListener('click', function (ev) {
                if (ev.target.closest('.pv-vod-buy-episode, .pv-vod-buy-series, a, button')) {
                    return;
                }
                var id = parseInt(ep.getAttribute('data-episode-id'), 10) || 0;
                if (!id) {
                    return;
                }
                episodes.forEach(function (other) {
                    other.classList.remove('pv-vod-ep--active');
                });
                ep.classList.add('pv-vod-ep--active');
                if (shared) {
                    loadEpisode(list, id, ep);
                } else {
                    loadEpisode(ep, id);
                }
            });
        });
        var first = episodes[0];
        var firstId = parseInt(first.getAttribute('data-episode-id'), 10) || 0;
        if (firstId) {
            first.classList.add('pv-vod-ep--active');
            if (shared) {
                loadEpisode(list, firstId, first);
            } else {
                loadEpisode(first, firstId);
            }
        }
    }

    document.addEventListener('DOMContentLoaded', function () {
        qsa('[data-pv-vod-list]').forEach(initList);
        handleUnlockFromUrl();
    });
})();

  PV.modules.videoPlayer = PV.modules.videoPlayer || {};
})(window.PV = window.PV || {}, window.pvUrl);
