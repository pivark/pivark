<?php
declare(strict_types=1);

namespace weapp\doc_vod\service;

/** 播放源解析（embed / 本地 / 远程 / 解析 URL 壳） */
class VideoSourceResolver
{
    /**
     * @param array<string, mixed> $source
     * @return array{type:string,embed_html:string,play_url:string,cover_url:string,provider:string,label:string,source_id:int}
     */
    public static function resolve(array $source, string $title = '', string $coverPath = ''): array
    {
        $provider = strtolower(trim((string) ($source['provider'] ?? 'embed')));
        $playUrl  = trim((string) ($source['play_url'] ?? ''));
        $cover    = VideoService::publicUrl($coverPath);
        $label    = VideoSourceCatalog::label($source);
        $sourceId = (int) ($source['id'] ?? 0);

        $resolved = match ($provider) {
            'local', 'remote_url', 'file', 'parse_url', 'parse_generic' => self::resolveDirect($playUrl, $cover, $title, $provider),
            default => self::resolveEmbed($playUrl, $cover, $title, $provider),
        };

        return array_merge($resolved, [
            'label'     => $label,
            'source_id' => $sourceId,
        ]);
    }

    /** @return array{type:string,embed_html:string,play_url:string,cover_url:string,provider:string} */
    private static function resolveEmbed(string $playUrl, string $cover, string $title, string $provider): array
    {
        $embedHtml = VideoService::buildEmbedHtmlPublic($playUrl, $cover, $title);
        $type      = str_contains($embedHtml, 'pv-vod-platform-card') ? 'external' : 'embed';

        return [
            'type'       => $type,
            'embed_html' => $embedHtml,
            'play_url'   => $playUrl,
            'cover_url'  => $cover,
            'provider'   => $provider !== '' ? $provider : 'embed',
        ];
    }

    /** @return array{type:string,embed_html:string,play_url:string,cover_url:string,provider:string} */
    private static function resolveDirect(string $playUrl, string $cover, string $title, string $provider): array
    {
        if ($playUrl === '') {
            return ['type' => 'none', 'embed_html' => '', 'play_url' => '', 'cover_url' => $cover, 'provider' => $provider];
        }
        if (in_array($provider, ['parse_url', 'parse_generic'], true)) {
            $playUrl = VideoParseUrlService::resolvePlayUrl($playUrl);
        }
        if (preg_match('#\.(m3u8)(\?|$)#i', $playUrl)) {
            if (VideoConfigService::hlsProxyOpen() && preg_match('#^https?://#i', $playUrl)) {
                $playUrl = VideoStreamProxyService::proxiedUrl($playUrl);
            }
            $src = htmlspecialchars($playUrl, ENT_QUOTES, 'UTF-8');

            return [
                'type'       => 'hls',
                'embed_html' => '<video class="pv-video-native w-100" controls playsinline data-pv-hls="' . $src . '"></video>',
                'play_url'   => $playUrl,
                'cover_url'  => $cover,
                'provider'   => $provider,
            ];
        }
        if (preg_match('#\.(mp4|webm|mov)(\?|$)#i', $playUrl)) {
            $src = htmlspecialchars($playUrl, ENT_QUOTES, 'UTF-8');

            return [
                'type'       => 'video',
                'embed_html' => '<video class="pv-video-native w-100" controls playsinline src="' . $src . '"></video>',
                'play_url'   => $playUrl,
                'cover_url'  => $cover,
                'provider'   => $provider,
            ];
        }

        return [
            'type'       => 'embed',
            'embed_html' => VideoService::buildEmbedHtmlPublic($playUrl, $cover, $title),
            'play_url'   => $playUrl,
            'cover_url'  => $cover,
            'provider'   => $provider,
        ];
    }
}
