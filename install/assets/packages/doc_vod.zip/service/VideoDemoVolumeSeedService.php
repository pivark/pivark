<?php
/**
 * 元舟 PivArk — 企业全域原子化数字资产中枢
 * (c) 2024-2026 pivark.com. All rights reserved.
 * Author: Angelo
 * 未经允许，不可用于商业用途。
 *
 * 视频插件：发行演示加灌（多来源/试看/积分/系列感）
 */
declare(strict_types=1);

namespace weapp\doc_vod\service;

use app\common\service\weapp\WeappConfigGateway;
use app\common\service\weapp\WeappPluginGateway;
use weapp\doc_vod\model\WeappVideoItem;

final class VideoDemoVolumeSeedService
{
    /**
     * @return array{docs:int,items:int}
     */
    public static function seed(): array
    {
        app(WeappPluginGateway::class)->pluginRegisterAutoloadPublic('doc_vod');
        $cfg = app(WeappConfigGateway::class);
        $tagSlug = 'pv-demo-video';
        $tagIds = [
            $tagSlug => $cfg->installDemoUpsertTag([
                'slug'        => $tagSlug,
                'name'        => '产品视频',
                'tpl'         => 'list_document_video.php',

                'nav_sort'    => 5,
                'description' => '产品介绍、操作指南与案例视频（演示加灌多播放形态）',
                'url_path'    => 'video',
            ]),
        ];
        $cfg->installDemoAppendContentCategoryNav('video', '产品视频', 5);

        $specs = [
            ['pv-demo-video-01', 'HY-810 产品介绍（直链 MP4）', 'direct', 'https://www.w3schools.com/html/mov_bbb.mp4', true, ''],
            ['pv-demo-video-02', 'HY-900 组态操作（外链演示）', 'embed', 'https://www.w3schools.com/html/mov_bbb.mp4', false, ''],
            ['pv-demo-video-03', 'HART 手操器现场调试', 'direct', 'https://www.w3schools.com/html/movie.mp4', true, ''],
            ['pv-demo-video-04', 'Modbus 接线与上位采集', 'embed', 'https://www.w3schools.com/html/mov_bbb.mp4', false, ''],
            ['pv-demo-video-05', 'DCS / PLC 对接配置', 'direct', 'https://www.w3schools.com/html/movie.mp4', true, 'preview'],
            ['pv-demo-video-06', '防爆区域安装规范讲解', 'embed', 'https://www.w3schools.com/html/mov_bbb.mp4', false, ''],
            ['pv-demo-video-07', '污水处理升级案例纪实', 'direct', 'https://www.w3schools.com/html/movie.mp4', true, ''],
            ['pv-demo-video-08', '华仪智控企业宣传片', 'embed', 'https://www.w3schools.com/html/mov_bbb.mp4', true, ''],
            ['pv-demo-video-09', '膜片更换实操（短片）', 'direct', 'https://www.w3schools.com/html/movie.mp4', false, ''],
            ['pv-demo-video-10', '校准实验室一天', 'embed', 'https://www.w3schools.com/html/mov_bbb.mp4', true, ''],
            ['pv-demo-video-11', '客户培训课堂实录', 'direct', 'https://www.w3schools.com/html/movie.mp4', false, 'points'],
            ['pv-demo-video-12', '展会展台讲解精彩片段', 'embed', 'https://www.w3schools.com/html/mov_bbb.mp4', true, ''],
            ['pv-demo-video-13', '罐区液位监测巡检 Vlog', 'direct', 'https://www.w3schools.com/html/movie.mp4', false, ''],
            ['pv-demo-video-14', '多机房温湿度监控演示', 'embed', 'https://www.w3schools.com/html/mov_bbb.mp4', true, 'preview'],
        ];

        $docs = 0;
        $items = 0;
        foreach ($specs as $idx => $spec) {
            [$html, $title, $provider, $url, $withCover, $extra] = $spec;
            // 社区种子已有文档时只挂点播表，保留华仪标题；缺篇再 upsert
            $docId = $cfg->installDemoDocumentIdByHtml((string) $html);
            $playTitle = $title;
            if ($docId > 0) {
                $existingTitle = trim($cfg->installDemoDocumentField($docId, 'title'));
                if ($existingTitle !== '') {
                    $playTitle = $existingTitle;
                }
            } else {
                $summary = '演示视频：' . $title . ' · 形态=' . $provider . ($extra !== '' ? ' · ' . $extra : '');
                $content = '<p class="lead">' . htmlspecialchars($title, ENT_QUOTES, 'UTF-8') . '</p>'
                    . '<p>本页用于验收视频插件播放入口、封面与列表样式。正文不堆砌大图。</p>';
                if ($extra === 'preview') {
                    $content .= '<p>本片开启试看演示策略（具体以插件设置为准）。</p>';
                }
                if ($extra === 'points') {
                    $content .= '<p>本片演示积分相关 CTA（若站点开启积分）。</p>';
                }
                $litpic = $withCover ? self::cover($idx + 1) : '';
                $docId = $cfg->installDemoUpsertDocument(
                    $html,
                    $title,
                    $summary,
                    $content,
                    $litpic,
                    $withCover ? 'has_image' : '',
                    500 + random_int(0, 1500),
                    0,
                    'view_document_video.php',
                );
            }
            if ($docId < 1) {
                continue;
            }
            $docs++;
            $cfg->installDemoLinkDocumentTags($docId, [$tagSlug], $tagIds);
            if (self::seedItem($docId, $playTitle, $provider, $url, $withCover ? self::cover($idx + 1) : self::cover($idx + 5))) {
                $items++;
            }
        }
        $cfg->installDemoRefreshTagUseCounts();
        echo "OK VideoDemoVolumeSeedService docs={$docs} items={$items}\n";

        return ['docs' => $docs, 'items' => $items];
    }

    private static function cover(int $n): string
    {
        $idx = (($n - 1) % 14) + 1;
        $rel = '/uploads/demo-seed/product/' . str_pad((string) $idx, 2, '0', STR_PAD_LEFT) . '.jpg';
        $abs = rtrim((string) ROOT_PATH, '/\\') . '/public' . $rel;

        return is_file($abs) ? $rel : '/uploads/demo-seed/product/01.jpg';
    }

    private static function seedItem(int $documentId, string $title, string $provider, string $url, string $cover): bool
    {
        $now = date('Y-m-d H:i:s');
        $row = [
            'document_id' => $documentId,
            'title'       => $title,
            'video_url'   => $url,
            'cover_path'  => $cover,
            'provider'    => $provider === 'direct' ? 'direct' : 'embed',
            'sort'        => 1,
            'status'      => 1,
            'created_at'  => $now,
            'updated_at'  => $now,
        ];
        try {
            WeappVideoItem::where('document_id', $documentId)->delete();
            WeappVideoItem::insert($row);

            return true;
        } catch (\Throwable) {
            return false;
        }
    }
}
