<?php
declare(strict_types=1);

namespace weapp\doc_vod\service\parser;


use weapp\doc_vod\service\VideoConfigService;
use weapp\doc_vod\service\VideoHttpClient;
use app\common\service\weapp\WeappSupportGateway;

/** B 站番剧/课堂合集批量导入 */
class BilibiliBangumiVideoLinkDriver implements VideoLinkParserDriverInterface
{
    public function supports(string $url): bool
    {
        return (bool) preg_match('#bilibili\.com/(?:bangumi|cheese)/play/(ss\d+)#i', $url);
    }

    public function match(string $url): ?array
    {
        return null;
    }

    /**
     * @return mixed
     */
    public function parseCollection(string $url, string $rawContext = '')
    {
        if (!VideoConfigService::isPlatformEnabled('bilibili')) {
            return app(WeappSupportGateway::class)->resultFail('哔哩哔哩解析已在后台关闭');
        }
        if (!preg_match('#/(?:bangumi|cheese)/play/(ss(\d+))#i', $url, $m)) {
            return app(WeappSupportGateway::class)->resultFail('无法识别番剧 season_id');
        }
        $seasonId = (int) $m[1];
        $apiUrl   = 'https://api.bilibili.com/pgc/view/web/season?season_id=' . $seasonId;
        $body     = VideoHttpClient::get($apiUrl, VideoConfigService::platformCookie('bilibili'));
        $data     = json_decode($body, true);
        if (!is_array($data) || (int) ($data['code'] ?? -1) !== 0) {
            return app(WeappSupportGateway::class)->resultFail('番剧元数据拉取失败，请检查 Cookie 或改用单集 BV 链接');
        }
        $result = is_array($data['result'] ?? null) ? $data['result'] : [];
        $title  = trim((string) ($result['title'] ?? ''));
        if ($title === '' && $rawContext !== '') {
            foreach (preg_split('/\r\n|\n/', $rawContext) ?: [] as $line) {
                $line = trim((string) $line);
                if ($line !== '' && !preg_match('#^https?://#i', $line) && mb_strlen($line) <= 120) {
                    $title = $line;
                    break;
                }
            }
        }
        $episodes = [];
        $epNo     = 0;
        foreach ($result['episodes'] ?? [] as $ep) {
            if (!is_array($ep)) {
                continue;
            }
            $bvid = trim((string) ($ep['bvid'] ?? ''));
            $aid  = (int) ($ep['aid'] ?? 0);
            $cid  = (int) ($ep['cid'] ?? 0);
            $play = $bvid !== ''
                ? 'https://www.bilibili.com/video/' . $bvid
                : ($aid > 0 && $cid > 0
                    ? 'https://www.bilibili.com/video/av' . $aid
                    : '');
            if ($play === '') {
                continue;
            }
            $epNo++;
            $episodes[] = [
                'title'       => trim((string) ($ep['long_title'] ?? $ep['title'] ?? ('第' . $epNo . '集'))),
                'ep_no'       => $epNo,
                'play_url'    => $play,
                'provider'    => 'embed',
                'access_mode' => '',
                'price'       => 0,
                'status'      => 1,
            ];
        }
        if ($episodes === []) {
            foreach ($result['section'] ?? [] as $section) {
                if (!is_array($section)) {
                    continue;
                }
                foreach ($section['episodes'] ?? [] as $ep) {
                    if (!is_array($ep)) {
                        continue;
                    }
                    $bvid = trim((string) ($ep['bvid'] ?? ''));
                    if ($bvid === '') {
                        continue;
                    }
                    $epNo++;
                    $episodes[] = [
                        'title'       => trim((string) ($ep['long_title'] ?? $ep['title'] ?? ('第' . $epNo . '集'))),
                        'ep_no'       => $epNo,
                        'play_url'    => 'https://www.bilibili.com/video/' . $bvid,
                        'provider'    => 'embed',
                        'access_mode' => '',
                        'price'       => 0,
                        'status'      => 1,
                    ];
                }
            }
        }
        if ($episodes === []) {
            return app(WeappSupportGateway::class)->resultFail('未解析到分集列表');
        }

        return app(WeappSupportGateway::class)->resultOk(['mode' => 'vod_bangumi', 'platform' => 'bilibili', 'title' => $title !== '' ? $title : '哔哩哔哩番剧', 'episodes' => $episodes], '');
    }
}
