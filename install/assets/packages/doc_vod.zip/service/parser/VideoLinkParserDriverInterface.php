<?php
declare(strict_types=1);

namespace weapp\doc_vod\service\parser;

interface VideoLinkParserDriverInterface
{
    public function supports(string $url): bool;

    /**
     * @return array{platform:string,provider:string,play_url:string}|null
     */
    public function match(string $url): ?array;
}
