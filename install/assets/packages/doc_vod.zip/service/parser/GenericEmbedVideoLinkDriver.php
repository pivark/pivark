<?php
declare(strict_types=1);

namespace weapp\doc_vod\service\parser;

/** 腾讯/优酷/爱奇艺/芒果/AcFun 等 embed 页 */
class GenericEmbedVideoLinkDriver implements VideoLinkParserDriverInterface
{
    public function supports(string $url): bool
    {
        return $this->match($url) !== null;
    }

    public function match(string $url): ?array
    {
        if (preg_match('#v\.qq\.com/x/cover/[\w]+/(\w+)\.html#i', $url)) {
            return ['platform' => 'qq', 'provider' => 'embed', 'play_url' => $url];
        }
        if (preg_match('#v\.qq\.com/x/page/[\w/]+#i', $url)) {
            return ['platform' => 'qq', 'provider' => 'embed', 'play_url' => $url];
        }
        if (preg_match('#youku\.com/v_show/id_([\w=]+)#i', $url)) {
            return ['platform' => 'youku', 'provider' => 'embed', 'play_url' => $url];
        }
        if (preg_match('#iqiyi\.com/v_|iqiyi\.com/a_#i', $url)) {
            return ['platform' => 'iqiyi', 'provider' => 'embed', 'play_url' => $url];
        }
        if (preg_match('#mgtv\.com/b/[\w/]+#i', $url)) {
            return ['platform' => 'mgtv', 'provider' => 'embed', 'play_url' => $url];
        }
        if (preg_match('#acfun\.cn/v/ac#i', $url)) {
            return ['platform' => 'acfun', 'provider' => 'embed', 'play_url' => $url];
        }

        return null;
    }
}
