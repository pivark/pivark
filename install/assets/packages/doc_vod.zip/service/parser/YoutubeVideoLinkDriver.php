<?php
declare(strict_types=1);

namespace weapp\doc_vod\service\parser;

class YoutubeVideoLinkDriver implements VideoLinkParserDriverInterface
{
    public function supports(string $url): bool
    {
        return (bool) preg_match('#(youtube\.com|youtu\.be)#i', $url);
    }

    public function match(string $url): ?array
    {
        if (preg_match('#(?:youtube\.com/watch\?v=|youtu\.be/)([\w-]+)#i', $url, $m)) {
            return [
                'platform' => 'youtube',
                'provider' => 'embed',
                'play_url' => 'https://www.youtube.com/watch?v=' . $m[1],
            ];
        }

        return null;
    }
}
