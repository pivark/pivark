<?php
declare(strict_types=1);

namespace weapp\doc_vod\service\parser;

class BilibiliVideoLinkDriver implements VideoLinkParserDriverInterface
{
    public function supports(string $url): bool
    {
        return (bool) preg_match('#bilibili\.com#i', $url);
    }

    public function match(string $url): ?array
    {
        if (preg_match('#bilibili\.com/video/(BV[\w]+)#i', $url, $m)) {
            return [
                'platform' => 'bilibili',
                'provider' => 'embed',
                'play_url' => 'https://www.bilibili.com/video/' . $m[1],
            ];
        }

        return null;
    }
}
