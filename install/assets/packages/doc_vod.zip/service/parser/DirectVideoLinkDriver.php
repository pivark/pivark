<?php
declare(strict_types=1);

namespace weapp\doc_vod\service\parser;

class DirectVideoLinkDriver implements VideoLinkParserDriverInterface
{
    public function supports(string $url): bool
    {
        return (bool) preg_match('#\.(m3u8|mp4|webm|mov)(\?|$)#i', $url);
    }

    public function match(string $url): ?array
    {
        if ($this->supports($url)) {
            return [
                'platform' => 'direct',
                'provider' => 'remote_url',
                'play_url' => $url,
            ];
        }

        return null;
    }
}
