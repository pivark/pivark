<?php
declare(strict_types=1);

namespace weapp\doc_vod\service;

use think\db\Query;
use app\common\service\weapp\WeappMemberGateway;
use app\common\service\weapp\WeappPaymentGateway;

/** 会员消费 · doc_vod 付费订单（内核 PaymentOrder · scene 过滤） */
final class VideoMemberConsumptionHelper
{
    public const PAID_BIZ_TYPE = 'doc_vod_paid';

    /** @var list<string> */
    private const PAY_SCENES = [VideoPaymentScenes::EPISODE, VideoPaymentScenes::SERIES];

    public static function unionPayOrderPart(int $branchLimit, string $bizTypeFilter = ''): string
    {
        if ($bizTypeFilter !== '' && $bizTypeFilter !== self::PAID_BIZ_TYPE) {
            return '';
        }

        return app(WeappPaymentGateway::class)->payOrderUnionSqlPart(self::PAY_SCENES, self::PAID_BIZ_TYPE, $branchLimit);
    }

    public static function countPayOrders(int $userId, string $keyword, string $bizTypeFilter = ''): int
    {
        if ($bizTypeFilter !== '' && $bizTypeFilter !== self::PAID_BIZ_TYPE) {
            return 0;
        }

        return app(WeappPaymentGateway::class)->payOrderCountForMember(
            $userId,
            $keyword,
            self::PAY_SCENES,
            [self::class, 'applyUserScope'],
            [self::class, 'applyKeyword'],
        );
    }

    /**
     * @return list<array<string, mixed>>
     */
    public static function fetchPayOrderRows(int $userId, string $keyword, string $bizTypeFilter = ''): array
    {
        if ($bizTypeFilter !== '' && $bizTypeFilter !== self::PAID_BIZ_TYPE) {
            return [];
        }

        return app(WeappPaymentGateway::class)->payOrderRowsForMember(
            $userId,
            $keyword,
            self::PAY_SCENES,
            self::PAID_BIZ_TYPE,
            [self::class, 'applyUserScope'],
            [self::class, 'applyKeyword'],
        );
    }

    public static function applyUserScope(Query $query, int $userId, string $userIdField): void
    {
        if ($userId > 0) {
            $query->where($userIdField, $userId);
        }
    }

    public static function applyKeyword(Query $query, string $keyword, string $userIdField): void
    {
        if ($keyword === '') {
            return;
        }
        if (ctype_digit($keyword)) {
            $query->where($userIdField, (int) $keyword);

            return;
        }
        $like    = '%' . addcslashes($keyword, '%_\\') . '%';
        $userIds = app(WeappMemberGateway::class)->memberUserIdsByUsernameNicknameLike($like);
        if ($userIds !== []) {
            $query->whereIn($userIdField, $userIds);
        } else {
            $query->where($userIdField, 0);
        }
    }
}
