<?php
declare(strict_types=1);

namespace weapp\doc_vod\service;



use weapp\doc_vod\service\parser\BilibiliBangumiVideoLinkDriver;
use weapp\doc_vod\service\parser\BilibiliVideoLinkDriver;
use weapp\doc_vod\service\parser\DirectVideoLinkDriver;
use weapp\doc_vod\service\parser\GenericEmbedVideoLinkDriver;
use weapp\doc_vod\service\parser\VideoLinkParserDriverInterface;
use weapp\doc_vod\service\parser\YoutubeVideoLinkDriver;
use app\common\service\weapp\WeappContentGateway;
use app\common\service\weapp\WeappSupportGateway;

/**
 * 视频链接解析（仅插件内维护，常改平台规则）
 */
class VideoLinkParserService
{
    /** @var list<VideoLinkParserDriverInterface>|null */
    private static ?array $drivers = null;

    /**
     * @return array{
     *   code:int,
     *   msg:string,
     *   mode?:string,
     *   platform?:string,
     *   title?:string,
     *   play_url?:string,
     *   provider?:string,
     *   episodes?:list<array<string,mixed>>
     * }
     */
    public static function parse(string $url, string $rawContext = '')
    {
        $t0  = microtime(true);
        $url = trim($url);
        if ($url === '' || !app(WeappContentGateway::class)->contentClipboardIsFetchableUrl($url)) {
            return self::finishParse('', $url, app(WeappSupportGateway::class)->resultFail('链接无效'), $t0);
        }

        $bangumi = new BilibiliBangumiVideoLinkDriver();
        if ($bangumi->supports($url)) {
            return self::finishParse('bilibili_bangumi', $url, $bangumi->parseCollection($url, $rawContext), $t0);
        }

        $title = self::titleFromContext($rawContext, $url);
        $match = self::matchUrl($url);
        if ($match === null) {
            return self::finishParse('', $url, app(WeappSupportGateway::class)->resultFail('暂不支持该视频站链接格式'), $t0);
        }

        if ($title === '') {
            $title = self::titleFromRemoteInsight($url, $rawContext) ?: self::defaultTitle($match);
        }

        $episode = [
            'title'       => $title,
            'ep_no'       => 1,
            'play_url'    => (string) ($match['play_url'] ?? $url),
            'provider'    => (string) ($match['provider'] ?? 'embed'),
            'access_mode' => '',
            'price'       => 0,
            'status'      => 1,
        ];

        return self::finishParse(
            (string) ($match['platform'] ?? ''),
            $url,
            app(WeappSupportGateway::class)->resultOk([
                'mode'     => 'vod_single',
                'platform' => (string) ($match['platform'] ?? ''),
                'title'    => $title,
                'play_url' => (string) ($match['play_url'] ?? $url),
                'provider' => (string) ($match['provider'] ?? 'embed'),
                'episodes' => [$episode],
            ]),
            $t0
        );
    }

    /**
     * @return mixed
     */
    private static function finishParse(string $platform, string $url, ServiceResult $res, float $t0)
    {
        $ms = (int) round((microtime(true) - $t0) * 1000);
        VideoParseLogService::log(
            $platform !== '' ? $platform : (string) ($res['platform'] ?? 'unknown'),
            $url,
            $res->isOk(),
            (string) ($res->message() ?? ''),
            $ms
        );

        return $res;
    }

    /**
     * @return mixed
     */
    public static function parseBatch(string $raw)
    {
        $lines = preg_split('/\r\n|\n/', $raw) ?: [];
        $episodes = [];
        $errors   = [];
        $epNo     = 0;
        foreach ($lines as $line) {
            $line = trim((string) $line);
            if ($line === '' || !preg_match('#^https?://#i', $line)) {
                continue;
            }
            $res = self::parse($line, $raw);
            if (!$res->isOk()) {
                $errors[] = $line . ': ' . (string) ($res->message() ?? '失败');
                continue;
            }
            foreach ($res['episodes'] ?? [] as $ep) {
                if (!is_array($ep)) {
                    continue;
                }
                $epNo++;
                $ep['ep_no'] = $epNo;
                $episodes[] = $ep;
            }
        }
        if ($episodes === []) {
            return app(WeappSupportGateway::class)->resultFail('未解析到有效视频链接');
        }

        return app(WeappSupportGateway::class)->resultOk(['mode' => 'vod_batch', 'episodes' => $episodes, 'errors' => $errors], '');
    }

    /**
     * @return array{platform:string,provider:string,play_url:string}|null
     */
    private static function matchUrl(string $url): ?array
    {
        foreach (self::drivers() as $driver) {
            if (!$driver->supports($url)) {
                continue;
            }
            $m = $driver->match($url);
            if ($m === null) {
                continue;
            }
            $platform = (string) ($m['platform'] ?? '');
            if ($platform !== '' && !VideoConfigService::isPlatformEnabled($platform)) {
                continue;
            }

            return $m;
        }

        return null;
    }

    /** @return list<VideoLinkParserDriverInterface> */
    private static function drivers(): array
    {
        if (self::$drivers !== null) {
            return self::$drivers;
        }
        self::$drivers = [
            new BilibiliVideoLinkDriver(),
            new YoutubeVideoLinkDriver(),
            new GenericEmbedVideoLinkDriver(),
            new DirectVideoLinkDriver(),
        ];

        return self::$drivers;
    }

    private static function titleFromContext(string $raw, string $url): string
    {
        $raw = trim($raw);
        if ($raw === '') {
            return '';
        }
        foreach (preg_split('/\r\n|\n/', $raw) ?: [] as $line) {
            $line = trim((string) $line);
            if ($line === '' || str_contains($line, $url)) {
                continue;
            }
            if (preg_match('/^https?:\/\//i', $line)) {
                continue;
            }
            if (mb_strlen($line) >= 2 && mb_strlen($line) <= 120) {
                return $line;
            }
        }

        return '';
    }

    private static function titleFromRemoteInsight(string $url, string $raw): string
    {
        $res = app(WeappContentGateway::class)->contentClipboardAnalyze($url, $raw);
        if (!$res->isOk()) {
            return '';
        }
        $data = is_array($res->dataArray() ?? null) ? $res->dataArray() : [];

        return trim((string) ($data['title'] ?? ''));
    }

    /** @param array<string, string> $match */
    private static function defaultTitle(array $match): string
    {
        $platform = (string) ($match['platform'] ?? '');
        $labels   = [
            'bilibili' => '哔哩哔哩视频',
            'youtube'  => 'YouTube 视频',
            'qq'       => '腾讯视频',
            'youku'    => '优酷视频',
            'iqiyi'    => '爱奇艺视频',
            'mgtv'     => '芒果TV',
            'acfun'    => 'AcFun',
            'direct'   => '视频',
        ];

        return $labels[$platform] ?? '在线视频';
    }
}
