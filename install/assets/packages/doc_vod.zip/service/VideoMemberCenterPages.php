<?php
declare(strict_types=1);

namespace weapp\doc_vod\service;

use think\facade\Request;
use think\Response;
use app\common\service\weapp\WeappEntitlementGateway;
use app\common\service\weapp\WeappMemberGateway;

/** 会员中心 video 页面（member.center.page） */
final class VideoMemberCenterPages
{
    public static function register(): void
    {
        app(WeappMemberGateway::class)->memberCenterPageRegister(
            'doc_vod',
            'viewing',
            [self::class, 'viewing'],
            'viewing',
            null,
            '我的观影',
        );
    }

    /**
     * @param array{
     *   member: array<string,mixed>,
     *   render: callable(string,string,string,string,array=): Response,
     *   redirect_unavailable: callable(string): Response
     * } $host
     */
    public static function viewing(array $host): Response
    {
        if (!app(WeappEntitlementGateway::class)->entitlementCan('doc_vod')) {
            return ($host['redirect_unavailable'])('我的观影');
        }
        VideoService::ensureAutoload();
        $member = $host['member'];
        $page   = max(1, (int) Request::get('page', 1));
        $limit  = 20;
        $grantResult = VideoPurchaseService::listGrantsForMember((int) $member['id'], $page, $limit);
        $result = $grantResult->isOk()
            ? $grantResult->dataArray()
            : ['list' => [], 'total' => 0];
        $progress = VideoWatchProgressService::listForMember((int) $member['id'], 10);

        return ($host['render'])('member/viewing', 'viewing', '我的观影', 'viewing', [
            'viewing_list'   => $result['list'],
            'continue_list'  => $progress,
            'continue_empty' => $progress === [] ? 1 : 0,
            'ledger_total'   => (int) $result['total'],
            'ledger_page'    => $page,
            'ledger_limit'   => $limit,
            'ledger_pages'   => max(1, (int) ceil(((int) $result['total']) / $limit)),
            'ledger_empty'   => ($result['list'] ?? []) === [] ? 1 : 0,
        ]);
    }
}
