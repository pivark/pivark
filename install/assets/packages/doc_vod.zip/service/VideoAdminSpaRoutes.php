<?php
declare(strict_types=1);

namespace weapp\doc_vod\service;

use app\common\service\weapp\WeappAdminGateway;

final class VideoAdminSpaRoutes
{
    public static function register(): void
    {
        $gw = app(WeappAdminGateway::class);
        $id = 'doc_vod';

        $gw->adminSpaHostRegisterPluginPage($id,
            'settings',
            'WeappVideoSettings',
            ['title' => '基础设置'],
        );
        $gw->adminSpaHostRegisterPluginPage($id,
            'series',
            'WeappVideoSeries',
            ['title' => '点播剧集'],
        );
        $gw->adminSpaHostRegisterPluginPage($id,
            'stats',
            'WeappVideoStats',
            ['title' => '运营统计'],
        );
        $gw->adminSpaHostRegisterPluginPage($id,
            'list',
            'WeappVideoList',
            [
                'title'               => '嵌入条目',
                'pivarkWeapp'         => $id,
                'pivarkEmbedListHint' => '视频嵌入条目在「内容 → 文档」编辑器内的视频插件面板中维护；此列表用于查看与启停、删除已挂载条目。',
                'api'                 => '/weapp/doc_vod/list',
                'delete'              => '/weapp/doc_vod/delete',
                'status'              => '/weapp/doc_vod/status',
            ],
            null,
            '/pivark/dynamic/list',
        );

        foreach (['usage' => ['WeappVideoUsage', '前台调用说明', '/weapp/usage/index'], 'guide' => ['WeappVideoGuide', '功能介绍', '/weapp/guide/index']] as $seg => [$name, $title, $component]) {
            $path = $gw->adminSpaHostPath($id, $seg);
            $gw->adminSpaExplicitRouteRegister($path, [
                'name'      => $name,
                'path'      => $path,
                'component' => $component,
                'meta'      => ['pivarkWeapp' => $id, 'title' => $title],
            ]);
        }

        $gw->adminSpaRouteIconRegister($gw->adminSpaHostPath($id, 'settings'), 'lucide:clapperboard');
        $gw->adminSpaRouteIconRegister($gw->adminSpaHostPath($id, 'series'), 'lucide:clapperboard');
        $gw->adminSpaRouteIconRegister($gw->adminSpaHostPath($id, 'list'), 'lucide:list');
        $gw->adminWeappNavTabsRegister($id, [
            $gw->adminWeappNavTab('settings', '基础设置', 'settings'),
            $gw->adminWeappNavTab('series', '点播剧集', 'series'),
            $gw->adminWeappNavTab('list', '嵌入条目', 'list'),
        ]);
    }
}
