<?php
declare(strict_types=1);

namespace weapp\doc_vod\service;


use app\common\service\weapp\WeappConfigGateway;
use app\common\service\weapp\WeappPluginGateway;
use app\common\service\weapp\WeappSupportGateway;
/** 文档视频 全局配置（站点键前缀 doc_vod_*） */
class VideoConfigService
{
    public const PLATFORM_KEYS = [
        'bilibili',
        'youtube',
        'qq',
        'youku',
        'iqiyi',
        'mgtv',
        'acfun',
        'direct',
    ];

    /** @return list<string> */
    public static function keys(): array
    {
        $keys = [
            'doc_vod_open',
            'doc_vod_document_editor_slot',
            'doc_vod_film_level_id',
            'doc_vod_parse_api_url',
            'doc_vod_platforms_json',
            'doc_vod_series_channel_open',
            'doc_vod_plaza_open',
            'doc_vod_play_cache_sec',
            'doc_vod_hls_proxy_open',
            'doc_vod_hls_proxy_domains',
            'doc_vod_auto_next_sec',
        ];
        foreach (self::PLATFORM_KEYS as $p) {
            $keys[] = 'doc_vod_cookie_' . $p;
        }

        return $keys;
    }

    /** @return array<string, string> */
    public static function all(): array
    {
        $out = [];
        foreach (self::keys() as $key) {
            $out[$key] = self::read($key, self::defaultFor($key));
        }
        $out['doc_vod_document_editor_slot'] = app(WeappPluginGateway::class)->pluginEditorResolveSlot('doc_vod');
        if ($out['doc_vod_platforms_json'] === '') {
            $out['doc_vod_platforms_json'] = self::defaultPlatformsJson();
        }

        return $out;
    }

    public static function defaultFor(string $key): string
    {
        if (str_starts_with($key, 'doc_vod_cookie_')) {
            return '';
        }
        if ($key === 'doc_vod_platforms_json') {
            return self::defaultPlatformsJson();
        }

        return match ($key) {
            'doc_vod_open' => '1',
            'doc_vod_document_editor_slot' => app(WeappPluginGateway::class)->pluginEditorManifestDefaultSlot('doc_vod'),
            'doc_vod_film_level_id' => '0',
            'doc_vod_parse_api_url' => '',
            'doc_vod_series_channel_open' => '1',
            'doc_vod_plaza_open'          => '1',
            'doc_vod_play_cache_sec' => '12',
            'doc_vod_hls_proxy_open' => '0',
            'doc_vod_hls_proxy_domains' => '',
            'doc_vod_auto_next_sec' => '8',
            default => '',
        };
    }

    public static function defaultPlatformsJson(): string
    {
        $map = [];
        foreach (self::PLATFORM_KEYS as $p) {
            $map[$p] = 1;
        }

        return json_encode($map, JSON_UNESCAPED_UNICODE) ?: '{}';
    }

    /** @return array<string, int> */
    public static function platformsEnabled(): array
    {
        $raw = self::read('doc_vod_platforms_json', self::defaultPlatformsJson());
        $data = json_decode($raw, true);
        if (!is_array($data)) {
            $data = json_decode(self::defaultPlatformsJson(), true) ?: [];
        }
        $out = [];
        foreach (self::PLATFORM_KEYS as $p) {
            $out[$p] = !empty($data[$p]) ? 1 : 0;
        }

        return $out;
    }

    public static function isPlatformEnabled(string $platform): bool
    {
        $platform = strtolower(trim($platform));
        $map      = self::platformsEnabled();

        return ($map[$platform] ?? 1) === 1;
    }

    public static function platformCookie(string $platform): string
    {
        $platform = strtolower(trim($platform));

        return trim(self::read('doc_vod_cookie_' . $platform, ''));
    }

    public static function isOpen(): bool
    {
        return self::read('doc_vod_open', '1') === '1';
    }

    public static function seriesChannelOpen(): bool
    {
        return self::read('doc_vod_series_channel_open', '1') === '1';
    }

    public static function plazaOpen(): bool
    {
        return self::read('doc_vod_plaza_open', '1') === '1';
    }

    public static function playCacheSec(): int
    {
        return max(0, min(120, (int) self::read('doc_vod_play_cache_sec', '12')));
    }

    public static function autoNextSec(): int
    {
        return max(0, min(30, (int) self::read('doc_vod_auto_next_sec', '8')));
    }

    public static function hlsProxyOpen(): bool
    {
        return self::read('doc_vod_hls_proxy_open', '0') === '1';
    }

    /** @return list<string> */
    public static function hlsProxyDomains(): array
    {
        $raw = trim(self::read('doc_vod_hls_proxy_domains', ''));
        if ($raw === '') {
            return [];
        }
        $out = [];
        foreach (preg_split('/\r\n|\n|,/', $raw) ?: [] as $line) {
            $line = strtolower(trim((string) $line));
            if ($line !== '') {
                $out[] = $line;
            }
        }

        return $out;
    }

    public static function filmLevelId(): int
    {
        return max(0, (int) self::read('doc_vod_film_level_id', '0'));
    }

    public static function parseApiUrl(): string
    {
        $urls = self::parseApiUrls();

        return $urls[0] ?? '';
    }

    /** @return list<string> */
    public static function parseApiUrls(): array
    {
        $raw = trim(self::read('doc_vod_parse_api_url', ''));
        if ($raw === '') {
            return [];
        }
        $out = [];
        foreach (preg_split('/\r\n|\n/', $raw) ?: [] as $line) {
            $line = trim((string) $line);
            if ($line !== '') {
                $out[] = $line;
            }
        }

        return $out;
    }

    /** @param array<string, mixed> $post @return mixed */
    public static function saveAdmin(array $post)
    {
        app(WeappConfigGateway::class)->configSet('doc_vod_open', !empty($post['doc_vod_open']) ? '1' : '0');
        if (array_key_exists('doc_vod_series_channel_open', $post)) {
            app(WeappConfigGateway::class)->configSet(
                'doc_vod_series_channel_open',
                !empty($post['doc_vod_series_channel_open']) ? '1' : '0',
            );
        }
        if (array_key_exists('doc_vod_plaza_open', $post)) {
            app(WeappConfigGateway::class)->configSet(
                'doc_vod_plaza_open',
                !empty($post['doc_vod_plaza_open']) ? '1' : '0',
            );
        }
        if (array_key_exists('doc_vod_play_cache_sec', $post)) {
            app(WeappConfigGateway::class)->configSet(
                'doc_vod_play_cache_sec',
                (string) max(0, min(120, (int) $post['doc_vod_play_cache_sec'])),
            );
        }
        if (array_key_exists('doc_vod_hls_proxy_open', $post)) {
            app(WeappConfigGateway::class)->configSet(
                'doc_vod_hls_proxy_open',
                !empty($post['doc_vod_hls_proxy_open']) ? '1' : '0',
            );
        }
        if (array_key_exists('doc_vod_hls_proxy_domains', $post)) {
            app(WeappConfigGateway::class)->configSet(
                'doc_vod_hls_proxy_domains',
                trim((string) $post['doc_vod_hls_proxy_domains']),
            );
        }
        if (array_key_exists('doc_vod_auto_next_sec', $post)) {
            app(WeappConfigGateway::class)->configSet(
                'doc_vod_auto_next_sec',
                (string) max(0, min(30, (int) $post['doc_vod_auto_next_sec'])),
            );
        }
        if (array_key_exists('doc_vod_film_level_id', $post)) {
            app(WeappConfigGateway::class)->configSet(
                'doc_vod_film_level_id',
                (string) max(0, (int) $post['doc_vod_film_level_id']),
            );
        }
        if (array_key_exists('doc_vod_parse_api_url', $post)) {
            app(WeappConfigGateway::class)->configSet(
                'doc_vod_parse_api_url',
                trim((string) $post['doc_vod_parse_api_url']),
            );
        }
        if (array_key_exists('doc_vod_platforms_json', $post)) {
            $raw = $post['doc_vod_platforms_json'];
            if (is_array($raw)) {
                $raw = json_encode($raw, JSON_UNESCAPED_UNICODE);
            }
            app(WeappConfigGateway::class)->configSet(
                'doc_vod_platforms_json',
                trim((string) $raw) ?: self::defaultPlatformsJson(),
            );
        }
        foreach (self::PLATFORM_KEYS as $p) {
            $ck = 'doc_vod_cookie_' . $p;
            if (array_key_exists($ck, $post)) {
                app(WeappConfigGateway::class)->configSet($ck, trim((string) $post[$ck]));
            }
        }
        if (array_key_exists('doc_vod_document_editor_slot', $post)) {
            $slotRes = app(WeappPluginGateway::class)->pluginEditorSaveSiteSlot(
                'doc_vod',
                (string) ($post['doc_vod_document_editor_slot'] ?? ''),
            );
            if (!$slotRes->isOk()) {
                return $slotRes;
            }
        }

        app(WeappPluginGateway::class)->pluginAfterConfigSaved('documents');

        return app(WeappSupportGateway::class)->resultOk(null, '保存成功');
    }

    private static function read(string $key, string $default = ''): string
    {
        $value = trim((string) app(WeappConfigGateway::class)->configGet($key, ''));

        return $value !== '' ? $value : $default;
    }
}
