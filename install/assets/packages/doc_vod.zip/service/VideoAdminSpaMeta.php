<?php
declare(strict_types=1);

namespace weapp\doc_vod\service;


use app\common\service\weapp\WeappPluginGateway;
use app\common\service\weapp\WeappMemberGateway;
final class VideoAdminSpaMeta
{
    /** @param array<string, mixed> $ctx @return array<string, mixed> */
    public static function build(array $ctx): array
    {
        VideoService::ensureAutoload();

        $stats = VideoStatsService::overviewAdmin();
        
        return [
            'cfg'          => VideoConfigService::all(),
            'stats'        => is_array($stats['items'] ?? null) ? $stats['items'] : ['total' => 0, 'enabled' => 0],
            'vodStats'     => is_array($stats['vod'] ?? null) ? $stats['vod'] : [],
            'platforms'    => VideoConfigService::platformsEnabled(),
            'platformKeys' => VideoConfigService::PLATFORM_KEYS,
            'memberLevels' => app(WeappMemberGateway::class)->memberLevelsActive(),
            'slotCards'    => app(WeappPluginGateway::class)->pluginEditorSurfaceSlotCards('doc_vod'),
            'editorSlot'   => app(WeappPluginGateway::class)->pluginEditorResolveSlot('doc_vod'),
            'plugin'       => app(WeappPluginGateway::class)->pluginPresentationForAdmin('doc_vod'),
        ];
    }
}
