<?php
declare(strict_types=1);

namespace weapp\doc_vod\service;

/** 播放线路类型与前台展示名 */
class VideoSourceCatalog
{
    /** @return array<string, string> */
    public static function providerLabels(): array
    {
        return [
            'bilibili'      => '哔哩哔哩',
            'iqiyi'         => '爱奇艺',
            'youku'         => '优酷',
            'tencent'       => '腾讯视频',
            'youtube'       => 'YouTube',
            'local'         => '本地播放',
            'file'          => '本地文件',
            'remote_url'    => '直链/HLS',
            'parse_url'     => '解析线路',
            'parse_generic' => '解析线路',
            'embed'         => '外链嵌入',
        ];
    }

    /**
     * @param array<string, mixed> $source 库表行或 sources[] 项
     */
    public static function label(array $source): string
    {
        $custom = self::labelFromConfig((string) ($source['config_json'] ?? ''));
        if ($custom !== '') {
            return $custom;
        }
        $provider = strtolower(trim((string) ($source['provider'] ?? '')));
        $map      = self::providerLabels();
        if ($provider !== '' && isset($map[$provider])) {
            return $map[$provider];
        }
        $url = trim((string) ($source['play_url'] ?? ''));
        if ($url !== '') {
            $guess = self::guessFromUrl($url);
            if ($guess !== '') {
                return $guess;
            }
        }

        return $provider !== '' ? $provider : '线路';
    }

    public static function labelFromConfig(string $json): string
    {
        if ($json === '') {
            return '';
        }
        $data = json_decode($json, true);

        return is_array($data) ? trim((string) ($data['label'] ?? '')) : '';
    }

    /** @return array{label:string} */
    public static function configWithLabel(string $label): string
    {
        $label = trim($label);

        return $label === '' ? '' : json_encode(['label' => $label], JSON_UNESCAPED_UNICODE);
    }

    /** @param array<string, mixed> $health */
    public static function configWithHealth(string $existingJson, array $health): string
    {
        $data = [];
        if ($existingJson !== '') {
            $decoded = json_decode($existingJson, true);
            if (is_array($decoded)) {
                $data = $decoded;
            }
        }
        $data['health'] = $health;
        if (trim((string) ($data['label'] ?? '')) === '' && self::labelFromConfig($existingJson) !== '') {
            $data['label'] = self::labelFromConfig($existingJson);
        }

        return json_encode($data, JSON_UNESCAPED_UNICODE) ?: '';
    }

    public static function guessFromUrl(string $url): string
    {
        $u = strtolower($url);
        if (str_contains($u, 'bilibili.com') || preg_match('#\bbv[0-9a-zA-Z]+#i', $url)) {
            return '哔哩哔哩';
        }
        if (str_contains($u, 'iqiyi.com') || str_contains($u, 'iq.com')) {
            return '爱奇艺';
        }
        if (str_contains($u, 'youku.com')) {
            return '优酷';
        }
        if (str_contains($u, 'v.qq.com') || str_contains($u, 'qq.com/video')) {
            return '腾讯视频';
        }
        if (preg_match('#^/storage/|^/uploads/#i', $url) || str_contains($u, '/storage/')) {
            return '本地播放';
        }
        if (preg_match('#\.(m3u8)(\?|$)#i', $url)) {
            return 'HLS 流';
        }
        if (preg_match('#\.(mp4|webm|mov)(\?|$)#i', $url)) {
            return 'MP4 直链';
        }

        return '';
    }
}
