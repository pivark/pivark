<?php
declare(strict_types=1);

namespace weapp\doc_vod\service;

use think\Response;
use app\common\service\weapp\WeappPluginGateway;

/** 可选：同源 HLS 代理（租户 CDN/CORS 受限时） */
class VideoStreamProxyService
{
    public static function boot(): void
    {
        if (!VideoConfigService::hlsProxyOpen()) {
            return;
        }
        app(WeappPluginGateway::class)->pluginRouteRegister(
            'get',
            'api/v1/plugins/doc_vod/hls-proxy',
            '\\weapp\\doc_vod\\api\\controller\\Video@hlsProxy'
        );
    }

    public static function proxyResponse(string $rawUrl): Response
    {
        if (!VideoConfigService::hlsProxyOpen()) {
            return response('proxy disabled', 403);
        }
        $url = trim($rawUrl);
        if ($url === '' || !preg_match('#^https?://#i', $url)) {
            return response('invalid url', 400);
        }
        if (!self::urlAllowed($url)) {
            return response('domain not allowed', 403);
        }
        $path = strtolower(parse_url($url, PHP_URL_PATH) ?: '');
        if (!str_ends_with($path, '.m3u8') && !str_contains($path, '.m3u8')) {
            return response('only m3u8', 400);
        }
        $ch = curl_init($url);
        if ($ch === false) {
            return response('curl error', 502);
        }
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => false,
            CURLOPT_TIMEOUT        => 30,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_USERAGENT      => 'Pivark-HLS-Proxy/1.0',
        ]);
        $body = curl_exec($ch);
        $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        if (!is_string($body) || $body === '' || $code < 200 || $code >= 400) {
            return response('upstream error', 502);
        }

        return response($body, 200, [
            'Content-Type'  => 'application/vnd.apple.mpegurl; charset=utf-8',
            'Cache-Control' => 'private, max-age=60',
        ]);
    }

    public static function proxiedUrl(string $absoluteUrl): string
    {
        if (!VideoConfigService::hlsProxyOpen() || !self::urlAllowed($absoluteUrl)) {
            return $absoluteUrl;
        }

        return '/api/v1/plugins/doc_vod/hls-proxy?url=' . rawurlencode($absoluteUrl);
    }

    private static function urlAllowed(string $url): bool
    {
        $parsed = parse_url($url);
        if (!is_array($parsed) || !isset($parsed['host'], $parsed['scheme'])) {
            return false;
        }
        if (!in_array(strtolower((string) $parsed['scheme']), ['http', 'https'], true)) {
            return false;
        }
        if (isset($parsed['user']) || isset($parsed['pass'])) {
            return false;
        }
        $host = strtolower((string) $parsed['host']);
        if ($host === '') {
            return false;
        }
        foreach (VideoConfigService::hlsProxyDomains() as $allowed) {
            if ($host === $allowed || str_ends_with($host, '.' . $allowed)) {
                return true;
            }
        }

        return false;
    }
}
