<?php
declare(strict_types=1);

namespace weapp\doc_vod\service;

/**
 * 常维护解析平台（改规则只动对应 Driver + 本表样本 URL）
 */
class VideoParserCatalog
{
    /** @return list<array{key:string,label:string,sample_url:string,driver:string,notes:string,maintained:int}> */
    public static function maintainedPlatforms(): array
    {
        return [
            [
                'key'        => 'bilibili',
                'label'      => '哔哩哔哩单集 (BV)',
                'sample_url' => 'https://www.bilibili.com/video/BV1GJ411x7h7',
                'driver'     => 'BilibiliVideoLinkDriver',
                'notes'      => '高频改 BV 规则；embed 播放',
                'maintained' => 1,
            ],
            [
                'key'        => 'bilibili_bangumi',
                'label'      => '哔哩哔哩番剧/课堂',
                'sample_url' => 'https://www.bilibili.com/bangumi/play/ss25617',
                'driver'     => 'BilibiliBangumiVideoLinkDriver',
                'notes'      => '依赖 API+Cookie；批量分集',
                'maintained' => 1,
            ],
            [
                'key'        => 'youtube',
                'label'      => 'YouTube',
                'sample_url' => 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
                'driver'     => 'YoutubeVideoLinkDriver',
                'notes'      => 'youtu.be / watch?v=',
                'maintained' => 1,
            ],
            [
                'key'        => 'qq',
                'label'      => '腾讯视频',
                'sample_url' => 'https://v.qq.com/x/cover/m441e3rjq9kwpsc9/t0016a5q8a2.html',
                'driver'     => 'GenericEmbedVideoLinkDriver',
                'notes'      => 'embed 页；直链需外置解析',
                'maintained' => 1,
            ],
            [
                'key'        => 'youku',
                'label'      => '优酷',
                'sample_url' => 'https://v.youku.com/v_show/id_XNTExODMyNjM2.html',
                'driver'     => 'GenericEmbedVideoLinkDriver',
                'notes'      => 'v_show 链接',
                'maintained' => 1,
            ],
            [
                'key'        => 'iqiyi',
                'label'      => '爱奇艺',
                'sample_url' => 'https://www.iqiyi.com/v_19rrlhplu.html',
                'driver'     => 'GenericEmbedVideoLinkDriver',
                'notes'      => 'embed',
                'maintained' => 1,
            ],
            [
                'key'        => 'direct',
                'label'      => '直链 mp4/m3u8',
                'sample_url' => 'https://example.com/demo.mp4',
                'driver'     => 'DirectVideoLinkDriver',
                'notes'      => '远程/解析站直链',
                'maintained' => 1,
            ],
        ];
    }

    public static function labelForKey(string $key): string
    {
        foreach (self::maintainedPlatforms() as $row) {
            if (($row['key'] ?? '') === $key) {
                return (string) ($row['label'] ?? $key);
            }
        }

        return $key;
    }
}
