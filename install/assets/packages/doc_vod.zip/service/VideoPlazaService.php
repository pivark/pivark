<?php
declare(strict_types=1);

namespace weapp\doc_vod\service;



use weapp\doc_vod\model\WeappVideoSeries;
use think\facade\Db;
use app\common\service\weapp\WeappFrontGateway;
use app\common\service\weapp\WeappPluginGateway;
use app\common\service\weapp\WeappSearchGateway;
use app\common\service\weapp\WeappPaginationGateway;
use app\common\service\weapp\WeappSupportGateway;

/** 剧集广场：前台剧集列表入口 */
class VideoPlazaService
{
    public static function boot(): void
    {
        $gw = app(WeappPluginGateway::class);
        $gw->pluginRouteRegister(
            'get',
            'doc_vod/plaza',
            '\\weapp\\doc_vod\\front\\controller\\Plaza@index',
            [],
            null,
            true,
        );
        // 禁兼容：不再双注册 video/plaza；广场真源路径仅 /doc_vod/plaza
        app(WeappFrontGateway::class)->frontPluginPathRegister('doc_vod', [self::class, 'dispatchPathSegment']);
    }

    public static function dispatchPathSegment(string $segment): ?\think\Response
    {
        if ($segment !== 'plaza') {
            return null;
        }
        VideoService::ensureAutoload();

        return (new \weapp\doc_vod\front\controller\Plaza())->index();
    }

    /**
     * @return mixed
     */
    public static function listPublic(int $page = 1, int $limit = 24, string $sort = 'hot', string $keyword = '')
    {
        if (!VideoService::isActive() || !VideoAccessService::schemaReady()) {
            return app(WeappSupportGateway::class)->resultOk(['total' => 0, 'page' => max(1, $page), 'pages' => 1, 'limit' => $limit, 'list' => []], '');
        }
        $page  = max(1, $page);
        $limit = min(48, max(6, $limit));
        $sort  = strtolower(trim($sort));
        $kw    = trim($keyword);

        $activeEpisodes = static function ($episodeQuery): void {
            $episodeQuery->where('status', 1);
        };
        $query = WeappVideoSeries::where('status', 1)
            ->withCount(['episodes' => $activeEpisodes])
            ->withSum(['episodes' => $activeEpisodes], 'play_count');
        if ($kw !== '') {
            $query->whereLike('title|slug|summary', app(WeappSearchGateway::class)->searchLikePattern($kw));
        }
        if ($sort === 'new') {
            $query->order('id', 'desc');
        } else {
            $query->order('episodes_sum', 'desc')->order('sort', 'asc')->order('id', 'desc');
        }
        $total = (int) (clone $query)->removeOption('order')->count();
        $list  = [];
        foreach ($query->page($page, $limit)->select()->toArray() as $row) {
            if (!is_array($row)) {
                continue;
            }
            $row['ep_count']  = (int) ($row['episodes_count'] ?? 0);
            $row['play_sum']  = (int) ($row['episodes_sum'] ?? 0);
            $slug = trim((string) ($row['slug'] ?? ''));
            $list[] = [
                'id'           => (int) ($row['id'] ?? 0),
                'title'        => (string) ($row['title'] ?? ''),
                'slug'         => $slug,
                'summary'      => self::excerpt((string) ($row['summary'] ?? '')),
                'cover_url'    => VideoService::publicUrl((string) ($row['cover_path'] ?? '')),
                'ep_count'     => (int) ($row['ep_count'] ?? 0),
                'play_sum'     => (int) ($row['play_sum'] ?? 0),
                'access_mode'  => (string) ($row['access_mode'] ?? 'free'),
                'price'        => (string) ($row['price'] ?? '0.00'),
                'channel_url'  => $slug !== '' && VideoConfigService::seriesChannelOpen()
                    ? VideoChannelService::channelUrl($slug)
                    : '',
            ];
        }
        $pages = max(1, (int) ceil($total / $limit));

        return app(WeappSupportGateway::class)->resultOk([
            'list'  => $list,
            'total' => $total,
            'page'  => $page,
            'pages' => $pages,
            'limit' => $limit,
        ], '');
    }

    /**
     * @return mixed
     */
    public static function pageVars(int $page = 1, string $sort = 'hot', string $keyword = '')
    {
        app(WeappFrontGateway::class)->frontAssetRegisterVideoVodStyles();
        if (!VideoConfigService::plazaOpen()) {
            return app(WeappSupportGateway::class)->resultOk(['vars' => [
                'seo_title'       => '剧集广场',
                'page_title'      => '剧集广场',
                'plaza_sort'      => 'hot',
                'plaza_sort_label'=> '最热播放',
                'plaza_keyword'   => '',
                'plaza_list'      => [],
                'plaza_total'     => 0,
                'plaza_page'      => max(1, $page),
                'plaza_pages'     => 1,
                'plaza_empty'     => 1,
            ]], '');
        }
        $res = self::listPublic($page, 24, $sort, $keyword);
        if (!$res->isOk()) {
            return app(WeappSupportGateway::class)->resultFail((string) ($res->message() ?? '加载失败'));
        }
        $sortLabel = match (strtolower(trim($sort))) {
            'new' => '最新上架',
            default => '最热播放',
        };

        $pageNum = (int) ($res['page'] ?? 1);
        $total   = (int) ($res['total'] ?? 0);
        $limit   = (int) ($res['limit'] ?? 24);
        $sortKey = strtolower(trim($sort)) ?: 'hot';
        $kwEnc   = rawurlencode(trim($keyword));
        $query   = static function (int $p) use ($sortKey, $kwEnc): string {
            $q = '/doc_vod/plaza?page=' . $p . '&sort=' . rawurlencode($sortKey);
            if ($kwEnc !== '') {
                $q .= '&q=' . $kwEnc;
            }

            return $q;
        };

        return app(WeappSupportGateway::class)->resultOk(['vars' => array_merge([
                'seo_title'       => '剧集广场 · 在线观看',
                'seo_description' => '浏览全部点播剧集，选集播放、多线路切换',
                'page_title'      => '剧集广场',
                'plaza_sort'      => $sortKey,
                'plaza_sort_label'=> $sortLabel,
                'plaza_keyword'   => trim($keyword),
                'plaza_list'      => $res['list'] ?? [],
                'plaza_total'     => $total,
                'plaza_page'      => $pageNum,
                'plaza_pages'     => (int) ($res['pages'] ?? 1),
                'plaza_empty'     => ($res['list'] ?? []) === [] ? 1 : 0,
            ], app(WeappPaginationGateway::class)->paginationBuild($pageNum, $total, $limit, $query))], '');
    }

    private static function excerpt(string $text, int $max = 120): string
    {
        $text = trim(strip_tags($text));
        if ($text === '') {
            return '';
        }
        if (mb_strlen($text) <= $max) {
            return $text;
        }

        return mb_substr($text, 0, $max) . '…';
    }
}
