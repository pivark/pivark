<?php
declare(strict_types=1);

namespace weapp\doc_vod\service;


use weapp\doc_vod\model\WeappVideoEpisode;
use weapp\doc_vod\model\WeappVideoSource;
use think\facade\Db;
use app\common\service\weapp\WeappDocumentGateway;
use app\common\service\weapp\WeappSupportGateway;

/** 文档绑定的点播单集（发布页 / 文档 Surface） */
class VideoDocumentVodService
{
    /** @return list<array<string, mixed>> */
    public static function listForDocument(int $documentId): array
    {
        if ($documentId < 1 || !VideoAccessService::schemaReady()) {
            return [];
        }
        $out = [];
        foreach (WeappVideoEpisode::with(['series' => static function ($seriesQuery): void {
            $seriesQuery->field('id,title');
        }])
            ->where('document_id', $documentId)
            ->order(['sort' => 'asc', 'ep_no' => 'asc', 'id' => 'asc'])
            ->select() as $model) {
            $row = ModelRelationLoad::mergeBelongsTo($model, 'series', ['title' => 'series_title']);
            $episodeId = (int) ($row['id'] ?? 0);
            $sources   = [];
            foreach (WeappVideoSource::where('episode_id', $episodeId)
                ->where('status', 1)
                ->order('priority', 'desc')
                ->select() as $srcModel) {
                $src = is_object($srcModel) && method_exists($srcModel, 'toArray')
                    ? $srcModel->toArray()
                    : (array) $srcModel;
                $label = '';
                $cfg   = trim((string) ($src['config_json'] ?? ''));
                if ($cfg !== '') {
                    $decoded = json_decode($cfg, true);
                    if (is_array($decoded)) {
                        $label = trim((string) ($decoded['label'] ?? ''));
                    }
                }
                $sources[] = [
                    'id'       => (int) ($src['id'] ?? 0),
                    'provider' => (string) ($src['provider'] ?? 'embed'),
                    'play_url' => (string) ($src['play_url'] ?? ''),
                    'label'    => $label,
                    'priority' => (int) ($src['priority'] ?? 0),
                ];
            }
            $first = $sources[0] ?? null;
            $out[] = [
                'id'                 => $episodeId,
                'series_id'          => (int) ($row['series_id'] ?? 0),
                'series_title'       => (string) ($row['series_title'] ?? ''),
                'document_id'        => $documentId,
                'ep_no'              => (int) ($row['ep_no'] ?? 0),
                'title'              => (string) ($row['title'] ?? ''),
                'cover_path'         => (string) ($row['cover_path'] ?? ''),
                'access_mode'        => (string) ($row['access_mode'] ?? ''),
                'read_level_id'      => (int) ($row['read_level_id'] ?? 0),
                'price'              => (float) ($row['price'] ?? 0),
                'points_cost'        => (int) round((float) ($row['price'] ?? 0)),
                'trial_preview_sec'  => (int) ($row['trial_preview_sec'] ?? 0),
                'duration_sec'       => (int) ($row['duration_sec'] ?? 0),
                'sort'               => (int) ($row['sort'] ?? 0),
                'status'             => (int) ($row['status'] ?? 1),
                'play_url'           => is_array($first) ? (string) ($first['play_url'] ?? '') : '',
                'provider'           => is_array($first) ? (string) ($first['provider'] ?? 'embed') : 'embed',
                'sources'            => $sources,
            ];
        }

        return $out;
    }

    /**
     * @param list<array<string, mixed>> $episodes
     * @return mixed
     */
    public static function syncForDocument(int $documentId, array $episodes)
    {
        if ($documentId < 1 || !VideoAccessService::schemaReady()) {
            return app(WeappSupportGateway::class)->resultFail('点播未就绪');
        }
        $doc = app(WeappDocumentGateway::class)->documentRowById($documentId, false);
        if (!is_array($doc) || $doc === []) {
            return app(WeappSupportGateway::class)->resultFail('文档不存在');
        }

        $seriesPatch = null;
        $rows        = [];
        foreach ($episodes as $row) {
            if (!is_array($row)) {
                continue;
            }
            if (!empty($row['__series__'])) {
                $seriesPatch = $row;
                continue;
            }
            $rows[] = $row;
        }

        Db::startTrans();
        try {
            $seriesId = 0;
            foreach ($rows as $row) {
                $sid = (int) ($row['series_id'] ?? 0);
                if ($sid > 0) {
                    $seriesId = $sid;
                    break;
                }
            }
            if ($seriesId < 1) {
                $seriesId = self::ensureSeriesForDocument($documentId, (string) ($doc['title'] ?? '文档视频'));
            }
            if (is_array($seriesPatch) && $seriesId > 0) {
                $seriesRow = VideoAccessService::seriesRow($seriesId);
                if (is_array($seriesRow)) {
                    $seriesRes = VideoCatalogService::saveSeriesAdmin([
                        'id'                 => $seriesId,
                        'title'              => (string) ($seriesRow['title'] ?? ($doc['title'] ?? '文档视频')),
                        'slug'               => (string) ($seriesRow['slug'] ?? ('doc-' . $documentId)),
                        'cover_path'         => (string) ($seriesRow['cover_path'] ?? ''),
                        'summary'            => (string) ($seriesRow['summary'] ?? ''),
                        'access_mode'        => trim((string) ($seriesPatch['access_mode'] ?? $seriesRow['access_mode'] ?? VideoAccessService::MODE_FREE)),
                        'read_level_id'      => (int) ($seriesPatch['read_level_id'] ?? $seriesRow['read_level_id'] ?? 0),
                        'price'              => (float) ($seriesPatch['price'] ?? $seriesRow['price'] ?? 0),
                        'trial_preview_sec'  => (int) ($seriesPatch['trial_preview_sec'] ?? $seriesRow['trial_preview_sec'] ?? 0),
                        'free_ep_count'      => (int) ($seriesPatch['free_ep_count'] ?? $seriesRow['free_ep_count'] ?? 0),
                        'sort'               => (int) ($seriesRow['sort'] ?? 0),
                        'status'             => (int) ($seriesRow['status'] ?? 1),
                    ]);
                    if (!$seriesRes->isOk()) {
                        Db::rollback();

                        return app(WeappSupportGateway::class)->resultFail((string) ($seriesRes->message() ?? '剧集同步失败'));
                    }
                }
            }

            $keepIds = [];
            $sort    = 0;
            foreach ($rows as $row) {
                $title   = trim((string) ($row['title'] ?? ''));
                $sources = $row['sources'] ?? null;
                $url     = trim((string) ($row['play_url'] ?? $row['video_url'] ?? ''));
                if ($title === '' && $url === '' && (!is_array($sources) || $sources === [])) {
                    continue;
                }
                if ($title === '') {
                    $title = '第' . max(1, (int) ($row['ep_no'] ?? ($sort + 1))) . '集';
                }
                $mode = trim((string) ($row['access_mode'] ?? ''));
                $price = (float) ($row['price'] ?? 0);
                if ($mode === VideoAccessService::MODE_POINTS) {
                    $points = max(0, (int) ($row['points_cost'] ?? $price));
                    $price  = (float) $points;
                }
                $payload = [
                    'id'                 => (int) ($row['id'] ?? 0),
                    'series_id'          => $seriesId,
                    'document_id'        => $documentId,
                    'ep_no'              => (int) ($row['ep_no'] ?? ($sort + 1)),
                    'title'              => $title,
                    'cover_path'         => trim((string) ($row['cover_path'] ?? '')),
                    'access_mode'        => $mode,
                    'read_level_id'      => (int) ($row['read_level_id'] ?? 0),
                    'price'              => $price,
                    'trial_preview_sec'  => (int) ($row['trial_preview_sec'] ?? 0),
                    'duration_sec'       => (int) ($row['duration_sec'] ?? 0),
                    'sort'               => (int) ($row['sort'] ?? $sort),
                    'status'             => array_key_exists('status', $row) ? (!empty($row['status']) ? 1 : 0) : 1,
                    'play_url'           => $url,
                    'provider'           => trim((string) ($row['provider'] ?? 'embed')),
                ];
                if (is_array($sources) && $sources !== []) {
                    $payload['sources'] = $sources;
                }
                $res = VideoCatalogService::saveEpisodeAdmin($payload);
                if (!$res->isOk()) {
                    Db::rollback();

                    return app(WeappSupportGateway::class)->resultFail((string) ($res->message() ?? '单集同步失败'));
                }
                $newId = (int) ($res->dataArray()['id'] ?? 0);
                if ($newId > 0) {
                    $keepIds[] = $newId;
                }
                $sort++;
            }

            $query = WeappVideoEpisode::where('document_id', $documentId);
            if ($keepIds === []) {
                $query->delete();
            } else {
                $query->whereNotIn('id', $keepIds)->delete();
            }
            Db::commit();
        } catch (\Throwable $e) {
            Db::rollback();
            app(WeappSupportGateway::class)->kernelOpsLog('vod_document_sync_failed', [
                'document_id' => $documentId,
                'msg'         => $e->getMessage(),
            ]);

            return app(WeappSupportGateway::class)->resultFail('同步失败');
        }

        return app(WeappSupportGateway::class)->resultOk(null, 'ok');
    }

    public static function purgeForDocument(int $documentId): void
    {
        if ($documentId < 1 || !VideoAccessService::schemaReady()) {
            return;
        }
        $ids = WeappVideoEpisode::where('document_id', $documentId)
            ->column('id');
        if ($ids === []) {
            return;
        }
        Db::startTrans();
        try {
            WeappVideoSource::whereIn('episode_id', $ids)->delete();
            WeappVideoEpisode::where('document_id', $documentId)->delete();
            Db::commit();
        } catch (\Throwable $e) {
            Db::rollback();
            app(WeappSupportGateway::class)->kernelOpsLog('vod_document_purge_failed', [
                'document_id' => $documentId,
                'msg'         => $e->getMessage(),
            ]);
        }
    }

    private static function ensureSeriesForDocument(int $documentId, string $docTitle): int
    {
        $existing = WeappVideoEpisode::where('document_id', $documentId)
            ->where('series_id', '>', 0)
            ->order('id', 'asc')
            ->value('series_id');
        if ($existing) {
            return (int) $existing;
        }
        $title = trim($docTitle) !== '' ? trim($docTitle) : ('文档 #' . $documentId);
        $res   = VideoCatalogService::saveSeriesAdmin([
            'title'       => $title,
            'slug'        => 'doc-' . $documentId,
            'access_mode' => VideoAccessService::MODE_FREE,
            'status'      => 1,
        ]);
        if (is_object($res) && method_exists($res, 'dataArray')) {
            return (int) ($res->dataArray()['id'] ?? 0);
        }
        if (is_array($res)) {
            return (int) ($res['id'] ?? 0);
        }

        return 0;
    }

    /** @return array<string, mixed>|null */
    public static function seriesMetaForDocument(int $documentId): ?array
    {
        if ($documentId < 1 || !VideoAccessService::schemaReady()) {
            return null;
        }
        $seriesId = (int) WeappVideoEpisode::where('document_id', $documentId)
            ->where('series_id', '>', 0)
            ->order('id', 'asc')
            ->value('series_id');
        if ($seriesId < 1) {
            return null;
        }
        $row = VideoAccessService::seriesRow($seriesId);
        if ($row === null) {
            return null;
        }

        return [
            'id'                => $seriesId,
            'title'             => (string) ($row['title'] ?? ''),
            'slug'              => (string) ($row['slug'] ?? ''),
            'access_mode'       => (string) ($row['access_mode'] ?? VideoAccessService::MODE_FREE),
            'read_level_id'     => (int) ($row['read_level_id'] ?? 0),
            'price'             => (float) ($row['price'] ?? 0),
            'trial_preview_sec' => (int) ($row['trial_preview_sec'] ?? 0),
            'free_ep_count'     => (int) ($row['free_ep_count'] ?? 0),
            'status'            => (int) ($row['status'] ?? 1),
        ];
    }
}
