<?php
declare(strict_types=1);

namespace weapp\doc_vod\service;

/** 前台选集展示文案（权益标签、进度、时长） */
class VideoEpisodeDisplayService
{
    /**
     * @param array<string, mixed> $episode
     * @param array<string, mixed> $series
     * @param array<string, mixed> $decision VideoAccessService::decision 结果
     * @return array<string, mixed>
     */
    public static function listFields(
        array $episode,
        array $series,
        array $decision,
        int $progressSec = 0,
    ): array {
        $badge = self::badge($episode, $series, $decision);
        $durationSec = max(0, (int) ($episode['duration_sec'] ?? 0));
        $progressPct = 0;
        $progressLabel = '';
        if ($progressSec > 0 && $durationSec > 10) {
            $progressPct = min(100, (int) round($progressSec / $durationSec * 100));
            $progressLabel = '看到 ' . self::formatClock($progressSec);
        } elseif ($progressSec > 0) {
            $progressLabel = '看到 ' . self::formatClock($progressSec);
        }

        return array_merge($badge, [
            'duration_sec'    => $durationSec,
            'duration_label'  => $durationSec > 0 ? self::formatClock($durationSec) : '',
            'progress_sec'    => $progressSec,
            'progress_pct'    => $progressPct,
            'progress_label'  => $progressLabel,
            'price_text'      => self::priceText($episode, $series, $decision),
        ]);
    }

    /**
     * @param array<string, mixed> $episode
     * @param array<string, mixed> $series
     * @param array<string, mixed> $decision
     * @return array{badge_text:string,badge_type:string,need_label:string}
     */
    public static function badge(array $episode, array $series, array $decision): array
    {
        $allowed   = (int) ($decision['allowed'] ?? 0);
        $trialMode = (int) ($decision['trial_mode'] ?? 0);
        $need      = (string) ($decision['need'] ?? '');
        $reason    = (string) ($decision['reason'] ?? '');

        if ($allowed === 1 && $trialMode === 1) {
            $sec = (int) ($decision['trial_sec'] ?? 0);

            return [
                'badge_text'  => $sec > 0 ? ('试看 ' . $sec . ' 秒') : '试看',
                'badge_type'  => 'trial',
                'need_label'  => $reason !== '' ? $reason : '试看',
            ];
        }
        if ($allowed === 1) {
            if (VideoAccessService::isFreeEpisodeInSeries((int) ($episode['id'] ?? 0), $series)) {
                return ['badge_text' => '免费', 'badge_type' => 'free', 'need_label' => '免费'];
            }
            $mode = VideoAccessService::effectiveMode($episode, $series);
            if ($mode === VideoAccessService::MODE_FREE) {
                return ['badge_text' => '免费', 'badge_type' => 'free', 'need_label' => '免费'];
            }
            if ($mode === VideoAccessService::MODE_LOGIN) {
                return ['badge_text' => '登录可看', 'badge_type' => 'login', 'need_label' => '登录可看'];
            }
            if ($mode === VideoAccessService::MODE_LEVEL) {
                return ['badge_text' => '会员', 'badge_type' => 'level', 'need_label' => '会员专享'];
            }

            return ['badge_text' => '已解锁', 'badge_type' => 'ok', 'need_label' => '可观看'];
        }

        return match ($need) {
            'login' => ['badge_text' => '需登录', 'badge_type' => 'login', 'need_label' => $reason],
            'level' => ['badge_text' => '需会员', 'badge_type' => 'level', 'need_label' => $reason],
            'pay_episode' => [
                'badge_text' => self::episodePriceLabel($episode, $series),
                'badge_type'  => 'paid',
                'need_label'  => $reason,
            ],
            'pay_series' => [
                'badge_text' => self::seriesPriceLabel($series),
                'badge_type'  => 'paid',
                'need_label'  => $reason,
            ],
            'points' => [
                'badge_text'  => '积分',
                'badge_type'  => 'points',
                'need_label'  => $reason !== '' ? $reason : '积分兑换',
            ],
            default => ['badge_text' => $reason !== '' ? $reason : '受限', 'badge_type' => 'muted', 'need_label' => $reason],
        };
    }

    /**
     * @param array<string, mixed> $episode
     * @param array<string, mixed> $series
     * @param array<string, mixed> $decision
     */
    public static function priceText(array $episode, array $series, array $decision): string
    {
        if ((int) ($decision['allowed'] ?? 0) === 1 && (int) ($decision['trial_mode'] ?? 0) !== 1) {
            return '';
        }
        $need = (string) ($decision['need'] ?? '');
        if ($need === 'pay_episode') {
            return self::episodePriceLabel($episode, $series);
        }
        if ($need === 'pay_series') {
            return self::seriesPriceLabel($series);
        }
        if ($need === 'level') {
            return '升级会员';
        }

        return '';
    }

    /** @param array<string, mixed> $episode @param array<string, mixed> $series */
    private static function episodePriceLabel(array $episode, array $series): string
    {
        $price = round((float) ($episode['price'] ?? 0), 2);
        if ($price < 0.01) {
            $price = round((float) ($series['price'] ?? 0), 2);
        }

        return $price >= 0.01 ? ('¥' . number_format($price, 2)) : '付费';
    }

    /** @param array<string, mixed> $series */
    private static function seriesPriceLabel(array $series): string
    {
        $price = round((float) ($series['price'] ?? 0), 2);

        return $price >= 0.01 ? ('全集 ¥' . number_format($price, 2)) : '全集付费';
    }

    public static function formatClock(int $sec): string
    {
        $sec = max(0, $sec);
        $h   = (int) floor($sec / 3600);
        $m   = (int) floor(($sec % 3600) / 60);
        $s   = $sec % 60;
        if ($h > 0) {
            return sprintf('%d:%02d:%02d', $h, $m, $s);
        }

        return sprintf('%d:%02d', $m, $s);
    }
}
