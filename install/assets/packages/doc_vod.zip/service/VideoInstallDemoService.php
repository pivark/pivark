<?php
declare(strict_types=1);

namespace weapp\doc_vod\service;

use app\common\service\weapp\WeappConfigGateway;
use app\common\service\weapp\WeappInstallDemoService;
use weapp\doc_vod\model\WeappVideoItem;

/** 视频插件：安装向导首次装插件时的默认演示数据 */
final class VideoInstallDemoService
{
    public static function seed(): void
    {
        $cfg     = app(WeappConfigGateway::class);
        $tagSlug = 'pv-demo-video';
        $tagIds  = [
            $tagSlug => $cfg->installDemoUpsertTag([
                'slug'        => $tagSlug,
                'name'        => '产品视频',
                'tpl'         => 'list_document_video.php',

                'nav_sort'    => 5,
                'description' => '产品介绍、操作指南与案例视频',
                'url_path'    => 'video',
            ]),
        ];
        $docId = $cfg->installDemoUpsertDocument(
            'pv-demo-video-01',
            'HY-810 产品介绍',
            '演示视频播放入口与封面展示。',
            '<p>本视频为插件自带演示外链，可在后台替换为站内或第三方地址。</p>',
        );
        $cfg->installDemoLinkDocumentTags($docId, [$tagSlug], $tagIds);
        $cfg->installDemoAppendContentCategoryNav('video', '产品视频', 5);
        self::seedVideoItem($docId);
        $cfg->installDemoRefreshTagUseCounts();
    }

    private static function seedVideoItem(int $documentId): void
    {
        if ($documentId < 1) {
            return;
        }
        $cfg = app(WeappConfigGateway::class);
        $now = WeappInstallDemoService::now();
        $url = 'https://www.w3schools.com/html/mov_bbb.mp4';
        $row = [
            'document_id' => $documentId,
            'title'       => 'HY-810 产品介绍',
            'video_url'   => $url,
            'cover_path'  => $cfg->installDemoPreviewImage(),
            'provider'    => 'direct',
            'sort'        => 1,
            'status'      => 1,
            'created_at'  => $now,
            'updated_at'  => $now,
        ];

        try {
            WeappVideoItem::where('document_id', $documentId)->delete();
            WeappVideoItem::insert($row);
        } catch (\Throwable) {
            // 现行表 weapp_doc_vod_items；无旧表回退（禁种 weapp_doc_vod_assets）
        }
    }
}
