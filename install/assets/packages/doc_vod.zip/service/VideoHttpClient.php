<?php
declare(strict_types=1);

namespace weapp\doc_vod\service;


use app\common\service\weapp\WeappSupportGateway;
/** 插件内 HTTP（解析 API / B 站元数据），带重试 */
class VideoHttpClient
{
    public static function get(string $url, string $cookie = '', int $retries = 2): string
    {
        $url = trim($url);
        if ($url === '') {
            return '';
        }
        $attempts = max(1, min(4, $retries + 1));
        $last     = '';
        for ($i = 0; $i < $attempts; $i++) {
            $last = self::getOnce($url, $cookie);
            if ($last !== '') {
                return $last;
            }
            if ($i < $attempts - 1) {
                usleep(150000);
            }
        }

        return $last;
    }

    private static function getOnce(string $url, string $cookie): string
    {
        $headers = [
            'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            'Accept: application/json,text/plain,*/*',
        ];
        if ($cookie !== '') {
            $headers[] = 'Cookie: ' . $cookie;
        }
        if (function_exists('curl_init')) {
            $ch = curl_init($url);
            if ($ch === false) {
                return '';
            }
            curl_setopt_array($ch, [
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_CONNECTTIMEOUT => 8,
                CURLOPT_TIMEOUT        => 15,
                CURLOPT_HTTPHEADER     => $headers,
            ]);
            $body = curl_exec($ch);
            $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);
            if ($body === false || ($code >= 400 && $code < 600)) {
                return '';
            }

            return (string) $body;
        }
        $ctx = stream_context_create([
            'http' => [
                'method'  => 'GET',
                'header'  => implode("\r\n", $headers) . "\r\n",
                'timeout' => 15,
            ],
        ]);
        $body = app(WeappSupportGateway::class)->localFileGetContents($url, false, $ctx);

        return $body ?? '';
    }
}
