<?php
declare(strict_types=1);

namespace weapp\doc_vod\service;

use weapp\doc_vod\model\WeappVideoEpisode;
use weapp\doc_vod\model\WeappVideoSeries;
use think\facade\Db;
use app\common\service\weapp\WeappMemberGateway;
use app\common\service\weapp\WeappSupportGateway;

/** 视频观看鉴权 */
class VideoAccessService
{
    public const MODE_FREE        = 'free';
    public const MODE_LOGIN       = 'login';
    public const MODE_LEVEL       = 'level';
    public const MODE_PAID        = 'paid';
    public const MODE_PAID_SERIES = 'paid_series';
    /** 积分兑换：price 字段存所需积分（整数） */
    public const MODE_POINTS      = 'points';

    /**
     * @return array{
     *   allowed:int,
     *   reason:string,
     *   need:string,
     *   cta_url:string,
     *   cta_label:string,
     *   episode?:array,
     *   series?:array
     * }
     */
    public static function decision(?array $member, int $episodeId): array
    {
        $episode = self::episodeRow($episodeId);
        if ($episode === null) {
            return self::deny('not_found', '视频不存在', '', '');
        }
        $series = self::seriesRow((int) ($episode['series_id'] ?? 0));
        if ($series === null || (int) ($series['status'] ?? 0) !== 1) {
            return self::deny('offline', '视频已下架', '', '');
        }

        $mode      = self::effectiveMode($episode, $series);
        $levelId   = self::effectiveLevelId($episode, $series);
        $memberId  = (int) ($member['id'] ?? 0);
        $loggedIn  = $memberId > 0;

        if ($mode === self::MODE_FREE) {
            return self::allow($episode, $series);
        }
        if ($mode === self::MODE_LOGIN) {
            return $loggedIn
                ? self::allow($episode, $series)
                : self::deny('login', '请登录后观看', app(WeappSupportGateway::class)->siteUrlMemberLogin(), '登录观看');
        }
        if ($mode === self::MODE_LEVEL) {
            if (!$loggedIn) {
                return self::deny('login', '请登录后观看', app(WeappSupportGateway::class)->siteUrlMemberLogin(), '登录观看');
            }
            $row = ['read_perm' => 1, 'read_level_id' => $levelId];
            if (app(WeappMemberGateway::class)->memberLevelCanReadDocument($row, $member)
                || self::memberHasFilmLevel($member, $levelId)) {
                return self::allow($episode, $series);
            }
            $name = $levelId > 0 ? app(WeappMemberGateway::class)->memberLevelGetName($levelId) : '指定等级';

            return self::deny(
                'level',
                "需要 {$name} 及以上会员",
                app(WeappSupportGateway::class)->siteUrlMemberRecharge(),
                '升级会员'
            );
        }
        if ($mode === self::MODE_PAID_SERIES) {
            if (!$loggedIn) {
                return self::deny('login', '请登录后购买', app(WeappSupportGateway::class)->siteUrlMemberLogin(), '登录');
            }
            if (VideoPurchaseService::hasSeriesGrant($memberId, (int) $series['id'])) {
                return self::allow($episode, $series);
            }
            if (self::isFreeEpisodeInSeries($episodeId, $series)) {
                return self::allow($episode, $series);
            }
            $trial = self::effectiveTrialSec($episode, $series);
            if ($trial > 0) {
                return self::allowTrial($episode, $series, $trial);
            }
            $price = round((float) ($series['price'] ?? 0), 2);

            return self::deny(
                'pay_series',
                $price > 0 ? ('购买全集 ¥' . number_format($price, 2)) : '购买全集后观看',
                '',
                '购买全集'
            );
        }
        if ($mode === self::MODE_PAID) {
            if (!$loggedIn) {
                return self::deny('login', '请登录后购买', app(WeappSupportGateway::class)->siteUrlMemberLogin(), '登录');
            }
            if (VideoPurchaseService::hasEpisodeGrant($memberId, $episodeId)
                || VideoPurchaseService::hasSeriesGrant($memberId, (int) $series['id'])) {
                return self::allow($episode, $series);
            }
            if (self::isFreeEpisodeInSeries($episodeId, $series)) {
                return self::allow($episode, $series);
            }
            $trial = self::effectiveTrialSec($episode, $series);
            if ($trial > 0) {
                return self::allowTrial($episode, $series, $trial);
            }
            $price = round((float) ($episode['price'] ?? 0), 2);
            if ($price <= 0) {
                $price = round((float) ($series['price'] ?? 0), 2);
            }

            return self::deny(
                'pay_episode',
                $price > 0 ? ('购买本集 ¥' . number_format($price, 2)) : '购买后观看',
                '',
                '购买本集'
            );
        }
        if ($mode === self::MODE_POINTS) {
            if (!$loggedIn) {
                return self::deny('login', '请登录后兑换', app(WeappSupportGateway::class)->siteUrlMemberLogin(), '登录');
            }
            if (VideoPurchaseService::hasEpisodeGrant($memberId, $episodeId)
                || VideoPurchaseService::hasSeriesGrant($memberId, (int) $series['id'])) {
                return self::allow($episode, $series);
            }
            $trial = self::effectiveTrialSec($episode, $series);
            if ($trial > 0) {
                return self::allowTrial($episode, $series, $trial);
            }
            $cost = max(0, (int) round((float) ($episode['price'] ?? 0)));
            $bal  = app(WeappMemberGateway::class)->memberPointBalance($memberId);

            return self::deny(
                'points',
                $cost > 0 ? ('需 ' . $cost . ' 积分兑换（当前 ' . $bal . '）') : '积分兑换未配置',
                app(WeappSupportGateway::class)->siteUrlMemberRecharge(),
                '积分兑换'
            );
        }

        return self::allow($episode, $series);
    }

    /** @param array<string, mixed> $episode @param array<string, mixed> $series */
    private static function allow(array $episode, array $series): array
    {
        return [
            'allowed'    => 1,
            'reason'     => 'ok',
            'need'       => '',
            'cta_url'    => '',
            'cta_label'  => '',
            'trial_mode' => 0,
            'trial_sec'  => 0,
            'episode'    => $episode,
            'series'     => $series,
        ];
    }

    /** @param array<string, mixed> $episode @param array<string, mixed> $series */
    private static function allowTrial(array $episode, array $series, int $trialSec): array
    {
        $out = self::allow($episode, $series);
        $out['trial_mode'] = 1;
        $out['trial_sec']  = $trialSec;
        $out['reason']     = '试看 ' . $trialSec . ' 秒';

        return $out;
    }

    /** @param array<string, mixed> $episode @param array<string, mixed> $series */
    public static function effectiveTrialSec(array $episode, array $series): int
    {
        $ep = (int) ($episode['trial_preview_sec'] ?? 0);
        if ($ep > 0) {
            return min(3600, $ep);
        }
        $sr = (int) ($series['trial_preview_sec'] ?? 0);

        return $sr > 0 ? min(3600, $sr) : 0;
    }

    /** @param array<string, mixed> $series */
    public static function isFreeEpisodeInSeries(int $episodeId, array $series): bool
    {
        $freeN = (int) ($series['free_ep_count'] ?? 0);
        if ($freeN < 1) {
            return false;
        }
        $seriesId = (int) ($series['id'] ?? 0);
        if ($seriesId < 1) {
            return false;
        }
        $ids = WeappVideoEpisode::where('series_id', $seriesId)
            ->where('status', 1)
            ->order(['sort' => 'asc', 'ep_no' => 'asc', 'id' => 'asc'])
            ->limit($freeN)
            ->column('id');

        return in_array($episodeId, array_map('intval', $ids), true);
    }

    private static function deny(string $need, string $reason, string $ctaUrl, string $ctaLabel): array
    {
        return [
            'allowed'    => 0,
            'reason'     => $reason,
            'need'       => $need,
            'cta_url'    => $ctaUrl,
            'cta_label'  => $ctaLabel,
            'trial_mode' => 0,
            'trial_sec'  => 0,
        ];
    }

    /** @return array<string, mixed>|null */
    public static function episodeRow(int $episodeId): ?array
    {
        if ($episodeId < 1 || !self::schemaReady()) {
            return null;
        }
        $row = WeappVideoEpisode::where('id', $episodeId)->where('status', 1)->find();

        return self::rowToArray($row);
    }

    /** @return array<string, mixed>|null */
    public static function seriesRow(int $seriesId): ?array
    {
        if ($seriesId < 1 || !self::schemaReady()) {
            return null;
        }
        $row = WeappVideoSeries::where('id', $seriesId)->find();

        return self::rowToArray($row);
    }

    /** @return array<string, mixed>|null */
    private static function rowToArray(mixed $row): ?array
    {
        if ($row === null) {
            return null;
        }
        if (is_array($row)) {
            return $row;
        }
        if (method_exists($row, 'toArray')) {
            $arr = $row->toArray();

            return is_array($arr) ? $arr : null;
        }

        return null;
    }

    /** @param array<string, mixed> $episode @param array<string, mixed> $series */
    public static function effectiveMode(array $episode, array $series): string
    {
        $mode = strtolower(trim((string) ($episode['access_mode'] ?? '')));
        if ($mode === '') {
            $mode = strtolower(trim((string) ($series['access_mode'] ?? self::MODE_FREE)));
        }
        $allowed = [self::MODE_FREE, self::MODE_LOGIN, self::MODE_LEVEL, self::MODE_PAID, self::MODE_PAID_SERIES];

        return in_array($mode, $allowed, true) ? $mode : self::MODE_FREE;
    }

    /** @param array<string, mixed> $episode @param array<string, mixed> $series */
    /** @param array<string, mixed>|null $member */
    public static function memberHasFilmLevel(?array $member, int $requiredLevelId = 0): bool
    {
        $filmId = VideoConfigService::filmLevelId();
        if ($filmId < 1 || $member === null || (int) ($member['id'] ?? 0) < 1) {
            return false;
        }
        $memberLevelId = (int) ($member['member_level_id'] ?? 0);
        if ($memberLevelId < 1) {
            return false;
        }
        if ($requiredLevelId > 0 && $requiredLevelId !== $filmId) {
            return false;
        }

        return (int) ($member['member_level_id'] ?? 0) === $filmId;
    }

    /** @param array<string, mixed> $episode @param array<string, mixed> $series */
    public static function effectiveLevelId(array $episode, array $series): int
    {
        $level = (int) ($episode['read_level_id'] ?? 0);
        if ($level < 1) {
            $level = (int) ($series['read_level_id'] ?? 0);
        }

        return max(0, $level);
    }

    public static function schemaReady(): bool
    {
        static $ok = null;
        if ($ok !== null) {
            return $ok;
        }
        try {
            WeappVideoEpisode::limit(1)->select();
            $ok = true;
        } catch (\Throwable $e) {
            app(WeappSupportGateway::class)->kernelOpsLog('video_access_table_probe_failed', ['msg' => $e->getMessage()]);
            $ok = false;
        }

        return $ok;
    }
}
