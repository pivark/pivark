<?php
/**
 * 元舟 PivArk — 企业全域原子化数字资产中枢
 * (c) 2024-2026 pivark.com. All rights reserved.
 * Author: Angelo
 * 未经允许，不可用于商业用途。
 */
declare(strict_types=1);

namespace weapp\doc_vod\service;

use app\common\contract\ImportIntentDelegateInterface;
use app\common\service\weapp\WeappEntitlementGateway;

/** video 导入意图 delegate（视频文件/视频页/本地视频） */
final class VideoImportIntentDelegate implements ImportIntentDelegateInterface
{
    public function identifier(): string
    {
        return 'doc_vod';
    }

    public function isEnabled(): bool
    {
        return app(WeappEntitlementGateway::class)->entitlementCan('doc_vod')
            && is_dir(ROOT_PATH . 'weapp/doc_vod');
    }

    public function supportedIntentKinds(): array
    {
        return [
            'video_file',
            'video_page',
            'local_video',
        ];
    }

    public function supportedChannels(): array
    {
        return ['paste', 'drop', 'scan', 'import', 'voice', 'chat'];
    }

    public function priority(): int
    {
        return 90;
    }

    public function label(): string
    {
        return '视频插件';
    }
}
