<?php
declare(strict_types=1);

namespace weapp\doc_vod\service;

use app\common\service\weapp\WeappPaymentGateway;
use app\common\service\weapp\WeappPluginGateway;

/** video 支付 scene 注册 */
final class VideoPaymentFulfillment
{
    public static function register(): void
    {
                app(WeappPaymentGateway::class)->paymentFulfillmentRegister(
            VideoPaymentScenes::EPISODE,
            [self::class, 'handleEpisode'],
            '付费视频',
        );
        app(WeappPaymentGateway::class)->paymentFulfillmentRegister(
            VideoPaymentScenes::SERIES,
            [self::class, 'handleSeries'],
            '视频全集',
        );
    }

    /** @param array<string, mixed> $order */
    public static function handleEpisode(array $order)
    {
        self::ensureVideo();

        return VideoPurchaseService::fulfillEpisode(
            (int) ($order['user_id'] ?? 0),
            (int) ($order['scene_id'] ?? 0),
            (string) ($order['order_no'] ?? ''),
            (float) ($order['amount'] ?? 0)
        );
    }

    /** @param array<string, mixed> $order */
    public static function handleSeries(array $order)
    {
        self::ensureVideo();

        return VideoPurchaseService::fulfillSeries(
            (int) ($order['user_id'] ?? 0),
            (int) ($order['scene_id'] ?? 0),
            (string) ($order['order_no'] ?? ''),
            (float) ($order['amount'] ?? 0)
        );
    }

    private static function ensureVideo(): void
    {
        if (!class_exists(VideoPurchaseService::class)) {
            app(WeappPluginGateway::class)->pluginRegisterAutoloadPublic('doc_vod');
        }
    }

    /**
     * @param array<string, mixed> $payload
     */
    public static function onPaymentRefunded(array $payload): void
    {
        $scene = trim((string) ($payload['scene'] ?? ''));
        if ($scene !== VideoPaymentScenes::EPISODE && $scene !== VideoPaymentScenes::SERIES) {
            return;
        }
        $orderNo = trim((string) ($payload['order_no'] ?? ''));
        if ($orderNo === '') {
            return;
        }
        self::ensureVideo();
        if (class_exists(VideoPurchaseService::class)) {
            VideoPurchaseService::revokeByOrderNo($orderNo);
        }
    }
}
