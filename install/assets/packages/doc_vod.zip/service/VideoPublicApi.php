<?php
declare(strict_types=1);

namespace weapp\doc_vod\service;

use app\common\contract\PluginApiCallableTrait;
use app\common\contract\PluginApiInterface;

/** 视频插件对外 API（跨插件经 PluginApiRegistry 调用） */
final class VideoPublicApi implements PluginApiInterface
{
    use PluginApiCallableTrait;

    public function pluginIdentifier(): string
    {
        return 'doc_vod';
    }

    public function isActive(): bool
    {
        VideoService::ensureAutoload();

        return VideoService::isActive();
    }

    /** @return list<array<string, mixed>> */
    public function listForDocument(int $documentId): array
    {
        VideoService::ensureAutoload();

        return VideoService::listForDocument($documentId);
    }
}
