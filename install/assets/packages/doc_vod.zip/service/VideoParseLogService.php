<?php
declare(strict_types=1);

namespace weapp\doc_vod\service;


use app\common\support\AppTime;
use weapp\doc_vod\model\WeappVideoParseLog;
use think\facade\Db;
use app\common\service\weapp\WeappSupportGateway;

/** 解析成功/失败日志（运维排障） */
class VideoParseLogService
{
    public static function schemaReady(): bool
    {
        static $ok = null;
        if ($ok !== null) {
            return $ok;
        }
        try {
            WeappVideoParseLog::limit(1)->select();
            $ok = true;
        } catch (\Throwable) {
            $ok = false;
        }

        return $ok;
    }

    public static function log(string $platform, string $url, bool $success, string $msg, int $durationMs = 0): void
    {
        if (!self::schemaReady()) {
            return;
        }
        $url = mb_substr(trim($url), 0, 480);
        WeappVideoParseLog::insert([
            'platform'    => mb_substr($platform, 0, 32),
            'url'         => $url,
            'success'     => $success ? 1 : 0,
            'msg'         => mb_substr($msg, 0, 255),
            'duration_ms' => max(0, min(60000, $durationMs)),
            'created_at'  => app(WeappSupportGateway::class)->appTimeNow(),
        ]);
        self::prune(500);
    }

    private static function prune(int $keep): void
    {
        $maxId = (int) WeappVideoParseLog::max('id');
        if ($maxId <= $keep) {
            return;
        }
        WeappVideoParseLog::where('id', '<', $maxId - $keep)->delete();
    }

    /** @return list<array<string, mixed>> */
    public static function recentFailures(int $limit = 20): array
    {
        if (!self::schemaReady()) {
            return [];
        }

        return WeappVideoParseLog::where('success', 0)
            ->order('id', 'desc')
            ->limit(max(1, min(50, $limit)))
            ->select()
            ->toArray();
    }

    /** @return list<array<string, mixed>> */
    public static function platformFailCounts(int $days = 7): array
    {
        if (!self::schemaReady()) {
            return [];
        }
        $since = AppTime::format('Y-m-d H:i:s', strtotime('-' . max(1, min(90, $days)) . ' days'));

        return WeappVideoParseLog::where('success', 0)
            ->where('created_at', '>=', $since)
            ->field('platform, count(*) as fail_count')
            ->group('platform')
            ->order('fail_count', 'desc')
            ->select()
            ->toArray();
    }
}
