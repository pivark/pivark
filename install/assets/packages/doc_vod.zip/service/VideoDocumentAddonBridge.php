<?php
/**
 * 元舟 PivArk — document-addon bridge handler（weapp SSOT）
 */
declare(strict_types=1);

namespace weapp\doc_vod\service;

use app\common\contract\DocumentAddonBridgeHandlerInterface;
use app\common\contract\WeappPluginBridgeTrait;
use app\common\service\weapp\WeappSupportGateway;


final class VideoDocumentAddonBridge implements DocumentAddonBridgeHandlerInterface
{
    use WeappPluginBridgeTrait;

    
    

    public function isEnabled(): bool
    {
        return $this->bridgeEnabled('doc_vod');
    }

    public function identifier(): string
    {
        return 'doc_vod';
    }
    /** @return array<string, mixed> */
    public function documentEditorSpaPayload(int $documentId): array
    {
        return [
            'save_field'     => 'videos_json',
            'vod_save_field' => 'videos_vod_json',
            'items'          => $documentId > 0 ? $this->listForDocument($documentId) : [],
            'vod_episodes'   => $documentId > 0 ? $this->listVodForDocument($documentId) : [],
            'vod_series'     => $documentId > 0
                ? (\weapp\doc_vod\service\VideoDocumentVodService::seriesMetaForDocument($documentId) ?? new \stdClass())
                : new \stdClass(),
            'vod_ready'      => $this->vodSchemaReady() ? 1 : 0,
            'member_levels'  => app(\app\common\service\weapp\WeappMemberGateway::class)->memberLevelsActive(),
        ];
    }

    /** @return list<array<string, mixed>> */
    public function listForDocument(int $documentId): array
    {
        if (!$this->isEnabled() || $documentId < 1) {
            return [];
        }
        $this->ensurePluginLoaded();

        return \weapp\doc_vod\service\VideoService::listForDocument($documentId);
    }

    /**
     * @param list<array<string, mixed>> $items
     * @return mixed
     */
    public function syncForDocument(int $documentId, array $items)
    {
        if (!$this->isEnabled() || $documentId < 1) {
            return app(WeappSupportGateway::class)->resultFail('参数错误');
        }
        $this->ensurePluginLoaded();

        return \weapp\doc_vod\service\VideoService::syncForDocument($documentId, $items);
    }

    /** @return list<array<string, mixed>> */
    public function listVodForDocument(int $documentId): array
    {
        if (!$this->isEnabled() || $documentId < 1) {
            return [];
        }
        $this->ensurePluginLoaded();

        return \weapp\doc_vod\service\VideoDocumentVodService::listForDocument($documentId);
    }

    public function vodSchemaReady(): bool
    {
        if (!$this->isEnabled()) {
            return false;
        }
        $this->ensurePluginLoaded();

        return \weapp\doc_vod\service\VideoAccessService::schemaReady();
    }

    /**
     * @param list<array<string, mixed>> $episodes
     * @return mixed
     */
    public function syncVodForDocument(int $documentId, array $episodes)
    {
        if (!$this->isEnabled() || $documentId < 1) {
            return app(WeappSupportGateway::class)->resultFail('参数错误');
        }
        $this->ensurePluginLoaded();

        return \weapp\doc_vod\service\VideoDocumentVodService::syncForDocument($documentId, $episodes);
    }

    public function purgeForDocument(int $documentId): void
    {
        if (!$this->isEnabled() || $documentId < 1) {
            return;
        }
        $this->ensurePluginLoaded();
        \weapp\doc_vod\service\VideoService::purgeForDocument($documentId);
        \weapp\doc_vod\service\VideoDocumentVodService::purgeForDocument($documentId);
    }

    /** 模板 flag document_has_doc_vod */
    public function hasAvailabilityForDocument(int $documentId): bool
    {
        if (!$this->isEnabled() || $documentId < 1) {
            return false;
        }
        $this->ensurePluginLoaded();
        if (\weapp\doc_vod\service\VideoService::listForDocument($documentId) !== []) {
            return true;
        }

        return \weapp\doc_vod\service\VideoDocumentVodService::listForDocument($documentId) !== [];
    }

    /**
     * @return list<int>
     */
    public function documentIdsWithAvailability(): array
    {
        if (!$this->isEnabled()) {
            return [];
        }
        $this->ensurePluginLoaded();

        return \weapp\doc_vod\service\VideoService::documentIdsWithPublicAvailability();
    }

    /** @param array<string, mixed>|null $order */
    public function watchUrlForOrder(?array $order): string
    {
        if (!$this->isEnabled() || !is_array($order)) {
            return '';
        }
        $this->ensurePluginLoaded();

        return \weapp\doc_vod\service\VideoPurchaseService::watchUrlForOrder($order);
    }

    public function frontPlazaPath(): string
    {
        if (!$this->isEnabled()) {
            return '';
        }

        return '/doc_vod/plaza';
    }

    private function ensurePluginLoaded(): void
    {
        $this->registerWeappAutoload('doc_vod');
        \weapp\doc_vod\service\VideoService::ensureAutoload();
    }
}
