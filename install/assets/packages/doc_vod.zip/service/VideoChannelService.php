<?php
declare(strict_types=1);

namespace weapp\doc_vod\service;


use weapp\doc_vod\model\WeappVideoSeries;
use think\facade\Db;
use app\common\service\weapp\WeappPluginGateway;
use app\common\service\weapp\WeappSupportGateway;

/** 剧集频道页：一剧一页，无需为每集建文档 */
class VideoChannelService
{
    public static function boot(): void
    {
        if (!VideoConfigService::seriesChannelOpen()) {
            return;
        }
        $gw = app(WeappPluginGateway::class);
        $gw->pluginRouteRegister(
            'get',
            'doc_vod/series/:slug',
            '\\weapp\\doc_vod\\front\\controller\\Series@show',
            ['slug' => '[a-zA-Z0-9_\-]+'],
        );
        $gw->pluginRouteRegister(
            'get',
            'video/series/:slug',
            '\\weapp\\doc_vod\\front\\controller\\Series@show',
            ['slug' => '[a-zA-Z0-9_\-]+'],
        );
    }

    /** @return array<string, mixed>|null */
    public static function seriesBySlug(string $slug): ?array
    {
        $slug = trim($slug);
        if ($slug === '' || !VideoAccessService::schemaReady()) {
            return null;
        }
        $row = WeappVideoSeries::where('slug', $slug)
            ->where('status', 1)
            ->find();

        return is_array($row) ? $row : null;
    }

    public static function channelUrl(string $slug): string
    {
        $slug = trim($slug);

        return $slug === '' ? '' : '/doc_vod/series/' . rawurlencode($slug);
    }

    /** @return list<array<string, mixed>> */
    public static function listEpisodesForSeries(int $seriesId): array
    {
        if ($seriesId < 1 || !VideoAccessService::schemaReady()) {
            return [];
        }
        $series = VideoAccessService::seriesRow($seriesId);
        if ($series === null || (int) ($series['status'] ?? 0) !== 1) {
            return [];
        }

        return VideoPlaybackService::listEpisodesForSeries($seriesId);
    }

    /**
     * @return mixed
     */
    public static function pageVars(string $slug)
    {
        if (!VideoService::isActive()) {
            return app(WeappSupportGateway::class)->resultFail('视频功能未开启');
        }
        if (!VideoConfigService::seriesChannelOpen()) {
            return app(WeappSupportGateway::class)->resultFail('剧集频道页未开启');
        }
        $series = self::seriesBySlug($slug);
        if ($series === null) {
            return app(WeappSupportGateway::class)->resultFail('剧集不存在或已下架');
        }
        $seriesId = (int) ($series['id'] ?? 0);
        $episodes = self::listEpisodesForSeries($seriesId);
        if ($episodes === []) {
            return app(WeappSupportGateway::class)->resultFail('该剧集暂无可用单集');
        }
        $title    = (string) ($series['title'] ?? '');
        $summary  = trim((string) ($series['summary'] ?? ''));
        $coverUrl = VideoService::publicUrl((string) ($series['cover_path'] ?? ''));
        $html     = VideoService::appendVodFrontAssets(VideoService::renderVodEpisodesMarkup($episodes, [
            'channel'    => true,
            'series_id'  => $seriesId,
            'ep_search'  => true,
        ]));

        return app(WeappSupportGateway::class)->resultOk(['vars' => [
                'seo_title'           => $title . ' · 在线观看',
                'seo_description'     => $summary !== '' ? $summary : ($title . ' 全集选集播放'),
                'seo_keywords'        => $title,
                'page_title'          => $title,
                'series_id'           => $seriesId,
                'series_slug'         => (string) ($series['slug'] ?? ''),
                'series_title'        => $title,
                'series_summary'      => $summary,
                'series_cover_url'    => $coverUrl,
                'episode_count'       => count($episodes),
                'video_channel_html'  => $html,
                'channel_url'         => self::channelUrl((string) ($series['slug'] ?? '')),
                'home_url'            => SiteUrl::home(),
            ]], '');
    }
}
