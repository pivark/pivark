<?php
declare(strict_types=1);

namespace weapp\doc_vod\service;




use weapp\doc_vod\model\WeappVideoEpisode;
use weapp\doc_vod\model\WeappVideoGrant;
use think\facade\Db;
use app\common\service\weapp\WeappDocumentGateway;
use app\common\service\weapp\WeappFrontGateway;
use app\common\service\weapp\WeappMemberGateway;
use app\common\service\weapp\WeappPaymentGateway;
use app\common\service\weapp\WeappSupportGateway;

class VideoPurchaseService
{
    /**
     * @return mixed
     */
    public static function checkoutEpisode(int $memberId, int $episodeId, string $channel = 'alipay')
    {
        $episode = VideoAccessService::episodeRow($episodeId);
        if ($episode === null) {
            return app(WeappSupportGateway::class)->resultFail('视频不存在');
        }
        $series = VideoAccessService::seriesRow((int) ($episode['series_id'] ?? 0));
        if ($series === null) {
            return app(WeappSupportGateway::class)->resultFail('剧集不存在');
        }
        if (VideoAccessService::effectiveMode($episode, $series) !== VideoAccessService::MODE_PAID) {
            return app(WeappSupportGateway::class)->resultFail('该集无需单独购买');
        }
        if (self::hasEpisodeGrant($memberId, $episodeId) || self::hasSeriesGrant($memberId, (int) $series['id'])) {
            return app(WeappSupportGateway::class)->resultFail('您已拥有观看权限');
        }
        $price = round((float) ($episode['price'] ?? 0), 2);
        if ($price < 0.01) {
            return app(WeappSupportGateway::class)->resultFail('该集未设置售价');
        }
        if (!app(WeappPaymentGateway::class)->paymentDocumentEnabled()) {
            return app(WeappSupportGateway::class)->resultFail('在线支付未开启');
        }
        $channel = app(WeappPaymentGateway::class)->paymentNormalizeChannel($channel);
        if (!app(WeappPaymentGateway::class)->paymentIsFrontChannelAllowed($channel)) {
            return app(WeappSupportGateway::class)->resultFail(app(WeappPaymentGateway::class)->paymentChannelUnavailableMessage($channel));
        }

        return app(WeappPaymentGateway::class)->paymentCreateDocumentOrder(
            $memberId,
            VideoPaymentScenes::EPISODE,
            $episodeId,
            $channel,
            [
                'amount'  => $price,
                'title'   => mb_substr((string) ($episode['title'] ?? '视频单集'), 0, 40),
                'series_id' => (int) $series['id'],
            ]
        );
    }

    /**
     * @return mixed
     */
    public static function checkoutSeries(int $memberId, int $seriesId, string $channel = 'alipay')
    {
        $series = VideoAccessService::seriesRow($seriesId);
        if ($series === null) {
            return app(WeappSupportGateway::class)->resultFail('剧集不存在');
        }
        if (self::hasSeriesGrant($memberId, $seriesId)) {
            return app(WeappSupportGateway::class)->resultFail('您已购买该剧集');
        }
        $price = round((float) ($series['price'] ?? 0), 2);
        if ($price < 0.01) {
            return app(WeappSupportGateway::class)->resultFail('该剧集未设置售价');
        }
        if (!app(WeappPaymentGateway::class)->paymentDocumentEnabled()) {
            return app(WeappSupportGateway::class)->resultFail('在线支付未开启');
        }
        $channel = app(WeappPaymentGateway::class)->paymentNormalizeChannel($channel);
        if (!app(WeappPaymentGateway::class)->paymentIsFrontChannelAllowed($channel)) {
            return app(WeappSupportGateway::class)->resultFail(app(WeappPaymentGateway::class)->paymentChannelUnavailableMessage($channel));
        }

        return app(WeappPaymentGateway::class)->paymentCreateDocumentOrder(
            $memberId,
            VideoPaymentScenes::SERIES,
            $seriesId,
            $channel,
            [
                'amount' => $price,
                'title'  => (string) ($series['title'] ?? '视频全集'),
            ]
        );
    }

    /** @return mixed */
    public static function fulfillEpisode(int $memberId, int $episodeId, string $orderNo = '', float $amount = 0)
    {
        if ($memberId < 1 || $episodeId < 1) {
            return app(WeappSupportGateway::class)->resultFail('参数无效');
        }
        try {
            Db::transaction(function () use ($memberId, $episodeId, $orderNo, $amount): void {
                try {
                    WeappVideoGrant::insert([
                        'user_id'          => $memberId,
                        'grant_type'       => 'episode',
                        'ref_id'           => $episodeId,
                        'payment_order_no' => $orderNo,
                        'amount'           => number_format($amount, 2, '.', ''),
                        'created_at'       => app(WeappSupportGateway::class)->appTimeNow(),
                    ]);
                } catch (\Throwable $e) {
                    if (!str_contains($e->getMessage(), 'uk_user_grant')) {
                        throw $e;
                    }
                }
                if ($amount > 0) {
                    app(WeappMemberGateway::class)->memberPointGiftTryGrantConsume($memberId, $amount, '购买视频：' . $orderNo);
                }
            });
        } catch (\Throwable) {
            return app(WeappSupportGateway::class)->resultFail('授权失败');
        }

        return app(WeappSupportGateway::class)->resultOk(null, '已开通观看');
    }

    /** @return mixed */
    public static function fulfillSeries(int $memberId, int $seriesId, string $orderNo = '', float $amount = 0)
    {
        if ($memberId < 1 || $seriesId < 1) {
            return app(WeappSupportGateway::class)->resultFail('参数无效');
        }
        try {
            Db::transaction(function () use ($memberId, $seriesId, $orderNo, $amount): void {
                try {
                    WeappVideoGrant::insert([
                        'user_id'          => $memberId,
                        'grant_type'       => 'series',
                        'ref_id'           => $seriesId,
                        'payment_order_no' => $orderNo,
                        'amount'           => number_format($amount, 2, '.', ''),
                        'created_at'       => app(WeappSupportGateway::class)->appTimeNow(),
                    ]);
                } catch (\Throwable $e) {
                    if (!str_contains($e->getMessage(), 'uk_user_grant')) {
                        throw $e;
                    }
                }
                if ($amount > 0) {
                    app(WeappMemberGateway::class)->memberPointGiftTryGrantConsume($memberId, $amount, '购买剧集：' . $orderNo);
                }
            });
        } catch (\Throwable) {
            return app(WeappSupportGateway::class)->resultFail('授权失败');
        }

        return app(WeappSupportGateway::class)->resultOk(null, '已开通全集');
    }

    public static function hasEpisodeGrant(int $memberId, int $episodeId): bool
    {
        if ($memberId < 1 || $episodeId < 1 || !VideoAccessService::schemaReady()) {
            return false;
        }

        return WeappVideoGrant::where('user_id', $memberId)
            ->where('grant_type', 'episode')
            ->where('ref_id', $episodeId)
            ->count() > 0;
    }

    public static function hasSeriesGrant(int $memberId, int $seriesId): bool
    {
        if ($memberId < 1 || $seriesId < 1 || !VideoAccessService::schemaReady()) {
            return false;
        }

        return WeappVideoGrant::where('user_id', $memberId)
            ->where('grant_type', 'series')
            ->where('ref_id', $seriesId)
            ->count() > 0;
    }

    /** 退款后按订单号删 grant（蓝队 K-2） */
    public static function revokeByOrderNo(string $orderNo): void
    {
        $orderNo = trim($orderNo);
        if ($orderNo === '' || !VideoAccessService::schemaReady()) {
            return;
        }
        WeappVideoGrant::where('payment_order_no', $orderNo)->delete();
    }

    /**
     * @return mixed
     */
    public static function listGrantsForMember(int $memberId, int $page = 1, int $limit = 20)
    {
        if ($memberId < 1 || !VideoAccessService::schemaReady()) {
            return app(WeappSupportGateway::class)->resultOk(['total' => 0], '');
        }
        $page  = max(1, $page);
        $limit = min(max($limit, 1), 50);
        $query = WeappVideoGrant::where('user_id', $memberId)->order('id', 'desc');
        $total = (int) $query->count();
        $rows  = $query->page($page, $limit)->select()->toArray();
        $list  = [];
        foreach ($rows as $row) {
            $type = (string) ($row['grant_type'] ?? '');
            $ref  = (int) ($row['ref_id'] ?? 0);
            $title       = '';
            $seriesTitle = '';
            $documentUrl = '';
            if ($type === 'episode') {
                $ep = VideoAccessService::episodeRow($ref);
                $title = (string) ($ep['title'] ?? ('单集 #' . $ref));
                $sr    = VideoAccessService::seriesRow((int) ($ep['series_id'] ?? 0));
                $seriesTitle = (string) ($sr['title'] ?? '');
                $documentUrl = self::documentUrlForEpisode(is_array($ep) ? $ep : [], $ref);
            } elseif ($type === 'series') {
                $sr = VideoAccessService::seriesRow($ref);
                $title = (string) ($sr['title'] ?? ('剧集 #' . $ref));
                $seriesTitle = $title;
            }
            $list[] = [
                'grant_type'       => $type,
                'grant_type_label' => $type === 'series' ? '全集' : '单集',
                'ref_id'           => $ref,
                'title'            => $title,
                'series_title'     => $seriesTitle,
                'document_url'     => $documentUrl,
                'has_doc_link'     => $documentUrl !== '' ? 1 : 0,
                'amount'           => round((float) ($row['amount'] ?? 0), 2),
                'amount_text'      => '¥' . number_format((float) ($row['amount'] ?? 0), 2, '.', ''),
                'payment_order_no' => (string) ($row['payment_order_no'] ?? ''),
                'created_at'       => (string) ($row['created_at'] ?? ''),
            ];
        }

        return app(WeappSupportGateway::class)->resultOk(['list' => $list, 'total' => $total], '');
    }

    /** 支付成功后跳转文档续播（带 video_unlock 参数） */
    public static function watchUrlForOrder(?array $order): string
    {
        if (!is_array($order) || (string) ($order['status'] ?? '') !== 'paid') {
            return '';
        }
        $scene = (string) ($order['scene'] ?? '');
        $refId = (int) ($order['ref_id'] ?? 0);
        if ($refId < 1) {
            return '';
        }
        if ($scene === VideoPaymentScenes::EPISODE) {
            $ep = VideoAccessService::episodeRow($refId);

            return self::documentUrlForEpisode(is_array($ep) ? $ep : [], $refId);
        }
        if ($scene === VideoPaymentScenes::SERIES) {
            $ep = WeappVideoEpisode::where('series_id', $refId)
                ->where('status', 1)
                ->order(['sort' => 'asc', 'ep_no' => 'asc', 'id' => 'asc'])
                ->find();

            return self::documentUrlForEpisode(is_array($ep) ? $ep : [], (int) ($ep['id'] ?? 0));
        }

        return '';
    }

    /** @param array<string, mixed> $episode */
    private static function documentUrlForEpisode(array $episode, int $episodeId = 0): string
    {
        $documentId = (int) ($episode['document_id'] ?? 0);
        if ($documentId < 1) {
            return '';
        }
        $doc = app(WeappDocumentGateway::class)->documentRowById($documentId, true);
        if (!is_array($doc) || $doc === []) {
            return '';
        }

        $url = app(WeappFrontGateway::class)->frontBuildDocumentUrl($doc);
        if ($url !== '' && $episodeId > 0) {
            $url .= (str_contains($url, '?') ? '&' : '?') . 'video_unlock=' . $episodeId;
        }

        return $url;
    }
}
