<?php
/**
 * 元舟 PivArk — 企业全域原子化数字资产中枢
 * (c) 2024-2026 pivark.com. All rights reserved.
 * Author: Angelo
 * 未经允许，不可用于商业用途。
 */
declare(strict_types=1);

namespace weapp\doc_vod\service;


use app\common\service\weapp\WeappSupportGateway;
final class VideoDocumentAddonVodSync
{
    /** @param list<array<string, mixed>> $rows */
    public static function syncVodForDocument(int $documentId, array $rows)
    {
        $bridge = new VideoDocumentAddonBridge();
        if (!$bridge->isEnabled()) {
            return app(WeappSupportGateway::class)->resultOk(null, 'ok');
        }

        return $bridge->syncVodForDocument($documentId, $rows);
    }
}