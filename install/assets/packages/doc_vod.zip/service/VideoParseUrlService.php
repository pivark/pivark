<?php
declare(strict_types=1);

namespace weapp\doc_vod\service;

/** 外置解析站：支持多线路 failover */
class VideoParseUrlService
{
    public static function resolvePlayUrl(string $playUrl): string
    {
        $playUrl = trim($playUrl);
        if ($playUrl === '') {
            return '';
        }
        foreach (VideoConfigService::parseApiUrls() as $template) {
            $resolved = self::resolveViaTemplate($playUrl, $template);
            if ($resolved !== '' && $resolved !== $playUrl) {
                return $resolved;
            }
        }

        return $playUrl;
    }

    private static function resolveViaTemplate(string $playUrl, string $template): string
    {
        $template = trim($template);
        if ($template === '') {
            return '';
        }
        $endpoint = str_contains($template, '{url}')
            ? str_replace('{url}', rawurlencode($playUrl), $template)
            : rtrim($template, '&?') . (str_contains($template, '?') ? '&' : '?') . 'url=' . rawurlencode($playUrl);

        $body = VideoHttpClient::get($endpoint);
        if ($body === '') {
            return '';
        }
        $data = json_decode($body, true);
        if (!is_array($data)) {
            return '';
        }
        if (($data['code'] ?? 0) === 200 || ($data['success'] ?? false) === true) {
            $resolved = trim((string) (
                $data['data']['url']
                ?? $data['data']['play_url']
                ?? $data['url']
                ?? $data['play_url']
                ?? ''
            ));
            if ($resolved !== '') {
                return $resolved;
            }
        }

        return '';
    }
}
