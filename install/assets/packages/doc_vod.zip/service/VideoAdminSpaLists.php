<?php
declare(strict_types=1);

namespace weapp\doc_vod\service;

/** 后台 SPA 列表扩展（admin.spa_plugin_list） */
final class VideoAdminSpaLists
{
    /** @param array<string, mixed> $query @return array<string, mixed> */
    public static function itemsList(array $query): array
    {
        VideoService::ensureAutoload();
        $page  = max(1, (int) ($query['page'] ?? 1));
        $limit = max(10, min(100, (int) ($query['limit'] ?? 20)));
        $filters = [
            'status'      => (string) ($query['status'] ?? ''),
            'document_id' => (int) ($query['document_id'] ?? 0),
            'keyword'     => (string) ($query['keyword'] ?? ''),
        ];
        $res = VideoService::listAdmin($filters, $page, $limit);
        if (!$res->isOk()) {
            return ['list' => [], 'total' => 0, 'page' => $page, 'limit' => $limit];
        }
        $data = $res->dataArray();

        return [
            'list'  => is_array($data['list'] ?? null) ? $data['list'] : [],
            'total' => (int) ($data['total'] ?? 0),
            'page'  => $page,
            'limit' => $limit,
        ];
    }
}
