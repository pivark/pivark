<?php
declare(strict_types=1);

namespace weapp\doc_vod\service;



use weapp\doc_vod\model\WeappVideoEpisode;
use weapp\doc_vod\model\WeappVideoSource;
use think\facade\Cache;
use think\facade\Db;
use app\common\service\weapp\WeappPluginGateway;
use app\common\service\weapp\WeappFrontGateway;
use app\common\service\weapp\WeappPaymentGateway;
use app\common\service\weapp\WeappSupportGateway;

class VideoPlaybackService
{
    public static function boot(): void
    {
        app(WeappPluginGateway::class)->pluginRouteRegister('get', 'api/v1/plugins/doc_vod/play', '\\weapp\\doc_vod\\api\\controller\\Video@play');
        app(WeappPluginGateway::class)->pluginRouteRegister('post', 'api/v1/plugins/doc_vod/checkout/episode', '\\weapp\\doc_vod\\api\\controller\\Video@checkoutEpisode');
        app(WeappPluginGateway::class)->pluginRouteRegister('post', 'api/v1/plugins/doc_vod/checkout/series', '\\weapp\\doc_vod\\api\\controller\\Video@checkoutSeries');
        app(WeappPluginGateway::class)->pluginRouteRegister('get', 'api/v1/plugins/doc_vod/grants', '\\weapp\\doc_vod\\api\\controller\\Video@grants');
        VideoWatchProgressService::boot();
        VideoFunnelService::boot();
    }

    /**
     * @return mixed
     */
    public static function playPayload(?array $member, int $episodeId)
    {
        if (!VideoService::isActive() || !VideoAccessService::schemaReady()) {
            return app(WeappSupportGateway::class)->resultFail('视频功能未开启');
        }
        $ttl = VideoConfigService::playCacheSec();
        $memberId = (int) ($member['id'] ?? 0);
        if ($ttl > 0 && $episodeId > 0) {
            $cacheKey = 'pv_vod_play:' . $episodeId . ':' . $memberId;
            $cached   = Cache::get($cacheKey);
            if (is_array($cached) && $cached->isOk()) {
                return $cached;
            }
        }
        $payload = self::buildPlayPayload($member, $episodeId);
        if ($ttl > 0 && $episodeId > 0 && $payload->isOk() && ($payload['allowed'] ?? 0) === 1) {
            Cache::set('pv_vod_play:' . $episodeId . ':' . $memberId, $payload, $ttl);
        }

        return $payload;
    }

    /**
     * @return mixed
     */
    private static function buildPlayPayload(?array $member, int $episodeId)
    {
        $decision = VideoAccessService::decision($member, $episodeId);
        if (($decision['allowed'] ?? 0) !== 1) {
            $need  = (string) ($decision['need'] ?? '');
            $epRow = VideoAccessService::episodeRow($episodeId) ?? [];
            $srRow = VideoAccessService::seriesRow((int) ($epRow['series_id'] ?? 0)) ?? [];

            return self::attachPaymentChannels(app(WeappSupportGateway::class)->resultOk([
                'allowed'      => 0,
                'need'         => $need,
                'cta_url'      => (string) ($decision['cta_url'] ?? ''),
                'cta_label'    => (string) ($decision['cta_label'] ?? ''),
                'login_url'    => $need === 'login' ? SiteUrl::memberLogin() : '',
                'recharge_url' => $need === 'level' ? SiteUrl::memberRecharge() : '',
                'price_text'   => VideoEpisodeDisplayService::priceText($epRow, $srRow, $decision),
                'episode_id'   => $episodeId,
                'series_id'    => (int) ($epRow['series_id'] ?? $srRow['id'] ?? 0),
            ], (string) ($decision['reason'] ?? '无权观看')));
        }

        $episode = $decision['episode'] ?? [];
        $memberId = (int) ($member['id'] ?? 0);
        $trialMode = (int) ($decision['trial_mode'] ?? 0);
        $trialSec  = (int) ($decision['trial_sec'] ?? 0);
        $payNeed   = '';
        $trialCtaUrl = '';
        $trialCtaLabel = '';
        if ($trialMode) {
            $epRow = is_array($decision['episode'] ?? null) ? $decision['episode'] : [];
            $srRow = is_array($decision['series'] ?? null) ? $decision['series'] : [];
            $mode = VideoAccessService::effectiveMode($epRow, $srRow);
            $payNeed = $mode === VideoAccessService::MODE_PAID_SERIES ? 'pay_series' : 'pay_episode';
            $trialCtaLabel = $payNeed === 'pay_series' ? '购买全集' : '购买本集';
            if ($memberId < 1) {
                $trialCtaUrl = SiteUrl::memberLogin();
                $trialCtaLabel = '登录观看';
            }
        }
        self::bumpPlayCount($episodeId);
        $sources = WeappVideoSource::where('episode_id', $episodeId)
            ->where('status', 1)
            ->order(['priority' => 'desc', 'id' => 'asc'])
            ->select()
            ->toArray();
        $plays = [];
        foreach ($sources as $src) {
            $plays[] = VideoSourceResolver::resolve(
                is_array($src) ? $src : [],
                (string) ($episode['title'] ?? ''),
                (string) ($episode['cover_path'] ?? '')
            );
        }

        $progressSec = 0;
        if ($memberId > 0) {
            $prog = VideoWatchProgressService::getForUser($memberId, $episodeId);
            $progressSec = (int) ($prog['position_sec'] ?? 0);
        }

        $durationSec = max(0, (int) ($episode['duration_sec'] ?? 0));
        $documentId  = (int) ($episode['document_id'] ?? 0);
        $seriesId    = (int) ($episode['series_id'] ?? 0);
        $nextId      = self::nextEpisodeId($documentId, $episodeId, $seriesId);

        return self::attachPaymentChannels(app(WeappSupportGateway::class)->resultOk([
            'allowed'        => 1,
            'trial_mode'     => $trialMode,
            'trial_sec'      => $trialSec,
            'need'           => $payNeed,
            'cta_url'        => $trialCtaUrl,
            'cta_label'      => $trialCtaLabel,
            'login_url'      => $memberId < 1 ? SiteUrl::memberLogin() : '',
            'recharge_url'   => SiteUrl::memberRecharge(),
            'episode_id'     => $episodeId,
            'series_id'      => (int) ($episode['series_id'] ?? 0),
            'document_id'    => $documentId,
            'next_episode_id'=> $nextId,
            'duration_sec'   => $durationSec,
            'progress_sec'   => $progressSec,
            'resume_hint'    => $progressSec > 0 ? ('上次看到 ' . VideoEpisodeDisplayService::formatClock($progressSec)) : '',
            'resume_choose'  => $progressSec > 30 ? 1 : 0,
            'ad_cues'        => self::parseAdCues((string) ($episode['ad_cues_json'] ?? '')),
            'episode'        => [
                'id'        => $episodeId,
                'title'     => (string) ($episode['title'] ?? ''),
                'ep_no'     => (int) ($episode['ep_no'] ?? 0),
                'series_id' => (int) ($episode['series_id'] ?? 0),
            ],
            'play'           => $plays[0] ?? ['type' => 'none', 'embed_html' => ''],
            'sources'        => $plays,
        ]));
    }

    private static function attachPaymentChannels(ServiceResult $payload)
    {
        $flags = app(WeappPaymentGateway::class)->paymentFrontFlags();
        $data = $payload->dataArray();
        $data['payment_channels'] = $flags['channels'];
        $data['pay_wechat']       = $flags['wechat'];
        $data['pay_alipay']       = $flags['alipay'];

        return app(WeappSupportGateway::class)->resultOk($data, $payload->message(), $payload->meta());
    }

    private static function bumpPlayCount(int $episodeId): void
    {
        if ($episodeId < 1) {
            return;
        }
        try {
            $epRow = VideoAccessService::episodeRow($episodeId);
            WeappVideoEpisode::where('id', $episodeId)->inc('play_count')->update();
            VideoStatsService::recordDailyPlay();
            if (is_array($epRow)) {
                VideoStatsService::recordEpisodeDailyPlay(
                    $episodeId,
                    (int) ($epRow['series_id'] ?? 0)
                );
            }
        } catch (\Throwable $e) {
            // play_count 列可能尚未迁移；记日志禁静默吞
            app(WeappSupportGateway::class)->kernelOpsLog('vod_bump_play_count_failed', [
                'episode_id' => $episodeId,
                'msg'        => $e->getMessage(),
            ]);
        }
    }

    /** @return list<array<string, mixed>> */
    private static function formatDuration(int $sec): string
    {
        if ($sec < 60) {
            return $sec . ' 秒';
        }
        $m = (int) floor($sec / 60);
        $s = $sec % 60;

        return $m . ' 分 ' . $s . ' 秒';
    }

    private static function parseAdCues(string $json): array
    {
        if ($json === '') {
            return [];
        }
        $data = json_decode($json, true);
        if (!is_array($data)) {
            return [];
        }
        $out = [];
        foreach ($data as $cue) {
            if (!is_array($cue)) {
                continue;
            }
            $at = (int) ($cue['at_sec'] ?? $cue['at'] ?? 0);
            if ($at < 0) {
                continue;
            }
            $out[] = [
                'at_sec'  => $at,
                'type'    => (string) ($cue['type'] ?? 'image'),
                'content' => (string) ($cue['content'] ?? $cue['url'] ?? ''),
                'link'    => (string) ($cue['link'] ?? ''),
            ];
        }
        usort($out, static fn ($a, $b) => ($a['at_sec'] ?? 0) <=> ($b['at_sec'] ?? 0));

        return $out;
    }

    /** @return list<array<string, mixed>> */
    public static function listEpisodesForDocument(int $documentId): array
    {
        if ($documentId < 1 || !VideoAccessService::schemaReady()) {
            return [];
        }
        $rows = WeappVideoEpisode::where('document_id', $documentId)
            ->where('status', 1)
            ->order(['sort' => 'asc', 'ep_no' => 'asc', 'id' => 'asc'])
            ->select()
            ->toArray();

        return self::enrichEpisodeRows($rows);
    }

    /** @return list<array<string, mixed>> */
    public static function listEpisodesForSeries(int $seriesId): array
    {
        if ($seriesId < 1 || !VideoAccessService::schemaReady()) {
            return [];
        }
        $rows = WeappVideoEpisode::where('series_id', $seriesId)
            ->where('status', 1)
            ->order(['sort' => 'asc', 'ep_no' => 'asc', 'id' => 'asc'])
            ->select()
            ->toArray();

        return self::enrichEpisodeRows($rows);
    }

    /**
     * @param list<array<string, mixed>> $rows
     * @return list<array<string, mixed>>
     */
    private static function enrichEpisodeRows(array $rows): array
    {
        $member   = app(WeappFrontGateway::class)->frontCurrent();
        $memberId = (int) ($member['id'] ?? 0);
        $epIds    = [];
        $seriesCache = [];
        foreach ($rows as $row) {
            if (!is_array($row)) {
                continue;
            }
            $id = (int) ($row['id'] ?? 0);
            if ($id > 0) {
                $epIds[] = $id;
            }
        }
        $sourceCounts = self::batchSourceCounts($epIds);
        $out          = [];
        foreach ($rows as $row) {
            if (!is_array($row)) {
                continue;
            }
            $id       = (int) ($row['id'] ?? 0);
            $seriesId = (int) ($row['series_id'] ?? 0);
            if (!isset($seriesCache[$seriesId])) {
                $seriesCache[$seriesId] = VideoAccessService::seriesRow($seriesId) ?? [];
            }
            $series = $seriesCache[$seriesId];
            $dec    = VideoAccessService::decision($member, $id);
            $prog   = 0;
            if ($memberId > 0) {
                $p = VideoWatchProgressService::getForUser($memberId, $id);
                $prog = (int) ($p['position_sec'] ?? 0);
            }
            $display = VideoEpisodeDisplayService::listFields($row, $series, $dec, $prog);
            $out[]   = array_merge([
                'id'           => $id,
                'series_id'    => $seriesId,
                'document_id'  => (int) ($row['document_id'] ?? 0),
                'title'        => (string) ($row['title'] ?? ''),
                'ep_no'        => (int) ($row['ep_no'] ?? 0),
                'cover_url'    => VideoService::publicUrl((string) ($row['cover_path'] ?? '')),
                'allowed'      => (int) ($dec['allowed'] ?? 0),
                'need'         => (string) ($dec['need'] ?? ''),
                'source_count' => $sourceCounts[$id] ?? 0,
            ], $display);
        }

        return $out;
    }

    /** @param list<int> $episodeIds @return array<int, int> */
    private static function batchSourceCounts(array $episodeIds): array
    {
        $episodeIds = array_values(array_unique(array_filter(array_map('intval', $episodeIds))));
        if ($episodeIds === []) {
            return [];
        }
        $rows = WeappVideoSource::whereIn('episode_id', $episodeIds)
            ->where('status', 1)
            ->field('episode_id, COUNT(*) AS cnt')
            ->group('episode_id')
            ->select()
            ->toArray();
        $out = [];
        foreach ($rows as $row) {
            if (!is_array($row)) {
                continue;
            }
            $out[(int) ($row['episode_id'] ?? 0)] = (int) ($row['cnt'] ?? 0);
        }

        return $out;
    }

    private static function nextEpisodeId(int $documentId, int $currentId, int $seriesId = 0): int
    {
        if ($currentId < 1) {
            return 0;
        }
        if ($documentId > 0) {
            $ids = WeappVideoEpisode::where('document_id', $documentId)
                ->where('status', 1)
                ->order(['sort' => 'asc', 'ep_no' => 'asc', 'id' => 'asc'])
                ->column('id');
        } elseif ($seriesId > 0) {
            $ids = WeappVideoEpisode::where('series_id', $seriesId)
                ->where('status', 1)
                ->order(['sort' => 'asc', 'ep_no' => 'asc', 'id' => 'asc'])
                ->column('id');
        } else {
            return 0;
        }
        $ids = array_map('intval', $ids);
        $pos = array_search($currentId, $ids, true);
        if ($pos === false || !isset($ids[$pos + 1])) {
            return 0;
        }

        return (int) $ids[$pos + 1];
    }
}
