<?php
declare(strict_types=1);

namespace weapp\doc_vod\service;



use app\common\support\AppTime;
use app\common\service\weapp\WeappEntitlementGateway;
use app\common\service\weapp\WeappSearchGateway;
use app\common\service\weapp\WeappSupportGateway;

use weapp\doc_vod\model\WeappVideoEpisode;
use weapp\doc_vod\model\WeappVideoSeries;
use weapp\doc_vod\model\WeappVideoSource;
use think\facade\Db;

/** 剧集/单集后台维护 */
class VideoCatalogService
{
    /** @param array<string, mixed> $filters */
    public static function listSeriesAdmin(array $filters, int $page = 1, int $limit = 20)
    {
        if (!app(WeappEntitlementGateway::class)->entitlementCan('doc_vod') || !VideoAccessService::schemaReady()) {
            return app(WeappSupportGateway::class)->resultFail('不可用');
        }
        $query = WeappVideoSeries::order('sort', 'asc')->order('id', 'desc');
        $kw = trim((string) ($filters['keyword'] ?? ''));
        if ($kw !== '') {
            $query->whereLike('title|slug', app(WeappSearchGateway::class)->searchLikePattern($kw));
        }
        if (($filters['status'] ?? '') !== '') {
            $query->where('status', (int) $filters['status']);
        }
        $total = (int) (clone $query)->count();
        $list  = $query->page(max(1, $page), min(100, max(10, $limit)))->select()->toArray();
        foreach ($list as $i => $row) {
            if (!is_array($row)) {
                continue;
            }
            $slug = trim((string) ($row['slug'] ?? ''));
            $list[$i]['channel_url'] = $slug !== '' && VideoConfigService::seriesChannelOpen()
                ? VideoChannelService::channelUrl($slug)
                : '';
        }

        return app(WeappSupportGateway::class)->resultList($list, $total);
    }

    /** @param array<string, mixed> $data */
    public static function saveSeriesAdmin(array $data)
    {
        if (!VideoAccessService::schemaReady()) {
            return app(WeappSupportGateway::class)->resultFail('请先执行视频点播迁移');
        }
        $id    = (int) ($data['id'] ?? 0);
        $title = trim((string) ($data['title'] ?? ''));
        if ($title === '') {
            return app(WeappSupportGateway::class)->resultFail('请填写剧集名称');
        }
        $payload = [
            'title'         => $title,
            'slug'          => trim((string) ($data['slug'] ?? '')),
            'cover_path'    => trim((string) ($data['cover_path'] ?? '')),
            'summary'       => trim((string) ($data['summary'] ?? '')),
            'access_mode'   => self::normMode((string) ($data['access_mode'] ?? 'free')),
            'read_level_id' => max(0, (int) ($data['read_level_id'] ?? 0)),
            'price'              => number_format(max(0, (float) ($data['price'] ?? 0)), 2, '.', ''),
            'trial_preview_sec'  => max(0, min(3600, (int) ($data['trial_preview_sec'] ?? 0))),
            'free_ep_count'      => max(0, min(500, (int) ($data['free_ep_count'] ?? 0))),
            'sort'               => (int) ($data['sort'] ?? 0),
            'status'             => !empty($data['status']) ? 1 : 0,
            'updated_at'         => app(WeappSupportGateway::class)->appTimeNow(),
        ];
        if ($id > 0) {
            WeappVideoSeries::where('id', $id)->update($payload);

            return app(WeappSupportGateway::class)->resultOk(['id' => $id], '已更新');
        }
        $payload['created_at'] = app(WeappSupportGateway::class)->appTimeNow();
        $newId = (int) WeappVideoSeries::insertGetId($payload);

        return app(WeappSupportGateway::class)->resultOk(['id' => $newId], '已创建');
    }

    public static function listEpisodesAdmin(int $seriesId, int $page = 1, int $limit = 50)
    {
        if ($seriesId < 1 || !VideoAccessService::schemaReady()) {
            return app(WeappSupportGateway::class)->resultFail('剧集不可用');
        }
        $query = WeappVideoEpisode::where('series_id', $seriesId)->order(['sort' => 'asc', 'ep_no' => 'asc']);
        $total = (int) (clone $query)->count();
        $list  = $query->page(max(1, $page), min(100, max(10, $limit)))->select()->toArray();
        $out   = [];
        foreach ($list as $row) {
            if (!is_array($row)) {
                continue;
            }
            $episodeId = (int) ($row['id'] ?? 0);
            $srcRows = WeappVideoSource::where('episode_id', $episodeId)
                ->where('status', 1)
                ->order(['priority' => 'desc', 'id' => 'asc'])
                ->select()
                ->toArray();
            $sources = [];
            foreach ($srcRows as $src) {
                if (!is_array($src)) {
                    continue;
                }
                $health = VideoSourceHealthService::healthFromConfig((string) ($src['config_json'] ?? ''));
                $sources[] = [
                    'id'           => (int) ($src['id'] ?? 0),
                    'provider'     => (string) ($src['provider'] ?? 'embed'),
                    'play_url'     => (string) ($src['play_url'] ?? ''),
                    'priority'     => (int) ($src['priority'] ?? 0),
                    'config_json'  => (string) ($src['config_json'] ?? ''),
                    'label'        => VideoSourceCatalog::label($src),
                    'health_status'=> (string) ($health['status'] ?? ''),
                    'health_msg'   => (string) ($health['msg'] ?? ($health['message'] ?? '')),
                ];
            }
            $row['sources']  = $sources;
            $first           = $sources[0] ?? null;
            $row['play_url'] = is_array($first) ? (string) ($first['play_url'] ?? '') : '';
            $row['provider'] = is_array($first) ? (string) ($first['provider'] ?? 'embed') : 'embed';
            if (!empty($row['ad_cues_json'])) {
                $decoded = json_decode((string) $row['ad_cues_json'], true);
                $row['ad_cues'] = is_array($decoded) ? $decoded : [];
            } else {
                $row['ad_cues'] = [];
            }
            $out[] = $row;
        }

        return app(WeappSupportGateway::class)->resultList($out, $total);
    }

    /** @param array<string, mixed> $data */
    public static function saveEpisodeAdmin(array $data)
    {
        if (!VideoAccessService::schemaReady()) {
            return app(WeappSupportGateway::class)->resultFail('请先执行视频点播迁移');
        }
        $seriesId = (int) ($data['series_id'] ?? 0);
        if ($seriesId < 1 || VideoAccessService::seriesRow($seriesId) === null) {
            return app(WeappSupportGateway::class)->resultFail('请选择有效剧集');
        }
        $id    = (int) ($data['id'] ?? 0);
        $title = trim((string) ($data['title'] ?? ''));
        if ($title === '') {
            return app(WeappSupportGateway::class)->resultFail('请填写单集标题');
        }
        $payload = [
            'series_id'     => $seriesId,
            'document_id'   => max(0, (int) ($data['document_id'] ?? 0)),
            'ep_no'         => max(0, (int) ($data['ep_no'] ?? 0)),
            'title'         => $title,
            'cover_path'    => trim((string) ($data['cover_path'] ?? '')),
            'access_mode'   => trim((string) ($data['access_mode'] ?? '')),
            'read_level_id' => max(0, (int) ($data['read_level_id'] ?? 0)),
            'price'              => number_format(max(0, (float) ($data['price'] ?? 0)), 2, '.', ''),
            'trial_preview_sec'  => max(0, min(3600, (int) ($data['trial_preview_sec'] ?? 0))),
            'duration_sec'       => max(0, (int) ($data['duration_sec'] ?? 0)),
            'ad_cues_json'       => self::normAdCuesJson($data['ad_cues_json'] ?? ''),
            'sort'               => (int) ($data['sort'] ?? 0),
            'status'        => !empty($data['status']) ? 1 : 0,
            'updated_at'    => app(WeappSupportGateway::class)->appTimeNow(),
        ];
        if ($id > 0) {
            WeappVideoEpisode::where('id', $id)->update($payload);
            self::syncSources($id, $data);

            return app(WeappSupportGateway::class)->resultOk(['id' => $id], '已更新');
        }
        $payload['created_at'] = app(WeappSupportGateway::class)->appTimeNow();
        $newId = (int) WeappVideoEpisode::insertGetId($payload);
        self::syncSources($newId, $data);

        return app(WeappSupportGateway::class)->resultOk(['id' => $newId], '已添加');
    }

    /** @param array<string, mixed> $data */
    public static function batchPatchEpisodesAdmin(array $data)
    {
        if (!VideoAccessService::schemaReady()) {
            return app(WeappSupportGateway::class)->resultFail('请先执行视频点播迁移');
        }
        $seriesId = (int) ($data['series_id'] ?? 0);
        if ($seriesId < 1) {
            return app(WeappSupportGateway::class)->resultFail('请选择剧集');
        }
        $ids = $data['episode_ids'] ?? [];
        if (is_string($ids)) {
            $decoded = json_decode($ids, true);
            $ids     = is_array($decoded) ? $decoded : [];
        }
        if (!is_array($ids) || $ids === []) {
            return app(WeappSupportGateway::class)->resultFail('请选择单集');
        }
        $patch = [];
        if (array_key_exists('access_mode', $data) && trim((string) $data['access_mode']) !== '') {
            $patch['access_mode'] = trim((string) $data['access_mode']);
        }
        if (!empty($data['patch_trial'])) {
            $patch['trial_preview_sec'] = max(0, min(3600, (int) ($data['trial_preview_sec'] ?? 0)));
        }
        if (array_key_exists('price', $data)) {
            $patch['price'] = number_format(max(0, (float) $data['price']), 2, '.', '');
        }
        if ($patch === []) {
            return app(WeappSupportGateway::class)->resultFail('无批量字段');
        }
        $patch['updated_at'] = app(WeappSupportGateway::class)->appTimeNow();
        $count = 0;
        foreach ($ids as $id) {
            $epId = (int) $id;
            if ($epId < 1) {
                continue;
            }
            $n = WeappVideoEpisode::where('id', $epId)
                ->where('series_id', $seriesId)
                ->update($patch);
            if ($n) {
                $count++;
            }
        }

        return app(WeappSupportGateway::class)->resultOk(['updated' => $count], "已更新 {$count} 条单集");
    }

    /** @param array<string, mixed> $data */
    public static function duplicateSeriesAdmin(array $data)
    {
        if (!VideoAccessService::schemaReady()) {
            return app(WeappSupportGateway::class)->resultFail('请先执行视频点播迁移');
        }
        $seriesId = (int) ($data['series_id'] ?? $data['id'] ?? 0);
        $src      = VideoAccessService::seriesRow($seriesId);
        if ($src === null) {
            return app(WeappSupportGateway::class)->resultFail('剧集不存在');
        }
        $slug = trim((string) ($src['slug'] ?? ''));
        if ($slug === '') {
            $slug = 'series-' . $seriesId;
        }
        $slug .= '-copy-' . AppTime::format('His');
        $payload = [
            'title'              => trim((string) ($src['title'] ?? '')) . '（副本）',
            'slug'               => $slug,
            'cover_path'         => trim((string) ($src['cover_path'] ?? '')),
            'summary'            => trim((string) ($src['summary'] ?? '')),
            'access_mode'        => (string) ($src['access_mode'] ?? 'free'),
            'read_level_id'      => max(0, (int) ($src['read_level_id'] ?? 0)),
            'price'              => (string) ($src['price'] ?? '0.00'),
            'trial_preview_sec'  => max(0, (int) ($src['trial_preview_sec'] ?? 0)),
            'free_ep_count'      => max(0, (int) ($src['free_ep_count'] ?? 0)),
            'sort'               => (int) ($src['sort'] ?? 0),
            'status'             => 0,
            'created_at'         => app(WeappSupportGateway::class)->appTimeNow(),
            'updated_at'         => app(WeappSupportGateway::class)->appTimeNow(),
        ];
        $newSeriesId = (int) WeappVideoSeries::insertGetId($payload);
        $episodes    = WeappVideoEpisode::where('series_id', $seriesId)->select()->toArray();
        $copied      = 0;
        foreach ($episodes as $ep) {
            if (!is_array($ep)) {
                continue;
            }
            $oldEpId = (int) ($ep['id'] ?? 0);
            $epPayload = [
                'series_id'          => $newSeriesId,
                'document_id'        => 0,
                'ep_no'              => (int) ($ep['ep_no'] ?? 0),
                'title'              => (string) ($ep['title'] ?? ''),
                'cover_path'         => (string) ($ep['cover_path'] ?? ''),
                'access_mode'        => (string) ($ep['access_mode'] ?? ''),
                'read_level_id'      => max(0, (int) ($ep['read_level_id'] ?? 0)),
                'price'              => (string) ($ep['price'] ?? '0.00'),
                'trial_preview_sec'  => max(0, (int) ($ep['trial_preview_sec'] ?? 0)),
                'duration_sec'       => max(0, (int) ($ep['duration_sec'] ?? 0)),
                'ad_cues_json'       => (string) ($ep['ad_cues_json'] ?? ''),
                'sort'               => (int) ($ep['sort'] ?? 0),
                'status'             => (int) ($ep['status'] ?? 1),
                'created_at'         => app(WeappSupportGateway::class)->appTimeNow(),
                'updated_at'         => app(WeappSupportGateway::class)->appTimeNow(),
            ];
            $newEpId = (int) WeappVideoEpisode::insertGetId($epPayload);
            $sources           = WeappVideoSource::where('episode_id', $oldEpId)->select()->toArray();
            foreach ($sources as $s) {
                if (!is_array($s)) {
                    continue;
                }
                unset($s['id']);
                $s['episode_id']  = $newEpId;
                $s['created_at']  = app(WeappSupportGateway::class)->appTimeNow();
                $s['updated_at']  = $s['created_at'];
                WeappVideoSource::insert($s);
            }
            $copied++;
        }

        return app(WeappSupportGateway::class)->resultOk(['id' => $newSeriesId, 'slug' => $slug, 'channel_url' => VideoChannelService::channelUrl($slug)], "已复制剧集，含 {$copied} 集（默认停用，请检查 slug）");
    }

    /** @param array<string, mixed> $data */
    public static function importEpisodesCsvAdmin(array $data)
    {
        if (!VideoAccessService::schemaReady()) {
            return app(WeappSupportGateway::class)->resultFail('请先执行视频点播迁移');
        }
        $seriesId = (int) ($data['series_id'] ?? 0);
        if ($seriesId < 1 || VideoAccessService::seriesRow($seriesId) === null) {
            return app(WeappSupportGateway::class)->resultFail('请选择有效剧集');
        }
        $raw = trim((string) ($data['csv'] ?? $data['content'] ?? ''));
        if ($raw === '') {
            return app(WeappSupportGateway::class)->resultFail('请粘贴 CSV 内容');
        }
        $lines   = preg_split('/\r\n|\n/', $raw) ?: [];
        $created = 0;
        $sort    = (int) WeappVideoEpisode::where('series_id', $seriesId)->max('sort');
        foreach ($lines as $line) {
            $line = trim((string) $line);
            if ($line === '' || str_starts_with($line, '#')) {
                continue;
            }
            $cols = str_getcsv($line);
            if (count($cols) < 2) {
                continue;
            }
            $epNo  = (int) trim((string) ($cols[0] ?? '0'));
            $title = trim((string) ($cols[1] ?? ''));
            $url   = trim((string) ($cols[2] ?? ''));
            $prov  = trim((string) ($cols[3] ?? 'remote_url')) ?: 'remote_url';
            $label = trim((string) ($cols[4] ?? ''));
            if ($title === '') {
                continue;
            }
            $sort += 10;
            $epId = (int) WeappVideoEpisode::insertGetId([
                'series_id'   => $seriesId,
                'document_id' => max(0, (int) ($cols[5] ?? 0)),
                'ep_no'       => $epNo > 0 ? $epNo : $created + 1,
                'title'       => $title,
                'access_mode' => '',
                'sort'        => $sort,
                'status'      => 1,
                'created_at'  => app(WeappSupportGateway::class)->appTimeNow(),
                'updated_at'  => app(WeappSupportGateway::class)->appTimeNow(),
            ]);
            if ($url !== '') {
                WeappVideoSource::insert([
                    'episode_id'  => $epId,
                    'provider'    => $prov,
                    'play_url'    => $url,
                    'config_json' => VideoSourceCatalog::configWithLabel($label),
                    'priority'    => 100,
                    'status'      => 1,
                    'created_at'  => app(WeappSupportGateway::class)->appTimeNow(),
                    'updated_at'  => app(WeappSupportGateway::class)->appTimeNow(),
                ]);
            }
            $created++;
        }
        if ($created < 1) {
            return app(WeappSupportGateway::class)->resultFail('未解析到有效行（格式：集号,标题,播放地址,provider,label[,document_id]）');
        }

        return app(WeappSupportGateway::class)->resultOk(['created' => $created], "已导入 {$created} 集");
    }

    /** @param array<string, mixed> $data */
    private static function syncSources(int $episodeId, array $data): void
    {
        $list = self::normalizeSourcesInput($data);
        if ($list === []) {
            return;
        }
        $keepIds = [];
        $prio    = count($list) * 10;
        foreach ($list as $item) {
            $url = trim((string) ($item['play_url'] ?? ''));
            if ($url === '') {
                continue;
            }
            $provider = trim((string) ($item['provider'] ?? 'embed')) ?: 'embed';
            $srcId    = (int) ($item['id'] ?? 0);
            $label    = trim((string) ($item['label'] ?? ''));
            $row      = [
                'provider'    => $provider,
                'play_url'    => $url,
                'config_json' => VideoSourceCatalog::configWithLabel($label),
                'priority'    => (int) ($item['priority'] ?? $prio),
                'status'      => 1,
                'updated_at'  => app(WeappSupportGateway::class)->appTimeNow(),
            ];
            $prio -= 10;
            if ($srcId > 0) {
                WeappVideoSource::where('id', $srcId)->where('episode_id', $episodeId)->update($row);
                $keepIds[] = $srcId;
            } else {
                $row['episode_id']  = $episodeId;
                $row['created_at']  = app(WeappSupportGateway::class)->appTimeNow();
                $keepIds[]          = (int) WeappVideoSource::insertGetId($row);
            }
        }
        if ($keepIds !== []) {
            WeappVideoSource::where('episode_id', $episodeId)
                ->whereNotIn('id', $keepIds)
                ->delete();
        }
    }

    /** @return list<array<string, mixed>> */
    private static function normalizeSourcesInput(array $data): array
    {
        $raw = $data['sources'] ?? $data['sources_json'] ?? null;
        if (is_string($raw) && $raw !== '') {
            $decoded = json_decode($raw, true);
            $raw     = is_array($decoded) ? $decoded : [];
        }
        if (!is_array($raw)) {
            $raw = [];
        }
        if ($raw === []) {
            $url = trim((string) ($data['play_url'] ?? $data['video_url'] ?? ''));
            if ($url !== '') {
                $raw = [[
                    'provider' => (string) ($data['provider'] ?? 'embed'),
                    'play_url' => $url,
                ]];
            }
        }
        $out = [];
        foreach ($raw as $item) {
            if (!is_array($item)) {
                continue;
            }
            $out[] = $item;
        }

        return $out;
    }

    private static function normAdCuesJson(mixed $raw): string
    {
        if (is_array($raw)) {
            return json_encode($raw, JSON_UNESCAPED_UNICODE) ?: '';
        }
        $s = trim((string) $raw);
        if ($s === '') {
            return '';
        }
        $decoded = json_decode($s, true);

        return is_array($decoded) ? (json_encode($decoded, JSON_UNESCAPED_UNICODE) ?: '') : '';
    }

    private static function normMode(string $mode): string
    {
        $mode = strtolower(trim($mode));
        $allowed = [
            VideoAccessService::MODE_FREE,
            VideoAccessService::MODE_LOGIN,
            VideoAccessService::MODE_LEVEL,
            VideoAccessService::MODE_PAID,
            VideoAccessService::MODE_PAID_SERIES,
        ];

        return in_array($mode, $allowed, true) ? $mode : VideoAccessService::MODE_FREE;
    }
}
