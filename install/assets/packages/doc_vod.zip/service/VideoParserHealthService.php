<?php
declare(strict_types=1);

namespace weapp\doc_vod\service;



use weapp\doc_vod\model\WeappVideoSeries;
use weapp\doc_vod\service\parser\BilibiliBangumiVideoLinkDriver;
use app\common\service\weapp\WeappEntitlementGateway;
use app\common\service\weapp\WeappSupportGateway;
/** 常维护平台解析自检 */
class VideoParserHealthService
{
    /** @return mixed */
    public static function checkAll(bool $network = true)
    {
        if (!app(WeappEntitlementGateway::class)->entitlementCan('doc_vod')) {
            return app(WeappSupportGateway::class)->resultFail('插件未授权');
        }
        $items = [];
        foreach (VideoParserCatalog::maintainedPlatforms() as $row) {
            $key = (string) ($row['key'] ?? '');
            if ($key === 'bilibili_bangumi') {
                $key = 'bilibili';
            }
            if (!VideoConfigService::isPlatformEnabled($key) && $key !== 'direct') {
                $items[] = self::rowResult($row, false, '平台已在后台关闭', 0);
                continue;
            }
            $sample = (string) ($row['sample_url'] ?? '');
            if ($sample === '') {
                $items[] = self::rowResult($row, false, '无样本 URL', 0);
                continue;
            }
            if (!$network && ($row['key'] ?? '') !== 'bilibili_bangumi') {
                $items[] = self::rowResult($row, true, '本地规则（未测网络）', 0);
                continue;
            }
            $t0  = microtime(true);
            $res = self::probe((string) ($row['key'] ?? ''), $sample);
            $ms  = (int) round((microtime(true) - $t0) * 1000);
            $ok  = $res->isOk();
            $items[] = self::rowResult($row, $ok, (string) ($res->message() ?? ''), $ms);
        }

        return app(WeappSupportGateway::class)->resultOk(['items' => $items], '');
    }

    /** @param array<string, mixed> $row */
    private static function rowResult(array $row, bool $ok, string $msg, int $ms): array
    {
        return [
            'key'          => (string) ($row['key'] ?? ''),
            'label'        => (string) ($row['label'] ?? ''),
            'driver'       => (string) ($row['driver'] ?? ''),
            'sample_url'   => (string) ($row['sample_url'] ?? ''),
            'notes'        => (string) ($row['notes'] ?? ''),
            'ok'           => $ok ? 1 : 0,
            'msg'          => $msg,
            'duration_ms'  => $ms,
        ];
    }

    /** @return mixed */
    private static function probe(string $platformKey, string $sampleUrl)
    {
        if ($platformKey === 'bilibili_bangumi') {
            $driver = new BilibiliBangumiVideoLinkDriver();

            return $driver->parseCollection($sampleUrl);
        }
        if ($platformKey === 'direct') {
            return app(WeappSupportGateway::class)->resultOk(null, '直链规则可用');
        }

        return VideoLinkParserService::parse($sampleUrl);
    }
}
