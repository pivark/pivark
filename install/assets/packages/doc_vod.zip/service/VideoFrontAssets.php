<?php
declare(strict_types=1);

namespace weapp\doc_vod\service;

use app\common\service\weapp\WeappFrontGateway;

final class VideoFrontAssets
{
    public static function registerVodStyles(): void
    {
        app(WeappFrontGateway::class)->frontAssetRegisterWeappStylesheet('doc_vod', 'pv-vod-css', 'assets/css/vod.css');
    }

    public static function registerVod(): void
    {
        self::registerVodStyles();
        $gw = app(WeappFrontGateway::class);
        $gw->frontAssetRegisterWeappScript('doc_vod', 'pv-vod-player', 'assets/js/player.js');
    }
}
