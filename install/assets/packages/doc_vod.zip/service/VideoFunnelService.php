<?php
declare(strict_types=1);

namespace weapp\doc_vod\service;


use app\common\support\AppTime;
use app\common\service\weapp\WeappPluginGateway;
use app\common\service\weapp\WeappSupportGateway;

use weapp\doc_vod\model\WeappVideoPlayDaily;
use think\facade\Db;

/** 试看结束 / 购买点击等转化事件日汇总 */
class VideoFunnelService
{
    public const EVENT_TRIAL_END  = 'trial_end';
    public const EVENT_BUY_CLICK  = 'buy_click';

    public static function boot(): void
    {
        app(WeappPluginGateway::class)->pluginRouteRegister(
            'post',
            'api/v1/plugins/doc_vod/track',
            '\\weapp\\doc_vod\\api\\controller\\Video@track'
        );
    }

    public static function schemaReady(): bool
    {
        static $ok = null;
        if ($ok !== null) {
            return $ok;
        }
        if (!VideoStatsService::dailySchemaReady()) {
            $ok = false;

            return $ok;
        }
        try {
            WeappVideoPlayDaily::field('trial_end_hits')->limit(1)->select();
            $ok = true;
        } catch (\Throwable) {
            $ok = false;
        }

        return $ok;
    }

    /** @return mixed */
    public static function track(int $episodeId, string $event)
    {
        if ($episodeId < 1) {
            return app(WeappSupportGateway::class)->resultFail('参数无效');
        }
        if (!self::schemaReady()) {
            return app(WeappSupportGateway::class)->resultOk(null, '');
        }
        $event = strtolower(trim($event));
        $col   = match ($event) {
            self::EVENT_TRIAL_END => 'trial_end_hits',
            self::EVENT_BUY_CLICK => 'buy_click_hits',
            default               => '',
        };
        if ($col === '') {
            return app(WeappSupportGateway::class)->resultFail('未知事件');
        }
        if (VideoAccessService::episodeRow($episodeId) === null) {
            return app(WeappSupportGateway::class)->resultFail('单集不存在');
        }
        $date = AppTime::format('Y-m-d');
        $now  = app(WeappSupportGateway::class)->appTimeNow();
        $row  = WeappVideoPlayDaily::where('stat_date', $date)->find();
        if ($row) {
            WeappVideoPlayDaily::where('stat_date', $date)->inc($col)->update(['updated_at' => $now]);
        } else {
            WeappVideoPlayDaily::insert([
                'stat_date'      => $date,
                'play_hits'      => 0,
                'trial_end_hits' => $event === self::EVENT_TRIAL_END ? 1 : 0,
                'buy_click_hits' => $event === self::EVENT_BUY_CLICK ? 1 : 0,
                'updated_at'     => $now,
            ]);
        }

        return app(WeappSupportGateway::class)->resultOk(null, '');
    }

    /** @return array{trial_end:int,buy_click:int} */
    public static function totalsLastDays(int $days = 30): array
    {
        if (!self::schemaReady()) {
            return ['trial_end' => 0, 'buy_click' => 0];
        }
        $days = max(7, min(90, $days));
        $from = AppTime::format('Y-m-d', strtotime('-' . ($days - 1) . ' days'));
        try {
            $trial = (int) WeappVideoPlayDaily::where('stat_date', '>=', $from)
                ->sum('trial_end_hits');
            $buy = (int) WeappVideoPlayDaily::where('stat_date', '>=', $from)
                ->sum('buy_click_hits');
        } catch (\Throwable) {
            return ['trial_end' => 0, 'buy_click' => 0];
        }

        return ['trial_end' => $trial, 'buy_click' => $buy];
    }

    /** @return list<array{date:string,trial_end:int,buy_click:int}> */
    public static function dailyTrend(int $days = 30): array
    {
        if (!self::schemaReady()) {
            return [];
        }
        $days = max(7, min(90, $days));
        $out  = [];
        for ($i = $days - 1; $i >= 0; $i--) {
            $date = AppTime::format('Y-m-d', strtotime("-{$i} days"));
            $row  = WeappVideoPlayDaily::where('stat_date', $date)->find();
            $out[] = [
                'date'       => $date,
                'trial_end'  => (int) (is_array($row) ? ($row['trial_end_hits'] ?? 0) : 0),
                'buy_click'  => (int) (is_array($row) ? ($row['buy_click_hits'] ?? 0) : 0),
            ];
        }

        return $out;
    }
}
