<?php
declare(strict_types=1);

namespace weapp\doc_vod\service;



use app\common\support\AppTime;
use app\common\service\weapp\WeappEntitlementGateway;
use app\common\service\weapp\WeappPaymentGateway;
use app\common\service\weapp\WeappSupportGateway;

use weapp\doc_vod\model\WeappVideoEpisode;
use weapp\doc_vod\model\WeappVideoEpisodePlayDaily;
use weapp\doc_vod\model\WeappVideoGrant;
use weapp\doc_vod\model\WeappVideoItem;
use weapp\doc_vod\model\WeappVideoPlayDaily;
use weapp\doc_vod\model\WeappVideoSeries;
use think\facade\Db;
/** 点播运营统计 */
class VideoStatsService
{
    public static function recordDailyPlay(): void
    {
        if (!self::dailySchemaReady()) {
            return;
        }
        $date = AppTime::format('Y-m-d');
        $now  = app(WeappSupportGateway::class)->appTimeNow();
        $exists = WeappVideoPlayDaily::where('stat_date', $date)->find();
        if ($exists) {
            WeappVideoPlayDaily::where('stat_date', $date)->inc('play_hits')->update([
                'updated_at' => $now,
            ]);
        } else {
            WeappVideoPlayDaily::insert([
                'stat_date'  => $date,
                'play_hits'  => 1,
                'updated_at' => $now,
            ]);
        }
    }

    public static function dailySchemaReady(): bool
    {
        static $ok = null;
        if ($ok !== null) {
            return $ok;
        }
        try {
            WeappVideoPlayDaily::limit(1)->select();
            $ok = true;
        } catch (\Throwable $e) {
            app(WeappSupportGateway::class)->kernelOpsLog('video_stats_table_probe_failed', ['msg' => $e->getMessage()]);
            $ok = false;
        }

        return $ok;
    }

    /** @return array<string, mixed> */
    public static function overviewAdmin(): array
    {
        $dash = self::dashboardAdmin(30);
        if (!$dash->isOk()) {
            return [
                'items'       => ['total' => 0, 'enabled' => 0],
                'vod'         => [],
                'series_rank' => [],
            ];
        }
        $data = $dash->dataArray();

        return [
            'items'       => is_array($data['items'] ?? null) ? $data['items'] : ['total' => 0, 'enabled' => 0],
            'vod'         => is_array($data['vod'] ?? null) ? $data['vod'] : [],
            'series_rank' => is_array($data['series_rank'] ?? null) ? $data['series_rank'] : [],
        ];
    }

    /** @return array<string, mixed> */
    public static function dashboardAdmin(int $days = 30)
    {
        if (!app(WeappEntitlementGateway::class)->entitlementCan('doc_vod')) {
            return app(WeappSupportGateway::class)->resultFail('插件未授权');
        }
        $days = max(7, min(90, $days));
        $itemsTotal   = (int) WeappVideoItem::count();
        $itemsEnabled = (int) WeappVideoItem::where('status', 1)->count();
        $seriesTotal  = 0;
        $epTotal      = 0;
        $playTotal    = 0;
        $grantTotal   = 0;
        $orderPaid    = 0;
        $seriesRank   = [];
        $topEpisodes  = [];
        $dailyTrend   = [];
        $orderTrend   = [];
        $grantTrend   = [];
        $parseFails   = [];

        if (VideoAccessService::schemaReady()) {
            $seriesTotal = (int) WeappVideoSeries::count();
            $epTotal     = (int) WeappVideoEpisode::count();
            $playTotal   = (int) WeappVideoEpisode::sum('play_count');
            $grantTotal  = (int) WeappVideoGrant::count();
            $topEpisodes = [];
            foreach (WeappVideoEpisode::with(['series' => static function ($seriesQuery): void {
                $seriesQuery->field('id,title');
            }])
                ->field('id,title,play_count,document_id,series_id')
                ->order('play_count', 'desc')
                ->limit(20)
                ->select() as $model) {
                $topEpisodes[] = app(WeappSupportGateway::class)->modelRelationMergeBelongsTo(
                    $model,
                    'series',
                    ['title' => 'series_title'],
                );
            }
            $seriesRank = self::seriesRank();
            $dailyTrend = self::playDailyTrend($days);
            $orderTrend = self::orderDailyTrend($days);
            $grantTrend = self::grantDailyTrend($days);
            try {
                $orderPaid = app(WeappPaymentGateway::class)->payOrderCountPaidByScenes([
                    VideoPaymentScenes::EPISODE,
                    VideoPaymentScenes::SERIES,
                ]);
            } catch (\Throwable $e) {
                app(WeappSupportGateway::class)->kernelOpsLog('video_stats_order_paid_count_failed', ['msg' => $e->getMessage()]);
                $orderPaid = 0;
            }
        }
        $parseFails   = VideoParseLogService::platformFailCounts(7);
        $funnelTotals = VideoFunnelService::totalsLastDays($days);
        $funnelTrend  = VideoFunnelService::dailyTrend($days);

        return app(WeappSupportGateway::class)->resultOk(['days' => $days, 'items' => ['total' => $itemsTotal, 'enabled' => $itemsEnabled], 'vod' => [
                'series_total'  => $seriesTotal,
                'episode_total' => $epTotal,
                'play_total'    => $playTotal,
                'grant_total'   => $grantTotal,
                'order_paid'    => $orderPaid,
            ], 'series_rank' => $seriesRank, 'top_episodes' => $topEpisodes, 'daily_trend' => $dailyTrend, 'order_trend' => $orderTrend, 'grant_trend' => $grantTrend, 'parse_fails' => $parseFails, 'parse_recent' => VideoParseLogService::recentFailures(15), 'parser_catalog' => VideoParserCatalog::maintainedPlatforms(), 'funnel' => [
                'trial_end_total' => $funnelTotals['trial_end'],
                'buy_click_total' => $funnelTotals['buy_click'],
                'trend'           => $funnelTrend,
            ]], '');
    }

    /** @return list<array<string, mixed>> */
    private static function seriesRank(): array
    {
        $seriesRank = WeappVideoSeries::withCount('episodes')
            ->withSum('episodes', 'play_count')
            ->order('episodes_sum', 'desc')
            ->limit(30)
            ->select()
            ->toArray();
        foreach ($seriesRank as &$rankRow) {
            if (!is_array($rankRow)) {
                continue;
            }
            $rankRow['play_sum']  = (int) ($rankRow['episodes_sum'] ?? 0);
            $rankRow['ep_count']  = (int) ($rankRow['episodes_count'] ?? 0);
        }
        unset($rankRow);
        foreach ($seriesRank as &$row) {
            if (!is_array($row)) {
                continue;
            }
            $sid    = (int) ($row['id'] ?? 0);
            $plays  = (int) ($row['play_sum'] ?? 0);
            $grants = 0;
            if ($sid > 0) {
                $grants = (int) WeappVideoGrant::where('grant_type', 'series')
                    ->where('ref_id', $sid)
                    ->count();
                $epIds = WeappVideoEpisode::where('series_id', $sid)->column('id');
                if ($epIds !== []) {
                    $grants += (int) WeappVideoGrant::where('grant_type', 'episode')
                        ->whereIn('ref_id', $epIds)
                        ->count();
                }
            }
            $row['grant_count']    = $grants;
            $row['conversion_pct'] = $plays > 0 ? round(100 * $grants / $plays, 2) : 0;
        }
        unset($row);

        return $seriesRank;
    }

    /** @return array{labels:list<string>,plays:list<int>} */
    private static function playDailyTrend(int $days): array
    {
        $labels = [];
        $plays  = [];
        $map    = [];
        if (self::dailySchemaReady()) {
            $since = AppTime::format('Y-m-d', strtotime('-' . ($days - 1) . ' days'));
            $rows  = WeappVideoPlayDaily::where('stat_date', '>=', $since)
                ->order('stat_date', 'asc')
                ->select()
                ->toArray();
            foreach ($rows as $row) {
                if (!is_array($row)) {
                    continue;
                }
                $map[(string) ($row['stat_date'] ?? '')] = (int) ($row['play_hits'] ?? 0);
            }
        }
        for ($i = $days - 1; $i >= 0; $i--) {
            $d = AppTime::format('Y-m-d', strtotime("-{$i} days"));
            $labels[] = substr($d, 5);
            $plays[]  = $map[$d] ?? 0;
        }

        return ['labels' => $labels, 'plays' => $plays];
    }

    /** @return array{labels:list<string>,values:list<int>} */
    private static function orderDailyTrend(int $days): array
    {
        $labels = [];
        $values = [];
        $map    = [];
        try {
            $since = AppTime::format('Y-m-d 00:00:00', strtotime('-' . ($days - 1) . ' days'));
            $map   = app(WeappPaymentGateway::class)->payOrderDailyPaidCountsByScenes([
                VideoPaymentScenes::EPISODE,
                VideoPaymentScenes::SERIES,
            ], $since);
        } catch (\Throwable $e) {
            app(WeappSupportGateway::class)->kernelOpsLog('video_stats_play_daily_map_failed', ['msg' => $e->getMessage()]);
        }
        for ($i = $days - 1; $i >= 0; $i--) {
            $d = AppTime::format('Y-m-d', strtotime("-{$i} days"));
            $labels[] = substr($d, 5);
            $values[] = $map[$d] ?? 0;
        }

        return ['labels' => $labels, 'values' => $values];
    }

    /** @return array{labels:list<string>,values:list<int>} */
    private static function grantDailyTrend(int $days): array
    {
        $labels = [];
        $values = [];
        $map    = [];
        if (!VideoAccessService::schemaReady()) {
            return ['labels' => $labels, 'values' => $values];
        }
        $since = AppTime::format('Y-m-d 00:00:00', strtotime('-' . ($days - 1) . ' days'));
        $rows  = WeappVideoGrant::where('created_at', '>=', $since)
            ->field('DATE(created_at) as d, count(*) as c')
            ->group('d')
            ->select()
            ->toArray();
        foreach ($rows as $row) {
            if (!is_array($row)) {
                continue;
            }
            $map[(string) ($row['d'] ?? '')] = (int) ($row['c'] ?? 0);
        }
        for ($i = $days - 1; $i >= 0; $i--) {
            $d = AppTime::format('Y-m-d', strtotime("-{$i} days"));
            $labels[] = substr($d, 5);
            $values[] = $map[$d] ?? 0;
        }

        return ['labels' => $labels, 'values' => $values];
    }

    /** @return mixed */
    public static function exportSeriesCsv()
    {
        $dash = self::dashboardAdmin(30);
        if (!$dash->isOk()) {
            return app(WeappSupportGateway::class)->resultFail('不可用');
        }
        $lines = ["剧集,单集数,播放,授权,转化%"];
        foreach ($dash['series_rank'] ?? [] as $row) {
            if (!is_array($row)) {
                continue;
            }
            $lines[] = sprintf(
                '%s,%d,%d,%d,%s',
                str_replace(',', ' ', (string) ($row['title'] ?? '')),
                (int) ($row['ep_count'] ?? 0),
                (int) ($row['play_sum'] ?? 0),
                (int) ($row['grant_count'] ?? 0),
                (string) ($row['conversion_pct'] ?? 0)
            );
        }

        return app(WeappSupportGateway::class)->resultOk(['csv' => implode("\n", $lines) . "\n"], '');
    }

    public static function episodeDailySchemaReady(): bool
    {
        static $ok = null;
        if ($ok !== null) {
            return $ok;
        }
        try {
            WeappVideoEpisodePlayDaily::limit(1)->select();
            $ok = true;
        } catch (\Throwable $e) {
            app(WeappSupportGateway::class)->kernelOpsLog('video_stats_table_probe_failed', ['msg' => $e->getMessage()]);
            $ok = false;
        }

        return $ok;
    }

    public static function recordEpisodeDailyPlay(int $episodeId, int $seriesId): void
    {
        if ($episodeId < 1 || !self::episodeDailySchemaReady()) {
            return;
        }
        $date = AppTime::format('Y-m-d');
        $now  = app(WeappSupportGateway::class)->appTimeNow();
        $row  = WeappVideoEpisodePlayDaily::where('episode_id', $episodeId)
            ->where('stat_date', $date)
            ->find();
        if ($row) {
            WeappVideoEpisodePlayDaily::where('episode_id', $episodeId)
                ->where('stat_date', $date)
                ->inc('play_hits')
                ->update(['updated_at' => $now]);
        } else {
            WeappVideoEpisodePlayDaily::insert([
                'episode_id' => $episodeId,
                'series_id'  => max(0, $seriesId),
                'stat_date'  => $date,
                'play_hits'  => 1,
                'updated_at' => $now,
            ]);
        }
    }

    /** @return array<string, mixed> */
    public static function heatmapOverviewAdmin(int $days = 30, int $seriesLimit = 12, int $epSlots = 16)
    {
        if (!app(WeappEntitlementGateway::class)->entitlementCan('doc_vod') || !VideoAccessService::schemaReady()) {
            return app(WeappSupportGateway::class)->resultFail('不可用');
        }
        $days        = max(7, min(90, $days));
        $seriesLimit = max(4, min(20, $seriesLimit));
        $epSlots     = max(8, min(24, $epSlots));
        $since       = AppTime::format('Y-m-d', strtotime('-' . ($days - 1) . ' days'));
        $useDaily    = self::episodeDailySchemaReady();

        $activeEpisodes = static function ($episodeQuery): void {
            $episodeQuery->where('status', 1);
        };
        $seriesRows = WeappVideoSeries::where('status', 1)
            ->withSum(['episodes' => $activeEpisodes], 'play_count')
            ->order('episodes_sum', 'desc')
            ->limit($seriesLimit)
            ->select()
            ->toArray();
        foreach ($seriesRows as &$heatmapRow) {
            if (!is_array($heatmapRow)) {
                continue;
            }
            $heatmapRow['play_sum'] = (int) ($heatmapRow['episodes_sum'] ?? 0);
        }
        unset($heatmapRow);

        $yLabels = [];
        $xLabels = [];
        for ($i = 1; $i <= $epSlots; $i++) {
            $xLabels[] = 'E' . $i;
        }
        $data = [];
        $max  = 0;

        foreach ($seriesRows as $sr) {
            if (!is_array($sr)) {
                continue;
            }
            $sid = (int) ($sr['id'] ?? 0);
            if ($sid < 1) {
                continue;
            }
            $yLabels[] = (string) ($sr['title'] ?? '');
            $yIndex    = count($yLabels) - 1;
            $episodes  = WeappVideoEpisode::where('series_id', $sid)
                ->where('status', 1)
                ->order(['sort' => 'asc', 'ep_no' => 'asc', 'id' => 'asc'])
                ->limit($epSlots)
                ->select()
                ->toArray();
            foreach ($episodes as $xi => $ep) {
                if (!is_array($ep)) {
                    continue;
                }
                $epId = (int) ($ep['id'] ?? 0);
                $val  = 0;
                if ($useDaily && $epId > 0) {
                    $val = (int) WeappVideoEpisodePlayDaily::where('episode_id', $epId)
                        ->where('stat_date', '>=', $since)
                        ->sum('play_hits');
                }
                if ($val < 1) {
                    $val = (int) ($ep['play_count'] ?? 0);
                }
                if ($val > 0) {
                    $data[] = [$xi, $yIndex, $val];
                    $max    = max($max, $val);
                }
            }
        }

        return app(WeappSupportGateway::class)->resultOk($data, '');
    }

    /** @return array<string, mixed> */
    public static function heatmapSeriesDrillAdmin(int $seriesId, int $days = 30, int $epLimit = 24)
    {
        if (!app(WeappEntitlementGateway::class)->entitlementCan('doc_vod') || $seriesId < 1) {
            return app(WeappSupportGateway::class)->resultFail('参数无效');
        }
        $series = VideoAccessService::seriesRow($seriesId);
        if ($series === null) {
            return app(WeappSupportGateway::class)->resultFail('剧集不存在');
        }
        $days     = max(7, min(90, $days));
        $epLimit  = max(8, min(40, $epLimit));
        $since    = AppTime::format('Y-m-d', strtotime('-' . ($days - 1) . ' days'));
        $useDaily = self::episodeDailySchemaReady();

        $dateLabels = [];
        $fullDates  = [];
        for ($i = $days - 1; $i >= 0; $i--) {
            $full = AppTime::format('Y-m-d', strtotime("-{$i} days"));
            $fullDates[]  = $full;
            $dateLabels[] = substr($full, 5);
        }

        $episodes = WeappVideoEpisode::where('series_id', $seriesId)
            ->where('status', 1)
            ->order(['sort' => 'asc', 'ep_no' => 'asc', 'id' => 'asc'])
            ->limit($epLimit)
            ->select()
            ->toArray();

        $epLabels = [];
        $epMeta   = [];
        $data     = [];
        $max      = 0;

        foreach ($episodes as $yi => $ep) {
            if (!is_array($ep)) {
                continue;
            }
            $epId   = (int) ($ep['id'] ?? 0);
            $epNo   = (int) ($ep['ep_no'] ?? 0);
            $label  = ($epNo > 0 ? $epNo . ' ' : '') . (string) ($ep['title'] ?? '');
            $epLabels[] = mb_strlen($label) > 18 ? mb_substr($label, 0, 18) . '…' : $label;
            $epMeta[]   = [
                'id'    => $epId,
                'ep_no' => $epNo,
                'title' => (string) ($ep['title'] ?? ''),
            ];
            foreach ($fullDates as $xi => $fullDate) {
                $val = 0;
                if ($useDaily && $epId > 0) {
                    $val = (int) WeappVideoEpisodePlayDaily::where('episode_id', $epId)
                        ->where('stat_date', $fullDate)
                        ->value('play_hits');
                }
                if ($val > 0) {
                    $data[] = [$xi, $yi, $val];
                    $max    = max($max, $val);
                }
            }
        }

        if ($data === [] && $episodes !== []) {
            foreach ($episodes as $yi => $ep) {
                if (!is_array($ep)) {
                    continue;
                }
                $cum = (int) ($ep['play_count'] ?? 0);
                if ($cum > 0) {
                    $data[] = [count($dateLabels) - 1, $yi, $cum];
                    $max    = max($max, $cum);
                }
            }
        }

        return app(WeappSupportGateway::class)->resultOk($data, '');
    }
}
