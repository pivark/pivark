<?php
declare(strict_types=1);

namespace weapp\doc_vod\service;

use app\common\service\weapp\WeappConfigGateway;
use weapp\doc_vod\model\WeappVideoEpisode;
use weapp\doc_vod\model\WeappVideoItem;
use weapp\doc_vod\model\WeappVideoSeries;
use app\common\service\weapp\WeappPluginGateway;
use app\common\service\weapp\WeappEntitlementGateway;
use app\common\service\weapp\WeappFrontGateway;

/** 视频插件：验收 fixture（dev/demo 可重复灌，稳定 html_name） */
final class VideoAcceptanceFixtureService
{
    public const TAG_SLUG = 'pv-accept-video';

    public const DOC_EMBED = 'accept-video-embed';

    public const DOC_VOD = 'accept-video-vod';

    public const DOC_EMPTY = 'accept-video-empty';

    public const SERIES_SLUG = 'accept-demo';

    private const DEMO_MP4 = 'https://www.w3schools.com/html/mov_bbb.mp4';

    /** 公开样例 BV（解析/片源演示用，非站内直链） */
    private const DEMO_BILIBILI = 'https://www.bilibili.com/video/BV1GJ411x7h7';

    public static function seed(): int
    {
        $ent = self::ensureEntitlement();
        if ($ent === 'skip') {
            return 0;
        }
        if ($ent === 'fail') {
            return 1;
        }
        if (!self::ensureEnabled()) {
            return 1;
        }

        app(WeappPluginGateway::class)->pluginRegisterAutoloadPublic('doc_vod');
        VideoService::ensureAutoload();
        app(WeappPluginGateway::class)->weappSchemaApply('doc_vod');
        if (!VideoAccessService::schemaReady()) {
            echo "FAIL fixture seed (video VOD schema not ready — run reapply_doc_vod_schema_cli.php)\n";

            return 1;
        }

        self::ensureConfig();

        $tagId = self::ensureTag();
        $embedDocId = self::ensureDocument(
            self::DOC_EMBED,
            '【验收】嵌入多视频',
            '三条外链 mp4，测 {pv:doc_vod} 嵌入列表与 frontassets。',
        );
        $vodDocId = self::ensureDocument(
            self::DOC_VOD,
            '【验收】点播选集',
            '绑定 accept-demo 剧集单集，前台优先点播 UI。',
        );
        $emptyDocId = self::ensureDocument(
            self::DOC_EMPTY,
            '【验收】无视频对照',
            '本文无视频条目、无点播单集，前台不应输出视频块。',
        );

        self::linkTags($embedDocId, $vodDocId, $emptyDocId, $tagId);
        self::seedEmbedItems($embedDocId);
        WeappVideoItem::where('document_id', $vodDocId)->delete();
        WeappVideoItem::where('document_id', $emptyDocId)->delete();

        $seriesId = self::ensureSeries();
        self::ensureEpisodes($seriesId, $vodDocId);

        self::printSummary($embedDocId, $vodDocId, $emptyDocId, $seriesId);
        app(WeappFrontGateway::class)->frontCacheInvalidateDocuments();

        return 0;
    }

    /** @return 'ok'|'skip'|'fail' */
    private static function ensureEntitlement(): string
    {
        if (app(WeappEntitlementGateway::class)->entitlementCan('doc_vod')) {
            echo "OK fixture entitlement video\n";

            return 'ok';
        }

        $installed = app(WeappPluginGateway::class)->pluginIsInstalled('doc_vod');
        if (!$installed) {
            echo "SKIP fixture seed (video not installed)\n";

            return 'skip';
        }

        $manifest = app(WeappPluginGateway::class)->pluginReadManifest('doc_vod');
        if (is_array($manifest)) {
            app(WeappEntitlementGateway::class)->entitlementApplyInstallPolicy('doc_vod', $manifest);
        }
        if (!app(WeappEntitlementGateway::class)->entitlementCan('doc_vod')) {
            app(WeappEntitlementGateway::class)->entitlementGrantFreeInstall('doc_vod');
        }
        if (!app(WeappEntitlementGateway::class)->entitlementCan('doc_vod')) {
            echo "FAIL fixture seed (video not entitled)\n";

            return 'fail';
        }
        echo "OK fixture entitlement reconciled\n";

        return 'ok';
    }

    private static function ensureEnabled(): bool
    {
        if (app(WeappPluginGateway::class)->pluginIsEnabled('doc_vod')) {
            echo "OK fixture plugin enabled\n";

            return true;
        }
        $enable = app(WeappPluginGateway::class)->pluginEnable('doc_vod');
        if (!$enable->isOk()) {
            echo 'FAIL fixture enable ' . $enable->message() . PHP_EOL;

            return false;
        }
        echo "OK fixture plugin enabled\n";

        return true;
    }

    private static function ensureConfig(): void
    {
        foreach (['doc_vod_open' => '1', 'doc_vod_plaza_open' => '1', 'doc_vod_series_channel_open' => '1'] as $key => $val) {
            if ((string) app(WeappConfigGateway::class)->configGet($key, '') === $val) {
                continue;
            }
            app(WeappConfigGateway::class)->configSet($key, $val);
            echo "OK fixture config {$key}={$val}\n";
        }
    }

    private static function ensureTag(): int
    {
        $cfg   = app(WeappConfigGateway::class);
        $tagId = $cfg->installDemoUpsertTag([
            'slug'        => self::TAG_SLUG,
            'name'        => '验收视频',
            'tpl'         => 'list_document_video.php',

            'nav_sort'    => 6,
            'description' => '手工验收用：嵌入 / 点播 / 空文档对照',
            'url_path'    => 'accept-video',
        ]);
        echo 'OK fixture tag #' . $tagId . ' slug=' . self::TAG_SLUG . PHP_EOL;

        return $tagId;
    }

    private static function ensureDocument(string $htmlName, string $title, string $summary): int
    {
        $cfg   = app(WeappConfigGateway::class);
        $docId = $cfg->installDemoUpsertDocument(
            $htmlName,
            $title,
            $summary,
            '<p>' . htmlspecialchars($summary, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') . '</p>',
            '',
            'has_image',
            520,
            2,
        );
        echo 'OK fixture document #' . $docId . ' html_name=' . $htmlName . PHP_EOL;

        return $docId;
    }

    private static function linkTags(int $embedDocId, int $vodDocId, int $emptyDocId, int $tagId): void
    {
        $cfg    = app(WeappConfigGateway::class);
        $tagIds = [self::TAG_SLUG => $tagId];
        foreach ([$embedDocId, $vodDocId, $emptyDocId] as $docId) {
            if ($docId > 0) {
                $cfg->installDemoLinkDocumentTags($docId, [self::TAG_SLUG], $tagIds);
            }
        }
        $cfg->installDemoRefreshTagUseCounts();
    }

    private static function seedEmbedItems(int $documentId): void
    {
        $specs = [
            ['title' => '验收嵌入 1 · 产品概览', 'video_url' => self::DEMO_MP4, 'provider' => 'embed', 'sort' => 0],
            ['title' => '验收嵌入 2 · 操作演示', 'video_url' => self::DEMO_MP4, 'provider' => 'embed', 'sort' => 1],
            ['title' => '验收嵌入 3 · 案例分享', 'video_url' => self::DEMO_MP4, 'provider' => 'embed', 'sort' => 2],
        ];

        $keepIds = [];
        foreach ($specs as $spec) {
            $existing = WeappVideoItem::where('document_id', $documentId)
                ->where('title', $spec['title'])
                ->find();
            $res = VideoService::saveAdmin([
                'id'          => (int) ($existing['id'] ?? 0),
                'document_id' => $documentId,
                'title'       => $spec['title'],
                'video_url'   => $spec['video_url'],
                'cover_path'  => app(WeappConfigGateway::class)->installDemoPreviewImage(),
                'provider'    => $spec['provider'],
                'sort'        => $spec['sort'],
                'status'      => 1,
            ]);
            if (!$res->isOk()) {
                echo 'FAIL fixture embed ' . $spec['title'] . ' ' . $res->message() . PHP_EOL;

                continue;
            }
            $id = (int) ($res->dataArray()['id'] ?? 0);
            if ($id > 0) {
                $keepIds[] = $id;
            }
        }
        if ($keepIds !== []) {
            WeappVideoItem::where('document_id', $documentId)
                ->whereNotIn('id', $keepIds)
                ->delete();
        }

        $cnt = (int) WeappVideoItem::where('document_id', $documentId)->where('status', 1)->count();
        if ($cnt < count($specs)) {
            echo "FAIL fixture embed items doc={$documentId} count={$cnt} expected=" . count($specs) . PHP_EOL;

            return;
        }
        echo 'OK fixture embed items doc=' . $documentId . ' count=' . $cnt . PHP_EOL;
    }

    private static function ensureSeries(): int
    {
        $row = WeappVideoSeries::where('slug', self::SERIES_SLUG)->find();
        $seriesId = (int) ($row['id'] ?? 0);
        if ($seriesId > 0) {
            echo 'OK fixture series exists #' . $seriesId . PHP_EOL;

            return $seriesId;
        }

        $res = VideoCatalogService::saveSeriesAdmin([
            'title'       => '【验收】演示剧集',
            'slug'        => self::SERIES_SLUG,
            'summary'     => '广场 / 频道 / 选集 UI 验收：双线路 + 试看 + 登录 + 付费 + 积分。',
            'access_mode' => 'free',
            'free_ep_count' => 1,
            'sort'        => 0,
            'status'      => 1,
        ]);
        if (!$res->isOk()) {
            echo 'FAIL fixture series ' . $res->message() . PHP_EOL;

            return 0;
        }
        $seriesId = (int) ($res['id'] ?? 0);
        echo 'OK fixture series created #' . $seriesId . PHP_EOL;

        return $seriesId;
    }

    private static function ensureEpisodes(int $seriesId, int $vodDocId): void
    {
        if ($seriesId < 1) {
            return;
        }

        $specs = [
            [
                'ep_no'       => 1,
                'title'       => '第 1 集 · 入门（双线路演示）',
                'document_id' => $vodDocId,
                'access_mode' => 'free',
                'sources'     => [
                    [
                        'provider' => 'bilibili',
                        'label'    => 'B站',
                        'play_url' => self::DEMO_BILIBILI,
                        'priority' => 20,
                    ],
                    [
                        'provider' => 'local',
                        'label'    => '直链',
                        'play_url' => self::DEMO_MP4,
                        'priority' => 10,
                    ],
                ],
            ],
            [
                'ep_no'       => 2,
                'title'       => '第 2 集 · 进阶（试看 15 秒）',
                'document_id' => 0,
                'play_url'    => self::DEMO_MP4,
                'access_mode' => 'login',
                'trial_preview_sec' => 15,
                'cover_path'  => '',
            ],
            [
                'ep_no'       => 3,
                'title'       => '第 3 集 · 登录门槛（手测 E2）',
                'document_id' => 0,
                'play_url'    => self::DEMO_MP4,
                'access_mode' => 'login',
            ],
            [
                'ep_no'       => 4,
                'title'       => '第 4 集 · 单集付费（手测）',
                'document_id' => 0,
                'play_url'    => self::DEMO_MP4,
                'access_mode' => 'paid',
                'price'       => 1.00,
            ],
            [
                'ep_no'       => 5,
                'title'       => '第 5 集 · 积分兑换（手测）',
                'document_id' => 0,
                'play_url'    => self::DEMO_MP4,
                'access_mode' => 'points',
                'points_cost' => 10,
            ],
        ];

        foreach ($specs as $spec) {
            $epNo = (int) $spec['ep_no'];
            $existing = WeappVideoEpisode::where('series_id', $seriesId)->where('ep_no', $epNo)->find();
            $epId = (int) ($existing['id'] ?? 0);
            $payload = [
                'id'          => $epId,
                'series_id'   => $seriesId,
                'ep_no'       => $epNo,
                'title'       => (string) $spec['title'],
                'document_id' => (int) $spec['document_id'],
                'access_mode' => (string) $spec['access_mode'],
                'status'      => 1,
            ];
            if (isset($spec['trial_preview_sec'])) {
                $payload['trial_preview_sec'] = (int) $spec['trial_preview_sec'];
            }
            if (isset($spec['price'])) {
                $payload['price'] = (float) $spec['price'];
            }
            if (isset($spec['points_cost'])) {
                $payload['price'] = (float) $spec['points_cost'];
            }
            if (isset($spec['sources']) && is_array($spec['sources'])) {
                $payload['sources'] = $spec['sources'];
            } else {
                $payload['play_url'] = (string) ($spec['play_url'] ?? '');
                $payload['provider'] = 'embed';
            }
            $res = VideoCatalogService::saveEpisodeAdmin($payload);
            if (!$res->isOk()) {
                echo 'FAIL fixture episode ep=' . $epNo . ' ' . $res->message() . PHP_EOL;

                continue;
            }
            $srcN = isset($spec['sources']) && is_array($spec['sources']) ? count($spec['sources']) : 1;
            echo 'OK fixture episode ep=' . $epNo . ' id=' . (int) ($res['id'] ?? $epId) . ' sources=' . $srcN . PHP_EOL;
        }
    }

    private static function printSummary(int $embedDocId, int $vodDocId, int $emptyDocId, int $seriesId): void
    {
        echo PHP_EOL . '=== video acceptance fixture ===' . PHP_EOL;
        echo 'tag:        /' . self::TAG_SLUG . ' (slug ' . self::TAG_SLUG . ')' . PHP_EOL;
        echo 'embed doc:  /documents/' . $embedDocId . '.html  (' . self::DOC_EMBED . ')' . PHP_EOL;
        echo 'vod doc:    /documents/' . $vodDocId . '.html  (' . self::DOC_VOD . ' · series ' . self::SERIES_SLUG . ' · ep1 双线路 B站+直链)' . PHP_EOL;
        echo 'empty doc:  /documents/' . $emptyDocId . '.html  (' . self::DOC_EMPTY . ')' . PHP_EOL;
        echo 'plaza:      /doc_vod/plaza' . PHP_EOL;
        echo 'channel:    /doc_vod/series/' . self::SERIES_SLUG . PHP_EOL;
        echo 'admin:      /admin/#/weapp/doc_vod/series · stats' . PHP_EOL;
        echo 'PASS fixture summary series_id=' . $seriesId . PHP_EOL;
    }
}
