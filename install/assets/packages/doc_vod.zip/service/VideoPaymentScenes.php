<?php
declare(strict_types=1);

namespace weapp\doc_vod\service;

/** doc_vod 支付 scene（仅插件内引用；内核经 PaymentFulfillmentRegistry 分发） */
final class VideoPaymentScenes
{
    public const EPISODE = 'doc_vod_episode';
    public const SERIES  = 'doc_vod_series';
}
