<?php
declare(strict_types=1);

namespace weapp\doc_vod\service;




use weapp\doc_vod\model\WeappVideoItem;
use weapp\doc_vod\model\WeappVideoEpisode;
use think\facade\Db;
use app\common\service\weapp\WeappEntitlementGateway;
use app\common\service\weapp\WeappFrontGateway;
use app\common\service\weapp\WeappSearchGateway;
use app\common\service\weapp\WeappTemplateGateway;
use app\common\service\weapp\WeappSupportGateway;

/** 文档视频 业务逻辑 */
class VideoService
{
    public static function ensureAutoload(): void
    {
        // no-op; class loaded by Plugin::boot or bridge
    }

    public static function isActive(): bool
    {
        return app(WeappEntitlementGateway::class)->entitlementCan('doc_vod') && VideoConfigService::isOpen();
    }

    /** @param array<string,mixed> $attrs @param array<string,mixed> $pageVars */
    public static function resolveDocumentId(array $attrs, array $pageVars): int
    {
        return (int) ($attrs['id'] ?? $attrs['aid'] ?? $attrs['document_id'] ?? $pageVars['document_id'] ?? 0);
    }

    /** @return list<array<string,mixed>> */
    public static function listForDocument(int $documentId): array
    {
        if (!self::isActive() || $documentId < 1) {
            return [];
        }

        return WeappVideoItem::where('document_id', $documentId)
            ->where('status', 1)
            ->order(['sort' => 'asc', 'id' => 'asc'])
            ->select()
            ->toArray();
    }

    /**
     * 有嵌入视频或点播单集的文档 ID（arclist has=doc_vod）。
     *
     * @return list<int>
     */
    public static function documentIdsWithPublicAvailability(): array
    {
        if (!self::isActive()) {
            return [];
        }
        $ids = [];
        try {
            $embed = WeappVideoItem::where('status', 1)
                ->where('document_id', '>', 0)
                ->distinct(true)
                ->column('document_id');
            foreach ($embed ?: [] as $id) {
                $ids[(int) $id] = true;
            }
            if (VideoAccessService::schemaReady()) {
                $eps = WeappVideoEpisode::where('status', 1)
                    ->where('document_id', '>', 0)
                    ->distinct(true)
                    ->column('document_id');
                foreach ($eps ?: [] as $id) {
                    $ids[(int) $id] = true;
                }
            }
        } catch (\Throwable $e) {
            app(WeappSupportGateway::class)->kernelOpsLog('vod_document_ids_availability_failed', [
                'msg' => $e->getMessage(),
            ]);

            return [];
        }

        return array_values(array_filter(array_map('intval', array_keys($ids)), static fn (int $id): bool => $id > 0));
    }

    /** @param array<string,mixed> $attrs @param array<string,mixed> $pageVars */
    public static function renderTag(array $attrs, array $pageVars, string $tpl): string
    {
        if (!self::isActive()) {
            return '';
        }
        $documentId = self::resolveDocumentId($attrs, $pageVars);
        if ($documentId < 1) {
            return '';
        }
        if (VideoAccessService::schemaReady()) {
            $episodes = VideoPlaybackService::listEpisodesForDocument($documentId);
            if ($episodes !== []) {
                return self::renderVodBlock($episodes, $tpl);
            }
        }

        $rows = self::listForDocument($documentId);
        if ($rows === []) {
            return '';
        }
        $defaultTpl = '<div class="pv-video-item"><div class="pv-video-embed">{$field.embed_html}</div><p class="pv-video-title">{$field.title}</p></div>';
        $tpl = trim($tpl) !== '' ? $tpl : $defaultTpl;
        $items = array_map([self::class, 'formatPublic'], $rows);
        $out = app(WeappTemplateGateway::class)->templateRenderItemLoop($tpl, $items, $pageVars);

        return self::appendFrontStyles($out);
    }

    /** 嵌入列表也加载点播样式（16:9 容器与窄屏） */
    private static function appendFrontStyles(string $html): string
    {
        if ($html !== '') {
            app(WeappFrontGateway::class)->frontAssetRegisterVideoVodStyles();
        }

        return $html;
    }

    /** 频道/广场等整页点播块：CSS + 播放器脚本 */
    public static function appendVodFrontAssets(string $html): string
    {
        if ($html === '') {
            return $html;
        }
        app(WeappFrontGateway::class)->frontAssetRegisterVideoVod();

        return self::appendFrontStyles($html);
    }

    /**
     * @param list<array<string, mixed>> $episodes
     */
    private static function renderVodBlock(array $episodes, string $tpl): string
    {
        $useDefault = trim($tpl) === '';
        if (!$useDefault) {
            $out = '<div class="pv-vod-list pv-vod-list--legacy" data-pv-vod-list>';
            foreach ($episodes as $ep) {
                if (is_array($ep)) {
                    $out .= self::renderVodEpisodeFromTpl($ep, $tpl);
                }
            }
            $out .= '</div>';
        } else {
            $out = self::renderVodEpisodesMarkup($episodes);
        }
        app(WeappFrontGateway::class)->frontAssetRegisterVideoVod();

        return $out;
    }

    /**
     * B 站式：左播放区 + 右选集（权限/试看/价格）
     *
     * @param list<array<string, mixed>> $episodes
     * @param array<string, mixed> $options channel|series_id|ep_search
     */
    public static function renderVodEpisodesMarkup(array $episodes, array $options = []): string
    {
        return self::renderVodBilibiliLayout($episodes, $options);
    }

    /**
     * @param list<array<string, mixed>> $episodes
     * @param array<string, mixed> $options
     */
    private static function renderVodBilibiliLayout(array $episodes, array $options = []): string
    {
        $items = '';
        foreach ($episodes as $ep) {
            if (is_array($ep)) {
                $items .= self::renderVodEpisodeSidebarHtml($ep);
            }
        }
        $count = count($episodes);
        $seriesTitle = '';
        $sid         = (int) ($episodes[0]['series_id'] ?? 0);
        if ($sid > 0) {
            $sr = VideoAccessService::seriesRow($sid);
            if (is_array($sr)) {
                $seriesTitle = htmlspecialchars((string) ($sr['title'] ?? ''), ENT_QUOTES, 'UTF-8');
            }
        }
        $seriesHead = $seriesTitle !== ''
            ? '<p class="pv-vod-layout__series-title">' . $seriesTitle . '</p>'
            : '';
        $searchBox  = '';
        if (!empty($options['ep_search'])) {
            $searchBox = '<div class="pv-vod-layout__search mb-2">'
                . '<input type="search" class="form-control form-control-sm" '
                . 'placeholder="筛选集数/标题" data-pv-vod-ep-filter autocomplete="off">'
                . '</div>';
        }
        $autoNext = VideoConfigService::autoNextSec();
        $layoutAttrs = ' data-pv-vod-list';
        if (!empty($options['channel'])) {
            $layoutAttrs .= ' data-pv-vod-channel="1"';
        }
        if ($sid > 0) {
            $layoutAttrs .= ' data-series-id="' . $sid . '"';
        }
        if ($autoNext > 0) {
            $layoutAttrs .= ' data-auto-next-sec="' . $autoNext . '"';
        }

        return '<div class="pv-vod-layout"' . $layoutAttrs . '>'
            . '<div class="pv-vod-layout__main">'
            . '<div class="pv-vod-layout__player-wrap">'
            . '<h3 class="pv-vod-layout__playing-title" data-pv-vod-playing-title></h3>'
            . '<div class="pv-vod-player-shell"><div class="pv-vod-player" data-pv-vod-player></div></div>'
            . '</div></div>'
            . '<aside class="pv-vod-layout__sidebar" aria-label="选集列表">'
            . '<div class="pv-vod-layout__sidebar-head">'
            . '<span class="pv-vod-layout__sidebar-label">选集</span>'
            . '<span class="pv-vod-layout__sidebar-count">共 ' . $count . ' 集</span>'
            . '</div>'
            . $seriesHead
            . $searchBox
            . '<div class="pv-vod-ep-list" role="list">' . $items . '</div>'
            . '<div class="pv-vod-layout__source-panel" data-pv-vod-source-panel>'
            . '<div class="pv-vod-layout__source-head">片源</div>'
            . '<p class="pv-vod-layout__source-hint text-muted small mb-2">同一集可配置爱奇艺、哔哩哔哩、本地等多条线路</p>'
            . '<div class="pv-vod-sources-slot" data-pv-vod-sources-slot></div>'
            . '</div>'
            . '</aside></div>';
    }

    /** @param array<string, mixed> $ep */
    private static function renderVodEpisodeSidebarHtml(array $ep): string
    {
        $id        = (int) ($ep['id'] ?? 0);
        $epNo      = (int) ($ep['ep_no'] ?? 0);
        $numLabel  = $epNo > 0 ? (string) $epNo : (string) $id;
        $title     = htmlspecialchars((string) ($ep['title'] ?? ''), ENT_QUOTES, 'UTF-8');
        $titleAttr = $title;
        $badge     = htmlspecialchars((string) ($ep['badge_text'] ?? $ep['need_label'] ?? ''), ENT_QUOTES, 'UTF-8');
        $bType     = preg_replace('/[^a-z0-9_-]/', '', (string) ($ep['badge_type'] ?? 'muted')) ?: 'muted';
        $needLabel = htmlspecialchars((string) ($ep['need_label'] ?? ''), ENT_QUOTES, 'UTF-8');
        $price     = trim((string) ($ep['price_text'] ?? ''));
        $priceHtml = $price !== ''
            ? '<span class="pv-vod-ep__price">' . htmlspecialchars($price, ENT_QUOTES, 'UTF-8') . '</span>'
            : '';
        $srcCount  = (int) ($ep['source_count'] ?? 0);
        $srcBadge  = $srcCount > 1
            ? '<span class="pv-vod-ep__src-count">' . $srcCount . ' 源</span>'
            : '';

        $progress = '';
        $pct      = (int) ($ep['progress_pct'] ?? 0);
        if ($pct > 0) {
            $label = htmlspecialchars((string) ($ep['progress_label'] ?? ''), ENT_QUOTES, 'UTF-8');
            $progress = '<div class="pv-vod-ep__progress" style="--pv-progress:' . $pct . '%"><span>' . $label . '</span></div>';
        }
        $duration = '';
        $durLabel = trim((string) ($ep['duration_label'] ?? ''));
        if ($durLabel !== '') {
            $duration = '<span class="pv-vod-ep__duration">' . htmlspecialchars($durLabel, ENT_QUOTES, 'UTF-8') . '</span>';
        }

        $cover = (string) ($ep['cover_url'] ?? '');
        $thumb = $cover !== ''
            ? '<div class="pv-vod-ep__thumb-mini"><img src="' . htmlspecialchars($cover, ENT_QUOTES, 'UTF-8') . '" alt="" loading="lazy"></div>'
            : '';

        return '<div class="pv-vod-ep" role="listitem" data-episode-id="' . $id
            . '" data-series-id="' . (int) ($ep['series_id'] ?? 0)
            . '" data-ep-no="' . $epNo
            . '" data-allowed="' . (int) ($ep['allowed'] ?? 0)
            . '" data-ep-title="' . $titleAttr . '">'
            . '<span class="pv-vod-ep__num" aria-hidden="true">' . htmlspecialchars($numLabel, ENT_QUOTES, 'UTF-8') . '</span>'
            . '<div class="pv-vod-ep__body">'
            . '<div class="pv-vod-ep__row">'
            . '<strong class="pv-vod-ep__title">' . $title . '</strong>'
            . $duration
            . '</div>'
            . '<div class="pv-vod-ep__meta-line">'
            . '<span class="pv-vod-ep__badge pv-vod-ep__badge--' . $bType . '" title="' . $needLabel . '">' . $badge . '</span>'
            . $srcBadge
            . $priceHtml
            . '</div>'
            . $progress
            . '</div>'
            . $thumb
            . '</div>';
    }

    /** @param array<string, mixed> $ep */
    private static function renderVodEpisodeFromTpl(array $ep, string $tpl): string
    {
        $chunk = $tpl;
        foreach ($ep as $key => $val) {
            if (is_scalar($val)) {
                $chunk = str_replace('{$field.' . $key . '}', htmlspecialchars((string) $val), $chunk);
            }
        }

        return $chunk;
    }

    public static function wrapEmbed(string $innerHtml): string
    {
        if ($innerHtml === '') {
            return '';
        }
        if (str_contains($innerHtml, 'pv-vod-embed-ratio')) {
            return $innerHtml;
        }

        return '<div class="pv-vod-embed-ratio">' . $innerHtml . '</div>';
    }

    /** @param array<string,mixed> $row @return array<string, mixed> */
    public static function formatPublic(array $row): array
    {
        $videoUrl = self::publicUrl((string) ($row['video_url'] ?? ''));
        $coverUrl = self::publicUrl((string) ($row['cover_path'] ?? ''));

        return [
            'id' => (int) ($row['id'] ?? 0),
            'title' => (string) ($row['title'] ?? ''),
            'video_url' => $videoUrl,
            'cover_url' => $coverUrl,
            'provider' => (string) ($row['provider'] ?? ''),
            'embed_html' => self::buildEmbedHtml($videoUrl, $coverUrl, (string) ($row['title'] ?? '')),
        ];
    }

    public static function buildEmbedHtmlPublic(string $videoUrl, string $coverUrl, string $title): string
    {
        return self::buildEmbedHtml($videoUrl, $coverUrl, $title);
    }

    private static function buildEmbedHtml(string $videoUrl, string $coverUrl, string $title): string
    {
        if ($videoUrl === '') {
            return '';
        }
        if (preg_match('#<iframe[^>]+src\s*=\s*["\']([^"\']+)#i', $videoUrl, $im)) {
            $videoUrl = html_entity_decode($im[1], ENT_QUOTES, 'UTF-8');
        }
        $safeTitle = htmlspecialchars($title, ENT_QUOTES, 'UTF-8');
        if (preg_match('#open\.iqiyi\.com/.*(?:coopPlayerIndex|player)#i', $videoUrl)
            || preg_match('#dispatcher\.video\.iqiyi\.com/.*shareplayer#i', $videoUrl)) {
            $src = htmlspecialchars($videoUrl, ENT_QUOTES, 'UTF-8');

            return self::wrapEmbed(
                '<iframe class="pv-video-iframe" src="' . $src . '" title="' . $safeTitle
                . '" allowfullscreen loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>'
            );
        }
        if (preg_match('#(?:youtube\.com/watch\?v=|youtu\.be/)([\w-]+)#i', $videoUrl, $m)) {
            $id = htmlspecialchars($m[1], ENT_QUOTES, 'UTF-8');

            return self::wrapEmbed(
                '<iframe class="pv-video-iframe" src="https://www.youtube.com/embed/' . $id
                . '" title="' . $safeTitle . '" allowfullscreen loading="lazy"></iframe>'
            );
        }
        if (preg_match('#bilibili\.com/video/(BV[\w]+)#i', $videoUrl, $m)) {
            $id = htmlspecialchars($m[1], ENT_QUOTES, 'UTF-8');

            return self::wrapEmbed(
                '<iframe class="pv-video-iframe" src="https://player.bilibili.com/player.html?bvid=' . $id
                . '" title="' . $safeTitle . '" allowfullscreen loading="lazy"></iframe>'
            );
        }
        if (preg_match('#\.(mp4|webm|ogg)(\?|$)#i', $videoUrl)) {
            $src = htmlspecialchars($videoUrl, ENT_QUOTES, 'UTF-8');
            $poster = $coverUrl !== '' ? ' poster="' . htmlspecialchars($coverUrl, ENT_QUOTES, 'UTF-8') . '"' : '';

            return '<video class="pv-video-native" controls preload="metadata"' . $poster . '><source src="' . $src . '"></video>';
        }
        if (preg_match('#iqiyi\.com#i', $videoUrl)) {
            return self::platformExternalCard($videoUrl, $safeTitle, '爱奇艺', $coverUrl);
        }
        if (preg_match('#youku\.com#i', $videoUrl)) {
            return self::platformExternalCard($videoUrl, $safeTitle, '优酷', $coverUrl);
        }
        if (preg_match('#v\.qq\.com#i', $videoUrl)) {
            return self::platformExternalCard($videoUrl, $safeTitle, '腾讯视频', $coverUrl);
        }
        if (preg_match('#mgtv\.com#i', $videoUrl)) {
            return self::platformExternalCard($videoUrl, $safeTitle, '芒果 TV', $coverUrl);
        }
        $href = htmlspecialchars($videoUrl, ENT_QUOTES, 'UTF-8');
        $cover = $coverUrl !== '' ? htmlspecialchars($coverUrl, ENT_QUOTES, 'UTF-8') : '';

        return self::platformExternalCard($videoUrl, $safeTitle, '外链视频', $coverUrl);
    }

    private static function platformExternalCard(string $url, string $safeTitle, string $platform, string $coverUrl): string
    {
        $href  = htmlspecialchars($url, ENT_QUOTES, 'UTF-8');
        $plat  = htmlspecialchars($platform, ENT_QUOTES, 'UTF-8');
        $cover = $coverUrl !== '' ? htmlspecialchars($coverUrl, ENT_QUOTES, 'UTF-8') : '';
        $img   = $cover !== ''
            ? '<img class="pv-vod-platform-card__cover" src="' . $cover . '" alt="">'
            : '<span class="pv-vod-platform-card__icon" aria-hidden="true"><i class="bi bi-box-arrow-up-right"></i></span>';

        return self::wrapEmbed(
            '<div class="pv-vod-platform-card" data-pv-platform="' . $plat . '">'
            . $img
            . '<p class="pv-vod-platform-card__title">' . $safeTitle . '</p>'
            . '<p class="pv-vod-platform-card__hint">' . $plat . ' 播放页无法在本站直接嵌入。请在后台粘贴该平台「分享 → 通用代码」里的 <code>iframe</code> 地址，或点击下方按钮前往观看。</p>'
            . '<a class="btn btn-primary btn-sm pv-vod-platform-card__open" href="' . $href
            . '" target="_blank" rel="noopener noreferrer">前往 ' . $plat . ' 观看</a>'
            . '</div>'
        );
    }

    public static function publicUrl(string $path): string
    {
        $path = trim($path);
        if ($path === '') {
            return '';
        }
        if (str_starts_with($path, 'http://') || str_starts_with($path, 'https://') || str_starts_with($path, '//')) {
            return $path;
        }

        if (str_starts_with($path, '/')) {
            return $path;
        }
        if (str_starts_with($path, 'uploads/')) {
            return '/' . $path;
        }

        return '/uploads/' . ltrim($path, '/');
    }

    /** @return array{total:int,enabled:int} */
    public static function statsAdmin(): array
    {
        if (!app(WeappEntitlementGateway::class)->entitlementCan('doc_vod')) {
            return ['total' => 0, 'enabled' => 0];
        }
        $total = (int) WeappVideoItem::count();
        $enabled = (int) WeappVideoItem::where('status', 1)->count();

        return ['total' => $total, 'enabled' => $enabled];
    }

    /** @param array<string,mixed> $filters */
    public static function listAdmin(array $filters = [], int $page = 1, int $pageSize = 20)
    {
        if (!app(WeappEntitlementGateway::class)->entitlementCan('doc_vod')) {
            return app(WeappSupportGateway::class)->resultFail('plugin_disabled');
        }
        $page = max(1, $page);
        $pageSize = max(10, min(100, $pageSize));
        $query = WeappVideoItem::with(['document' => static function ($documentQuery): void {
            $documentQuery->field('id,title');
        }]);
        $documentId = (int) ($filters['document_id'] ?? 0);
        if ($documentId > 0) {
            $query->where('document_id', $documentId);
        }
        $status = $filters['status'] ?? '';
        if ($status !== '' && $status !== null) {
            $query->where('status', (int) $status);
        }
        $keyword = trim((string) ($filters['keyword'] ?? ''));
        if ($keyword !== '') {
            $query->whereLike('title|video_url', app(WeappSearchGateway::class)->searchLikePattern($keyword));
        }
        $total = (int) (clone $query)->count();
        $rows  = app(WeappSupportGateway::class)->modelRelationMapBelongsTo(
            $query->order('id', 'desc')->page($page, $pageSize)->select(),
            'document',
            ['title' => 'document_title'],
        );
        foreach ($rows as &$row) {
            $row['status_label'] = (int) ($row['status'] ?? 0) === 1 ? '启用' : '禁用';
        }
        unset($row);

        return app(WeappSupportGateway::class)->resultList($rows, $total);
    }

    /** @param array<string,mixed> $data */
    public static function saveAdmin(array $data)
    {
        if (!app(WeappEntitlementGateway::class)->entitlementCan('doc_vod')) {
            return app(WeappSupportGateway::class)->resultFail('plugin_disabled');
        }
        $id = (int) ($data['id'] ?? 0);
        $documentId = (int) ($data['document_id'] ?? 0);
        if ($documentId < 1) {
            return app(WeappSupportGateway::class)->resultFail('请填写文档 ID');
        }
        $payload = [
            'document_id' => $documentId,
            'title' => trim((string) ($data['title'] ?? '')),
            'video_url' => trim((string) ($data['video_url'] ?? '')),
            'cover_path' => trim((string) ($data['cover_path'] ?? '')),
            'provider' => trim((string) ($data['provider'] ?? '')),
            'sort'        => (int) ($data['sort'] ?? 0),
            'status'      => !empty($data['status']) ? 1 : 0,
            'updated_at'  => app(WeappSupportGateway::class)->appTimeNow(),
        ];
        if (($payload['title'] ?? '') === '') {
            return app(WeappSupportGateway::class)->resultFail('请填写标题');
        }
        if (($payload['video_url'] ?? '') === '') {
            return app(WeappSupportGateway::class)->resultFail('请填写视频地址');
        }

        if ($id > 0) {
            WeappVideoItem::where('id', $id)->update($payload);

            return app(WeappSupportGateway::class)->resultOk(['id' => $id], '更新成功');
        }
        $payload['created_at'] = app(WeappSupportGateway::class)->appTimeNow();
        $newId = (int) WeappVideoItem::insertGetId($payload);

        return app(WeappSupportGateway::class)->resultOk(['id' => $newId], '添加成功');
    }

    public static function deleteAdmin(int $id)
    {
        if (!app(WeappEntitlementGateway::class)->entitlementCan('doc_vod') || $id < 1) {
            return app(WeappSupportGateway::class)->resultFail('invalid_id');
        }
        WeappVideoItem::where('id', $id)->delete();

        return app(WeappSupportGateway::class)->resultOk(null, 'ok');
    }

    public static function statusAdmin(int $id, int $status)
    {
        if (!app(WeappEntitlementGateway::class)->entitlementCan('doc_vod') || $id < 1) {
            return app(WeappSupportGateway::class)->resultFail('invalid_id');
        }
        WeappVideoItem::where('id', $id)->update([
            'status'     => $status === 1 ? 1 : 0,
            'updated_at' => app(WeappSupportGateway::class)->appTimeNow(),
        ]);

        return app(WeappSupportGateway::class)->resultOk(null, 'ok');
    }

    /**
     * 文档发布页同步视频列表（标装：业务在 weapp）
     *
     * @param list<array<string, mixed>> $items
     * @return mixed
     */
    public static function syncForDocument(int $documentId, array $items)
    {
        if (!self::isActive() || $documentId < 1) {
            return app(WeappSupportGateway::class)->resultFail('参数错误');
        }
        Db::startTrans();
        try {
            $keepIds = [];
            $sort    = 0;
            foreach ($items as $row) {
                if (!is_array($row)) {
                    continue;
                }
                $videoUrl = trim((string) ($row['video_url'] ?? ''));
                if ($videoUrl === '') {
                    continue;
                }
                $title = trim((string) ($row['title'] ?? ''));
                if ($title === '') {
                    $title = '视频';
                }
                $res = self::saveAdmin([
                    'id'          => (int) ($row['id'] ?? 0),
                    'document_id' => $documentId,
                    'title'       => $title,
                    'video_url'   => $videoUrl,
                    'cover_path'  => trim((string) ($row['cover_path'] ?? '')),
                    'provider'    => trim((string) ($row['provider'] ?? '')),
                    'sort'        => (int) ($row['sort'] ?? $sort),
                    'status'      => !empty($row['status']) ? 1 : 0,
                ]);
                if (!$res->isOk()) {
                    Db::rollback();

                    return app(WeappSupportGateway::class)->resultFail((string) ($res->message() ?? '视频同步失败'));
                }
                $newId = (int) ($res->dataArray()['id'] ?? 0);
                if ($newId > 0) {
                    $keepIds[] = $newId;
                }
                $sort++;
            }
            if ($keepIds === []) {
                WeappVideoItem::where('document_id', $documentId)->delete();
            } else {
                WeappVideoItem::where('document_id', $documentId)
                    ->whereNotIn('id', $keepIds)
                    ->delete();
            }
            Db::commit();
        } catch (\Throwable $e) {
            Db::rollback();
            app(WeappSupportGateway::class)->kernelOpsLog('video_sync_for_document_failed', [
                'document_id' => $documentId,
                'msg'         => $e->getMessage(),
            ]);

            return app(WeappSupportGateway::class)->resultFail('同步失败');
        }

        return app(WeappSupportGateway::class)->resultOk(null, 'ok');
    }

    public static function purgeForDocument(int $documentId): void
    {
        if ($documentId < 1) {
            return;
        }
        WeappVideoItem::where('document_id', $documentId)->delete();
    }
}