<?php
declare(strict_types=1);

namespace weapp\doc_vod\service;




use weapp\doc_vod\model\WeappVideoWatchProgress;
use think\facade\Db;
use app\common\service\weapp\WeappPluginGateway;
use app\common\service\weapp\WeappDocumentGateway;
use app\common\service\weapp\WeappFrontGateway;
use app\common\service\weapp\WeappSupportGateway;

/** 观看进度读写 */
class VideoWatchProgressService
{
    public static function boot(): void
    {
        app(WeappPluginGateway::class)->pluginRouteRegister(
            'post',
            'api/v1/plugins/doc_vod/progress',
            '\\weapp\\doc_vod\\api\\controller\\Video@saveProgress'
        );
        app(WeappPluginGateway::class)->pluginRouteRegister(
            'get',
            'api/v1/plugins/doc_vod/progress',
            '\\weapp\\doc_vod\\api\\controller\\Video@getProgress'
        );
    }

    public static function schemaReady(): bool
    {
        return VideoAccessService::schemaReady();
    }

    /** @return mixed */
    public static function save(int $userId, int $episodeId, int $positionSec)
    {
        if ($userId < 1 || $episodeId < 1 || !self::schemaReady()) {
            return app(WeappSupportGateway::class)->resultFail('参数无效');
        }
        if (VideoAccessService::episodeRow($episodeId) === null) {
            return app(WeappSupportGateway::class)->resultFail('单集不存在');
        }
        $positionSec = max(0, min(86400 * 48, $positionSec));
        $now         = app(WeappSupportGateway::class)->appTimeNow();
        $exists      = WeappVideoWatchProgress::where('user_id', $userId)
            ->where('episode_id', $episodeId)
            ->find();
        if ($exists) {
            WeappVideoWatchProgress::where('user_id', $userId)
                ->where('episode_id', $episodeId)
                ->update(['position_sec' => $positionSec, 'updated_at' => $now]);
        } else {
            WeappVideoWatchProgress::insert([
                'user_id'       => $userId,
                'episode_id'    => $episodeId,
                'position_sec'  => $positionSec,
                'updated_at'    => $now,
            ]);
        }

        return app(WeappSupportGateway::class)->resultOk(['position_sec' => $positionSec], '');
    }

    /** @return mixed */
    public static function getForUser(int $userId, int $episodeId)
    {
        if ($userId < 1 || $episodeId < 1 || !self::schemaReady()) {
            return app(WeappSupportGateway::class)->resultFail('参数无效');
        }
        $row = WeappVideoWatchProgress::where('user_id', $userId)
            ->where('episode_id', $episodeId)
            ->find();

        return app(WeappSupportGateway::class)->resultOk(['position_sec' => (int) (is_array($row) ? ($row['position_sec'] ?? 0) : 0)], '');
    }

    /** @return list<array<string, mixed>> */
    public static function listForMember(int $userId, int $limit = 20): array
    {
        if ($userId < 1 || !self::schemaReady()) {
            return [];
        }
        $models = WeappVideoWatchProgress::with([
            'episode' => static function ($episodeQuery): void {
                $episodeQuery->field('id,title,cover_path,document_id,series_id')->with([
                    'series' => static function ($seriesQuery): void {
                        $seriesQuery->field('id,title');
                    },
                ]);
            },
        ])
            ->where('user_id', $userId)
            ->order('updated_at', 'desc')
            ->limit(max(1, min(50, $limit)))
            ->field('episode_id,position_sec,updated_at')
            ->select();
        $out = [];
        foreach ($models as $model) {
            $row    = $model->toArray();
            $episode = is_array($row['episode'] ?? null) ? $row['episode'] : [];
            if ($episode === []) {
                continue;
            }
            $series  = is_array($episode['series'] ?? null) ? $episode['series'] : [];
            $docId   = (int) ($episode['document_id'] ?? 0);
            $posSec  = (int) ($row['position_sec'] ?? 0);
            $docUrl = self::documentUrl($docId);
            if ($docUrl !== '' && $posSec > 0) {
                $docUrl .= (str_contains($docUrl, '?') ? '&' : '?') . 'video_unlock=' . (int) ($row['episode_id'] ?? 0);
            }
            $out[] = [
                'episode_id'      => (int) ($row['episode_id'] ?? 0),
                'position_sec'    => $posSec,
                'position_label'  => VideoEpisodeDisplayService::formatClock($posSec),
                'updated_at'      => (string) ($row['updated_at'] ?? ''),
                'title'           => (string) ($episode['title'] ?? ''),
                'series_title'    => (string) ($series['title'] ?? ''),
                'document_id'     => $docId,
                'document_url'    => $docUrl,
                'cover_url'       => VideoService::publicUrl((string) ($episode['cover_path'] ?? '')),
            ];
        }

        return $out;
    }

    private static function documentUrl(int $documentId): string
    {
        if ($documentId < 1) {
            return '';
        }
        $doc = app(WeappDocumentGateway::class)->documentRowById($documentId, true);
        if (!is_array($doc) || $doc === []) {
            return '';
        }

        return app(WeappFrontGateway::class)->frontBuildDocumentUrl($doc);
    }
}
