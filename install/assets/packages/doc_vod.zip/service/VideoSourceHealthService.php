<?php
declare(strict_types=1);

namespace weapp\doc_vod\service;



use weapp\doc_vod\model\WeappVideoEpisode;
use weapp\doc_vod\model\WeappVideoSource;
use think\facade\Db;
use app\common\service\weapp\WeappSupportGateway;

/** 播放线路可达性探测（HEAD/GET，结果写入 config_json） */
class VideoSourceHealthService
{
    /** @return mixed */
    public static function probeSeriesAdmin(int $seriesId, bool $network = true)
    {
        if (!VideoAccessService::schemaReady() || $seriesId < 1) {
            return app(WeappSupportGateway::class)->resultFail('不可用');
        }
        $epIds = WeappVideoEpisode::where('series_id', $seriesId)
            ->column('id');
        $epIds = array_map('intval', $epIds);
        if ($epIds === []) {
            return app(WeappSupportGateway::class)->resultFail('该剧集无单集');
        }
        $sources = WeappVideoSource::whereIn('episode_id', $epIds)
            ->where('status', 1)
            ->select()
            ->toArray();
        $items = [];
        $ok    = 0;
        $fail  = 0;
        foreach ($sources as $src) {
            if (!is_array($src)) {
                continue;
            }
            $srcId = (int) ($src['id'] ?? 0);
            if ($srcId < 1) {
                continue;
            }
            $item = self::probeOne($src, $network);
            self::persistHealth($srcId, $item);
            $items[] = $item;
            if (($item['status'] ?? '') === 'ok') {
                $ok++;
            } elseif (($item['status'] ?? '') === 'fail') {
                $fail++;
            }
        }

        return app(WeappSupportGateway::class)->resultOk([
            'items' => $items,
            'ok'    => $ok,
            'fail'  => $fail,
        ], "探测完成：{$ok} 正常 / {$fail} 异常 / " . count($items) . ' 条线路');
    }

    /** @param array<string, mixed> $src */
    private static function probeOne(array $src, bool $network): array
    {
        $srcId    = (int) ($src['id'] ?? 0);
        $provider = strtolower(trim((string) ($src['provider'] ?? '')));
        $url      = trim((string) ($src['play_url'] ?? ''));
        $label    = VideoSourceCatalog::label($src);
        $base     = [
            'source_id'  => $srcId,
            'episode_id' => (int) ($src['episode_id'] ?? 0),
            'label'      => $label,
            'provider'   => $provider,
            'play_url'   => $url,
        ];
        if (!$network) {
            return array_merge($base, [
                'status'  => 'skip',
                'msg'     => '未执行网络探测',
                'http'    => 0,
                'ms'      => 0,
            ]);
        }
        if ($url === '') {
            return array_merge($base, ['status' => 'fail', 'msg' => '无播放地址', 'http' => 0, 'ms' => 0]);
        }
        if (in_array($provider, ['embed', 'bilibili', 'iqiyi', 'youku', 'tencent', 'qq', 'mgtv', 'parse_url', 'parse_generic'], true)) {
            return array_merge($base, [
                'status' => 'skip',
                'msg'    => '平台嵌入/解析线路需前台人工验证',
                'http'   => 0,
                'ms'     => 0,
            ]);
        }
        if (!preg_match('#^https?://#i', $url)) {
            return array_merge($base, ['status' => 'skip', 'msg' => '相对路径或本地文件', 'http' => 0, 'ms' => 0]);
        }

        return array_merge($base, self::httpProbe($url));
    }

    /** @return array{status:string,msg:string,http:int,ms:int} */
    private static function httpProbe(string $url): array
    {
        $start = microtime(true);
        $ch    = curl_init($url);
        if ($ch === false) {
            return ['status' => 'fail', 'msg' => 'curl 初始化失败', 'http' => 0, 'ms' => 0];
        }
        curl_setopt_array($ch, [
            CURLOPT_NOBODY         => true,
            CURLOPT_FOLLOWLOCATION => false,
            CURLOPT_TIMEOUT        => 12,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
            CURLOPT_USERAGENT      => 'Pivark-Video-Health/1.0',
            CURLOPT_RETURNTRANSFER => true,
        ]);
        curl_exec($ch);
        $http = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $err  = curl_error($ch);
        curl_close($ch);
        $ms = (int) round((microtime(true) - $start) * 1000);
        if ($err !== '') {
            return ['status' => 'fail', 'msg' => $err, 'http' => $http, 'ms' => $ms];
        }
        if ($http >= 200 && $http < 400) {
            return ['status' => 'ok', 'msg' => '可达', 'http' => $http, 'ms' => $ms];
        }

        return ['status' => 'fail', 'msg' => 'HTTP ' . $http, 'http' => $http, 'ms' => $ms];
    }

    /** @param array<string, mixed> $probe */
    private static function persistHealth(int $sourceId, array $probe): void
    {
        $row = WeappVideoSource::where('id', $sourceId)->find();
        if (!is_array($row)) {
            return;
        }
        $json = VideoSourceCatalog::configWithHealth(
            (string) ($row['config_json'] ?? ''),
            [
                'status'     => (string) ($probe['status'] ?? 'skip'),
                'msg'        => (string) ($probe['msg'] ?? ''),
                'http'       => (int) ($probe['http'] ?? 0),
                'ms'         => (int) ($probe['ms'] ?? 0),
                'checked_at' => app(WeappSupportGateway::class)->appTimeNow(),
            ]
        );
        WeappVideoSource::where('id', $sourceId)->update([
            'config_json' => $json,
            'updated_at'  => app(WeappSupportGateway::class)->appTimeNow(),
        ]);
    }

    /** @param array<string, mixed> $source */
    public static function healthBadge(array $source): string
    {
        $data = self::healthFromConfig((string) ($source['config_json'] ?? ''));
        if ($data === []) {
            return '';
        }
        $st = (string) ($data['status'] ?? '');

        return match ($st) {
            'ok'   => '正常',
            'fail' => '异常',
            default => '',
        };
    }

    /** @return array<string, mixed> */
    public static function healthFromConfig(string $json): array
    {
        if ($json === '') {
            return [];
        }
        $data = json_decode($json, true);
        if (!is_array($data) || !is_array($data['health'] ?? null)) {
            return [];
        }

        return $data['health'];
    }
}
