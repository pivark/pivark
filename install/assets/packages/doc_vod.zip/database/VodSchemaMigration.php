<?php
declare(strict_types=1);

namespace weapp\doc_vod\database;

use app\common\contract\WeappSchemaMigration;

/**
 * doc_vod schema 台阶占位（SSOT：database/install.sql）。
 * Community 首版禁止再增 V2+ 台阶；升级链发版后再开。
 */
final class VodSchemaMigration extends WeappSchemaMigration
{
    public static function identifier(): string
    {
        return 'doc_vod';
    }

    public static function version(): int
    {
        return 1;
    }

    public static function up(): void
    {
        // install.sql 已含全量表结构；此处 intentionally empty。
    }
}
