<?php
/**
 * 元舟 PivArk — 企业全域原子化数字资产中枢
 * (c) 2024-2026 pivark.com. All rights reserved.
 * Author: Angelo
 * 未经允许，不可用于商业用途。
 */
/**
 * 视频点播 P4：转化漏斗日汇总字段
 * 用法: php app/database/migrations/migrate_doc_vod_pp4.php
 */
declare(strict_types=1);

require_once dirname(__DIR__, 4) . '/app/database/migrations/_migration_bootstrap.php';

$name = 'migrate_doc_vod_pp4';

function migration_down(PDO $pdo, string $pfx, string $db): void {
    // no-op structural rollback
}

migration_entry($name, static function (PDO $pdo, string $pfx, string $db): void {
    $col = migration_column_exists($db);
    
    $addColumn = static function (PDO $pdo, string $table, string $sql) use ($col, $pfx): void {
        if (!preg_match('/ADD COLUMN `([^`]+)`/', $sql, $m)) {
            return;
        }
        if (!$col($pdo, $pfx, $table, $m[1])) {
            $pdo->exec("ALTER TABLE `{$pfx}{$table}` {$sql}");
            echo "  + {$table}.{$m[1]}\n";
        }
    };
    
    $addColumn($pdo, 'weapp_doc_vod_play_daily', "ADD COLUMN `trial_end_hits` int unsigned NOT NULL DEFAULT 0 COMMENT '试看结束次数' AFTER `play_hits`");
    $addColumn($pdo, 'weapp_doc_vod_play_daily', "ADD COLUMN `buy_click_hits` int unsigned NOT NULL DEFAULT 0 COMMENT '购买点击次数' AFTER `trial_end_hits`");
});
