<?php
/**
 * 元舟 PivArk — 企业全域原子化数字资产中枢
 * (c) 2024-2026 pivark.com. All rights reserved.
 * Author: Angelo
 * 未经允许，不可用于商业用途。
 */
/**
 * 视频点播 P1：剧集/单集/来源/购买授权
 * 用法: php app/database/migrations/migrate_doc_vod_pp1.php
 */
declare(strict_types=1);

require_once dirname(__DIR__, 4) . '/app/database/migrations/_migration_bootstrap.php';

$name = 'migrate_doc_vod_pp1';

function migration_down(PDO $pdo, string $pfx, string $db): void {
    migration_drop_table_if_exists($pdo, $db, $pfx . 'weapp_doc_vod_watch_progress');
    migration_drop_table_if_exists($pdo, $db, $pfx . 'weapp_doc_vod_grants');
    migration_drop_table_if_exists($pdo, $db, $pfx . 'weapp_doc_vod_sources');
    migration_drop_table_if_exists($pdo, $db, $pfx . 'weapp_doc_vod_episodes');
    migration_drop_table_if_exists($pdo, $db, $pfx . 'weapp_doc_vod_series');
}

migration_entry($name, static function (PDO $pdo, string $pfx, string $db): void {
    $pdo->exec("CREATE TABLE IF NOT EXISTS `{$pfx}weapp_doc_vod_series` (
        `id` int unsigned NOT NULL AUTO_INCREMENT,
        `title` varchar(200) NOT NULL DEFAULT '',
        `slug` varchar(120) NOT NULL DEFAULT '',
        `cover_path` varchar(500) NOT NULL DEFAULT '',
        `summary` varchar(500) NOT NULL DEFAULT '',
        `access_mode` varchar(24) NOT NULL DEFAULT 'free' COMMENT 'free|login|level|paid_series',
        `read_level_id` int unsigned NOT NULL DEFAULT 0,
        `price` decimal(10,2) NOT NULL DEFAULT 0.00 COMMENT '全集售价',
        `sort` int NOT NULL DEFAULT 0,
        `status` tinyint NOT NULL DEFAULT 1,
        `created_at` datetime NOT NULL,
        `updated_at` datetime NOT NULL,
        PRIMARY KEY (`id`),
        KEY `idx_status` (`status`),
        KEY `idx_slug` (`slug`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='视频剧集'");
    
    $pdo->exec("CREATE TABLE IF NOT EXISTS `{$pfx}weapp_doc_vod_episodes` (
        `id` int unsigned NOT NULL AUTO_INCREMENT,
        `series_id` int unsigned NOT NULL DEFAULT 0,
        `document_id` int unsigned NOT NULL DEFAULT 0,
        `ep_no` int NOT NULL DEFAULT 0,
        `title` varchar(200) NOT NULL DEFAULT '',
        `cover_path` varchar(500) NOT NULL DEFAULT '',
        `access_mode` varchar(24) NOT NULL DEFAULT '' COMMENT '空=继承剧集',
        `read_level_id` int unsigned NOT NULL DEFAULT 0,
        `price` decimal(10,2) NOT NULL DEFAULT 0.00 COMMENT '单集售价',
        `duration_sec` int unsigned NOT NULL DEFAULT 0,
        `ad_cues_json` text COMMENT '广告点 JSON',
        `sort` int NOT NULL DEFAULT 0,
        `status` tinyint NOT NULL DEFAULT 1,
        `created_at` datetime NOT NULL,
        `updated_at` datetime NOT NULL,
        PRIMARY KEY (`id`),
        KEY `idx_series` (`series_id`),
        KEY `idx_document` (`document_id`),
        KEY `idx_status` (`status`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='视频单集'");
    
    $pdo->exec("CREATE TABLE IF NOT EXISTS `{$pfx}weapp_doc_vod_sources` (
        `id` int unsigned NOT NULL AUTO_INCREMENT,
        `episode_id` int unsigned NOT NULL,
        `provider` varchar(32) NOT NULL DEFAULT 'embed',
        `play_url` varchar(1000) NOT NULL DEFAULT '',
        `config_json` text,
        `priority` int NOT NULL DEFAULT 0,
        `status` tinyint NOT NULL DEFAULT 1,
        `created_at` datetime NOT NULL,
        `updated_at` datetime NOT NULL,
        PRIMARY KEY (`id`),
        KEY `idx_episode` (`episode_id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='视频播放源'");
    
    $pdo->exec("CREATE TABLE IF NOT EXISTS `{$pfx}weapp_doc_vod_grants` (
        `id` int unsigned NOT NULL AUTO_INCREMENT,
        `user_id` int unsigned NOT NULL,
        `grant_type` varchar(16) NOT NULL COMMENT 'episode|series',
        `ref_id` int unsigned NOT NULL,
        `payment_order_no` varchar(64) NOT NULL DEFAULT '',
        `amount` decimal(10,2) NOT NULL DEFAULT 0.00,
        `created_at` datetime NOT NULL,
        PRIMARY KEY (`id`),
        UNIQUE KEY `uk_user_grant` (`user_id`,`grant_type`,`ref_id`),
        KEY `idx_order` (`payment_order_no`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='视频观看授权'");
    
    $pdo->exec("CREATE TABLE IF NOT EXISTS `{$pfx}weapp_doc_vod_watch_progress` (
        `id` int unsigned NOT NULL AUTO_INCREMENT,
        `user_id` int unsigned NOT NULL,
        `episode_id` int unsigned NOT NULL,
        `position_sec` int unsigned NOT NULL DEFAULT 0,
        `updated_at` datetime NOT NULL,
        PRIMARY KEY (`id`),
        UNIQUE KEY `uk_user_ep` (`user_id`,`episode_id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='观看进度'");
    
    echo "  + weapp_doc_vod_series/episodes/sources/grants/watch_progress\n";
});
