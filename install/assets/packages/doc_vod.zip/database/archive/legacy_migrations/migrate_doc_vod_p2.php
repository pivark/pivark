<?php
/**
 * 元舟 PivArk — 企业全域原子化数字资产中枢
 * (c) 2024-2026 pivark.com. All rights reserved.
 * Author: Angelo
 * 未经允许，不可用于商业用途。
 */
/**
 * 视频点播 P2：试看、免费前 N 集、播放计数
 * 用法: php app/database/migrations/migrate_doc_vod_pp2.php
 */
declare(strict_types=1);

require_once dirname(__DIR__, 4) . '/app/database/migrations/_migration_bootstrap.php';

$name = 'migrate_doc_vod_pp2';

function migration_down(PDO $pdo, string $pfx, string $db): void {
    // no-op structural rollback
}

migration_entry($name, static function (PDO $pdo, string $pfx, string $db): void {
    $col = migration_column_exists($db);
    
    $addColumn = static function (PDO $pdo, string $table, string $sql) use ($col, $pfx): void {
        if (!preg_match('/ADD COLUMN `([^`]+)`/', $sql, $m)) {
            return;
        }
        if (!$col($pdo, $pfx, $table, $m[1])) {
            $pdo->exec("ALTER TABLE `{$pfx}{$table}` {$sql}");
            echo "  + {$table}.{$m[1]}\n";
        }
    };
    
    $addColumn($pdo, 'weapp_doc_vod_series', "ADD COLUMN `trial_preview_sec` int unsigned NOT NULL DEFAULT 0 COMMENT '试看秒数(0=关)' AFTER `price`");
    $addColumn($pdo, 'weapp_doc_vod_series', "ADD COLUMN `free_ep_count` int unsigned NOT NULL DEFAULT 0 COMMENT '前N集免费(0=关)' AFTER `trial_preview_sec`");
    $addColumn($pdo, 'weapp_doc_vod_episodes', "ADD COLUMN `trial_preview_sec` int unsigned NOT NULL DEFAULT 0 COMMENT '单集试看秒(0=继承剧集)' AFTER `price`");
    $addColumn($pdo, 'weapp_doc_vod_episodes', "ADD COLUMN `play_count` int unsigned NOT NULL DEFAULT 0 COMMENT '播放次数' AFTER `duration_sec`");
    
    echo "  + video vod p2 columns\n";
});
