<?php
/**
 * 元舟 PivArk — 企业全域原子化数字资产中枢
 * (c) 2024-2026 pivark.com. All rights reserved.
 * Author: Angelo
 * 未经允许，不可用于商业用途。
 */
/**
 * 视频点播 P3：日播放汇总、解析日志
 * 用法: php app/database/migrations/migrate_doc_vod_pp3.php
 */
declare(strict_types=1);

require_once dirname(__DIR__, 4) . '/app/database/migrations/_migration_bootstrap.php';

$name = 'migrate_doc_vod_pp3';

function migration_down(PDO $pdo, string $pfx, string $db): void {
    migration_drop_table_if_exists($pdo, $db, $pfx . 'weapp_doc_vod_parse_log');
    migration_drop_table_if_exists($pdo, $db, $pfx . 'weapp_doc_vod_play_daily');
}

migration_entry($name, static function (PDO $pdo, string $pfx, string $db): void {
    $pdo->exec("CREATE TABLE IF NOT EXISTS `{$pfx}weapp_doc_vod_play_daily` (
        `stat_date` date NOT NULL COMMENT '统计日',
        `play_hits` int unsigned NOT NULL DEFAULT 0 COMMENT '播放次数(增量)',
        `updated_at` datetime NOT NULL,
        PRIMARY KEY (`stat_date`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='视频日播放汇总'");
    
    $pdo->exec("CREATE TABLE IF NOT EXISTS `{$pfx}weapp_doc_vod_parse_log` (
        `id` int unsigned NOT NULL AUTO_INCREMENT,
        `platform` varchar(32) NOT NULL DEFAULT '',
        `url` varchar(500) NOT NULL DEFAULT '',
        `success` tinyint NOT NULL DEFAULT 0,
        `msg` varchar(255) NOT NULL DEFAULT '',
        `duration_ms` int unsigned NOT NULL DEFAULT 0,
        `created_at` datetime NOT NULL,
        PRIMARY KEY (`id`),
        KEY `idx_created` (`created_at`),
        KEY `idx_platform` (`platform`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='视频链接解析日志'");
    
    echo "  + weapp_doc_vod_play_daily / weapp_doc_vod_parse_log\n";
});
