<?php
/**
 * 元舟 PivArk — 企业全域原子化数字资产中枢
 * (c) 2024-2026 pivark.com. All rights reserved.
 * Author: Angelo
 * 未经允许，不可用于商业用途。
 */
/**
 * 视频点播 P5：单集日播放（热力图下钻）
 * 用法: php app/database/migrations/migrate_doc_vod_pp5.php
 */
declare(strict_types=1);

require_once dirname(__DIR__, 4) . '/app/database/migrations/_migration_bootstrap.php';

$name = 'migrate_doc_vod_pp5';

function migration_down(PDO $pdo, string $pfx, string $db): void {
    migration_drop_table_if_exists($pdo, $db, $pfx . 'weapp_doc_vod_episode_play_daily');
}

migration_entry($name, static function (PDO $pdo, string $pfx, string $db): void {
    $pdo->exec("CREATE TABLE IF NOT EXISTS `{$pfx}weapp_doc_vod_episode_play_daily` (
        `episode_id` int unsigned NOT NULL COMMENT '单集ID',
        `series_id` int unsigned NOT NULL DEFAULT 0 COMMENT '剧集ID',
        `stat_date` date NOT NULL COMMENT '统计日',
        `play_hits` int unsigned NOT NULL DEFAULT 0 COMMENT '播放次数',
        `updated_at` datetime NOT NULL,
        PRIMARY KEY (`episode_id`, `stat_date`),
        KEY `idx_series_date` (`series_id`, `stat_date`),
        KEY `idx_date` (`stat_date`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='视频单集日播放'");
    
    echo "  + weapp_doc_vod_episode_play_daily\n";
});
