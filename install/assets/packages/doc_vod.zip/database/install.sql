CREATE TABLE IF NOT EXISTS `{{prefix}}weapp_doc_vod_items` (
    `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
    `document_id` int unsigned NOT NULL DEFAULT 0 COMMENT '关联文档 ID',
    `title` varchar(200) NOT NULL DEFAULT '' COMMENT '标题',
    `video_url` varchar(500) NOT NULL DEFAULT '' COMMENT '视频地址或嵌入代码 URL',
    `cover_path` varchar(500) NOT NULL DEFAULT '' COMMENT '封面图',
    `provider` varchar(32) NOT NULL DEFAULT 'embed' COMMENT '来源：embed/local',
    `sort` int NOT NULL DEFAULT 0 COMMENT '排序',
    `status` tinyint NOT NULL DEFAULT 1 COMMENT '状态：0禁用 1启用',
    `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    PRIMARY KEY (`id`),
    KEY `idx_document_id` (`document_id`),
    KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='文档视频条目表（legacy 单条）';

CREATE TABLE IF NOT EXISTS `{{prefix}}weapp_doc_vod_series` (
    `id` int unsigned NOT NULL AUTO_INCREMENT,
    `title` varchar(200) NOT NULL DEFAULT '',
    `slug` varchar(120) NOT NULL DEFAULT '',
    `cover_path` varchar(500) NOT NULL DEFAULT '',
    `summary` varchar(500) NOT NULL DEFAULT '',
    `access_mode` varchar(24) NOT NULL DEFAULT 'free' COMMENT 'free|login|level|paid_series',
    `read_level_id` int unsigned NOT NULL DEFAULT 0,
    `price` decimal(10,2) NOT NULL DEFAULT 0.00 COMMENT '全集售价',
    `trial_preview_sec` int unsigned NOT NULL DEFAULT 0 COMMENT '试看秒数(0=关)',
    `free_ep_count` int unsigned NOT NULL DEFAULT 0 COMMENT '前N集免费(0=关)',
    `sort` int NOT NULL DEFAULT 0,
    `status` tinyint NOT NULL DEFAULT 1,
    `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_status` (`status`),
    KEY `idx_slug` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='视频剧集';

CREATE TABLE IF NOT EXISTS `{{prefix}}weapp_doc_vod_episodes` (
    `id` int unsigned NOT NULL AUTO_INCREMENT,
    `series_id` int unsigned NOT NULL DEFAULT 0,
    `document_id` int unsigned NOT NULL DEFAULT 0,
    `ep_no` int NOT NULL DEFAULT 0,
    `title` varchar(200) NOT NULL DEFAULT '',
    `cover_path` varchar(500) NOT NULL DEFAULT '',
    `access_mode` varchar(24) NOT NULL DEFAULT '' COMMENT '空=继承剧集',
    `read_level_id` int unsigned NOT NULL DEFAULT 0,
    `price` decimal(10,2) NOT NULL DEFAULT 0.00 COMMENT '单集售价',
    `trial_preview_sec` int unsigned NOT NULL DEFAULT 0 COMMENT '单集试看秒(0=继承剧集)',
    `duration_sec` int unsigned NOT NULL DEFAULT 0,
    `play_count` int unsigned NOT NULL DEFAULT 0 COMMENT '播放次数',
    `ad_cues_json` text COMMENT '广告点 JSON',
    `sort` int NOT NULL DEFAULT 0,
    `status` tinyint NOT NULL DEFAULT 1,
    `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_series` (`series_id`),
    KEY `idx_document` (`document_id`),
    KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='视频单集';

CREATE TABLE IF NOT EXISTS `{{prefix}}weapp_doc_vod_sources` (
    `id` int unsigned NOT NULL AUTO_INCREMENT,
    `episode_id` int unsigned NOT NULL,
    `provider` varchar(32) NOT NULL DEFAULT 'embed',
    `play_url` varchar(1000) NOT NULL DEFAULT '',
    `config_json` text,
    `priority` int NOT NULL DEFAULT 0,
    `status` tinyint NOT NULL DEFAULT 1,
    `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_episode` (`episode_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='视频播放源';

CREATE TABLE IF NOT EXISTS `{{prefix}}weapp_doc_vod_grants` (
    `id` int unsigned NOT NULL AUTO_INCREMENT,
    `user_id` int unsigned NOT NULL,
    `grant_type` varchar(16) NOT NULL COMMENT 'episode|series',
    `ref_id` int unsigned NOT NULL,
    `payment_order_no` varchar(64) NOT NULL DEFAULT '',
    `amount` decimal(10,2) NOT NULL DEFAULT 0.00,
    `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_user_grant` (`user_id`,`grant_type`,`ref_id`),
    KEY `idx_order` (`payment_order_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='视频观看授权';

CREATE TABLE IF NOT EXISTS `{{prefix}}weapp_doc_vod_watch_progress` (
    `id` int unsigned NOT NULL AUTO_INCREMENT,
    `user_id` int unsigned NOT NULL,
    `episode_id` int unsigned NOT NULL,
    `position_sec` int unsigned NOT NULL DEFAULT 0,
    `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_user_ep` (`user_id`,`episode_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='观看进度';

CREATE TABLE IF NOT EXISTS `{{prefix}}weapp_doc_vod_play_daily` (
    `stat_date` date NOT NULL COMMENT '统计日',
    `play_hits` int unsigned NOT NULL DEFAULT 0 COMMENT '播放次数(增量)',
    `trial_end_hits` int unsigned NOT NULL DEFAULT 0 COMMENT '试看结束次数',
    `buy_click_hits` int unsigned NOT NULL DEFAULT 0 COMMENT '购买点击次数',
    `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`stat_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='视频日播放汇总';

CREATE TABLE IF NOT EXISTS `{{prefix}}weapp_doc_vod_parse_log` (
    `id` int unsigned NOT NULL AUTO_INCREMENT,
    `platform` varchar(32) NOT NULL DEFAULT '',
    `url` varchar(500) NOT NULL DEFAULT '',
    `success` tinyint NOT NULL DEFAULT 0,
    `msg` varchar(255) NOT NULL DEFAULT '',
    `duration_ms` int unsigned NOT NULL DEFAULT 0,
    `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_created` (`created_at`),
    KEY `idx_platform` (`platform`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='视频链接解析日志';

CREATE TABLE IF NOT EXISTS `{{prefix}}weapp_doc_vod_episode_play_daily` (
    `episode_id` int unsigned NOT NULL COMMENT '单集ID',
    `series_id` int unsigned NOT NULL DEFAULT 0 COMMENT '剧集ID',
    `stat_date` date NOT NULL COMMENT '统计日',
    `play_hits` int unsigned NOT NULL DEFAULT 0 COMMENT '播放次数',
    `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`episode_id`, `stat_date`),
    KEY `idx_series_date` (`series_id`, `stat_date`),
    KEY `idx_date` (`stat_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='视频单集日播放';
