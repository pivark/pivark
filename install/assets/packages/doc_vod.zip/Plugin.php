<?php
declare(strict_types=1);

namespace weapp\doc_vod;

use weapp\doc_vod\service\VideoAdminSpaMeta;
use app\common\service\weapp\WeappAdminGateway;
use app\common\service\weapp\WeappEntitlementGateway;
use app\common\service\weapp\WeappFrontGateway;
use app\common\service\weapp\WeappMemberGateway;
use app\common\service\weapp\WeappPluginGateway;
use app\common\service\weapp\WeappSupportGateway;
use app\common\service\weapp\WeappTemplateGateway;
use weapp\doc_vod\service\VideoChannelService;
use weapp\doc_vod\service\VideoPaymentFulfillment;
use weapp\doc_vod\service\VideoPlazaService;
use weapp\doc_vod\service\VideoPlaybackService;
use weapp\doc_vod\service\VideoPublicApi;
use weapp\doc_vod\service\VideoFrontAssets;
use weapp\doc_vod\service\VideoService;
use weapp\doc_vod\service\VideoImportIntentDelegate;
use weapp\doc_vod\service\VideoMemberCenterPages;
use weapp\doc_vod\service\VideoStreamProxyService;
use weapp\doc_vod\service\VideoAdminSpaRoutes;
use weapp\doc_vod\service\VideoAdminSpaLists;
use weapp\doc_vod\service\VideoDocumentAddonBridge;

/** 官方 文档视频 插件 */
class Plugin
{
    public function install(): void
    {
        app(WeappEntitlementGateway::class)->entitlementGrantFreeInstall('doc_vod');
    }

    public function enable(): void
    {
    }

    public function disable(): void
    {
    }

    public function boot(): void
    {
        $admin = app(WeappAdminGateway::class);
        $plugin = app(WeappPluginGateway::class);
        $front = app(WeappFrontGateway::class);
        $member = app(WeappMemberGateway::class);
        $admin->adminSpaMetaRegister('doc_vod', 'doc_vod', [VideoAdminSpaMeta::class, 'build']);
        VideoAdminSpaRoutes::register();
        $admin->adminSpaPluginListRegister('doc_vod', 'items', [VideoAdminSpaLists::class, 'itemsList']);
        $plugin->pluginLogicalTableRegister('doc_vod', [
            'items'                => 'weapp_doc_vod_items',
            'series'               => 'weapp_doc_vod_series',
            'episodes'             => 'weapp_doc_vod_episodes',
            'sources'              => 'weapp_doc_vod_sources',
            'grants'               => 'weapp_doc_vod_grants',
            'watch_progress'       => 'weapp_doc_vod_watch_progress',
            'play_daily'           => 'weapp_doc_vod_play_daily',
            'parse_log'            => 'weapp_doc_vod_parse_log',
            'episode_play_daily'   => 'weapp_doc_vod_episode_play_daily',
        ]);
        $perm = 'plugin.doc_vod.use';
        $admin->adminPermissionExtensionRegisterMap('doc_vod', [
            'index'       => $perm,
            'list'        => $perm,
            'usage'       => $perm,
            'configsave'  => $perm,
            'save'        => $perm,
            'delete'      => $perm,
            'status'      => $perm,
            'statsexport' => $perm,
        ]);
        app(WeappSupportGateway::class)->dataExportExtensionRegister([
            'profile'    => 'video.stats',
            'label'      => '视频运营统计',
            'kind'       => 'export',
            'plugin_id'  => 'doc_vod',
            'permission' => $perm,
            'path'       => '/doc_vod/statsExport',
            'modes'      => ['all'],
            'max_rows'   => 50000,
            'audit_key'  => $perm,
        ]);
        $member->memberConsumptionRegister('doc_vod', 'VideoMemberConsumptionHelper');
        $member->memberConsumptionRegisterMeta('doc_vod', [
            'paid_biz_type'   => 'doc_vod_paid',
            'paid_biz_label'  => '付费·视频',
            'paid_source'     => 'pay_order',
        ]);
        $front->frontScriptUrlRegisterModule('doc_vod', [
            'videoPlaza'              => '/doc_vod/plaza',
            'apiVideoPlay'            => '/api/v1/plugins/doc_vod/play',
            'apiVideoProgress'        => '/api/v1/plugins/doc_vod/progress',
            'apiVideoCheckoutEpisode' => '/api/v1/plugins/doc_vod/checkout/episode',
            'apiVideoCheckoutSeries'  => '/api/v1/plugins/doc_vod/checkout/series',
            'apiVideoTrack'           => '/api/v1/plugins/doc_vod/track',
        ]);
        $plugin->pluginExtensionRegisterDocumentAddonBridge(
            'doc_vod',
            new VideoDocumentAddonBridge(),
            100,
            [
                'document_list_methods' => ['listForDocument', 'listVodForDocument'],
                'document_availability'   => 'doc_vod',
                'document_media_sync'     => true,
                'document_vod_sync'       => true,
                'payment_watch_url'       => true,
                'frontend_plaza'          => true,
                'dashboard_overview'    => [
                    'key'            => 'video',
                    'logical_table'  => 'items',
                    'title'          => '视频',
                    'unit'           => '条',
                    'defaultVisible' => false,
                ],
            ],
        );
        $front->frontAssetHandlerRegister('doc_vod', 'vod_styles', [VideoFrontAssets::class, 'registerVodStyles']);
        $front->frontAssetHandlerRegister('doc_vod', 'vod', [VideoFrontAssets::class, 'registerVod']);
        VideoService::ensureAutoload();
        VideoMemberCenterPages::register();
        VideoPaymentFulfillment::register();
        $plugin->pluginApiRegistryRegister('VideoPublic', new VideoPublicApi());
        VideoPlaybackService::boot();
        VideoChannelService::boot();
        VideoPlazaService::boot();
        VideoStreamProxyService::boot();
        $plugin->pluginExtensionRegisterImportIntentDelegate(new VideoImportIntentDelegate());
        app(WeappTemplateGateway::class)->templateRegisterExtensionTag('doc_vod', [VideoService::class, 'renderTag']);
    }
}
