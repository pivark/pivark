<script lang="ts" setup>
import {
  fetchVideoEpisodeListApi,
  saveVideoEpisodeApi,
  saveVideoSeriesApi,
} from '@weapp-doc-vod/api/video-catalog';
import {
  normalizeVideoSeries,
  normalizeVodEpisode,
  videoVodAccessModeOptions,
  type VideoSeriesRow,
  type VideoVodEpisode,
} from '@weapp-doc-vod/api/video-vod';
import { Plus } from '@pivark/icons';
import { ElMessage, type FormInstance, type FormRules } from 'element-plus';
import { reactive, ref } from 'vue';

import PvAdminGridLoadingSkeleton from '#/components/pivark/PvAdminGridLoadingSkeleton.vue';
import WeappPluginPageCard from '#/components/pivark/weapp/WeappPluginPageCard.vue';
import WeappPluginShell from '#/components/pivark/weapp/WeappPluginShell.vue';

import { useVideoSeriesList } from './list/use-video-series-list';

defineOptions({ name: 'WeappDocVodSeries' });

const saving = ref(false);
const seriesDialog = ref(false);
const episodeDrawer = ref(false);
const episodeLoading = ref(false);
const episodes = ref<VideoVodEpisode[]>([]);
const activeSeries = ref<VideoSeriesRow | null>(null);
const episodeDialog = ref(false);
const seriesFormRef = ref<FormInstance>();
const episodeFormRef = ref<FormInstance>();

const seriesRules: FormRules = {
  title: [{ message: '请填写剧集名称', required: true, trigger: 'blur' }],
};

const episodeRules: FormRules = {
  play_url: [{ message: '请填写播放地址', required: true, trigger: 'blur' }],
  title: [{ message: '请填写单集标题', required: true, trigger: 'blur' }],
};

const seriesForm = reactive({
  access_mode: 'free',
  free_ep_count: 0,
  id: 0,
  price: 0,
  read_level_id: 0,
  slug: '',
  sort: 0,
  status: 1,
  summary: '',
  title: '',
  trial_preview_sec: 0,
});
const episodeForm = reactive({
  access_mode: '',
  document_id: 0,
  ep_no: 1,
  id: 0,
  play_url: '',
  price: 0,
  provider: 'embed',
  read_level_id: 0,
  series_id: 0,
  sort: 0,
  status: 1,
  title: '',
  trial_preview_sec: 0,
});

const accessModes = videoVodAccessModeOptions();

function resetSeriesForm(row?: Partial<VideoSeriesRow>) {
  const n = normalizeVideoSeries(row ?? null);
  seriesForm.id = n.id ?? 0;
  seriesForm.title = n.title;
  seriesForm.slug = n.slug ?? '';
  seriesForm.summary = n.summary ?? '';
  seriesForm.access_mode = n.access_mode ?? 'free';
  seriesForm.read_level_id = n.read_level_id ?? 0;
  seriesForm.price = n.price ?? 0;
  seriesForm.trial_preview_sec = Number(
    (row as { trial_preview_sec?: number })?.trial_preview_sec ??
      n.trial_preview_sec ??
      0,
  );
  seriesForm.free_ep_count = Number(
    (row as { free_ep_count?: number })?.free_ep_count ?? n.free_ep_count ?? 0,
  );
  seriesForm.sort = n.sort ?? 0;
  seriesForm.status = n.status === 0 ? 0 : 1;
}

function resetEpisodeForm(row?: Partial<VideoVodEpisode>) {
  const n = normalizeVodEpisode(row ?? null);
  episodeForm.id = n.id ?? 0;
  episodeForm.series_id = n.series_id || activeSeries.value?.id || 0;
  episodeForm.document_id = n.document_id ?? 0;
  episodeForm.ep_no = n.ep_no ?? 1;
  episodeForm.title = n.title;
  episodeForm.play_url = n.play_url ?? '';
  episodeForm.provider = n.provider ?? 'embed';
  episodeForm.access_mode = n.access_mode ?? '';
  episodeForm.read_level_id = n.read_level_id ?? 0;
  episodeForm.price = n.price ?? 0;
  episodeForm.trial_preview_sec = Number(
    (row as { trial_preview_sec?: number })?.trial_preview_sec ??
      n.trial_preview_sec ??
      0,
  );
  episodeForm.sort = n.sort ?? 0;
  episodeForm.status = n.status === 0 ? 0 : 1;
}

async function openEpisodes(row: VideoSeriesRow) {
  activeSeries.value = row;
  episodeDrawer.value = true;
  episodeLoading.value = true;
  try {
    const data = await fetchVideoEpisodeListApi(Number(row.id ?? 0));
    episodes.value = data.list.map((item, index) =>
      normalizeVodEpisode(item, index),
    );
  } finally {
    episodeLoading.value = false;
  }
}

function openSeriesDialog(row?: VideoSeriesRow) {
  resetSeriesForm(row);
  seriesDialog.value = true;
}

function openEpisodeDialog(row?: VideoVodEpisode) {
  resetEpisodeForm(row);
  episodeDialog.value = true;
}

const { Grid, onAdd, refreshGrid } = useVideoSeriesList({
  onAdd: () => openSeriesDialog(),
  onEdit: (row) => openSeriesDialog(row),
  onEpisodes: (row) => void openEpisodes(row),
});

async function saveSeries() {
  const valid = await seriesFormRef.value?.validate().catch(() => false);
  if (!valid) {
    return;
  }
  saving.value = true;
  try {
    await saveVideoSeriesApi({
      ...seriesForm,
      status: seriesForm.status ? 1 : 0,
    });
    ElMessage.success('已保存');
    seriesDialog.value = false;
    await refreshGrid();
  } catch (e) {
    ElMessage.error(e instanceof Error ? e.message : '保存失败');
  } finally {
    saving.value = false;
  }
}

async function saveEpisode() {
  const valid = await episodeFormRef.value?.validate().catch(() => false);
  if (!valid) {
    return;
  }
  saving.value = true;
  try {
    await saveVideoEpisodeApi({
      ...episodeForm,
      status: episodeForm.status ? 1 : 0,
    });
    ElMessage.success('已保存');
    episodeDialog.value = false;
    if (activeSeries.value) {
      await openEpisodes(activeSeries.value);
    }
  } catch (e) {
    ElMessage.error(e instanceof Error ? e.message : '保存失败');
  } finally {
    saving.value = false;
  }
}
</script>

<template>
  <WeappPluginShell plugin-id="doc_vod" nav-key="series">
    <WeappPluginPageCard fill title="点播剧集">
      <template #actions>
        <el-button type="primary" :icon="Plus" @click="onAdd">
          新建剧集
        </el-button>
      </template>
      <Grid>
        <template #loading>
          <PvAdminGridLoadingSkeleton fill />
        </template>
      </Grid>
    </WeappPluginPageCard>

    <el-dialog
      v-model="seriesDialog"
      :title="seriesForm.id ? '编辑剧集' : '新建剧集'"
      width="520px"
      @closed="seriesFormRef?.clearValidate()"
    >
      <el-form
        ref="seriesFormRef"
        :model="seriesForm"
        :rules="seriesRules"
        label-position="top"
      >
        <el-form-item label="名称" prop="title" required>
          <el-input v-model="seriesForm.title" maxlength="120" show-word-limit />
        </el-form-item>
        <el-form-item label="标识 slug">
          <el-input v-model="seriesForm.slug" />
        </el-form-item>
        <el-form-item label="默认权限">
          <el-select v-model="seriesForm.access_mode" class="w-full">
            <el-option
              v-for="m in accessModes.filter((x) => x.value !== '')"
              :key="m.value"
              :label="m.label"
              :value="m.value"
            />
          </el-select>
        </el-form-item>
        <el-form-item label="全集售价">
          <el-input-number
            v-model="seriesForm.price"
            class="w-full"
            :min="0"
            :precision="2"
          />
        </el-form-item>
        <el-form-item label="试看秒数">
          <el-input-number
            v-model="seriesForm.trial_preview_sec"
            class="w-full"
            :max="3600"
            :min="0"
          />
        </el-form-item>
        <el-form-item label="前 N 集免费">
          <el-input-number
            v-model="seriesForm.free_ep_count"
            class="w-full"
            :max="500"
            :min="0"
          />
        </el-form-item>
        <el-form-item label="启用">
          <el-switch
            v-model="seriesForm.status"
            :active-value="1"
            :inactive-value="0"
          />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="seriesDialog = false">取消</el-button>
        <el-button :loading="saving" type="primary" @click="saveSeries">
          保存
        </el-button>
      </template>
    </el-dialog>

    <el-drawer
      v-model="episodeDrawer"
      :title="`单集 · ${activeSeries?.title ?? ''}`"
      size="56%"
    >
      <div class="mb-3">
        <el-button size="small" type="primary" @click="openEpisodeDialog()">
          添加单集
        </el-button>
      </div>
      <div v-if="episodeLoading" class="py-8">
        <PvAdminGridLoadingSkeleton />
      </div>
      <el-empty
        v-else-if="!episodes.length"
        description="暂无单集"
      >
        <el-button type="primary" @click="openEpisodeDialog()">
          添加单集
        </el-button>
      </el-empty>
      <el-table v-else v-loading="episodeLoading" :data="episodes" row-key="id">
        <el-table-column
          class-name="pv-tabular-nums"
          label="#"
          prop="ep_no"
          width="56"
        />
        <el-table-column label="标题" min-width="140" prop="title" show-overflow-tooltip />
        <el-table-column
          class-name="pv-tabular-nums"
          label="文档ID"
          prop="document_id"
          width="88"
        />
        <el-table-column label="权限" prop="access_mode" width="96" />
        <el-table-column
          class-name="pv-tabular-nums"
          label="播放"
          prop="play_count"
          width="72"
        />
        <el-table-column fixed="right" label="操作" width="100">
          <template #default="{ row }">
            <el-button plain size="small" @click="openEpisodeDialog(row)">
              编辑
            </el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-drawer>

    <el-dialog
      v-model="episodeDialog"
      title="单集"
      width="560px"
      @closed="episodeFormRef?.clearValidate()"
    >
      <el-form
        ref="episodeFormRef"
        :model="episodeForm"
        :rules="episodeRules"
        label-position="top"
      >
        <el-form-item label="集号">
          <el-input-number v-model="episodeForm.ep_no" class="w-full" :min="0" />
        </el-form-item>
        <el-form-item label="标题" prop="title" required>
          <el-input v-model="episodeForm.title" maxlength="120" show-word-limit />
        </el-form-item>
        <el-form-item label="播放地址" prop="play_url" required>
          <el-input
            v-model="episodeForm.play_url"
            placeholder="https:// 或 embed URL"
          />
        </el-form-item>
        <el-form-item label="文档 ID">
          <el-input-number
            v-model="episodeForm.document_id"
            class="w-full"
            :min="0"
          />
        </el-form-item>
        <el-form-item label="权限">
          <el-select
            v-model="episodeForm.access_mode"
            clearable
            placeholder="继承剧集"
            class="w-full"
          >
            <el-option
              v-for="m in accessModes"
              :key="m.value || 'inherit'"
              :label="m.label"
              :value="m.value"
            />
          </el-select>
        </el-form-item>
        <el-form-item label="单集价">
          <el-input-number
            v-model="episodeForm.price"
            class="w-full"
            :min="0"
            :precision="2"
          />
        </el-form-item>
        <el-form-item label="试看秒(0继承)">
          <el-input-number
            v-model="episodeForm.trial_preview_sec"
            class="w-full"
            :max="3600"
            :min="0"
          />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="episodeDialog = false">取消</el-button>
        <el-button :loading="saving" type="primary" @click="saveEpisode">
          保存
        </el-button>
      </template>
    </el-dialog>
  </WeappPluginShell>
</template>

<style scoped>
:deep(.pv-tabular-nums) {
  font-variant-numeric: tabular-nums;
}
</style>
