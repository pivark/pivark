import type { VideoSeriesRow } from '@weapp-doc-vod/api/video-vod';

import type { PvFormSchema } from '#/adapter/form';
import type {
  OnActionClickFn,
  VxeTableGridColumns,
} from '#/adapter/vxe-table';

import { fetchVideoSeriesListApi } from '@weapp-doc-vod/api/video-catalog';
import { videoVodAccessModeOptions } from '@weapp-doc-vod/api/video-vod';
import {
  PV_COL_FLAG,
  PV_COL_ID,
  PV_COL_NUM,
  PV_COL_OPS,
  PV_COL_TEXT,
} from '#/composables/pv-admin-list-column-presets';
import { usePvAdminListSearchFormOptions } from '#/composables/pv-admin-list-form-layout';

export type { VideoSeriesRow };

const VIDEO_SERIES_STATUS_OPTIONS = [
  { label: '启用', value: '1' },
  { label: '停用', value: '0' },
];

const ACCESS_MODE_LABELS = Object.fromEntries(
  videoVodAccessModeOptions()
    .filter((m) => m.value !== '')
    .map((m) => [m.value, m.label]),
);

export function videoSeriesAccessModeLabel(mode: unknown): string {
  const key = String(mode ?? '');
  return ACCESS_MODE_LABELS[key] ?? (key || '—');
}

export function useVideoSeriesGridFormSchema(): PvFormSchema[] {
  return [
    {
      component: 'Input',
      fieldName: 'keyword',
      label: '关键词',
      componentProps: {
        clearable: true,
        placeholder: '搜索剧集',
      },
    },
    {
      component: 'Select',
      fieldName: 'status',
      label: '状态',
      componentProps: {
        clearable: true,
        options: VIDEO_SERIES_STATUS_OPTIONS,
        placeholder: '全部',
      },
    },
  ];
}

export function useVideoSeriesListGridFormOptions() {
  return usePvAdminListSearchFormOptions(useVideoSeriesGridFormSchema());
}

export function mapVideoSeriesListQueryParams(formValues: Record<string, unknown>) {
  const status = formValues.status;
  return {
    keyword: String(formValues.keyword ?? '').trim() || undefined,
    status:
      status === '' || status === null || status === undefined
        ? ''
        : String(status),
  };
}

export function useVideoSeriesGridColumns(
  onActionClick: OnActionClickFn<VideoSeriesRow>,
): VxeTableGridColumns<VideoSeriesRow> {
  return [
    {
      field: 'id',
      title: 'ID',
      width: 72,
      ...PV_COL_ID,
    },
    {
      field: 'title',
      title: '剧集',
      minWidth: 160,
      ...PV_COL_TEXT,
    },
    {
      field: 'access_mode',
      title: '权限',
      width: 100,
      ...PV_COL_TEXT,
      formatter: ({ cellValue }) => videoSeriesAccessModeLabel(cellValue),
    },
    {
      field: 'price',
      title: '全集价',
      width: 88,
      ...PV_COL_NUM,
    },
    {
      field: 'status',
      title: '状态',
      width: 88,
      ...PV_COL_FLAG,
      cellRender: {
        name: 'CellTag',
        options: [
          { type: 'primary', label: '启用', value: 1 },
          { type: 'info', label: '停用', value: 0 },
        ],
      },
    },
    {
      ...PV_COL_OPS,
      cellRender: {
        attrs: {
          nameField: 'title',
          nameTitle: '剧集',
          onClick: onActionClick,
          skipDeleteConfirm: true,
          variant: 'capsule',
        },
        name: 'CellOperation',
        options: [
          { code: 'episodes', text: '单集' },
          { code: 'edit', text: '编辑' },
        ],
      },
      field: 'operation',
      fixed: 'right',
      showOverflow: false,
      title: '操作',
      width: 160,
    },
  ];
}

export async function fetchVideoSeriesListPage(
  page: { currentPage: number; pageSize: number },
  formValues: Record<string, unknown>,
) {
  const mapped = mapVideoSeriesListQueryParams(formValues);
  const result = await fetchVideoSeriesListApi({
    keyword: mapped.keyword,
    page: page.currentPage,
    pageSize: page.pageSize,
    status: mapped.status,
  });
  return {
    items: result.list,
    total: result.total,
  };
}
