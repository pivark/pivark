<script lang="ts" setup>
import { computed, onMounted, ref } from 'vue';
import { useRouter } from 'vue-router';

import { ElMessage } from 'element-plus';

import WeappPluginKpiRow from '#/components/pivark/weapp/WeappPluginKpiRow.vue';
import WeappPluginPageCard from '#/components/pivark/weapp/WeappPluginPageCard.vue';
import WeappPluginShell from '#/components/pivark/weapp/WeappPluginShell.vue';
import WeappPluginSlotCards from '#/components/pivark/weapp/WeappPluginSlotCards.vue';
import PvModuleSection from '#/components/pivark/shell/PvModuleSection.vue';
import { fetchSpaWeappPluginMetaApi } from '#/api/pivark/core/spa';
import { pivarkMutation } from '#/api/pivark/core/mutation';
import type { WeappVideoMeta } from '#/api/pivark/core/spa-meta-types';
import {
  cfgFlag,
  cfgString,
  useWeappPluginId,
  useWeappSettingsLoading,
  type WeappSlotCard,
} from '#/composables/use-weapp-plugin-settings';

defineOptions({ name: 'WeappDocVodSettings' });

const router = useRouter();
const pluginId = useWeappPluginId();
const { loading, saving, withLoading, withSaving } = useWeappSettingsLoading();
const videoOpen = ref(true);
const editorSlot = ref('tab');
const slotCards = ref<WeappSlotCard[]>([]);
const stats = ref({ total: 0, enabled: 0 });
const vodSeriesTotal = ref(0);

const kpiItems = computed(() => [
  { label: '嵌入条目', value: stats.value.total },
  { label: '已启用', value: stats.value.enabled },
  { label: '点播剧集', value: vodSeriesTotal.value },
]);

async function loadMeta() {
  await withLoading(async () => {
    const meta = await fetchSpaWeappPluginMetaApi<WeappVideoMeta>(pluginId.value);
    videoOpen.value = cfgFlag(meta.cfg, 'doc_vod_open');
    editorSlot.value = cfgString(
      meta.cfg,
      'doc_vod_document_editor_slot',
      String(meta.editorSlot ?? 'tab'),
    );
    slotCards.value = meta.slotCards ?? [];
    stats.value = {
      total: meta.stats?.total ?? 0,
      enabled: meta.stats?.enabled ?? 0,
    };
    const vod = meta.vodStats as Record<string, unknown> | undefined;
    vodSeriesTotal.value = Number(vod?.series_total ?? vod?.seriesTotal ?? 0);
  });
}

async function handleSave() {
  await withSaving(async () => {
    await pivarkMutation('/weapp/doc_vod/configSave', {
      doc_vod_open: videoOpen.value ? '1' : '0',
      doc_vod_document_editor_slot: editorSlot.value,
    });
    ElMessage.success('保存成功');
    await loadMeta();
  });
}

function goSeries() {
  router.push('/weapp/host/doc_vod/series');
}

function goList() {
  router.push('/weapp/host/doc_vod/list');
}

function goStats() {
  router.push('/weapp/host/doc_vod/stats');
}

onMounted(loadMeta);
</script>

<template>
  <WeappPluginShell :plugin-id="pluginId" nav-key="settings">
    <WeappPluginPageCard :loading="loading" title="基础设置">
      <template #actions>
        <el-button @click="goSeries">点播剧集</el-button>
        <el-button @click="goList">嵌入条目</el-button>
        <el-button :loading="saving" type="primary" @click="handleSave">
          保存配置
        </el-button>
      </template>

      <WeappPluginKpiRow :items="kpiItems" />

      <PvModuleSection title="功能开关">
        <el-switch
          v-model="videoOpen"
          active-text="启用"
          inactive-text="关闭"
          aria-label="文档视频功能开关"
        />
        <p class="pv-weapp-hint mt-2">
          关闭后前台不渲染视频标签，文档编辑器视频面板也会隐藏。
        </p>
      </PvModuleSection>

      <PvModuleSection title="发布页展现">
        <p class="pv-weapp-hint mb-3">
          控制文档发布页中「视频」面板出现的位置，保存后全站生效。
        </p>
        <WeappPluginSlotCards v-model="editorSlot" :cards="slotCards" />
      </PvModuleSection>

      <PvModuleSection title="运营入口">
        <p class="pv-weapp-hint mb-3">
          嵌入条目适合单篇外链视频；点播剧集支持选集、试看与付费。详细说明见「功能介绍」与「前台调用说明」。
        </p>
        <div class="flex flex-wrap gap-2">
          <el-button @click="goList">管理嵌入条目</el-button>
          <el-button type="primary" plain @click="goSeries">
            管理点播剧集
          </el-button>
          <el-button plain @click="goStats">运营统计</el-button>
        </div>
      </PvModuleSection>
    </WeappPluginPageCard>
  </WeappPluginShell>
</template>
