import type { VideoSeriesRow } from '../data';

import type { VxeTableGridOptions } from '#/adapter/vxe-table';

import { shallowRef } from 'vue';

import {
  PV_ADMIN_LIST_GRID_CLASS,
  PV_ADMIN_LIST_GRID_OPTIONS,
  usePvAdminListGrid,
} from '#/composables/use-pv-admin-list-grid';

import {
  fetchVideoSeriesListPage,
  useVideoSeriesGridColumns,
  useVideoSeriesListGridFormOptions,
} from '../data';

type VideoSeriesHandlers = {
  onAdd: () => void;
  onEdit: (row: VideoSeriesRow) => void;
  onEpisodes: (row: VideoSeriesRow) => void;
};

export function useVideoSeriesList(handlers: VideoSeriesHandlers) {
  const gridApiRef = shallowRef<
    ReturnType<typeof usePvAdminListGrid<VideoSeriesRow>>['gridApi'] | null
  >(null);

  async function refreshGrid() {
    await gridApiRef.value?.query();
  }

  function onActionClick(e: { code: string; row: VideoSeriesRow }) {
    if (e.code === 'episodes') {
      handlers.onEpisodes(e.row);
      return;
    }
    if (e.code === 'edit') {
      handlers.onEdit(e.row);
    }
  }

  const { Grid, gridApi } = usePvAdminListGrid<VideoSeriesRow>(() => ({
    formOptions: useVideoSeriesListGridFormOptions(),
    gridClass: PV_ADMIN_LIST_GRID_CLASS,
    gridOptions: {
      ...PV_ADMIN_LIST_GRID_OPTIONS,
      columns: useVideoSeriesGridColumns(onActionClick),
      proxyConfig: {
        ...PV_ADMIN_LIST_GRID_OPTIONS.proxyConfig,
        ajax: {
          query: async ({ page }, formValues) => {
            const result = await fetchVideoSeriesListPage(page, formValues ?? {});
            return {
              items: result.items,
              total: result.total,
            };
          },
        },
      },
      rowConfig: {
        keyField: 'id',
      },
    } as VxeTableGridOptions,
  }));
  gridApiRef.value = gridApi;

  return {
    Grid,
    onAdd: handlers.onAdd,
    refreshGrid,
  };
}
