<script lang="ts" setup>
import type { EchartsUIType } from '@pivark/plugins/echarts';

import { computed, onMounted, ref, watch } from 'vue';

import { ElMessage } from 'element-plus';
import { EchartsUI, useEcharts } from '@pivark/plugins/echarts';

import WeappPluginShell from '#/components/pivark/weapp/WeappPluginShell.vue';
import WeappPluginPageCard from '#/components/pivark/weapp/WeappPluginPageCard.vue';
import WeappPluginKpiRow from '#/components/pivark/weapp/WeappPluginKpiRow.vue';
import PvModuleSection from '#/components/pivark/shell/PvModuleSection.vue';
import { useAdminDataExport } from '#/composables/use-admin-data-export';
import { pivarkRestData, type PivarkRestEnvelope } from '#/api/pivark-rest';
import { resolveAdminRestUrl } from '#/api/admin-rest-url';
import {requestClient} from '#/api/request';

defineOptions({ name: 'WeappDocVodStats' });

type SeriesRank = {
  conversion_pct?: number;
  ep_count?: number;
  grant_count?: number;
  id?: number;
  play_sum?: number;
  title?: string;
};

type TopEpisode = {
  document_id?: number;
  id?: number;
  play_count?: number;
  series_title?: string;
  title?: string;
};

type ParseFail = { fail_count?: number; platform?: string };
type ParseLog = {
  created_at?: string;
  msg?: string;
  platform?: string;
  url?: string;
};

const loading = ref(false);
const days = ref(30);
const vod = ref({
  episode_total: 0,
  grant_total: 0,
  order_paid: 0,
  play_total: 0,
  series_total: 0,
});
const items = ref({ enabled: 0, total: 0 });
const seriesRank = ref<SeriesRank[]>([]);
const topEpisodes = ref<TopEpisode[]>([]);
const parseFails = ref<ParseFail[]>([]);
const parseRecent = ref<ParseLog[]>([]);
const funnel = ref({ trial_end_total: 0, buy_click_total: 0 });
const dailyTrend = ref<{ labels: string[]; plays: number[] }>({
  labels: [],
  plays: [],
});
const orderTrend = ref<{ labels: string[]; values: number[] }>({
  labels: [],
  values: [],
});
const grantTrend = ref<{ labels: string[]; values: number[] }>({
  labels: [],
  values: [],
});

const chartRef = ref<EchartsUIType>();
const heatmapRef = ref<EchartsUIType>();
const drillRef = ref<EchartsUIType>();
const { renderEcharts } = useEcharts(chartRef);
const { getChartInstance: getHeatmapChart, renderEcharts: renderHeatmap } = useEcharts(heatmapRef);
const { renderEcharts: renderDrill } = useEcharts(drillRef);

const heatmapLoading = ref(false);
const drillVisible = ref(false);
const drillTitle = ref('');
const drillSeriesId = ref(0);
const heatmapUseDaily = ref(1);
const seriesMeta = ref<Array<{ id?: number; title?: string }>>([]);

const trendLabels = computed(() => dailyTrend.value.labels);

const kpiItems = computed(() => [
  { label: '点播剧集', value: vod.value.series_total },
  { label: '点播单集', value: vod.value.episode_total },
  { label: '累计播放', value: vod.value.play_total },
  { label: '授权记录', value: vod.value.grant_total },
  { label: '已支付订单', value: vod.value.order_paid },
  { label: '嵌入条目', value: items.value.total },
  { label: '试看结束', value: funnel.value.trial_end_total },
  { label: '购买点击', value: funnel.value.buy_click_total },
]);

function renderChart() {
  renderEcharts({
    color: ['#6366f1', '#14b8a6', '#f59e0b'],
    grid: { bottom: 8, containLabel: true, left: 12, right: 16, top: 36 },
    legend: { data: ['播放', '付费订单', '新授权'], right: 0, top: 0 },
    series: [
      {
        data: dailyTrend.value.plays,
        name: '播放',
        smooth: true,
        type: 'line',
        areaStyle: { opacity: 0.12 },
      },
      {
        data: orderTrend.value.values,
        name: '付费订单',
        smooth: true,
        type: 'line',
      },
      {
        data: grantTrend.value.values,
        name: '新授权',
        smooth: true,
        type: 'line',
      },
    ],
    tooltip: { trigger: 'axis' },
    xAxis: {
      data: trendLabels.value,
      type: 'category',
    },
    yAxis: { minInterval: 1, type: 'value' },
  });
}

function renderHeatmapChart(payload: {
  data?: Array<[number, number, number]>;
  max?: number;
  use_daily?: number;
  x_labels?: string[];
  y_labels?: string[];
}) {
  heatmapUseDaily.value = payload.use_daily ?? 1;
  const maxVal = Math.max(1, payload.max ?? 1);
  renderHeatmap({
    grid: { bottom: 48, containLabel: true, left: 12, right: 24, top: 12 },
    series: [
      {
        data: payload.data ?? [],
        emphasis: {
          itemStyle: { shadowBlur: 8, shadowColor: 'rgba(0,0,0,0.25)' },
        },
        label: { show: false },
        name: '播放',
        type: 'heatmap',
      },
    ],
    tooltip: {
      formatter(params: { data?: [number, number, number]; value?: [number, number, number] }) {
        const d = params.data ?? params.value ?? [0, 0, 0];
        const y = payload.y_labels?.[d[1]] ?? '';
        const x = payload.x_labels?.[d[0]] ?? '';
        return `${y}<br/>${x}：${d[2]} 次`;
      },
      position: 'top',
    },
    visualMap: {
      calculable: true,
      inRange: { color: ['#eef2ff', '#6366f1', '#312e81'] },
      max: maxVal,
      min: 0,
      orient: 'horizontal',
      right: 0,
      top: 0,
    },
    xAxis: {
      data: payload.x_labels ?? [],
      splitArea: { show: true },
      type: 'category',
    },
    yAxis: {
      data: payload.y_labels ?? [],
      splitArea: { show: true },
      type: 'category',
    },
  });
}

async function loadHeatmap() {
  heatmapLoading.value = true;
  try {
    const body = await requestClient.get<PivarkRestEnvelope>(resolveAdminRestUrl('/weapp/doc_vod/statsHeatmap'), {
        params: { days: days.value },
        responseReturn: 'body',
        withCredentials: true,
      },
    );
    const data = pivarkRestData<{
      series_meta?: Array<{ id?: number; title?: string }>;
      data?: Array<[number, number, number]>;
      max?: number;
      use_daily?: number;
      x_labels?: string[];
      y_labels?: string[];
    }>(body, '热力图加载失败');
    seriesMeta.value = data.series_meta ?? [];
    renderHeatmapChart(data);
    const chart = getHeatmapChart();
    chart?.off('click');
    chart?.on('click', (params: { componentType?: string; data?: [number, number, number] }) => {
      if (params.componentType !== 'series' || !params.data) {
        return;
      }
      const yIdx = params.data[1];
      const meta = seriesMeta.value[yIdx];
      if (meta?.id) {
        openDrill(meta.id, meta.title ?? '');
      }
    });
  } catch (e) {
    ElMessage.error(e instanceof Error ? e.message : '热力图加载失败');
  } finally {
    heatmapLoading.value = false;
  }
}

async function openDrill(seriesId: number, title: string) {
  drillSeriesId.value = seriesId;
  drillTitle.value = title;
  drillVisible.value = true;
  try {
    const body = await requestClient.get<PivarkRestEnvelope>(resolveAdminRestUrl('/weapp/doc_vod/statsHeatmapDrill'), {
        params: { days: days.value, series_id: seriesId },
        responseReturn: 'body',
        withCredentials: true,
      },
    );
    const res = pivarkRestData<{
      data?: Array<[number, number, number]>;
      max?: number;
      use_daily?: number;
      x_labels?: string[];
      y_labels?: string[];
    }>(body, '下钻失败');
    const maxVal = Math.max(1, res.max ?? 1);
    renderDrill({
      grid: { bottom: 72, containLabel: true, left: 8, right: 16, top: 36 },
      series: [
        {
          data: res.data ?? [],
          name: '日播放',
          type: 'heatmap',
        },
      ],
      title: {
        left: 'center',
        text: `${title} · 单集 × 日期`,
        textStyle: { fontSize: 14 },
      },
      tooltip: {
        formatter(params: { data?: [number, number, number]; value?: [number, number, number] }) {
          const d = params.data ?? params.value ?? [0, 0, 0];
          const ep = res.y_labels?.[d[1]] ?? '';
          const day = res.x_labels?.[d[0]] ?? '';
          return `${ep}<br/>${day}：${d[2]} 次`;
        },
      },
      visualMap: {
        calculable: true,
        inRange: { color: ['#ecfdf5', '#14b8a6', '#134e4a'] },
        max: maxVal,
        min: 0,
        orient: 'horizontal',
        right: 0,
        top: 0,
      },
      xAxis: {
        data: res.x_labels ?? [],
        splitArea: { show: true },
        type: 'category',
      },
      yAxis: {
        data: res.y_labels ?? [],
        splitArea: { show: true },
        type: 'category',
      },
    });
  } catch (e) {
    ElMessage.error(e instanceof Error ? e.message : '下钻失败');
  }
}

async function load() {
  loading.value = true;
  try {
    const body = await requestClient.get<PivarkRestEnvelope>(resolveAdminRestUrl('/weapp/doc_vod/statsOverview'), {
        params: { days: days.value },
        responseReturn: 'body',
        withCredentials: true,
      },
    );
    const res = pivarkRestData<{
      daily_trend?: { labels: string[]; plays: number[] };
      grant_trend?: { labels: string[]; values: number[] };
      items?: { enabled: number; total: number };
      order_trend?: { labels: string[]; values: number[] };
      parse_fails?: ParseFail[];
      parse_recent?: ParseLog[];
      series_rank?: SeriesRank[];
      top_episodes?: TopEpisode[];
      funnel?: { buy_click_total?: number; trial_end_total?: number };
      vod?: typeof vod.value;
    }>(body, '加载失败');
    vod.value = { ...vod.value, ...(res.vod ?? {}) };
    items.value = res.items ?? { total: 0, enabled: 0 };
    seriesRank.value = res.series_rank ?? [];
    topEpisodes.value = res.top_episodes ?? [];
    dailyTrend.value = res.daily_trend ?? { labels: [], plays: [] };
    orderTrend.value = res.order_trend ?? { labels: [], values: [] };
    grantTrend.value = res.grant_trend ?? { labels: [], values: [] };
    parseFails.value = res.parse_fails ?? [];
    parseRecent.value = res.parse_recent ?? [];
    funnel.value = {
      trial_end_total: res.funnel?.trial_end_total ?? 0,
      buy_click_total: res.funnel?.buy_click_total ?? 0,
    };
    renderChart();
    await loadHeatmap();
  } catch (e) {
    ElMessage.error(e instanceof Error ? e.message : '加载失败');
  } finally {
    loading.value = false;
  }
}

const { canExport, exportAll: exportCsv } = useAdminDataExport({
  permission: 'plugin.doc_vod.use',
  path: '/weapp/doc_vod/statsExport',
  profile: 'video.stats',
  requireSelection: false,
  transport: 'download',
  successMessage: '剧集 CSV 导出已开始',
});

watch(days, load);
onMounted(load);
</script>

<template>
  <WeappPluginShell plugin-id="doc_vod" nav-key="stats">
    <WeappPluginPageCard :loading="loading" title="运营统计">
      <template #actions>
        <span class="text-sm text-muted-foreground">近</span>
        <el-select
          v-model="days"
          aria-label="统计时间范围"
          style="width: 100px"
        >
          <el-option :value="7" label="7 天" />
          <el-option :value="30" label="30 天" />
          <el-option :value="90" label="90 天" />
        </el-select>
        <el-tooltip
          :disabled="canExport"
          content="无导出权限，如需导出请联系管理员"
        >
          <el-button
            :class="{ 'opacity-60': !canExport }"
            @click="exportCsv"
          >
            导出剧集 CSV
          </el-button>
        </el-tooltip>
        <el-button @click="load">刷新</el-button>
      </template>

      <WeappPluginKpiRow :items="kpiItems" class="mb-4" />
      <p class="pv-weapp-hint mb-4">
        试看结束 / 购买点击自 P4 迁移起按日汇总；需先执行 <code>migrate_doc_vod_pp4.php</code>。
      </p>

      <PvModuleSection title="趋势（日播放自 P3 起累计；订单/授权按日期）">
        <EchartsUI ref="chartRef" height="280px" />
      </PvModuleSection>

      <PvModuleSection
        v-loading="heatmapLoading"
        title="播放热力图（剧集 × 集位）"
      >
        <p class="pv-weapp-hint mb-2">
          点击色块下钻「单集 × 日期」{{
            heatmapUseDaily ? '· 已启用 P5 单集日统计' : '· 请先执行 migrate_doc_vod_pp5.php'
          }}。纵轴为热门剧集，横轴为集序 E1–E16。
        </p>
        <EchartsUI ref="heatmapRef" height="320px" />
      </PvModuleSection>

      <el-drawer v-model="drillVisible" :title="`热力下钻 · ${drillTitle}`" size="62%">
        <EchartsUI ref="drillRef" height="420px" />
      </el-drawer>

      <el-row :gutter="16">
        <el-col :lg="14" :xs="24">
          <PvModuleSection title="剧集排行">
            <el-table
              v-if="seriesRank.length"
              :data="seriesRank"
              row-key="id"
              size="small"
            >
              <el-table-column label="剧集" min-width="140" prop="title">
                <template #default="{ row }">
                  <el-button
                    v-if="row.id"
                    link
                    type="primary"
                    @click="openDrill(Number(row.id), String(row.title ?? ''))"
                  >
                    {{ row.title }}
                  </el-button>
                  <span v-else>{{ row.title }}</span>
                </template>
              </el-table-column>
              <el-table-column
                class-name="pv-tabular-nums"
                label="单集"
                prop="ep_count"
                width="72"
              />
              <el-table-column
                class-name="pv-tabular-nums"
                label="播放"
                prop="play_sum"
                width="88"
              />
              <el-table-column
                class-name="pv-tabular-nums"
                label="授权"
                prop="grant_count"
                width="72"
              />
              <el-table-column
                class-name="pv-tabular-nums"
                label="转化%"
                prop="conversion_pct"
                width="80"
              />
            </el-table>
            <el-empty v-else description="暂无剧集播放数据" />
          </PvModuleSection>
          <PvModuleSection title="单集播放 Top">
            <el-table
              v-if="topEpisodes.length"
              :data="topEpisodes"
              row-key="id"
              size="small"
            >
              <el-table-column
                label="标题"
                min-width="120"
                prop="title"
                show-overflow-tooltip
              />
              <el-table-column
                label="剧集"
                min-width="100"
                prop="series_title"
                show-overflow-tooltip
              />
              <el-table-column
                class-name="pv-tabular-nums"
                label="播放"
                prop="play_count"
                width="80"
              />
              <el-table-column
                class-name="pv-tabular-nums"
                label="文档ID"
                prop="document_id"
                width="80"
              />
            </el-table>
            <el-empty v-else description="暂无单集播放数据" />
          </PvModuleSection>
        </el-col>
        <el-col :lg="10" :xs="24">
          <PvModuleSection title="近 7 日解析失败（按平台）">
            <el-table v-if="parseFails.length" :data="parseFails" size="small">
              <el-table-column label="平台" prop="platform" width="120" />
              <el-table-column
                class-name="pv-tabular-nums"
                label="次数"
                prop="fail_count"
                width="72"
              />
            </el-table>
            <el-empty v-else description="暂无失败记录" />
          </PvModuleSection>
          <PvModuleSection title="最近解析失败">
            <el-table v-if="parseRecent.length" :data="parseRecent" size="small">
              <el-table-column label="时间" prop="created_at" width="150" />
              <el-table-column label="平台" prop="platform" width="88" />
              <el-table-column
                label="说明"
                min-width="120"
                prop="msg"
                show-overflow-tooltip
              />
            </el-table>
            <el-empty v-else description="暂无解析失败日志" />
          </PvModuleSection>
        </el-col>
      </el-row>
    </WeappPluginPageCard>
  </WeappPluginShell>
</template>

<style scoped>
:deep(.pv-tabular-nums) {
  font-variant-numeric: tabular-nums;
}
</style>
