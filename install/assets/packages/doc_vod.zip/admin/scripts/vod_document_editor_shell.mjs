/** SSOT: doc_vod document-editor.html（文档 Tab：点播剧集 / 简单外链） */
export function buildVodDocumentEditorHtml() {
  return `<!DOCTYPE html>
<html lang="zh-CN" data-iframe-theme="light">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>文档视频 · 文档编辑</title>
  <style>
    :root {
      font-family: var(--pv-font-family, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif);
      font-size: var(--pv-font-size, 14px);
      --pv-radius-base: 4px;
      --pv-radius-lg: calc(var(--pv-radius-base) + 4px);
      --pv-primary: rgb(64, 158, 255);
      --pv-primary-soft: rgb(236, 245, 255);
      --pv-primary-border: rgb(179, 216, 255);
      --pv-primary-hover: rgb(102, 177, 255);
      --pv-danger: rgb(245, 108, 108);
      --pv-danger-soft: rgb(254, 240, 240);
      --pv-danger-border: rgb(251, 196, 196);
      --pv-card-bg: rgb(255, 255, 255);
      --pv-fill: rgb(245, 247, 250);
      --pv-border: rgb(228, 231, 237);
      --pv-text: rgb(48, 49, 51);
      --pv-text-secondary: rgb(144, 147, 153);
      --pv-input-bg: rgb(255, 255, 255);
    }
    html[data-iframe-theme='light'] {
      color-scheme: light;
      --pv-primary-soft: color-mix(in srgb, var(--pv-primary) 12%, var(--pv-card-bg));
      --pv-primary-border: color-mix(in srgb, var(--pv-primary) 35%, var(--pv-border));
      --pv-primary-hover: color-mix(in srgb, var(--pv-primary) 88%, #000);
      --pv-danger-soft: color-mix(in srgb, var(--pv-danger) 12%, var(--pv-card-bg));
      --pv-danger-border: color-mix(in srgb, var(--pv-danger) 40%, var(--pv-border));
    }
    html[data-iframe-theme='dark'] {
      color-scheme: dark;
      --pv-danger-soft: color-mix(in srgb, var(--pv-danger) 16%, var(--pv-card-bg));
      --pv-danger-border: color-mix(in srgb, var(--pv-danger) 40%, var(--pv-border));
      --pv-primary-soft: color-mix(in srgb, var(--pv-primary) 14%, var(--pv-card-bg));
      --pv-primary-border: color-mix(in srgb, var(--pv-primary) 35%, var(--pv-border));
      --pv-primary-hover: color-mix(in srgb, var(--pv-primary) 82%, #fff);
    }
    body { margin: 0; padding: 8px 4px 12px; background: transparent; color: var(--pv-text); font-size: inherit; }
    body.embed-tab { padding: 14px 20px 28px; box-sizing: border-box; overflow: auto; background: transparent; }
    html.embed-tab, body.embed-tab { min-height: 100%; height: auto; }
    .hint { color: var(--pv-text-secondary); margin: 0 0 12px; line-height: 1.5; font-size: 0.857em; }
    .hint.err { color: var(--pv-danger); font-weight: 500; }
    .actions { display: flex; gap: 10px; flex-wrap: wrap; margin-bottom: 12px; align-items: center; }
    button {
      padding: var(--pv-btn-padding, 8px 15px); border-radius: var(--pv-radius-base);
      border: 1px solid var(--pv-border); background: var(--pv-card-bg); color: var(--pv-text);
      cursor: pointer; font-size: inherit; line-height: 1.4;
    }
    button:hover { background: var(--pv-fill); }
    button.primary { background: var(--pv-primary); color: #fff; border-color: var(--pv-primary); }
    button.primary:hover { background: var(--pv-primary-hover); border-color: var(--pv-primary-hover); }
    button.plain { color: var(--pv-primary); border-color: var(--pv-primary-border); background: var(--pv-primary-soft); }
    button.danger { color: var(--pv-danger); border-color: var(--pv-danger-border); background: var(--pv-danger-soft); }
    a { color: var(--pv-primary); font-size: inherit; text-decoration: none; }
    a:hover { opacity: 0.85; }
    .link-sep { color: var(--pv-text-secondary); margin: 0 4px; opacity: 0.65; }
    .is-hidden { display: none !important; }
    input[type="text"], input[type="number"], select {
      box-sizing: border-box; padding: var(--pv-input-padding, 7px 11px);
      border: 1px solid var(--pv-border); border-radius: var(--pv-radius-base); font-size: inherit;
      background: var(--pv-input-bg, var(--pv-card-bg)); color: var(--pv-text);
    }
    input[type="text"]:focus, input[type="number"]:focus, select:focus {
      outline: none; border-color: var(--pv-primary);
      box-shadow: 0 0 0 2px color-mix(in srgb, var(--pv-primary) 18%, transparent);
    }
    input[type="checkbox"] { accent-color: var(--pv-primary); }
    label.lbl { font-size: 0.857em; color: var(--pv-text-secondary); font-weight: 500; white-space: nowrap; }
    .mode-bar {
      display: flex; flex-wrap: wrap; gap: 8px; align-items: center; margin-bottom: 12px;
      padding: 10px 12px; border: 1px solid var(--pv-border); border-radius: var(--pv-radius-base);
      background: var(--pv-fill);
    }
    .mode-bar label { font-size: 0.857em; color: var(--pv-text-secondary); margin-right: 4px; }
    .mode-bar button.is-active { background: var(--pv-primary-soft); border-color: var(--pv-primary-border); color: var(--pv-primary); font-weight: 600; }
    .card-list { display: flex; flex-direction: column; gap: 12px; }
    .card {
      border: 1px solid var(--pv-border); border-radius: var(--pv-radius-lg); background: var(--pv-card-bg);
      box-shadow: 0 1px 2px color-mix(in srgb, var(--pv-text) 6%, transparent); overflow: hidden;
    }
    html[data-iframe-theme='dark'] .card { box-shadow: none; }
    .card-head {
      display: flex; align-items: center; gap: 8px; flex-wrap: wrap;
      padding: 12px 14px; background: var(--pv-fill);
      border-bottom: 1px solid var(--pv-border); cursor: pointer; user-select: none;
    }
    .card-head-main { display: flex; align-items: center; gap: 8px; flex: 1; min-width: 0; }
    .chevron { color: var(--pv-text-secondary); font-size: 0.786em; width: 16px; text-align: center; flex-shrink: 0; transition: transform .15s; }
    .card.is-open .chevron { transform: rotate(90deg); }
    .card-title { font-weight: 600; font-size: 1em; }
    .card-meta { font-size: 0.857em; color: var(--pv-text-secondary); white-space: nowrap; }
    .card-body { padding: 12px 14px 14px; display: none; }
    .card.is-open .card-body { display: block; }
    .field-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(160px, 1fr)); gap: 10px 12px; margin-bottom: 10px; }
    .field { display: flex; flex-direction: column; gap: 4px; min-width: 0; }
    .field-wide { grid-column: 1 / -1; }
    .src-row {
      display: flex; flex-wrap: wrap; gap: 6px; align-items: center;
      padding: 8px 0; border-bottom: 1px dashed var(--pv-border); font-size: 0.857em;
    }
    .src-row:last-child { border-bottom: none; }
    .src-label { width: 88px; flex: 0 1 88px; }
    .src-provider { width: 96px; flex: 0 0 96px; }
    .src-url { flex: 1 1 140px; min-width: 120px; }
    .empty-tip {
      padding: 20px; text-align: center; color: var(--pv-text-secondary); font-size: 0.857em;
      border: 1px dashed var(--pv-border); border-radius: var(--pv-radius-base); background: var(--pv-fill);
    }
    .series-card { margin-bottom: 12px; }
    .series-card .card-head { cursor: default; }
    .series-panel {
      margin-bottom: 14px; border: 1px solid var(--pv-border); border-radius: var(--pv-radius-lg);
      background: var(--pv-card-bg); overflow: hidden;
      box-shadow: 0 1px 2px color-mix(in srgb, var(--pv-text) 6%, transparent);
    }
    html[data-iframe-theme='dark'] .series-panel { box-shadow: none; }
    .series-panel-head {
      display: flex; align-items: center; justify-content: space-between; gap: 8px; flex-wrap: wrap;
      padding: 12px 14px; background: var(--pv-fill); border-bottom: 1px solid var(--pv-border);
    }
    .series-panel-title { font-weight: 600; margin: 0; font-size: 1em; }
    .series-panel-hint { margin: 0; font-size: 0.857em; color: var(--pv-text-secondary); }
    .series-panel-body { padding: 12px 14px 14px; }
    .chip-row { display: flex; flex-wrap: wrap; gap: 6px; }
    .chip-row button {
      padding: 6px 12px; border-radius: 999px; border: 1px solid var(--pv-border);
      background: var(--pv-card-bg); color: var(--pv-text); font-size: 0.857em;
    }
    .chip-row button.is-active {
      background: var(--pv-primary-soft); border-color: var(--pv-primary-border);
      color: var(--pv-primary); font-weight: 600;
    }
    .field-soft {
      padding: 10px 12px; border: 1px solid var(--pv-border); border-radius: var(--pv-radius-base);
      background: var(--pv-fill);
    }
    .field-soft .lbl { display: block; margin-bottom: 6px; }
    .chk-inline { display: inline-flex; align-items: center; gap: 6px; font-size: 0.857em; }
    .url-main { width: 100%; box-sizing: border-box; padding: 10px 12px; font-size: 1em; }
    .more-toggle {
      margin: 10px 0 0; padding: 0; border: 0; background: transparent; color: var(--pv-primary);
      cursor: pointer; font-size: 0.857em; font-weight: 600;
    }
    .adv-block { margin-top: 10px; padding-top: 10px; border-top: 1px dashed var(--pv-border); }
    .paste-hint { margin: 0 0 10px; font-size: 0.857em; color: var(--pv-text-secondary); }
    .source-guide {
      margin: 0 0 12px; padding: 10px 12px; border-radius: var(--pv-radius-base);
      border: 1px solid var(--pv-primary-border); background: var(--pv-primary-soft);
      color: var(--pv-text); font-size: 0.857em; line-height: 1.55;
    }
    .source-guide strong { color: var(--pv-primary); }
    .url-warn {
      margin-top: 8px; padding: 8px 10px; border-radius: var(--pv-radius-base);
      border: 1px solid var(--pv-danger-border); background: var(--pv-danger-soft);
      color: var(--pv-danger); font-size: 0.857em; line-height: 1.45;
    }
    @media (max-width: 640px) {
      body.embed-tab { padding: 10px 12px 20px; }
      .field-grid { grid-template-columns: 1fr; }
      .src-row { flex-direction: column; align-items: stretch; }
      .src-label, .src-provider, .src-url { width: 100%; flex: 1 1 auto; }
    }
  </style>
</head>
<body>
  <p class="hint" id="status">加载中…</p>
  <div class="mode-bar" id="mode-bar" role="group" aria-label="录入模式">
    <label>录入模式</label>
    <button type="button" data-mode="vod" class="is-active">点播剧集</button>
    <button type="button" data-mode="embed">简单外链</button>
  </div>
  <div class="actions" id="toolbar">
    <button type="button" class="primary" id="add-ep">+ 添加单集</button>
    <button type="button" class="primary is-hidden" id="add-embed">+ 添加视频</button>
    <a href="/admin#/weapp/host/doc_vod/settings" target="_blank" rel="noopener" id="plugin-settings-link">插件设置</a>
  </div>
  <div class="source-guide" id="source-guide">
    <strong>片源填写：</strong>B 站可直接贴 BV 页链；爱奇艺 / 优酷 / 腾讯请用视频页「分享 → 通用代码」里的
    <code>iframe src</code>（如 <code>open.iqiyi.com</code>），普通播放页无法站内嵌播。粘贴链接会自动识别片源类型。
  </div>
  <div id="series-wrap"></div>
  <div id="root" class="card-list"></div>
  <script>
    const PLUGIN_ID = 'doc_vod';
    const PREPARE = 'pivark:document-editor-prepare-save';
    const EXPORT = 'pivark:document-editor-export';
    const PREFILL = 'pivark:document-editor-prefill';
    const INIT = 'pivark:document-editor-init';
    const THEME = 'pivark:document-editor-theme';
    const RESIZE = 'pivark:document-editor-resize';
    const PROVIDERS = [
      { id: 'embed', label: '嵌入' },
      { id: 'local', label: '本地/直链' },
      { id: 'bilibili', label: 'B站' },
      { id: 'iqiyi', label: '爱奇艺' },
      { id: 'youku', label: '优酷' },
      { id: 'tencent', label: '腾讯' },
      { id: 'youtube', label: 'YouTube' },
      { id: 'other', label: '其它' },
    ];
    const SERIES_MODES = [
      { v: 'free', l: '免费' },
      { v: 'login', l: '须登录' },
      { v: 'level', l: '会员等级' },
      { v: 'paid_series', l: '全集付费' },
    ];
    const EP_MODES = [
      { v: '', l: '继承剧集' },
      { v: 'free', l: '免费' },
      { v: 'login', l: '须登录' },
      { v: 'level', l: '会员等级' },
      { v: 'paid', l: '单集付费' },
      { v: 'paid_series', l: '全集付费' },
      { v: 'points', l: '积分兑换' },
    ];

    const params = new URLSearchParams(location.search);
    const editorSlot = String(params.get('slot') || '');
    let documentId = Number(params.get('document_id') || 0);
    let editorMode = 'vod';
    let series = defaultSeries();
    let seriesOpen = true;
    let episodes = [];
    let embedItems = [];
    let memberLevels = [];
    let vodReady = true;
    let dataReady = false;
    let dataDirty = false;
    let epOpen = {};
    let nextEpSeq = 1;
    let loadSeq = 0;

    const statusEl = document.getElementById('status');
    const rootEl = document.getElementById('root');
    const seriesWrap = document.getElementById('series-wrap');
    const addEpBtn = document.getElementById('add-ep');
    const addEmbedBtn = document.getElementById('add-embed');
    const sourceGuideEl = document.getElementById('source-guide');

    if (editorSlot === 'tab') {
      document.documentElement.classList.add('embed-tab');
      document.body.classList.add('embed-tab');
    }

    function defaultSeries() {
      return {
        id: 0,
        access_mode: 'free',
        read_level_id: 0,
        price: 0,
        trial_preview_sec: 0,
        free_ep_count: 0,
      };
    }

    function defaultSource() {
      return { id: 0, label: '', provider: 'embed', play_url: '', _url_warn: '' };
    }

    /** 从 URL 推断 provider / 通道名；爱奇艺页链给出引导 warn */
    function guessProviderFromUrl(url) {
      const raw = String(url || '').trim();
      const u = raw.toLowerCase();
      if (!u) return { provider: 'embed', label: '', warn: '' };
      if (u.indexOf('bilibili.com') >= 0 || new RegExp('\\\\bbv[0-9a-z]+', 'i').test(raw)) {
        return { provider: 'bilibili', label: 'B站', warn: '' };
      }
      if (u.indexOf('youtu.be') >= 0 || u.indexOf('youtube.com') >= 0) {
        return { provider: 'youtube', label: 'YouTube', warn: '' };
      }
      if (u.indexOf('open.iqiyi.com') >= 0) {
        return { provider: 'iqiyi', label: '爱奇艺', warn: '' };
      }
      if (u.indexOf('iqiyi.com') >= 0 || u.indexOf('iq.com') >= 0) {
        return {
          provider: 'iqiyi',
          label: '爱奇艺',
          warn: '这是爱奇艺播放页链接，站内通常无法直接嵌播。请到视频页点「分享 → 通用代码」，复制 iframe 里的地址（含 open.iqiyi.com）再粘贴。',
        };
      }
      if (u.indexOf('youku.com') >= 0) {
        const ok = u.indexOf('player.youku.com') >= 0 || u.indexOf('/embed/') >= 0;
        return {
          provider: 'youku',
          label: '优酷',
          warn: ok ? '' : '优酷普通播放页可能无法直接嵌，建议使用分享通用代码中的 iframe 地址。',
        };
      }
      if (u.indexOf('v.qq.com') >= 0 || u.indexOf('qq.com/video') >= 0) {
        const ok = u.indexOf('v.qq.com/txp/iframe') >= 0 || u.indexOf('/iframe/') >= 0;
        return {
          provider: 'tencent',
          label: '腾讯',
          warn: ok ? '' : '腾讯视频普通播放页可能无法直接嵌，建议使用分享通用代码中的 iframe 地址。',
        };
      }
      if (new RegExp('\\\\.(m3u8|mp4|webm|mov)(\\\\?|$)', 'i').test(u) || u.indexOf('/uploads/') >= 0 || u.indexOf('/storage/') >= 0) {
        return { provider: 'local', label: '直链', warn: '' };
      }
      return { provider: 'embed', label: '', warn: '' };
    }

    function applyGuessToSource(src, url) {
      const g = guessProviderFromUrl(url);
      src.provider = g.provider;
      if (!String(src.label || '').trim() && g.label) src.label = g.label;
      src._url_warn = g.warn || '';
      return g;
    }

    function defaultEpisode(no) {
      return {
        id: 0,
        ep_no: no,
        title: '',
        cover_path: '',
        duration_sec: 0,
        trial_preview_sec: 0,
        access_mode: '',
        read_level_id: 0,
        price: 0,
        points_cost: 1,
        status: 1,
        sources: [defaultSource()],
      };
    }

    function defaultEmbedItem() {
      return { id: 0, title: '', video_url: '', cover_path: '', provider: '', status: 1, sort: 0 };
    }

    function normalizeSeries(raw) {
      if (!raw || typeof raw !== 'object') return defaultSeries();
      return {
        id: Number(raw.id || 0),
        access_mode: String(raw.access_mode || 'free'),
        read_level_id: Number(raw.read_level_id || 0),
        price: Number(raw.price || 0),
        trial_preview_sec: Number(raw.trial_preview_sec || 0),
        free_ep_count: Number(raw.free_ep_count || 0),
      };
    }

    function normalizeSource(raw) {
      const src = {
        id: Number(raw && raw.id ? raw.id : 0),
        label: String(raw && raw.label ? raw.label : ''),
        provider: String(raw && raw.provider ? raw.provider : 'embed'),
        play_url: String(raw && (raw.play_url || raw.video_url) ? (raw.play_url || raw.video_url) : ''),
        _url_warn: '',
      };
      if (src.play_url) {
        // 加载时只补 warn，不覆盖已存 provider/label（粘贴/改址仍走 applyGuessToSource）
        const g = guessProviderFromUrl(src.play_url);
        src._url_warn = g.warn || '';
      }
      return src;
    }

    function normalizeEpisode(raw, idx) {
      const epNo = Number(raw && raw.ep_no != null ? raw.ep_no : (idx + 1));
      const srcs = Array.isArray(raw && raw.sources) ? raw.sources.map(normalizeSource) : [];
      if (!srcs.length && raw && (raw.play_url || raw.video_url)) {
        srcs.push(normalizeSource({ id: 0, label: '', provider: raw.provider || 'embed', play_url: raw.play_url || raw.video_url }));
      }
      if (!srcs.length) srcs.push(defaultSource());
      const mode = String(raw && raw.access_mode != null ? raw.access_mode : '');
      const price = Number(raw && raw.price != null ? raw.price : 0);
      const points = Number(raw && raw.points_cost != null ? raw.points_cost : (mode === 'points' ? price : 0));
      return {
        id: Number(raw && raw.id ? raw.id : 0),
        ep_no: epNo,
        title: String(raw && raw.title ? raw.title : ''),
        cover_path: String(raw && raw.cover_path ? raw.cover_path : ''),
        duration_sec: Number(raw && raw.duration_sec ? raw.duration_sec : 0),
        trial_preview_sec: Number(raw && raw.trial_preview_sec ? raw.trial_preview_sec : 0),
        access_mode: mode,
        read_level_id: Number(raw && raw.read_level_id ? raw.read_level_id : 0),
        price: price,
        points_cost: Math.max(1, points || 1),
        status: raw && raw.status != null ? (Number(raw.status) ? 1 : 0) : 1,
        sources: srcs,
      };
    }

    function normalizeEmbed(raw, idx) {
      return {
        id: Number(raw && raw.id ? raw.id : 0),
        title: String(raw && raw.title ? raw.title : ''),
        video_url: String(raw && raw.video_url ? raw.video_url : ''),
        cover_path: String(raw && raw.cover_path ? raw.cover_path : ''),
        provider: String(raw && raw.provider ? raw.provider : ''),
        status: raw && raw.status != null ? (Number(raw.status) ? 1 : 0) : 1,
        sort: Number(raw && raw.sort != null ? raw.sort : idx),
      };
    }

    function epHasContent(ep) {
      if (String(ep.title || '').trim()) return true;
      return (ep.sources || []).some(function (s) { return String(s.play_url || '').trim() !== ''; });
    }

    function embedHasContent(it) {
      return String(it.video_url || '').trim() !== '';
    }

    function fillLevelSelect(sel, selectedId, withEmpty) {
      sel.innerHTML = '';
      if (withEmpty) {
        const ph = document.createElement('option');
        ph.value = '0';
        ph.textContent = '—';
        sel.appendChild(ph);
      }
      memberLevels.forEach(function (lv) {
        const opt = document.createElement('option');
        opt.value = String(lv.id);
        opt.textContent = lv.name;
        sel.appendChild(opt);
      });
      sel.value = String(selectedId || 0);
    }

    function fillModeSelect(sel, modes, selected) {
      sel.innerHTML = '';
      modes.forEach(function (m) {
        const opt = document.createElement('option');
        opt.value = m.v;
        opt.textContent = m.l;
        sel.appendChild(opt);
      });
      sel.value = selected != null ? String(selected) : '';
    }

    function createField(labelText, inputEl, wide) {
      const wrap = document.createElement('div');
      wrap.className = 'field' + (wide ? ' field-wide' : '');
      const lab = document.createElement('label');
      lab.className = 'lbl';
      lab.textContent = labelText;
      wrap.appendChild(lab);
      wrap.appendChild(inputEl);
      return wrap;
    }

    function numInput(val, onInput, placeholder) {
      const inp = document.createElement('input');
      inp.type = 'number';
      inp.min = '0';
      inp.value = String(val || 0);
      if (placeholder) inp.placeholder = placeholder;
      inp.addEventListener('input', function () { dataDirty = true; onInput(parseInt(inp.value, 10) || 0); notifyParentHeight(); });
      return inp;
    }

    function textInput(val, onInput, placeholder) {
      const inp = document.createElement('input');
      inp.type = 'text';
      inp.value = String(val || '');
      if (placeholder) inp.placeholder = placeholder;
      inp.addEventListener('input', function () { dataDirty = true; onInput(inp.value); });
      return inp;
    }

    function renderSeriesCard() {
      seriesWrap.innerHTML = '';
      if (editorMode !== 'vod') return;

      const panel = document.createElement('div');
      panel.className = 'series-panel';

      const head = document.createElement('div');
      head.className = 'series-panel-head';
      const titles = document.createElement('div');
      const h = document.createElement('p');
      h.className = 'series-panel-title';
      h.textContent = '本剧默认';
      const hint = document.createElement('p');
      hint.className = 'series-panel-hint';
      hint.textContent = '单集在下方本页添加即可，无需另开剧集页';
      titles.appendChild(h);
      titles.appendChild(hint);
      head.appendChild(titles);
      panel.appendChild(head);

      const body = document.createElement('div');
      body.className = 'series-panel-body';

      const modeBlock = document.createElement('div');
      modeBlock.className = 'field-soft';
      modeBlock.style.marginBottom = '12px';
      const modeLab = document.createElement('label');
      modeLab.className = 'lbl';
      modeLab.textContent = '默认权限';
      modeBlock.appendChild(modeLab);
      const chips = document.createElement('div');
      chips.className = 'chip-row';
      SERIES_MODES.forEach(function (m) {
        const btn = document.createElement('button');
        btn.type = 'button';
        btn.textContent = m.l;
        if (series.access_mode === m.v) btn.className = 'is-active';
        btn.addEventListener('click', function () {
          dataDirty = true;
          series.access_mode = m.v;
          renderSeriesCard();
        });
        chips.appendChild(btn);
      });
      modeBlock.appendChild(chips);
      body.appendChild(modeBlock);

      const grid = document.createElement('div');
      grid.className = 'field-grid';

      const freeField = document.createElement('div');
      freeField.className = 'field field-soft';
      const freeLab = document.createElement('label');
      freeLab.className = 'lbl';
      freeLab.textContent = '前 N 集免费';
      freeField.appendChild(freeLab);
      freeField.appendChild(numInput(series.free_ep_count, function (v) { series.free_ep_count = v; }));
      grid.appendChild(freeField);

      const trialField = document.createElement('div');
      trialField.className = 'field field-soft';
      const trialLab = document.createElement('label');
      trialLab.className = 'lbl';
      trialLab.textContent = '试看秒数（0=关）';
      trialField.appendChild(trialLab);
      trialField.appendChild(numInput(series.trial_preview_sec, function (v) { series.trial_preview_sec = v; }));
      grid.appendChild(trialField);

      const lvlField = document.createElement('div');
      lvlField.className = 'field field-soft';
      const lvlLab = document.createElement('label');
      lvlLab.className = 'lbl';
      lvlLab.textContent = '会员等级';
      lvlField.appendChild(lvlLab);
      const lvlSel = document.createElement('select');
      fillLevelSelect(lvlSel, series.read_level_id, false);
      lvlSel.addEventListener('change', function () { dataDirty = true; series.read_level_id = parseInt(lvlSel.value, 10) || 0; });
      lvlField.appendChild(lvlSel);
      if (series.access_mode !== 'level') lvlField.style.display = 'none';
      grid.appendChild(lvlField);

      const priceField = document.createElement('div');
      priceField.className = 'field field-soft';
      const priceLab = document.createElement('label');
      priceLab.className = 'lbl';
      priceLab.textContent = '全集价（¥）';
      priceField.appendChild(priceLab);
      const priceInp = numInput(series.price, function (v) { series.price = v; });
      priceInp.step = '0.01';
      priceField.appendChild(priceInp);
      if (series.access_mode !== 'paid_series') priceField.style.display = 'none';
      grid.appendChild(priceField);

      body.appendChild(grid);
      panel.appendChild(body);
      seriesWrap.appendChild(panel);
    }

    function renderSourceRow(ep, srcIdx) {
      const src = ep.sources[srcIdx];
      const row = document.createElement('div');
      row.className = 'src-row';

      row.appendChild(textInput(src.label, function (v) { src.label = v; }, '通道名'));

      const provSel = document.createElement('select');
      provSel.className = 'src-provider';
      PROVIDERS.forEach(function (p) {
        const opt = document.createElement('option');
        opt.value = p.id;
        opt.textContent = p.label;
        provSel.appendChild(opt);
      });
      provSel.value = src.provider || 'embed';
      provSel.addEventListener('change', function () { dataDirty = true; src.provider = provSel.value; });
      row.appendChild(provSel);

      const urlInp = textInput(src.play_url, function (v) { src.play_url = v; }, '播放地址');
      urlInp.className = 'src-url';
      urlInp.addEventListener('change', function () {
        applyGuessToSource(src, urlInp.value.trim());
        dataDirty = true;
        render();
      });
      urlInp.addEventListener('paste', function () {
        setTimeout(function () {
          applyGuessToSource(src, urlInp.value.trim());
          dataDirty = true;
          render();
        }, 0);
      });
      row.appendChild(urlInp);

      if (String(src._url_warn || '').trim()) {
        const warn = document.createElement('div');
        warn.className = 'url-warn';
        warn.setAttribute('data-url-warn', '1');
        warn.style.flexBasis = '100%';
        warn.textContent = src._url_warn;
        row.appendChild(warn);
      }

      const del = document.createElement('button');
      del.type = 'button';
      del.className = 'danger';
      del.textContent = '删除通道';
      del.addEventListener('click', function () {
        if (ep.sources.length <= 1) { ep.sources[0] = defaultSource(); }
        else ep.sources.splice(srcIdx, 1);
        dataDirty = true;
        render();
      });
      row.appendChild(del);
      return row;
    }

    function renderEpisodeCard(ep, idx) {
      const key = String(ep.id || ('n' + idx));
      if (epOpen[key] == null) epOpen[key] = idx === episodes.length - 1;
      if (ep._more == null) ep._more = false;
      if (!Array.isArray(ep.sources) || !ep.sources.length) ep.sources = [defaultSource()];
      const card = document.createElement('div');
      card.className = 'card' + (epOpen[key] ? ' is-open' : '');
      card.setAttribute('data-ep-key', key);

      const head = document.createElement('div');
      head.className = 'card-head';
      head.addEventListener('click', function (ev) {
        if (ev.target.closest('input') || ev.target.closest('select') || ev.target.closest('button') || ev.target.closest('label')) return;
        epOpen[key] = !epOpen[key];
        render();
      });
      const main = document.createElement('div');
      main.className = 'card-head-main';
      const chev = document.createElement('span');
      chev.className = 'chevron';
      chev.textContent = '▶';
      const titleInp = document.createElement('input');
      titleInp.type = 'text';
      titleInp.className = 'card-title';
      titleInp.style.cssText = 'border:1px solid transparent;background:transparent;padding:4px 8px;border-radius:var(--pv-radius-base);font-weight:600;flex:1;min-width:100px;';
      titleInp.value = ep.title || ('第' + ep.ep_no + '集');
      titleInp.placeholder = '单集标题（可空，保存时自动生成）';
      titleInp.addEventListener('click', function (ev) { ev.stopPropagation(); });
      titleInp.addEventListener('input', function () { dataDirty = true; ep.title = titleInp.value; updateStatus(); });
      const meta = document.createElement('span');
      meta.className = 'card-meta';
      const url0 = String((ep.sources[0] && ep.sources[0].play_url) || '').trim();
      meta.textContent = '第' + ep.ep_no + '集' + (url0 ? ' · 已填地址' : ' · 待填地址');
      main.appendChild(chev);
      main.appendChild(titleInp);
      main.appendChild(meta);
      head.appendChild(main);

      const delEp = document.createElement('button');
      delEp.type = 'button';
      delEp.className = 'danger';
      delEp.textContent = '删除';
      delEp.addEventListener('click', function (ev) {
        ev.stopPropagation();
        const has = epHasContent(ep);
        if (has && !confirm('确定删除第' + ep.ep_no + '集？')) return;
        dataDirty = true;
        episodes.splice(idx, 1);
        render();
      });
      head.appendChild(delEp);
      card.appendChild(head);

      const body = document.createElement('div');
      body.className = 'card-body';

      const urlBlock = document.createElement('div');
      urlBlock.className = 'field field-soft field-wide';
      const urlLab = document.createElement('label');
      urlLab.className = 'lbl';
      urlLab.textContent = '播放地址';
      urlBlock.appendChild(urlLab);
      const mainRow = document.createElement('div');
      mainRow.className = 'src-row';
      const mainProv = document.createElement('select');
      mainProv.className = 'src-provider';
      mainProv.setAttribute('data-main-provider', '1');
      PROVIDERS.forEach(function (p) {
        const opt = document.createElement('option');
        opt.value = p.id;
        opt.textContent = p.label;
        mainProv.appendChild(opt);
      });
      mainProv.value = ep.sources[0].provider || 'embed';
      mainProv.addEventListener('change', function () {
        dataDirty = true;
        ep.sources[0].provider = mainProv.value;
      });
      mainRow.appendChild(mainProv);
      const urlInp = document.createElement('input');
      urlInp.type = 'text';
      urlInp.className = 'url-main src-url';
      urlInp.setAttribute('data-focus-url', key);
      urlInp.placeholder = '粘贴 B站 / 爱奇艺分享码 / YouTube / mp4 地址';
      urlInp.value = ep.sources[0].play_url || '';
      urlInp.addEventListener('input', function () {
        dataDirty = true;
        ep.sources[0].play_url = urlInp.value;
        updateStatus();
      });
      urlInp.addEventListener('change', function () {
        dataDirty = true;
        const v = urlInp.value.trim();
        ep.sources[0].play_url = v;
        applyGuessToSource(ep.sources[0], v);
        render();
      });
      urlInp.addEventListener('paste', function () {
        setTimeout(function () {
          dataDirty = true;
          const v = urlInp.value.trim();
          ep.sources[0].play_url = v;
          applyGuessToSource(ep.sources[0], v);
          render();
        }, 0);
      });
      mainRow.appendChild(urlInp);
      urlBlock.appendChild(mainRow);
      if (String(ep.sources[0]._url_warn || '').trim()) {
        const warn = document.createElement('div');
        warn.className = 'url-warn';
        warn.setAttribute('data-url-warn', '1');
        warn.textContent = ep.sources[0]._url_warn;
        urlBlock.appendChild(warn);
      }
      body.appendChild(urlBlock);

      const moreBtn = document.createElement('button');
      moreBtn.type = 'button';
      moreBtn.className = 'more-toggle';
      moreBtn.textContent = ep._more ? '收起更多设置 ▲' : '展开更多设置（权限 / 试看 / 备用线路）▼';
      moreBtn.addEventListener('click', function () {
        ep._more = !ep._more;
        render();
      });
      body.appendChild(moreBtn);

      if (ep._more) {
        const adv = document.createElement('div');
        adv.className = 'adv-block';

        const modeBlock = document.createElement('div');
        modeBlock.className = 'field-soft';
        modeBlock.style.marginBottom = '10px';
        const modeLab = document.createElement('label');
        modeLab.className = 'lbl';
        modeLab.textContent = '本集权限（空=继承本剧默认）';
        modeBlock.appendChild(modeLab);
        const chips = document.createElement('div');
        chips.className = 'chip-row';
        EP_MODES.forEach(function (m) {
          const btn = document.createElement('button');
          btn.type = 'button';
          btn.textContent = m.l;
          if (String(ep.access_mode || '') === m.v) btn.className = 'is-active';
          btn.addEventListener('click', function () {
            dataDirty = true;
            ep.access_mode = m.v;
            render();
          });
          chips.appendChild(btn);
        });
        modeBlock.appendChild(chips);
        adv.appendChild(modeBlock);

        const grid = document.createElement('div');
        grid.className = 'field-grid';
        grid.appendChild(createField('集号', numInput(ep.ep_no, function (v) { ep.ep_no = Math.max(1, v); })));
        grid.appendChild(createField('时长(秒)', numInput(ep.duration_sec, function (v) { ep.duration_sec = v; })));
        grid.appendChild(createField('试看(秒)', numInput(ep.trial_preview_sec, function (v) { ep.trial_preview_sec = v; }), '0=继承'));
        grid.appendChild(createField('封面路径', textInput(ep.cover_path, function (v) { ep.cover_path = v; }, '/uploads/...'), true));

        const lvlField = document.createElement('div');
        lvlField.className = 'field field-soft';
        const lvlLab = document.createElement('label');
        lvlLab.className = 'lbl';
        lvlLab.textContent = '会员等级';
        lvlField.appendChild(lvlLab);
        const lvlSel = document.createElement('select');
        fillLevelSelect(lvlSel, ep.read_level_id, true);
        lvlSel.addEventListener('change', function () { dataDirty = true; ep.read_level_id = parseInt(lvlSel.value, 10) || 0; });
        lvlField.appendChild(lvlSel);
        if (ep.access_mode !== 'level') lvlField.style.display = 'none';
        grid.appendChild(lvlField);

        const priceField = document.createElement('div');
        priceField.className = 'field field-soft';
        const priceLab = document.createElement('label');
        priceLab.className = 'lbl';
        priceLab.textContent = '单集价（¥）';
        priceField.appendChild(priceLab);
        const priceInp = numInput(ep.price, function (v) { ep.price = v; });
        priceInp.step = '0.01';
        priceField.appendChild(priceInp);
        if (ep.access_mode !== 'paid' && ep.access_mode !== 'paid_series') priceField.style.display = 'none';
        grid.appendChild(priceField);

        const ptsField = document.createElement('div');
        ptsField.className = 'field field-soft';
        const ptsLab = document.createElement('label');
        ptsLab.className = 'lbl';
        ptsLab.textContent = '所需积分';
        ptsField.appendChild(ptsLab);
        ptsField.appendChild(numInput(ep.points_cost, function (v) { ep.points_cost = Math.max(1, v); }));
        if (ep.access_mode !== 'points') ptsField.style.display = 'none';
        grid.appendChild(ptsField);

        const chkWrap = document.createElement('label');
        chkWrap.className = 'chk-inline field field-soft';
        const chk = document.createElement('input');
        chk.type = 'checkbox';
        chk.checked = !!ep.status;
        chk.addEventListener('change', function () { dataDirty = true; ep.status = chk.checked ? 1 : 0; });
        chkWrap.appendChild(chk);
        chkWrap.appendChild(document.createTextNode('上架'));
        grid.appendChild(chkWrap);
        adv.appendChild(grid);

        const srcHead = document.createElement('p');
        srcHead.className = 'hint';
        srcHead.style.margin = '10px 0 4px';
        srcHead.textContent = '备用线路（可选）';
        adv.appendChild(srcHead);
        for (let si = 1; si < ep.sources.length; si++) {
          adv.appendChild(renderSourceRow(ep, si));
        }
        const addSrc = document.createElement('button');
        addSrc.type = 'button';
        addSrc.className = 'plain';
        addSrc.textContent = '+ 添加备用线路';
        addSrc.style.marginTop = '8px';
        addSrc.addEventListener('click', function () {
          dataDirty = true;
          ep.sources.push(defaultSource());
          ep._more = true;
          render();
        });
        adv.appendChild(addSrc);
        body.appendChild(adv);
      }

      card.appendChild(body);
      return card;
    }

    function renderEmbedCard(it, idx) {
      const key = 'e' + idx;
      if (epOpen[key] == null) epOpen[key] = true;
      const card = document.createElement('div');
      card.className = 'card' + (epOpen[key] ? ' is-open' : '');
      const head = document.createElement('div');
      head.className = 'card-head';
      head.addEventListener('click', function (ev) {
        if (ev.target.closest('input') || ev.target.closest('button')) return;
        epOpen[key] = !epOpen[key];
        render();
      });
      const main = document.createElement('div');
      main.className = 'card-head-main';
      const chev = document.createElement('span');
      chev.className = 'chevron';
      chev.textContent = '▶';
      const title = document.createElement('span');
      title.className = 'card-title';
      title.textContent = String(it.title || '').trim() || ('视频 ' + (idx + 1));
      main.appendChild(chev);
      main.appendChild(title);
      head.appendChild(main);
      const del = document.createElement('button');
      del.type = 'button';
      del.className = 'danger';
      del.textContent = '删除';
      del.addEventListener('click', function (ev) {
        ev.stopPropagation();
        dataDirty = true;
        embedItems.splice(idx, 1);
        render();
      });
      head.appendChild(del);
      card.appendChild(head);

      const body = document.createElement('div');
      body.className = 'card-body';
      const grid = document.createElement('div');
      grid.className = 'field-grid';
      grid.appendChild(createField('标题', textInput(it.title, function (v) { it.title = v; })));
      grid.appendChild(createField('视频地址', textInput(it.video_url, function (v) { it.video_url = v; }, 'https://…'), true));
      grid.appendChild(createField('封面路径', textInput(it.cover_path, function (v) { it.cover_path = v; }, '/uploads/...')));
      body.appendChild(grid);
      card.appendChild(body);
      return card;
    }

    function setEditorMode(mode) {
      const next = mode === 'embed' ? 'embed' : 'vod';
      if (next === editorMode) return;
      editorMode = next;
      dataDirty = true;
      render();
    }

    function renderModeBar() {
      document.querySelectorAll('#mode-bar button[data-mode]').forEach(function (btn) {
        btn.classList.toggle('is-active', btn.getAttribute('data-mode') === editorMode);
      });
      addEpBtn.classList.toggle('is-hidden', editorMode !== 'vod');
      addEmbedBtn.classList.toggle('is-hidden', editorMode !== 'embed');
      seriesWrap.classList.toggle('is-hidden', editorMode !== 'vod');
      if (sourceGuideEl) sourceGuideEl.classList.toggle('is-hidden', editorMode !== 'vod');
    }

    function updateStatus() {
      if (editorMode === 'embed') {
        const n = embedItems.filter(embedHasContent).length;
        statusEl.textContent = (documentId > 0 ? '文档 #' + documentId + ' · ' : '新建文档 · ') + '视频 ' + n + ' 个';
      } else {
        const n = episodes.filter(epHasContent).length;
        statusEl.textContent = (documentId > 0 ? '文档 #' + documentId + ' · ' : '新建文档 · ') + '单集 ' + n + ' 个';
      }
      statusEl.className = 'hint';
    }

    function render() {
      renderModeBar();
      renderSeriesCard();
      rootEl.innerHTML = '';
      updateStatus();

      if (editorMode === 'embed') {
        if (!embedItems.length) {
          const empty = document.createElement('div');
          empty.className = 'empty-tip';
          empty.textContent = '暂无外链视频，点击「+ 添加视频」开始添加';
          rootEl.appendChild(empty);
        } else {
          embedItems.forEach(function (it, i) { rootEl.appendChild(renderEmbedCard(it, i)); });
        }
      } else {
        if (!episodes.length) {
          const empty = document.createElement('div');
          empty.className = 'empty-tip';
          empty.innerHTML = '暂无单集。可点「+ 添加单集」，或直接 <strong>Ctrl+V 粘贴视频链接</strong> 快速添加';
          rootEl.appendChild(empty);
        } else {
          episodes.forEach(function (ep, i) { rootEl.appendChild(renderEpisodeCard(ep, i)); });
        }
      }
      notifyParentHeight();
    }

    function exportEpisode(ep, sort) {
      const mode = String(ep.access_mode || '');
      let price = Number(ep.price || 0);
      let points = Number(ep.points_cost || 0);
      if (mode === 'points') {
        points = Math.max(1, points || Math.round(price) || 1);
        price = points;
      }
      const sources = (ep.sources || [])
        .filter(function (s) { return String(s.play_url || '').trim() !== '' || String(s.label || '').trim() !== ''; })
        .map(function (s, i) {
          return {
            id: s.id > 0 ? s.id : 0,
            label: String(s.label || ''),
            provider: String(s.provider || 'embed'),
            play_url: String(s.play_url || ''),
            priority: (ep.sources.length - i),
          };
        });
      const first = sources[0] || null;
      return {
        id: ep.id > 0 ? ep.id : 0,
        ep_no: Number(ep.ep_no || (sort + 1)),
        title: String(ep.title || ''),
        cover_path: String(ep.cover_path || ''),
        duration_sec: Number(ep.duration_sec || 0),
        trial_preview_sec: Number(ep.trial_preview_sec || 0),
        access_mode: mode,
        read_level_id: Number(ep.read_level_id || 0),
        price: price,
        points_cost: points,
        sort: sort,
        status: ep.status ? 1 : 0,
        play_url: first ? first.play_url : '',
        provider: first ? first.provider : 'embed',
        sources: sources,
      };
    }

    function exportFields() {
      const out = {};
      if (editorMode === 'embed') {
        const list = embedItems.filter(embedHasContent).map(function (it, i) {
          return {
            id: it.id > 0 ? it.id : 0,
            title: String(it.title || ''),
            video_url: String(it.video_url || ''),
            cover_path: String(it.cover_path || ''),
            provider: String(it.provider || ''),
            status: it.status ? 1 : 0,
            sort: i,
          };
        });
        out.videos_json = JSON.stringify(list);
        out.videos_vod_json = JSON.stringify([]);
        return out;
      }

      const vodRows = [];
      if (series && (series.free_ep_count || series.trial_preview_sec || series.access_mode !== 'free' || series.price || series.read_level_id)) {
        vodRows.push({
          __series__: 1,
          access_mode: String(series.access_mode || 'free'),
          read_level_id: Number(series.read_level_id || 0),
          price: Number(series.price || 0),
          trial_preview_sec: Number(series.trial_preview_sec || 0),
          free_ep_count: Number(series.free_ep_count || 0),
        });
      }
      episodes.filter(epHasContent).forEach(function (ep, i) {
        vodRows.push(exportEpisode(ep, i));
      });
      out.videos_vod_json = JSON.stringify(vodRows);
      out.videos_json = JSON.stringify([]);
      return out;
    }

    function restOk(data) {
      return data && typeof data === 'object' && !data.error && Object.prototype.hasOwnProperty.call(data, 'data');
    }

    async function api(path) {
      const restPath = String(path || '')
        .replace(/^document-form-meta/, 'meta/documents/form')
        .replace(/^upload\\/file/, 'upload/file');
      const res = await fetch('/api/v1/admin/' + restPath, {
        credentials: 'same-origin',
        headers: { 'X-Requested-With': 'XMLHttpRequest', Accept: 'application/json' },
      });
      const text = await res.text();
      try { return JSON.parse(text); } catch (e) {
        const looksHtml = /^\\s*</.test(text) || /<!doctype/i.test(text);
        return { error: { message: looksHtml
          ? ('接口非 JSON（HTTP ' + res.status + '）。请确认已登录且 REST 路径可用。')
          : String(text || '加载失败').slice(0, 240) } };
      }
    }

    function extractPayload(meta) {
      const surfaces = meta && meta.editorSurfaces ? meta.editorSurfaces : {};
      const rows = [].concat(surfaces.tabs || [], surfaces.inlines || []);
      let payload = {};
      rows.forEach(function (row) {
        if (String(row.identifier || '') !== PLUGIN_ID) return;
        payload = row.payload || {};
      });
      return payload;
    }

    function applyPayload(body) {
      if (!body || typeof body !== 'object') return;
      if (Array.isArray(body.member_levels)) memberLevels = body.member_levels;
      else if (Array.isArray(body.memberLevels)) memberLevels = body.memberLevels;
      if (body.vod_ready != null) vodReady = !!body.vod_ready;
      const docFrom = Number(body.document_id || body.documentId || 0);
      if (docFrom > 0) documentId = docFrom;
      if (body.vod_series && typeof body.vod_series === 'object' && Object.keys(body.vod_series).length) {
        series = normalizeSeries(body.vod_series);
      }
      if (Array.isArray(body.vod_episodes)) {
        episodes = body.vod_episodes.map(normalizeEpisode);
        editorMode = episodes.length ? 'vod' : editorMode;
      }
      if (Array.isArray(body.items)) {
        embedItems = body.items.map(normalizeEmbed);
        if (embedItems.length && !episodes.length) editorMode = 'embed';
      }
      dataReady = true;
      dataDirty = false;
      render();
    }

    function applyInitPayload(payload) {
      const body = payload && typeof payload === 'object' ? payload : {};
      applyThemeTokens(body.theme);
      if (dataDirty) {
        if (Array.isArray(body.member_levels || body.memberLevels)) {
          memberLevels = body.member_levels || body.memberLevels;
        }
        render();
        return;
      }
      applyPayload(body);
    }

    function themePreset(mode) {
      if (mode === 'dark') {
        return { contentTheme: 'dark', card: 'rgb(24,24,27)', fill: 'rgb(39,39,42)', border: 'rgb(63,63,70)', text: 'rgb(228,228,231)', textSecondary: 'rgb(161,161,170)', inputBg: 'rgb(24,24,27)' };
      }
      return { contentTheme: 'light', card: 'rgb(255,255,255)', fill: 'rgb(245,247,250)', border: 'rgb(228,231,237)', text: 'rgb(48,49,51)', textSecondary: 'rgb(144,147,153)', inputBg: 'rgb(255,255,255)' };
    }

    function applyThemeTokens(theme) {
      if (!theme || typeof theme !== 'object') return;
      const root = document.documentElement;
      const st = root.style;
      const mode = theme.contentTheme === 'dark' ? 'dark' : 'light';
      const preset = themePreset(mode);
      root.setAttribute('data-iframe-theme', mode);
      const set = function (k, v) { if (v) st.setProperty(k, String(v)); };
      set('--pv-card-bg', theme.card || preset.card);
      set('--pv-fill', theme.fill || preset.fill);
      set('--pv-border', theme.border || preset.border);
      set('--pv-text', theme.text || preset.text);
      set('--pv-text-secondary', theme.textSecondary || preset.textSecondary);
      set('--pv-input-bg', theme.inputBg || preset.inputBg);
      set('--pv-primary', theme.primary);
      set('--pv-primary-soft', theme.primarySoft);
      set('--pv-primary-border', theme.primaryBorder);
      set('--pv-danger', theme.danger);
      set('--pv-danger-soft', theme.dangerSoft);
      set('--pv-danger-border', theme.dangerBorder);
      set('--pv-font-family', theme.fontFamily);
      set('--pv-font-size', theme.fontSize);
      set('--pv-radius-base', theme.radiusBase);
      set('--pv-btn-padding', theme.btnPadding);
      set('--pv-input-padding', theme.inputPadding);
    }

    function notifyParentHeight() {
      if (editorSlot !== 'tab') return;
      const h = Math.max(document.documentElement.scrollHeight, document.body.scrollHeight, 120);
      try { parent.postMessage({ type: RESIZE, identifier: PLUGIN_ID, height: h }, '*'); } catch (e) {}
    }

    async function load() {
      const seq = ++loadSeq;
      if (documentId < 1) {
        dataReady = true;
        render();
        return;
      }
      statusEl.textContent = '正在同步…';
      statusEl.className = 'hint';
      try {
        const data = await api('meta/documents/form?id=' + encodeURIComponent(String(documentId)));
        if (seq !== loadSeq || dataDirty) return;
        if (!restOk(data)) {
          statusEl.textContent = (data.error && data.error.message) || '加载失败';
          statusEl.className = 'hint err';
          return;
        }
        applyPayload(extractPayload(data.data || {}));
      } catch (e) {
        if (seq !== loadSeq || dataDirty) return;
        statusEl.textContent = '加载失败';
        statusEl.className = 'hint err';
        render();
      }
    }

    document.querySelectorAll('#mode-bar button[data-mode]').forEach(function (btn) {
      btn.addEventListener('click', function () { setEditorMode(btn.getAttribute('data-mode')); });
    });

    addEpBtn.addEventListener('click', function () {
      dataDirty = true;
      const no = episodes.length ? Math.max.apply(null, episodes.map(function (e) { return e.ep_no; })) + 1 : 1;
      const ep = defaultEpisode(no);
      const key = 'n' + episodes.length;
      epOpen[key] = true;
      episodes.push(ep);
      render();
      setTimeout(function () {
        const el = document.querySelector('[data-focus-url="' + key + '"]');
        if (el) el.focus();
      }, 30);
    });

    function looksLikeVideoUrl(text) {
      const t = String(text || '').trim();
      // 注意：本文件是模板字符串生成 HTML，勿写 /https?:\/\// 这类字面量（\/ 会被吃掉变成 // 注释）
      if (!new RegExp('^https?://', 'i').test(t)) return false;
      return new RegExp('bilibili|youtube|youtu\\.be|\\.mp4|vimeo|qq\\.com|iqiyi|youku|m3u8', 'i').test(t) || t.length > 12;
    }

    function addEpisodeFromUrl(url) {
      dataDirty = true;
      const no = episodes.length ? Math.max.apply(null, episodes.map(function (e) { return e.ep_no; })) + 1 : 1;
      const ep = defaultEpisode(no);
      const cleaned = String(url || '').trim();
      ep.sources[0].play_url = cleaned;
      applyGuessToSource(ep.sources[0], cleaned);
      const key = 'n' + episodes.length;
      epOpen[key] = true;
      episodes.push(ep);
      if (editorMode !== 'vod') setEditorMode('vod');
      else render();
      setTimeout(function () {
        const el = document.querySelector('[data-focus-url="' + key + '"]');
        if (el) { el.focus(); el.select(); }
      }, 30);
    }

    document.addEventListener('paste', function (ev) {
      if (editorMode !== 'vod') return;
      const tag = (ev.target && ev.target.tagName) ? ev.target.tagName.toLowerCase() : '';
      if (tag === 'input' || tag === 'textarea' || tag === 'select') return;
      const text = (ev.clipboardData && ev.clipboardData.getData('text')) || '';
      if (!looksLikeVideoUrl(text)) return;
      ev.preventDefault();
      addEpisodeFromUrl(text);
    });

    addEmbedBtn.addEventListener('click', function () {
      dataDirty = true;
      embedItems.push(defaultEmbedItem());
      render();
    });

    window.addEventListener('message', function (ev) {
      const data = ev.data || {};
      if (data.type === INIT && String(data.identifier || '').toLowerCase() === PLUGIN_ID) {
        applyInitPayload(data.payload || {});
        return;
      }
      if (data.type === THEME && String(data.identifier || '').toLowerCase() === PLUGIN_ID) {
        applyThemeTokens(data.theme || {});
        return;
      }
      if (data.type === PREPARE && String(data.identifier || '').toLowerCase() === PLUGIN_ID) {
        parent.postMessage({ type: EXPORT, identifier: PLUGIN_ID, fields: exportFields() }, '*');
        return;
      }
      if (data.type === PREFILL && String(data.identifier || '').toLowerCase() === PLUGIN_ID) {
        applyPayload(data.payload || {});
      }
    });

    if (editorSlot === 'tab' && typeof ResizeObserver !== 'undefined') {
      new ResizeObserver(function () { notifyParentHeight(); }).observe(document.body);
    }
    window.addEventListener('load', notifyParentHeight);

    if (editorSlot === 'tab') {
      statusEl.textContent = '正在就绪…';
      render();
      window.setTimeout(function () { if (!dataReady && !dataDirty) load(); }, 160);
    } else {
      load();
    }
  </script>
</body>
</html>`;
}
