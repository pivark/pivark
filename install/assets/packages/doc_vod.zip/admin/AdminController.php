<?php
declare(strict_types=1);

namespace weapp\doc_vod\admin;

use app\common\contract\PluginAdminBaseTrait;
use app\common\contract\PluginAdminUsageTrait;
use think\facade\Request;
use think\Response;
use weapp\doc_vod\service\VideoCatalogService;
use weapp\doc_vod\service\VideoConfigService;
use weapp\doc_vod\service\VideoLinkParserService;
use weapp\doc_vod\service\VideoService;
use weapp\doc_vod\service\VideoParserCatalog;
use weapp\doc_vod\service\VideoParserHealthService;
use weapp\doc_vod\service\VideoSourceHealthService;
use weapp\doc_vod\service\VideoStatsService;
use app\common\service\weapp\WeappPluginGateway;
use app\common\service\weapp\WeappAdminGateway;
use app\common\service\weapp\WeappSupportGateway;

/** 文档视频 后台 */
class AdminController
{
    use PluginAdminBaseTrait;
    use PluginAdminUsageTrait;

    public function __construct()
    {
        $this->pluginIdentifier = 'doc_vod';
    }

    public function index(): Response
    {
        if (!$this->entitled()) {
            return $this->renderDisabled();
        }
        VideoService::ensureAutoload();
        $manifest = app(WeappPluginGateway::class)->pluginReadManifest('doc_vod') ?? [];

        return $this->renderPluginView('index', array_merge(
            $this->pluginContext($manifest),
            [
                'cfg'   => VideoConfigService::all(),
                'stats' => VideoStatsService::overviewAdmin(),
            ]
        ));
    }

    public function list(): Response
    {
        if (!$this->entitled()) {
            return $this->renderDisabled();
        }
        VideoService::ensureAutoload();
        $manifest = app(WeappPluginGateway::class)->pluginReadManifest('doc_vod') ?? [];
        if (Request::isAjax()) {
            $page = max(1, (int) Request::get('page', 1));
            $filters = [
                'status'      => Request::get('status', ''),
                'document_id' => (int) Request::get('document_id', 0),
                'keyword'     => (string) Request::get('keyword', ''),
            ];

            return app(WeappSupportGateway::class)->apiFromServiceResult(VideoService::listAdmin($filters, $page));
        }

        return $this->renderPluginView('list', array_merge(
            $this->pluginContext($manifest, 'items'),
            ['stats' => VideoService::statsAdmin()]
        ));
    }

    public function configSave(): Response
    {
        if (!Request::isPost()) {
            return app(WeappSupportGateway::class)->apiMethodNotAllowed();
        }
        if (!$this->entitled()) {
            return app(WeappSupportGateway::class)->apiFromServiceResult(app(WeappSupportGateway::class)->resultForbidden('插件未授权'));
        }

        return app(WeappSupportGateway::class)->apiFromServiceResult(VideoConfigService::saveAdmin(Request::post()));
    }

    public function save(): Response
    {
        if (!Request::isPost()) {
            return app(WeappSupportGateway::class)->apiMethodNotAllowed();
        }
        VideoService::ensureAutoload();

        return app(WeappSupportGateway::class)->apiFromServiceResult(VideoService::saveAdmin(Request::post()));
    }

    public function delete(): Response
    {
        if (!Request::isPost()) {
            return app(WeappSupportGateway::class)->apiMethodNotAllowed();
        }
        VideoService::ensureAutoload();

        return app(WeappSupportGateway::class)->apiFromServiceResult(VideoService::deleteAdmin((int) Request::post('id', 0)));
    }

    public function status(): Response
    {
        if (!Request::isPost()) {
            return app(WeappSupportGateway::class)->apiMethodNotAllowed();
        }
        VideoService::ensureAutoload();

        return app(WeappSupportGateway::class)->apiFromServiceResult(VideoService::statusAdmin((int) Request::post('id', 0), (int) Request::post('status', 1)));
    }

    public function seriesList(): Response
    {
        if (!$this->entitled()) {
            return app(WeappSupportGateway::class)->apiFromServiceResult(app(WeappSupportGateway::class)->resultForbidden('插件未授权'));
        }
        VideoService::ensureAutoload();
        $page = max(1, (int) Request::get('page', 1));

        return app(WeappSupportGateway::class)->apiFromServiceResult(VideoCatalogService::listSeriesAdmin([
            'keyword' => (string) Request::get('keyword', ''),
            'status'  => Request::get('status', ''),
        ], $page));
    }

    public function seriesSave(): Response
    {
        if (!Request::isPost() || !$this->entitled()) {
            return app(WeappSupportGateway::class)->apiFromServiceResult(app(WeappSupportGateway::class)->resultFail('请求无效'));
        }
        VideoService::ensureAutoload();

        return app(WeappSupportGateway::class)->apiFromServiceResult(VideoCatalogService::saveSeriesAdmin(Request::post()));
    }

    public function episodeList(): Response
    {
        if (!$this->entitled()) {
            return app(WeappSupportGateway::class)->apiFromServiceResult(app(WeappSupportGateway::class)->resultForbidden('插件未授权'));
        }
        VideoService::ensureAutoload();

        return app(WeappSupportGateway::class)->apiFromServiceResult(VideoCatalogService::listEpisodesAdmin(
            (int) Request::get('series_id', 0),
            max(1, (int) Request::get('page', 1))
        ));
    }

    public function episodeSave(): Response
    {
        if (!Request::isPost() || !$this->entitled()) {
            return app(WeappSupportGateway::class)->apiFromServiceResult(app(WeappSupportGateway::class)->resultFail('请求无效'));
        }
        VideoService::ensureAutoload();

        return app(WeappSupportGateway::class)->apiFromServiceResult(VideoCatalogService::saveEpisodeAdmin(Request::post()));
    }

    public function episodeBatchPatch(): Response
    {
        if (!Request::isPost() || !$this->entitled()) {
            return app(WeappSupportGateway::class)->apiFromServiceResult(app(WeappSupportGateway::class)->resultFail('请求无效'));
        }
        VideoService::ensureAutoload();

        return app(WeappSupportGateway::class)->apiFromServiceResult(VideoCatalogService::batchPatchEpisodesAdmin(Request::post()));
    }

    public function seriesDuplicate(): Response
    {
        if (!Request::isPost() || !$this->entitled()) {
            return app(WeappSupportGateway::class)->apiFromServiceResult(app(WeappSupportGateway::class)->resultFail('请求无效'));
        }
        VideoService::ensureAutoload();

        return app(WeappSupportGateway::class)->apiFromServiceResult(VideoCatalogService::duplicateSeriesAdmin(Request::post()));
    }

    public function episodeImportCsv(): Response
    {
        if (!Request::isPost() || !$this->entitled()) {
            return app(WeappSupportGateway::class)->apiFromServiceResult(app(WeappSupportGateway::class)->resultFail('请求无效'));
        }
        VideoService::ensureAutoload();

        return app(WeappSupportGateway::class)->apiFromServiceResult(VideoCatalogService::importEpisodesCsvAdmin(Request::post()));
    }

    public function probeSources(): Response
    {
        if (!$this->entitled()) {
            return app(WeappSupportGateway::class)->apiFromServiceResult(app(WeappSupportGateway::class)->resultForbidden('插件未授权'));
        }
        VideoService::ensureAutoload();
        $network = (int) Request::param('network', 1) === 1;

        return app(WeappSupportGateway::class)->apiFromServiceResult(VideoSourceHealthService::probeSeriesAdmin(
            (int) Request::param('series_id', 0),
            $network
        ));
    }

    /** 粘贴/剪贴板：解析视频站链接（插件内规则，可频繁迭代） */
    public function parseLink(): Response
    {
        if (!$this->entitled()) {
            return app(WeappSupportGateway::class)->apiFromServiceResult(app(WeappSupportGateway::class)->resultForbidden('插件未授权'));
        }
        VideoService::ensureAutoload();

        return app(WeappSupportGateway::class)->apiFromServiceResult(VideoLinkParserService::parse(
            (string) Request::param('url', ''),
            (string) Request::param('raw', '')
        ));
    }

    public function statsOverview(): Response
    {
        if (!$this->entitled()) {
            return app(WeappSupportGateway::class)->apiFromServiceResult(app(WeappSupportGateway::class)->resultForbidden('插件未授权'));
        }
        VideoService::ensureAutoload();
        $days = max(7, min(90, (int) Request::get('days', 30)));

        return app(WeappSupportGateway::class)->apiFromServiceResult(VideoStatsService::dashboardAdmin($days));
    }

    public function statsHeatmap(): Response
    {
        if (!$this->entitled()) {
            return app(WeappSupportGateway::class)->apiFromServiceResult(app(WeappSupportGateway::class)->resultForbidden('插件未授权'));
        }
        VideoService::ensureAutoload();

        return app(WeappSupportGateway::class)->apiFromServiceResult(VideoStatsService::heatmapOverviewAdmin(
            max(7, min(90, (int) Request::get('days', 30)))
        ));
    }

    public function statsHeatmapDrill(): Response
    {
        if (!$this->entitled()) {
            return app(WeappSupportGateway::class)->apiFromServiceResult(app(WeappSupportGateway::class)->resultForbidden('插件未授权'));
        }
        VideoService::ensureAutoload();

        return app(WeappSupportGateway::class)->apiFromServiceResult(VideoStatsService::heatmapSeriesDrillAdmin(
            (int) Request::get('series_id', 0),
            max(7, min(90, (int) Request::get('days', 30)))
        ));
    }

    public function statsExport(): Response
    {
        if (!$this->entitled()) {
            return app(WeappSupportGateway::class)->apiFromServiceResult(app(WeappSupportGateway::class)->resultForbidden('插件未授权'));
        }
        VideoService::ensureAutoload();
        $res = VideoStatsService::exportSeriesCsv();
        if (!$res->isOk()) {
            return app(WeappSupportGateway::class)->apiFromServiceResult($res);
        }
        $pack = [
            'filename' => 'video-series-stats.csv',
            'content'  => (string) ($res['csv'] ?? ''),
        ];

        return app(WeappAdminGateway::class)->adminDataExportRespondPack(
            $pack,
            'text/csv; charset=UTF-8',
            'plugin.doc_vod.use',
            ['export_scope' => 'all'],
            '导出 CSV',
            'video.stats',
        );
    }

    public function parserCatalog(): Response
    {
        if (!$this->entitled()) {
            return app(WeappSupportGateway::class)->apiFromServiceResult(app(WeappSupportGateway::class)->resultForbidden('插件未授权'));
        }

        return app(WeappSupportGateway::class)->apiFromServiceResult(app(WeappSupportGateway::class)->resultOk(['items' => VideoParserCatalog::maintainedPlatforms()]));
    }

    public function parseHealth(): Response
    {
        if (!$this->entitled()) {
            return app(WeappSupportGateway::class)->apiFromServiceResult(app(WeappSupportGateway::class)->resultForbidden('插件未授权'));
        }
        VideoService::ensureAutoload();
        $network = (int) Request::param('network', 1) === 1;

        return app(WeappSupportGateway::class)->apiFromServiceResult(VideoParserHealthService::checkAll($network));
    }

    /** 多行 URL 批量解析 */
    public function parseLinks(): Response
    {
        if (!$this->entitled()) {
            return app(WeappSupportGateway::class)->apiFromServiceResult(app(WeappSupportGateway::class)->resultForbidden('插件未授权'));
        }
        VideoService::ensureAutoload();

        return app(WeappSupportGateway::class)->apiFromServiceResult(VideoLinkParserService::parseBatch(
            (string) Request::param('raw', Request::param('urls', ''))
        ));
    }
}