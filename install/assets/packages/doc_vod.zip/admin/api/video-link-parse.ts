import { pivarkRestData, type PivarkRestEnvelope } from '#/api/pivark-rest';
import { resolveAdminRestUrl } from '#/api/admin-rest-url';
import {requestClient} from '#/api/request';

import type { VideoVodEpisode } from './video-vod';

export type VideoLinkParseResult = {
  episodes?: VideoVodEpisode[];
  mode?: string;
  msg?: string;
  platform?: string;
  play_url?: string;
  provider?: string;
  title?: string;
};

/** 调用 doc_vod 插件解析（规则在 weapp/doc_vod，非内核） */
export async function parseVideoLinkApi(url: string, raw = '') {
  const body = await requestClient.get<PivarkRestEnvelope>(resolveAdminRestUrl('/weapp/doc_vod/parseLink'), {
      params: { url, raw },
      responseReturn: 'body',
      withCredentials: true,
    },
  );
  return pivarkRestData<VideoLinkParseResult>(body, '链接解析失败');
}
