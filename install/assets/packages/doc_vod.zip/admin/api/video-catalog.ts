import {
  pivarkRestListPayload,
  type PivarkRestEnvelope,
} from '#/api/pivark-rest';
import { resolveAdminRestUrl } from '#/api/admin-rest-url';
import {requestClient} from '#/api/request';

import { pivarkMutation } from '#/api/pivark/core/mutation';

import type { VideoSeriesRow, VideoVodEpisode } from './video-vod';

export async function fetchVideoSeriesListApi(params: {
  keyword?: string;
  page?: number;
  pageSize?: number;
  status?: string;
}) {
  const body = await requestClient.get<PivarkRestEnvelope>(resolveAdminRestUrl('/weapp/doc_vod/seriesList'), {
      params: {
        keyword: params.keyword,
        page: params.page ?? 1,
        status: params.status,
      },
      responseReturn: 'body',
      withCredentials: true,
    },
  );
  const payload = pivarkRestListPayload(body);
  return {
    list: payload.list as VideoSeriesRow[],
    total: payload.total,
  };
}

export async function saveVideoSeriesApi(data: Record<string, unknown>) {
  return pivarkMutation<{ id?: number }>('/weapp/doc_vod/seriesSave', data);
}

export async function fetchVideoEpisodeListApi(seriesId: number, page = 1) {
  const body = await requestClient.get<PivarkRestEnvelope>(resolveAdminRestUrl('/weapp/doc_vod/episodeList'), {
      params: { page, series_id: seriesId },
      responseReturn: 'body',
      withCredentials: true,
    },
  );
  const payload = pivarkRestListPayload(body);
  return {
    list: payload.list as VideoVodEpisode[],
    total: payload.total,
  };
}

export async function saveVideoEpisodeApi(data: Record<string, unknown>) {
  return pivarkMutation<{ id?: number }>('/weapp/doc_vod/episodeSave', data);
}
