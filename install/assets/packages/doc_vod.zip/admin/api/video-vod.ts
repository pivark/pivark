export interface VideoVodEpisode {
  access_mode?: string;
  cover_path?: string;
  document_id?: number;
  duration_sec?: number;
  ep_no?: number;
  id?: number;
  play_url?: string;
  price?: number;
  provider?: string;
  read_level_id?: number;
  play_count?: number;
  series_id?: number;
  series_title?: string;
  sort?: number;
  status?: number;
  title: string;
  trial_preview_sec?: number;
}

export interface VideoSeriesRow {
  access_mode?: string;
  free_ep_count?: number;
  id?: number;
  price?: number;
  read_level_id?: number;
  slug?: string;
  sort?: number;
  status?: number;
  summary?: string;
  title: string;
  trial_preview_sec?: number;
}

const ACCESS_MODES = [
  { value: '', label: '继承剧集' },
  { value: 'free', label: '免费' },
  { value: 'login', label: '登录可看' },
  { value: 'level', label: '等级会员' },
  { value: 'paid', label: '单集付费' },
  { value: 'paid_series', label: '全集付费' },
  { value: 'points', label: '积分兑换' },
] as const;

export function videoVodAccessModeOptions() {
  return ACCESS_MODES;
}

export function normalizeVodEpisode(
  raw: Partial<VideoVodEpisode> | null,
  index = 0,
): VideoVodEpisode {
  return {
    access_mode: raw?.access_mode ?? '',
    cover_path: raw?.cover_path ?? '',
    document_id: Number(raw?.document_id ?? 0),
    duration_sec: Number(raw?.duration_sec ?? 0),
    ep_no: Number(raw?.ep_no ?? index + 1),
    id: Number(raw?.id ?? 0),
    play_url: String(raw?.play_url ?? '').trim(),
    price: Number(raw?.price ?? 0),
    provider: raw?.provider ?? 'embed',
    read_level_id: Number(raw?.read_level_id ?? 0),
    series_id: Number(raw?.series_id ?? 0),
    series_title: raw?.series_title ?? '',
    sort: Number(raw?.sort ?? index),
    status: Number(raw?.status ?? 1) ? 1 : 0,
    title: String(raw?.title ?? '').trim() || `第${index + 1}集`,
  };
}

export function exportVodEpisode(row: VideoVodEpisode): Record<string, unknown> {
  return {
    access_mode: row.access_mode ?? '',
    cover_path: row.cover_path ?? '',
    document_id: row.document_id ?? 0,
    duration_sec: row.duration_sec ?? 0,
    ep_no: row.ep_no ?? 0,
    id: row.id ?? 0,
    play_url: row.play_url ?? '',
    price: row.price ?? 0,
    provider: row.provider ?? 'embed',
    read_level_id: row.read_level_id ?? 0,
    series_id: row.series_id ?? 0,
    sort: row.sort ?? 0,
    status: row.status ? 1 : 0,
    title: row.title,
  };
}

export function normalizeVideoSeries(raw: Partial<VideoSeriesRow> | null): VideoSeriesRow {
  return {
    access_mode: raw?.access_mode ?? 'free',
    id: Number(raw?.id ?? 0),
    price: Number(raw?.price ?? 0),
    read_level_id: Number(raw?.read_level_id ?? 0),
    slug: raw?.slug ?? '',
    sort: Number(raw?.sort ?? 0),
    status: Number(raw?.status ?? 1) ? 1 : 0,
    summary: raw?.summary ?? '',
    title: String(raw?.title ?? '').trim() || '未命名剧集',
    trial_preview_sec: Number(raw?.trial_preview_sec ?? 0),
    free_ep_count: Number(raw?.free_ep_count ?? 0),
  };
}
