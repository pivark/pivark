/**
 * 剪贴板 → doc_vod 链接解析（插件内，不经内核 utils）
 */
import { parseVideoLinkApi } from '@weapp-doc-vod/api/video-link-parse';
import { stashPendingVideoParse, stashPendingVideoUrl } from '#/utils/clipboard-pending-flow';
import { guessTitleFromUrl } from '#/utils/clipboard-intent';

export async function stashVideoClipboardFromPlugin(
  url: string,
  raw = '',
): Promise<void> {
  const trimmed = url.trim();
  if (!trimmed) {
    return;
  }
  try {
    const parsed = await parseVideoLinkApi(trimmed, raw);
    stashPendingVideoParse(parsed as unknown as Record<string, unknown>);
  } catch {
    stashPendingVideoUrl(trimmed, guessTitleFromUrl(trimmed));
  }
}
