import type { ImportIntentStashContext } from '#/utils/import-intent-registry';
import type { ClipboardIntentKind } from '#/utils/clipboard-intent';
import { stashVideoClipboardFromPlugin } from '@weapp-doc-vod/clipboard/bridge';
import { stashPendingLocalImport } from '#/utils/clipboard-pending-flow';
import { registerImportIntentHandler } from '#/utils/import-intent-registry';
import { stashDocumentMetaOnly } from '#/utils/import-intent-core-stash';
import { VIDEO_PLUGIN_ID } from '@weapp-doc-vod/clipboard/plugin-id';

const KINDS: ClipboardIntentKind[] = [
  'video_file',
  'video_page',
  'local_video',
];

registerImportIntentHandler({
  pluginId: VIDEO_PLUGIN_ID,
  supportedKinds: KINDS,
  priority: 90,
  clipboardLocalFilesLabel: '去发布文档并上传视频',
  clipboardRemoteLabel: '去发布文档并添加视频',
  async applyDocumentFormClipboard(ctx, intent) {
    if (!ctx.hasSurface(VIDEO_PLUGIN_ID) || !intent.url.trim()) {
      return false;
    }
    await ctx.ensureSurfaceVisible(VIDEO_PLUGIN_ID);
    await ctx.prefillVideoUrl(intent.url.trim(), intent.titleHint ?? '');
    return true;
  },
  buildDocumentCreateQuery(ctx) {
    return { pv_video_url: ctx.url };
  },
  async stash(ctx: ImportIntentStashContext) {
    if (ctx.intent.files?.length) {
      await stashDocumentMetaOnly(ctx);
      stashPendingLocalImport(
        ctx.intent.files,
        ctx.intent.kind,
        ctx.intent.titleHint ?? '',
        VIDEO_PLUGIN_ID,
      );
      return;
    }
    await stashDocumentMetaOnly(ctx);
    await stashVideoClipboardFromPlugin(ctx.intent.url, ctx.intent.raw);
  },
});

export {};
