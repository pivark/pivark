import type { ClipboardIntent } from '#/utils/clipboard-intent';
import { registerImportIntentDetectRule } from '#/utils/import-intent-detect-registry';
import { extractUrlCandidatesFromText } from '#/utils/clipboard-link-sanitize';
import { pluginIdsSupportingKinds } from '#/utils/import-intent-resolve';
import { VIDEO_PLUGIN_ID } from '@weapp-doc-vod/clipboard/plugin-id';

const PLUGIN = VIDEO_PLUGIN_ID;

const VIDEO_FILE_RE = /\.(mp4|webm|m3u8|mov|mkv|avi|flv|ts)(\?|#|$)/i;
const VIDEO_EXT_RE = /\.(mp4|webm|m3u8|mov|mkv|avi|flv|ts)(\?|#|$)/i;
const VIDEO_PAGE_RE =
  /(?:bilibili\.com|youtu\.be|youtube\.com|vimeo\.com|iqiyi\.com|youku\.com|v\.qq\.com|mgtv\.com|acfun\.cn)/i;

function extractFirstUrl(text: string): string | null {
  const candidates = extractUrlCandidatesFromText(text);
  return candidates[0] ?? null;
}

function fileExt(name: string): string {
  const base = name.split(/[/\\]/).pop() ?? name;
  const dot = base.lastIndexOf('.');
  return dot >= 0 ? base.slice(dot).toLowerCase() : '';
}

function summarizeFileNames(files: File[]): string {
  if (files.length === 1) {
    return files[0]!.name;
  }
  return `${files[0]!.name} 等${files.length} 个文件`;
}

function titleFromFileName(name: string): string {
  const base = name.split(/[/\\]/).pop() ?? name;
  const dot = base.lastIndexOf('.');
  return (dot > 0 ? base.slice(0, dot) : base).trim() || '未命名文档';
}

function fallbackPluginIds(...kinds: Parameters<typeof pluginIdsSupportingKinds>[0]) {
  return pluginIdsSupportingKinds(kinds);
}

function detectVideoText(text: string): ClipboardIntent | null {
  const url = extractFirstUrl(text);
  if (!url) {
    return null;
  }

  if (VIDEO_FILE_RE.test(url)) {
    return {
      kind: 'video_file',
      plugins: fallbackPluginIds('video_file', 'generic_url', 'pan_share'),
      url,
      extractCode: '',
      raw: text,
    };
  }

  if (VIDEO_PAGE_RE.test(url)) {
    return {
      kind: 'video_page',
      plugins: [PLUGIN],
      url,
      extractCode: '',
      raw: text,
    };
  }

  return null;
}

function detectVideoFiles(files: File[]): ClipboardIntent | null {
  const exts = files.map((f) => fileExt(f.name));
  const allVideo = exts.every((e) => VIDEO_EXT_RE.test(e));
  const primary = files[0]!;
  if (!allVideo && !(files.length === 1 && VIDEO_EXT_RE.test(primary.name))) {
    return null;
  }
  const summary = summarizeFileNames(files);
  return {
    kind: 'local_video',
    plugins: fallbackPluginIds('local_video', 'local_archive', 'local_other'),
    url: summary,
    extractCode: '',
    raw: summary,
    files,
    titleHint: titleFromFileName(primary.name),
  };
}

registerImportIntentDetectRule({
  pluginId: PLUGIN,
  priority: 95,
  detectText: detectVideoText,
  detectFiles: detectVideoFiles,
});

export {};
