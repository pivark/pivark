/** doc_vod 剪贴板/import 意图标识（handler 自注册 SSOT · 仅 weapp/doc_vod 内引用） */
export const VIDEO_PLUGIN_ID = 'doc_vod' as const;
