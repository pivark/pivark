<?php
declare(strict_types=1);

namespace weapp\doc_vod\front\controller;

use app\home\controller\Base;
use think\facade\Request;
use think\Response;
use weapp\doc_vod\service\VideoChannelService;
use weapp\doc_vod\service\VideoService;

class Series extends Base
{
    public function show(): Response
    {
        VideoService::ensureAutoload();
        $slug = trim((string) Request::param('slug', ''));
        $res  = VideoChannelService::pageVars($slug);
        if (!$res->isOk()) {
            return $this->error($res->message() !== '' ? $res->message() : '页面不可用');
        }
        $vars = is_array($res->dataArray()['vars'] ?? null) ? $res->dataArray()['vars'] : [];

        return $this->render('view_video_channel', $vars);
    }
}
