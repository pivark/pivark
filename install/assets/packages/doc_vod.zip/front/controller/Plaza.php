<?php
declare(strict_types=1);

namespace weapp\doc_vod\front\controller;

use app\home\controller\Base;
use think\facade\Request;
use think\Response;
use weapp\doc_vod\service\VideoPlazaService;
use weapp\doc_vod\service\VideoService;

class Plaza extends Base
{
    public function index(): Response
    {
        VideoService::ensureAutoload();
        $page    = max(1, (int) Request::get('page', 1));
        $sort    = trim((string) Request::get('sort', 'hot'));
        $keyword = trim((string) Request::get('q', Request::get('keyword', '')));
        $res     = VideoPlazaService::pageVars($page, $sort, $keyword);
        if (!$res->isOk()) {
            return $this->error($res->message() !== '' ? $res->message() : '页面不可用');
        }
        $vars = is_array($res->dataArray()['vars'] ?? null) ? $res->dataArray()['vars'] : [];

        return $this->render('view_video_plaza', $vars);
    }
}
