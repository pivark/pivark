<?php
/**
 * 元舟 PivArk — download 官方标装插件（文档下载）
 */
declare(strict_types=1);

namespace weapp\doc_bundle;

use weapp\doc_bundle\model\WeappDownloadBundle;
use weapp\doc_bundle\model\WeappDownloadItem;
use weapp\doc_bundle\model\WeappDownloadLog;
use weapp\doc_bundle\model\WeappDownloadPurchase;
use weapp\doc_bundle\model\WeappDownloadToken;
use weapp\doc_bundle\service\DownloadAdminSpaLists;
use weapp\doc_bundle\service\DownloadAdminSpaMeta;
use weapp\doc_bundle\service\DownloadAdminSpaRoutes;
use weapp\doc_bundle\service\DownloadCronTasks;
use weapp\doc_bundle\service\DownloadDocumentAddonBridge;
use weapp\doc_bundle\service\DownloadFrontAssets;
use weapp\doc_bundle\service\DownloadImportIntentDelegate;
use weapp\doc_bundle\service\DownloadMemberCenterPages;
use weapp\doc_bundle\service\DownloadPaymentFulfillment;
use weapp\doc_bundle\service\DownloadPluginBootstrap;
use weapp\doc_bundle\service\DownloadPublicApi;
use app\common\service\weapp\WeappAdminGateway;
use app\common\service\weapp\WeappEntitlementGateway;
use app\common\service\weapp\WeappFrontGateway;
use app\common\service\weapp\WeappMemberGateway;
use app\common\service\weapp\WeappMiniprogramGateway;
use app\common\service\weapp\WeappPluginGateway;
use app\common\service\weapp\WeappSupportGateway;

class Plugin
{
    public function install(): void
    {
        app(WeappEntitlementGateway::class)->entitlementGrantFreeInstall('doc_bundle');
    }

    public function enable(): void
    {
    }

    public function disable(): void
    {
    }

    public function uninstall(): void
    {
        app(WeappEntitlementGateway::class)->entitlementRevoke('doc_bundle');
        $support = app(WeappSupportGateway::class);
        foreach ([
            WeappDownloadLog::class,
            WeappDownloadToken::class,
            WeappDownloadPurchase::class,
            WeappDownloadItem::class,
            WeappDownloadBundle::class,
        ] as $model) {
            try {
                $model::where('id', '>', 0)->delete();
            } catch (\Throwable $e) {
                $support->kernelOpsLog('download_plugin_purge_model_failed', ['model' => $model, 'msg' => $e->getMessage()]);
            }
        }
    }

    public function boot(): void
    {
        $admin = app(WeappAdminGateway::class);
        $plugin = app(WeappPluginGateway::class);
        $front = app(WeappFrontGateway::class);
        $member = app(WeappMemberGateway::class);
        $admin->adminSpaMetaRegister('doc_bundle', 'doc_bundle', [DownloadAdminSpaMeta::class, 'build']);
        $admin->adminSpaPluginListRegister('doc_bundle', 'resources', [DownloadAdminSpaLists::class, 'resourcesList']);
        $admin->adminSpaPluginListRegister('doc_bundle', 'link-check', [DownloadAdminSpaLists::class, 'linkCheckList']);
        DownloadAdminSpaRoutes::register();

        app(WeappSupportGateway::class)->dataExportExtensionRegister([
            'profile'    => 'doc_bundle.stats',
            'label'      => '下载统计 CSV',
            'kind'       => 'export',
            'plugin_id'  => 'doc_bundle',
            'permission' => 'plugin.doc_bundle.use',
            'path'       => '/weapp/doc_bundle/exportCsv',
            'modes'      => ['all'],
            'max_rows'   => 50000,
            'audit_key'  => 'plugin.doc_bundle.use',
        ]);

        $plugin->pluginLogicalTableRegister('doc_bundle', [
            'bundles'   => 'weapp_doc_bundle_bundles',
            'items'     => 'weapp_doc_bundle_items',
            'purchases' => 'weapp_doc_bundle_purchases',
        ]);
        $admin->adminPermissionExtensionRegisterMap('doc_bundle', [
            'index'         => 'plugin.doc_bundle.use',
            'resources'     => 'plugin.doc_bundle.use',
            'usage'         => 'plugin.doc_bundle.use',
            'configsave'    => 'plugin.doc_bundle.use',
            'save'          => 'plugin.doc_bundle.use',
            'delete'        => 'plugin.doc_bundle.use',
            'status'        => 'plugin.doc_bundle.use',
            'batchdelete'   => 'plugin.doc_bundle.use',
            'batchstatus'   => 'plugin.doc_bundle.use',
            'sort'          => 'plugin.doc_bundle.use',
            'linkchecklist' => 'plugin.doc_bundle.use',
            'checklinks'    => 'plugin.doc_bundle.use',
        ]);
        DownloadCronTasks::register();
        $front->frontScriptUrlRegisterModule('doc_bundle', [
            'apiDownloadPointsPreview' => '/api/v1/plugins/doc_bundle/points-preview/',
            'apiDownloadPointsUnlock'  => '/api/v1/plugins/doc_bundle/points-unlock/',
            'apiDownloadPaidPreview'   => '/api/v1/plugins/doc_bundle/paid-preview/',
            'apiDownloadPaidCreate'    => '/api/v1/plugins/doc_bundle/paid-create/',
        ]);
        $front->frontAssetHandlerRegister('doc_bundle', 'bundles', [DownloadFrontAssets::class, 'registerBundles']);
        app(WeappMiniprogramGateway::class)->miniprogramFeatureRegister('doc_bundle', '资料下载', false);
        $member->memberConsumptionRegister('doc_bundle', 'DownloadMemberConsumptionHelper');
        $member->memberConsumptionRegisterMeta('doc_bundle', [
            'point_unlock_like'     => ['下载解锁%', 'download unlock%'],
            'point_unlock_prefixes' => ['下载解锁', 'download unlock'],
            'point_biz_type'        => 'doc_bundle_points',
            'paid_biz_type'         => 'doc_bundle_paid',
            'point_biz_label'       => '积分·下载',
            'paid_biz_label'        => '付费·下载',
        ]);

        $plugin->pluginExtensionRegister(
            'document_addon.bridge',
            'doc_bundle',
            new DownloadDocumentAddonBridge(),
            100,
            [
                'doc_bundle'            => true,
                'document_availability' => 'doc_bundle',
                'gallery_pack'          => true,
                'dashboard_overview'    => [
                    'key'            => 'downloads',
                    'logical_table'  => 'files',
                    'title'          => '下载',
                    'unit'           => '个',
                    'defaultVisible' => true,
                ],
            ],
        );
        DownloadPluginBootstrap::ensureAutoload();
        DownloadMemberCenterPages::register();
        DownloadPaymentFulfillment::register();
        $plugin->pluginApiRegistryRegister('DownloadPublic', new DownloadPublicApi());

        $plugin->pluginRouteRegister(
            'get',
            'api/v1/plugins/doc_bundle/files/:id',
            '\\weapp\\doc_bundle\\api\\controller\\File@download',
            ['id' => '\\d+']
        );
        $plugin->pluginRouteRegister(
            'get',
            'api/v1/plugins/doc_bundle/points-preview/:bundle_id',
            '\\weapp\\doc_bundle\\api\\controller\\File@pointsPreview',
            ['bundle_id' => '\\d+']
        );
        $plugin->pluginRouteRegister(
            'post',
            'api/v1/plugins/doc_bundle/points-unlock/:bundle_id',
            '\\weapp\\doc_bundle\\api\\controller\\File@pointsUnlock',
            ['bundle_id' => '\\d+']
        );
        $plugin->pluginRouteRegister(
            'get',
            'api/v1/plugins/doc_bundle/paid-preview/:bundle_id',
            '\\weapp\\doc_bundle\\api\\controller\\File@paidPreview',
            ['bundle_id' => '\\d+']
        );
        $plugin->pluginRouteRegister(
            'post',
            'api/v1/plugins/doc_bundle/paid-create/:bundle_id',
            '\\weapp\\doc_bundle\\api\\controller\\File@paidCreate',
            ['bundle_id' => '\\d+']
        );
        $plugin->pluginExtensionRegisterImportIntentDelegate(new DownloadImportIntentDelegate());

        $plugin->pluginRouteRegister(
            'get',
            'api/v1/plugins/doc_bundle/list/:document_id',
            '\\weapp\\doc_bundle\\api\\controller\\File@list',
            ['document_id' => '\\d+']
        );
    }
}
