# 下载附件（`download`）

> **用户文档 SSOT：** 本目录 `README.md`（`## 功能介绍` · `## 使用说明` · `## 升级日志` · `## 安装与开发`） · v1.0.0 · `pivark/doc_bundle`；后台与市场直读，改完即生效。

## 功能介绍

<h3>下载附件插件是做什么的？</h3>
<p>给网站上的<strong>每一篇文章</strong>挂上可下载的资源：本地安装包、PDF 课件、压缩包，或百度网盘 / 夸克 / 阿里云盘等分享链接（含提取码）。访客在文章页一键下载或跳转网盘，站长在后台统一管理范围、权限与展示样式。</p>
<p class="pv-tip">适合软件站、教程站、资源分享站、会员素材站。模板怎么写请看「前台调用说明」Tab。</p>

<h3>四类典型场景</h3>
<figure class="pv-guide-figure">
  <img src="guide-scenarios.svg" alt="软件下载、教程资料、网盘分享、会员专享四类场景" loading="lazy" />
  <figcaption>同一套插件，通过「使用范围 + 下载权限 + 模板样式」组合出不同运营玩法。</figcaption>
</figure>

<h3>核心能力一览</h3>
<ul>
  <li><strong>一篇多包</strong>：同一文章可挂多个资源包，例如「Windows 版 + Mac 版 + 网盘备用链接」，各自独立排序与权限。</li>
  <li><strong>本地 + 网盘混排</strong>：附件直接上传，或填远程链接；提取码会随前台一起展示，无需访客再去找口令。</li>
  <li><strong>灵活权限</strong>：每个资源包可设「游客可下 / 登录后可下 / 指定会员等级 / 扣积分」；与文章「阅读权限」分开配置，可实现「能看不能下」或「能下不能看全文」。</li>
  <li><strong>下载统计</strong>：记录累计下载次数，便于观察哪份资料最受欢迎。</li>
  <li><strong>智能粘贴</strong>：复制网盘分享文案后，在后台粘贴即可自动识别链接与提取码，大幅节省录入时间。</li>
  <li><strong>两种维护方式</strong>：发布页可用独立「下载资源」页签，或与正文同屏嵌入，按站点习惯二选一（全站统一，在「基础设置 → 发布页展现」切换）。</li>
</ul>

<h3>从配置到访客下载：整体怎么运转？</h3>
<figure class="pv-guide-figure">
  <img src="guide-scope.svg" alt="基础设置决定范围，单篇维护资源包，前台模板输出下载区" loading="lazy" />
  <figcaption>先定「哪些文章能配下载」，再在符合范围的文章里维护具体资源，最后由主题模板决定前台长什么样。</figcaption>
</figure>

<h3>一篇文章，多个资源包</h3>
<figure class="pv-guide-figure">
  <img src="guide-per-article.svg" alt="单篇文档可挂多个资源包，互不干扰" loading="lazy" />
  <figcaption>资源包之间互不影响：A 文挂了 3 个包，不会出现在 B 文；不在使用范围内的文章，后台不会出现下载配置入口。</figcaption>
</figure>

<h3>发布页两种维护方式</h3>
<figure class="pv-guide-figure">
  <img src="guide-editor-slot.svg" alt="独立 Tab 与嵌入正文两种后台维护方式" loading="lazy" />
  <figcaption><strong>独立 Tab</strong>：链接多、字段多时用，界面更清爽。<strong>嵌入正文区</strong>：写正文时同屏维护下载，适合短文 + 单附件。两种方式只影响后台编辑体验，前台样式仍由主题模板决定。</figcaption>
</figure>

<h3>复制网盘口令，自动回填</h3>
<figure class="pv-guide-figure">
  <img src="guide-clipboard.svg" alt="复制网盘分享文案后粘贴即可识别" loading="lazy" />
  <figcaption>在网盘 App 复制分享文案 → 回到文章发布页粘贴 → 系统自动拆分链接、提取码、标题 → 确认保存即可。本地 .zip 等文件也支持拖入上传。</figcaption>
</figure>

<h3>站长上手：四步即可上线</h3>
<ol>
  <li>在「<strong>基础设置</strong>」选择使用范围（全部文档 / 指定栏目）和发布页展现方式，保存。</li>
  <li>打开一篇符合范围的文章，在「<strong>下载资源</strong>」页签（或正文旁嵌入区）新建资源包，上传文件或粘贴网盘链接。</li>
  <li>为每个资源包设置显示名称、排序，以及是否需要登录、会员等级或积分。</li>
  <li>确认主题已在文章详情页放置下载区块（见「前台调用说明」）。发布文章后，前台即可看到下载入口。</li>
</ol>

<h3>访客在前台看到什么？</h3>
<ul>
  <li>文章详情页出现「相关下载」或你自定义标题的区块，列出该文所有可用资源。</li>
  <li>本地文件：点击后直接下载；网盘链接：点击后跳转或复制（由主题样式决定）。</li>
  <li>若资源要求登录：未登录时会引导去登录页，成功后回到当前文章再下载。</li>
  <li>若要求会员等级或积分不足：前台可展示提示文案（主题可自定义），引导升级或充值。</li>
  <li>该文未配置下载、或未启用插件、或不在使用范围内：<strong>整块下载区不会出现</strong>，页面其它内容不受影响。</li>
</ul>

<h3>阅读与下载：两个开关，别搞混</h3>
<table>
  <thead><tr><th>配置位置</th><th>控制什么</th><th>举例</th></tr></thead>
  <tbody>
    <tr><td>文章「基础内容」里的阅读权限</td><td>能不能看<strong>正文全文</strong></td><td>未登录只看摘要，登录后看全文</td></tr>
    <tr><td>下载资源包里的下载权限</td><td>能不能<strong>下载附件</strong></td><td>正文免费看，附件登录后可下</td></tr>
  </tbody>
</table>
<p>两者可自由组合，满足「引流阅读 + 付费下载」「会员专享素材」等常见运营需求。</p>

<h3>常见问题（站长视角）</h3>
<ul>
  <li><strong>为什么发布页看不到下载入口？</strong> 检查插件是否已启用；文章主栏目是否在「使用范围」内；是否在「基础设置」保存过范围策略。</li>
  <li><strong>为什么前台没有下载区？</strong> 该文是否已配置资源包；主题是否已插入下载标签（见前台调用说明）；资源是否处于启用状态。</li>
  <li><strong>能否只对部分栏目开放？</strong> 可以。将「使用范围」设为指定栏目即可，例如仅「资源下载」栏目下的文章可配。</li>
</ul>

## 使用说明

<h3>写给主题 / 前端：你要做的事</h3>
<p>在<strong>文章详情页模板</strong>里插入 <code>{pv:doc_bundle}</code> 标签，即可输出当前文章已配置的下载列表。下面只讲<strong>模板写法与展示效果</strong>，不涉及服务器配置。</p>

<h3>开始之前：确认这三项</h3>
<ul>
  <li>站点已安装并<strong>启用</strong>「下载附件」插件。</li>
  <li>该文章已在后台配置至少一个下载资源包，且处于启用状态。</li>
  <li>文章主栏目符合插件「基础设置 → 使用范围」（不符合则标签整段不输出）。</li>
</ul>

<h3>放在模板的什么位置？</h3>
<figure class="pv-guide-figure">
  <img src="usage-template-wireframe.svg" alt="文章详情模板中正文下方插入下载区块" loading="lazy" />
  <figcaption>推荐放在 <code>{$document_content}</code> 之后、相关推荐之前。侧边栏模板需自行做栅格布局。</figcaption>
</figure>

<h3>最简写法（装完即用 · 推荐）</h3>
<p>插件自带三列卡片布局与样式（<code>weapp/doc_bundle/assets/css/download.css</code>），页脚须有 <code>{pv:frontassets /}</code> 按需输出 CSS/JS。</p>
<pre class="pv-weapp-code">{pv:if name="document_has_doc_bundle"}
  {pv:doc_bundle layout="cards" id="{$document_id}" /}
{/pv:if}</pre>
<p>可选属性：<code>title</code>、<code>hint</code> 自定义区块标题与说明。主题覆写：在 <code>{pv:frontassets /}</code> 之后加载 <code>overrides/download.css</code>，选择器 <code>.pv-doc-download-*</code>。</p>

<h3>自定义列表（高级）</h3>
<p>若需完全自定义 HTML，仍可使用标签体 + <code>[[pv-dl-bundle]]</code> / <code>[[pv-dl-item]]</code>；样式仍由插件 CSS 兜底。</p>
<pre class="pv-weapp-code">{pv:doc_bundle id="{$document_id}"}
&lt;a href="{$field.url}" class="pv-download-link"&gt;{$field.label}&lt;/a&gt;
  &lt;span class="pv-download-meta"&gt;{$field.file_size_text}&lt;/span&gt;
{/pv:doc_bundle}</pre>

<h3>完整列表示例（可直接套用）</h3>
<pre class="pv-weapp-code">&lt;section class="pv-download-block"&gt;
  &lt;h3 class="pv-download-block__title"&gt;相关下载&lt;/h3&gt;
  {pv:doc_bundle id="{$document_id}"}
  &lt;div class="pv-download-item"&gt;
    &lt;a href="{$field.url}" class="pv-download-item__link"&gt;{$field.label}&lt;/a&gt;
    &lt;span class="pv-download-item__size"&gt;{$field.file_size_text}&lt;/span&gt;
    {if $field.extract_code}
    &lt;span class="pv-download-item__code"&gt;提取码：{$field.extract_code}&lt;/span&gt;
    {/if}
    &lt;span class="pv-download-item__count"&gt;{$field.download_count} 次下载&lt;/span&gt;
  &lt;/div&gt;
  {/pv:doc_bundle}
&lt;/section&gt;</pre>
<p>标签体为空时，系统会使用默认单行链接：<code>&lt;a href="{$field.url}"&gt;{$field.label}&lt;/a&gt;</code></p>

<h3>卡片式布局示例</h3>
<pre class="pv-weapp-code">{pv:doc_bundle id="{$document_id}"}
&lt;article class="pv-download-card"&gt;
  &lt;h4&gt;{$field.title}&lt;/h4&gt;
  &lt;p&gt;{$field.label}&lt;/p&gt;
  &lt;a class="btn btn-primary" href="{$field.url}"&gt;立即下载&lt;/a&gt;
  &lt;small&gt;{$field.file_size_text}&lt;/small&gt;
&lt;/article&gt;
{/pv:doc_bundle}</pre>

<h3>标签属性</h3>
<table>
  <thead><tr><th>属性</th><th>说明</th></tr></thead>
  <tbody>
    <tr><td><code>id</code></td><td>文章 ID，详情页最常用</td></tr>
    <tr><td><code>document_id</code> / <code>aid</code></td><td>与 <code>id</code> 相同，任选其一</td></tr>
    <tr><td>（不写属性）</td><td>自动取当前页面的 <code>document_id</code>（仅详情页有效）</td></tr>
  </tbody>
</table>

<h3>循环变量 <code>{$field.*}</code>（每个下载项）</h3>
<table>
  <thead><tr><th>变量</th><th>含义</th><th>前台怎么用</th></tr></thead>
  <tbody>
    <tr><td><code>{$field.label}</code></td><td>本条资源的显示名称</td><td>推荐作为链接文字</td></tr>
    <tr><td><code>{$field.title}</code></td><td>所属资源包标题</td><td>分组标题、卡片主标题</td></tr>
    <tr><td><code>{$field.url}</code></td><td>下载 / 跳转地址</td><td>写在 <code>&lt;a href&gt;</code> 上，点击即触发下载或跳转</td></tr>
    <tr><td><code>{$field.file_size_text}</code></td><td>人类可读大小</td><td>如 <code>1.2 MB</code></td></tr>
    <tr><td><code>{$field.file_size}</code></td><td>字节数</td><td>需自行换算时使用</td></tr>
    <tr><td><code>{$field.extract_code}</code></td><td>网盘提取码</td><td>有值时展示「提取码：xxxx」</td></tr>
    <tr><td><code>{$field.remote_url}</code></td><td>原始网盘链接</td><td>想做「复制链接」按钮时使用</td></tr>
    <tr><td><code>{$field.source_type}</code></td><td><code>local</code> 或 <code>remote</code></td><td>本地附件 / 远程链接，可用来切换图标</td></tr>
    <tr><td><code>{$field.access_mode}</code></td><td>权限类型文字</td><td>如免费、登录、会员等级等，可做角标</td></tr>
    <tr><td><code>{$field.download_count}</code></td><td>累计下载次数</td><td>展示热度</td></tr>
    <tr><td><code>{$field.id}</code></td><td>下载项 ID</td><td>一般无需展示，统计埋点可用</td></tr>
  </tbody>
</table>

<h3>访客看到的效果（示意）</h3>
<figure class="pv-guide-figure">
  <img src="usage-front-mockup.svg" alt="前台下载列表、提取码、登录提示示意" loading="lazy" />
  <figcaption>列表结构、按钮样式、图标均由主题 CSS 决定；上图为常见布局参考。</figcaption>
</figure>

<h3>登录 / 权限相关（模板侧要知道的）</h3>
<ul>
  <li>资源包设为「登录后下载」：未登录访客点击 <code>{$field.url}</code> 会跳转登录页，登录成功后回到当前文章再点即可。</li>
  <li>文章本身设了「阅读权限」：与下载权限独立。正文可能只看摘要，但下载区仍可按资源包权限单独展示（若该文有配置下载）。</li>
  <li>可在下载区块上方加一句提示，配合 <code>{$document_login_required}</code>（若主题已有该变量）：<br />
    <code>{if $document_login_required}&lt;p class="pv-tip"&gt;登录后可查看全文与下载附件&lt;/p&gt;{/if}</code></li>
</ul>

<h3>什么时候整段不输出？</h3>
<p>以下任一情况，<code>{pv:doc_bundle}…{/pv:doc_bundle}</code> <strong>整段消失</strong>（不会留空壳）：</p>
<ul>
  <li>插件未安装或未启用</li>
  <li>当前文章不在插件「使用范围」内</li>
  <li>该文章未配置任何启用的下载项</li>
</ul>
<p>因此模板里<strong>不必</strong>再写 <code>{if}</code> 判断「有没有下载」，直接写标签即可。</p>

<h3>样式建议</h3>
<ul>
  <li>建议统一 class 前缀，如 <code>pv-download-*</code>，避免与主题其它模块冲突。</li>
  <li>本地文件与网盘链接可用不同图标（看 <code>{$field.source_type}</code>）。</li>
  <li>提取码建议用等宽字体 + 一键复制按钮（需主题自行写 JS，复制 <code>{$field.extract_code}</code> 或 <code>{$field.remote_url}</code>）。</li>
  <li>移动端请保证点击区域足够大，下载按钮不低于 44px 高。</li>
</ul>

<h3>自检清单（发布主题前）</h3>
<ol>
  <li>找一篇<strong>已配置下载</strong>的测试文章，详情页能看到列表。</li>
  <li>找一篇<strong>未配置下载</strong>的文章，页面无空白占位、无报错。</li>
  <li>测试「登录后可下」资源：未登录 → 跳转登录 → 回来能下。</li>
  <li>测试网盘项：提取码是否显示；链接是否可点。</li>
  <li>窄屏下布局不溢出、按钮可点。</li>
</ol>

<h3>常见问题（前端视角）</h3>
<ul>
  <li><strong>标签原样输出、不解析？</strong> 确认文件是 PivArk 主题模板（非纯静态 HTML）；标签拼写为 <code>{pv:doc_bundle}</code>，闭合为 <code>{/pv:doc_bundle}</code>。</li>
  <li><strong>有数据但不显示？</strong> 检查 <code>id</code> 是否传对；该文是否在插件使用范围内；资源是否启用。</li>
  <li><strong>想放到侧边栏？</strong> 可以，把标签放进侧边栏模板片段即可，需自行做宽度与换行样式。</li>
  <li><strong>能否在列表页显示每篇文章的下载数？</strong> 列表页通常没有 <code>document_id</code> 上下文，需在列表项循环内对每行单独写 <code>{pv:doc_bundle id="{$field.id}"}</code>（具体变量名以你的列表模板为准）。</li>
</ul>
<h3 id="pv-download-group-platform">按网盘平台分组（默认详情页）</h3>
<p>详情页内置区块会调用 <code>groupItemsByPlatform()</code>：同一文档下多条远程链接按平台（百度网盘、阿里云盘等）折叠展示。自定义模板若需相同效果，请在 PHP 侧先分组再循环，或沿用主题 <code>view_document.php</code> 中的 <code>pv-doc-downloads__groups</code> 结构。</p>
<pre class="pv-weapp-code">{pv:doc_bundle id="{$document_id"}
&lt;a href="{$field.url}"&gt;{$field.label}&lt;/a&gt;
{/pv:doc_bundle}</pre>
<p>标签循环输出的是<strong>扁平资源项</strong>；分组布局请参考主题默认模板或 API <code>GET /api/v1/plugins/doc_bundle/list/:document_id</code> 返回结构。</p>

## 升级日志

### 1.0.1 · 2026-07-06

- 前台默认样式迁入插件：`weapp/doc_bundle/assets/css/download.css`，经 `{pv:frontassets}` 按需加载
- 新增 `{pv:doc_bundle layout="cards"}` 默认三列卡片 markup，主题一行插槽即可
- 升级日志后台样式统一为 `pv-weapp-changelog-*` 类名
### 1.0.0 · 2026-01-15

- 文档挂载可下载附件，登录后下载与计数
- 文档编辑器「相关下载」Tab 与 `{pv:doc_bundle}` 前台标签
- 会员中心「我的下载」记录
- 官方 weapp 标装参考实现

## 安装与开发

### 目录

```text
weapp/doc_bundle/
├── plugin.json
├── Plugin.php
├── service/          # 业务 ONLY HERE
├── api/controller/
├── assets/guide/     # 功能介绍 / 用法示意图
├── database/
├── composer.json
└── README.md
```

### 说明

- 文档附件下载、付费/积分解锁、下载日志与 token
- 业务类：`DownloadService`、`DownloadDisplayService`、`DownloadConfigService` 等均在 `service/`
- 数据访问：优先 `WeappDownload*` Model（`Db::name` 已清零，基线 0）

### 卸载

`Plugin.php::uninstall()` 按依赖顺序清空：`WeappDownloadLog` → Token → Purchase → Item → Bundle（Model 删除，非 `Db::name`）。

### 禁止

- 在 `app/common/service/` 写 extends 业务实现（桥接仅 `document/bridge/DocumentDownloadService`）
- 插件内引用 `app/common/service/Download*` 业务空壳

### 验收

```bash
php devtools/test/scripts/qa/qa_download_plugin_cli.php
php devtools/test/scripts/audit/audit_weapp_standard_cli.php download
```

### 超级搜索

`plugin.json` → `document_search.contributor`（`DownloadDocumentSearchContributor`）；下载项标题/标签等按配置写入文档 `search_text`。见 [文档扩展插件-超级搜索接入.md](../../docs/06-插件/文档扩展插件-超级搜索接入.md)。

### 标装进度

| 项 | 状态 |
|----|------|
| `service/` 业务集中 | ✅ |
| `composer.json` | ✅ `pivark/doc_bundle` |
| `PluginApiRegistry` 对外 API | ✅ `DownloadPublic` |
| bridge 路径 SSOT | ✅ `document/bridge/` |
