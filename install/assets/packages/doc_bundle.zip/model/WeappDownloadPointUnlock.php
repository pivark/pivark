<?php
/**
 * 元舟 PivArk — 企业全域原子化数字资产中枢
 * (c) 2024-2026 pivark.com. All rights reserved.
 * Author: Angelo
 * 未经允许，不可用于商业用途。
 */
declare(strict_types=1);

namespace weapp\doc_bundle\model;


use think\Model;
use think\model\relation\BelongsTo;

/**
 * Class weapp\doc_bundle\model\WeappDownloadPointUnlock
 *
 * @property int $bundle_id 资源包 ID
 * @property int $id 主键
 * @property int $points_cost 实际扣除积分
 * @property int $user_id 会员用户 ID
 * @property string $created_at 解锁时间
 *  * @property-read \weapp\doc_bundle\model\WeappDownloadBundle $bundle
 */
class WeappDownloadPointUnlock extends Model
{
    protected $name = 'weapp_doc_bundle_point_unlocks';

        protected $type = [
        'bundle_id' => 'integer',
        'id' => 'integer',
        'points_cost' => 'integer',
        'user_id' => 'integer',
    ];

    protected $autoWriteTimestamp = false;
    public function bundle(): BelongsTo
    {
        return $this->belongsTo(WeappDownloadBundle::class, 'bundle_id');
    }
}
