<?php
/**
 * 元舟 PivArk — 企业全域原子化数字资产中枢
 * (c) 2024-2026 pivark.com. All rights reserved.
 * Author: Angelo
 * 未经允许，不可用于商业用途。
 */
declare(strict_types=1);

namespace weapp\doc_bundle\model;


use think\Model;
use think\model\relation\BelongsTo;

/**
 * Class weapp\doc_bundle\model\WeappDownloadToken
 *
 * @property int $id 主键
 * @property int $item_id 下载项ID
 * @property string $created_at 创建时间
 * @property string $expires_at 过期时间
 * @property string $token 一次性令牌
 * @property string $used_at 使用时间
 *  */
class WeappDownloadToken extends Model
{
    protected $name = 'weapp_doc_bundle_tokens';

        protected $type = [
        'id' => 'integer',
        'item_id' => 'integer',
    ];

    protected $autoWriteTimestamp = false;
    public function item(): BelongsTo
    {
        return $this->belongsTo(Item::class, 'item_id');
    }

}
