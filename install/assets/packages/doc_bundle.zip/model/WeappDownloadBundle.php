<?php
/**
 * 元舟 PivArk — 企业全域原子化数字资产中枢
 * (c) 2024-2026 pivark.com. All rights reserved.
 * Author: Angelo
 * 未经允许，不可用于商业用途。
 */
declare(strict_types=1);

namespace weapp\doc_bundle\model;


use think\Model;
use think\model\relation\BelongsTo;
use think\model\relation\HasMany;

/**
 * Class weapp\doc_bundle\model\WeappDownloadBundle
 *
 * @property float $price 购买价格（预留支付插件）
 * @property int $document_id 关联文档 ID
 * @property int $id 主键
 * @property int $member_level_id 指定会员等级 ID
 * @property int $points_cost 积分下载消耗（access_mode=points）
 * @property int $sort 排序
 * @property int $status 0禁用 1启用
 * @property string $access_mode free/login/member/paid/member_paid
 * @property string $created_at 创建时间
 * @property string $title 下载标题
 * @property string $updated_at 更新时间
 *  *  */
class WeappDownloadBundle extends Model
{
    protected $name = 'weapp_doc_bundle_bundles';

        protected $type = [
        'document_id' => 'integer',
        'id' => 'integer',
        'member_level_id' => 'integer',
        'points_cost' => 'integer',
        'price' => 'float',
        'sort' => 'integer',
        'status' => 'integer',
    ];

    protected $autoWriteTimestamp = false;
public function memberLevel(): BelongsTo
    {
        return $this->belongsTo(MemberLevel::class, 'member_level_id');
    }

    public function downloadItems(): HasMany
    {
        return $this->hasMany(WeappDownloadItem::class, 'bundle_id');
    }

    public function purchases(): HasMany
    {
        return $this->hasMany(WeappDownloadPurchase::class, 'bundle_id');
    }

}
