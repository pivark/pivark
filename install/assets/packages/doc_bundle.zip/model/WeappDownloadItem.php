<?php
/**
 * 元舟 PivArk — 企业全域原子化数字资产中枢
 * (c) 2024-2026 pivark.com. All rights reserved.
 * Author: Angelo
 * 未经允许，不可用于商业用途。
 */
declare(strict_types=1);

namespace weapp\doc_bundle\model;


use think\Model;
use think\model\relation\BelongsTo;

/**
 * Class weapp\doc_bundle\model\WeappDownloadItem
 *
 * @property int $bundle_id 资源包 ID
 * @property int $download_count 下载次数
 * @property int $file_size 字节
 * @property int $id 主键
 * @property int $link_check_http_code 最近 HTTP 状态码
 * @property int $sort 排序
 * @property int $status 0禁用 1启用
 * @property string $created_at 创建时间
 * @property string $extract_code 远程提取码
 * @property string $file_path 本地文件路径
 * @property string $label 链接显示名
 * @property string $link_check_at 最近巡检时间
 * @property string $link_check_message 巡检说明
 * @property string $link_check_status unknown/ok/warn/fail
 * @property string $remote_url 远程下载地址
 * @property string $source_type local/remote
 * @property string $updated_at 更新时间
 * @property-read \weapp\doc_bundle\model\WeappDownloadBundle $bundle
 */
class WeappDownloadItem extends Model
{
    protected $name = 'weapp_doc_bundle_items';

        protected $type = [
        'bundle_id' => 'integer',
        'download_count' => 'integer',
        'file_size' => 'integer',
        'id' => 'integer',
        'link_check_http_code' => 'integer',
        'sort' => 'integer',
        'status' => 'integer',
    ];

    protected $autoWriteTimestamp = false;
    public function bundle(): BelongsTo
    {
        return $this->belongsTo(WeappDownloadBundle::class, 'bundle_id');
    }

}
