<?php
/**
 * 元舟 PivArk — 企业全域原子化数字资产中枢
 * (c) 2024-2026 pivark.com. All rights reserved.
 * Author: Angelo
 * 未经允许，不可用于商业用途。
 */
declare(strict_types=1);

namespace weapp\doc_bundle\model;


use think\Model;
use think\model\relation\BelongsTo;

/**
 * Class weapp\doc_bundle\model\WeappDownloadLog
 *
 * @property int $bundle_id 资源包ID
 * @property int $document_id 文档ID
 * @property int $id 主键
 * @property int $item_id 下载项ID
 * @property int $user_id 前台用户ID，0为游客
 * @property string $created_at 下载时间
 * @property string $ip 客户端IP
 * @property string $user_agent UA摘要
 *  *  *  * @property-read \weapp\doc_bundle\model\WeappDownloadBundle $bundle
 */
class WeappDownloadLog extends Model
{
    protected $name = 'weapp_doc_bundle_logs';

        protected $type = [
        'bundle_id' => 'integer',
        'document_id' => 'integer',
        'id' => 'integer',
        'item_id' => 'integer',
        'user_id' => 'integer',
    ];

    protected $autoWriteTimestamp = false;
    public function bundle(): BelongsTo
    {
        return $this->belongsTo(WeappDownloadBundle::class, 'bundle_id');
    }
public function item(): BelongsTo
    {
        return $this->belongsTo(Item::class, 'item_id');
    }
}
