<?php
declare(strict_types=1);

namespace weapp\doc_bundle\api\controller;

use app\common\support\ServiceResult;
use think\facade\Request;
use think\Response;
use weapp\doc_bundle\service\DownloadPluginBootstrap;
use weapp\doc_bundle\service\DownloadAccessService;
use weapp\doc_bundle\service\DownloadBundleQueryService;
use weapp\doc_bundle\service\DownloadExportService;
use app\common\service\weapp\WeappFrontGateway;
use app\common\service\weapp\WeappSupportGateway;

class File
{
    public function download(int $id = 0): Response
    {
        $id = $id > 0 ? $id : (int) Request::param('id', 0);
        $token = trim((string) Request::param('token', ''));
        DownloadPluginBootstrap::ensureAutoload();

        $result = DownloadExportService::authorizeDownload($id, $token);
        if (!$result->isOk()) {
            $msg = $result->message();
            $payload = DownloadExportService::downloadErrorPayload($msg);
            if ($msg === 'login_required') {
                return redirect(app(WeappFrontGateway::class)->frontLoginRedirectUrl((string) Request::url(true)), 302);
            }
            if (Request::isAjax() || str_contains((string) Request::header('accept', ''), 'application/json')) {
                return app(WeappSupportGateway::class)->apiFromServiceResult($payload, $payload->httpStatus());
            }
            return Response::create($payload->message() !== '' ? $payload->message() : '无法下载', 'html', $payload->httpStatus());
        }

        $data = $result->dataArray();
        if (!empty($data['redirect_url'])) {
            return redirect((string) $data['redirect_url'], 302);
        }

        $path = (string) ($data['path'] ?? '');
        $name = (string) ($data['filename'] ?? 'download');
        $fileResponse = DownloadExportService::streamDownloadFile($path, $name);
        if ($fileResponse instanceof ServiceResult) {
            $payload = DownloadExportService::downloadErrorPayload($fileResponse->message());
            return app(WeappSupportGateway::class)->apiFromServiceResult($payload, $payload->httpStatus());
        }

        return $fileResponse;
    }

    public function list(int $documentId = 0): Response
    {
        $documentId = $documentId > 0 ? $documentId : (int) Request::param('document_id', 0);
        DownloadPluginBootstrap::ensureAutoload();
        return app(WeappSupportGateway::class)->apiFromServiceResult(DownloadBundleQueryService::listApiForDocument($documentId));
    }

    public function pointsPreview(int $bundleId = 0): Response
    {
        $bundleId = $bundleId > 0 ? $bundleId : (int) Request::param('bundle_id', 0);
        DownloadPluginBootstrap::ensureAutoload();
        $result = DownloadAccessService::getPointsUnlockPreview($bundleId);
        return app(WeappSupportGateway::class)->apiFromServiceResult($result, $result->httpStatus());
    }

    public function pointsUnlock(int $bundleId = 0): Response
    {
        $bundleId = $bundleId > 0 ? $bundleId : (int) Request::param('bundle_id', 0);
        DownloadPluginBootstrap::ensureAutoload();
        $result = DownloadAccessService::purchasePointsUnlock($bundleId);
        if (!$result->isOk()) {
            $msg = $result->message();
            $payload = DownloadExportService::downloadErrorPayload($msg);
            if ($msg === 'login_required') {
                $payload = $payload->withExtra(['login_url' => app(WeappFrontGateway::class)->frontLoginRedirectUrl('')]);
            }
            $failData = $result->dataArray();
            if ($failData !== []) {
                $payload = $payload->withExtra(['data' => $failData]);
            }
            return app(WeappSupportGateway::class)->apiFromServiceResult($payload, $payload->httpStatus());
        }
        return app(WeappSupportGateway::class)->apiFromServiceResult($result);
    }

    public function paidPreview(int $bundleId = 0): Response
    {
        $bundleId = $bundleId > 0 ? $bundleId : (int) Request::param('bundle_id', 0);
        DownloadPluginBootstrap::ensureAutoload();
        $result = DownloadAccessService::getPaidPreview($bundleId);
        return app(WeappSupportGateway::class)->apiFromServiceResult($result, $result->httpStatus());
    }

    public function paidCreate(int $bundleId = 0): Response
    {
        $bundleId = $bundleId > 0 ? $bundleId : (int) Request::param('bundle_id', 0);
        $channel  = trim((string) Request::param('channel', 'alipay'));
        DownloadPluginBootstrap::ensureAutoload();
        $result = DownloadAccessService::createPaidOrder($bundleId, $channel);
        if (!$result->isOk()) {
            $msg = $result->message();
            $payload = DownloadExportService::downloadErrorPayload($msg);
            if ($msg === 'login_required') {
                $payload = $payload->withExtra(['login_url' => app(WeappFrontGateway::class)->frontLoginRedirectUrl('')]);
            }
            $extra = $result->dataArray();
            if ($extra !== []) {
                $payload = $payload->withExtra($extra);
            }
            return app(WeappSupportGateway::class)->apiFromServiceResult($payload, $payload->httpStatus());
        }

        return app(WeappSupportGateway::class)->apiFromServiceResult($result);
    }
}