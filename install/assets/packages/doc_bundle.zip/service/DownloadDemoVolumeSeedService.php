<?php
/**
 * 元舟 PivArk — 企业全域原子化数字资产中枢
 * (c) 2024-2026 pivark.com. All rights reserved.
 * Author: Angelo
 * 未经允许，不可用于商业用途。
 *
 * 下载插件：发行演示加灌（36 篇 · 多权限 · 多附件形态 · 长文分页 · 稀疏 litpic）
 */
declare(strict_types=1);

namespace weapp\doc_bundle\service;

use app\common\service\weapp\WeappConfigGateway;
use app\common\service\weapp\WeappMemberGateway;
use app\common\service\weapp\WeappPluginGateway;
use app\common\service\weapp\WeappUploadGateway;

final class DownloadDemoVolumeSeedService
{
    private const COUNT = 36;

    /** 与 InstallDemo / seed_download_channel_complete 同目录，禁写 theme/.../seed */
    private const SEED_UPLOADS_REL = 'uploads/demo-seed/download-files';

    /** @var list<string> */
    private const TITLES = [
        'HY-810 智能压力变送器选型手册',
        'HY-810 安装调试与零点校准指南',
        'HY 系列 CAD 外形图与开孔尺寸包',
        'Modbus / HART 通信协议说明',
        '防爆合格证与 SIL 认证扫描件',
        '企业资质与质量体系文件包',
        'HY-900 无纸记录仪选型与通道配置',
        '温度变送器与热电阻匹配表',
        '现场接线典型图集（4~20 mA / RS485）',
        '年度巡检与预防性维护检查表',
        '投标技术规格书模板',
        'HY Config 组态助手试用说明',
        '膜片备件与密封圈订货清单',
        '本安回路安全栅选型速查',
        'DCS 点表导入模板（CSV）',
        'PLC 寄存器映射示例工程',
        '现场 FAT / SAT 验收记录表',
        '客户培训课件（压力仪表基础）',
        '售后服务网点与响应时效说明',
        '包装运输与开箱检查规范',
        '常见故障代码与排障流程',
        '软件升级包说明（固件 v2.x）',
        '多语言铭牌与说明书套件索引',
        'OEM 贴牌定制参数确认单',
        '能源计量项目成套资料包',
        '水处理泵站改造参考图纸',
        '石化罐区液位监测方案摘要',
        '电力调度辅助监控点位表',
        '食品 CIP 卫生型仪表白皮书',
        '港口油品储罐测控案例附件',
        '研发实验室校准证书合集',
        '展会展台产品彩页（PDF）',
        '渠道商价格政策（需登录）',
        'VIP 专属选型工具包',
        '黄金会员图纸库（积分兑换）',
        '付费精装工程设计说明书',
    ];

    /**
     * @return array{docs:int,bundles:int}
     */
    public static function seed(): array
    {
        app(WeappPluginGateway::class)->pluginRegisterAutoloadPublic('doc_bundle');
        $cfg = app(WeappConfigGateway::class);
        $tagSlug = 'pv-demo-download';
        $tagIds = [
            $tagSlug => $cfg->installDemoUpsertTag([
                'slug'        => $tagSlug,
                'name'        => '资料下载',
                'tpl'         => 'list_document_download.php',

                'nav_sort'    => 7,
                'description' => '产品手册、安装指南、资质文件与 CAD 图纸（演示加灌覆盖多权限与分页）',
                'url_path'    => 'downloads',
            ]),
        ];
        $cfg->installDemoAppendContentCategoryNav('downloads', '资料下载', 7);

        $docs = 0;
        $bundles = 0;
        $levelVip = self::memberLevelIdByName('VIP会员', 2);
        $levelGold = self::memberLevelIdByName('黄金会员', 3);

        for ($i = 1; $i <= self::COUNT; $i++) {
            $html = 'pv-demo-download-' . str_pad((string) $i, 2, '0', STR_PAD_LEFT);
            $title = self::TITLES[$i - 1] ?? ('演示资料 ' . $i);
            $withCover = ($i % 4 === 1); // 约 1/4 有封面，避免篇篇大图
            $longBody = ($i % 5 === 0); // 约 1/5 长文可正文分页
            $summary = self::summaryFor($i, $title);
            $content = self::contentFor($i, $title, $longBody, $withCover);
            $litpic = $withCover ? self::productImage($i) : '';

            $docId = $cfg->installDemoDocumentIdByHtml($html);
            if ($docId < 1) {
                $docId = $cfg->installDemoUpsertDocument(
                    $html,
                    $title,
                    $summary,
                    $content,
                    $litpic,
                    $withCover ? 'has_image' : '',
                    800 + random_int(0, 2000),
                    0,
                    'view_document_download.php',
                );
            }
            if ($docId < 1) {
                continue;
            }
            $docs++;
            $cfg->installDemoLinkDocumentTags($docId, [$tagSlug], $tagIds);

            $access = self::accessFor($i, $levelVip, $levelGold);
            $files = self::buildFiles($i, $title);
            if (self::saveBundle($docId, $title, $access, $files)) {
                $bundles++;
            }
        }

        $cfg->installDemoRefreshTagUseCounts();
        echo "OK DownloadDemoVolumeSeedService docs={$docs} bundles={$bundles}\n";

        return ['docs' => $docs, 'bundles' => $bundles];
    }

    private static function memberLevelIdByName(string $name, int $fallbackId): int
    {
        try {
            return app(WeappMemberGateway::class)->memberLevelIdByName($name, $fallbackId);
        } catch (\Throwable) {
            return $fallbackId;
        }
    }

    /**
     * @return array{access_mode:string,member_level_id:int,points_cost:int}
     */
    private static function accessFor(int $i, int $vipId, int $goldId): array
    {
        return match ($i % 6) {
            1 => ['access_mode' => 'free', 'member_level_id' => 0, 'points_cost' => 0],
            2 => ['access_mode' => 'login', 'member_level_id' => 0, 'points_cost' => 0],
            3 => ['access_mode' => 'member', 'member_level_id' => $vipId, 'points_cost' => 0],
            4 => ['access_mode' => 'member', 'member_level_id' => $goldId, 'points_cost' => 0],
            5 => ['access_mode' => 'points', 'member_level_id' => 0, 'points_cost' => 10 + ($i % 5) * 5],
            default => ['access_mode' => 'paid', 'member_level_id' => 0, 'points_cost' => 0],
        };
    }

    private static function summaryFor(int $i, string $title): string
    {
        $acl = match ($i % 6) {
            1 => '开放下载',
            2 => '登录后下载',
            3 => 'VIP 会员',
            4 => '黄金会员',
            5 => '积分兑换',
            default => '付费解锁',
        };

        return $title . ' · 演示权限：' . $acl . '。可用于验收列表分页与下载权限矩阵。';
    }

    private static function contentFor(int $i, string $title, bool $long, bool $withInlineImg): string
    {
        $img = self::productImage($i + 3);
        $bits = [];
        $bits[] = '<p class="lead">' . htmlspecialchars($title, ENT_QUOTES, 'UTF-8') . '</p>';
        $bits[] = '<p>本文档用于演示站资料下载频道：列表分页、附件权限（开放/登录/会员/积分/付费）、多文件与压缩包形态。</p>';
        if ($withInlineImg) {
            $bits[] = '<p><img src="' . htmlspecialchars($img, ENT_QUOTES, 'UTF-8') . '" alt="产品实拍" style="max-width:100%;height:auto"></p>';
            $bits[] = '<p class="text-muted small">配图为产品/现场实拍样例，非抽象科技插画。</p>';
        } else {
            $bits[] = '<p>本篇未设置列表封面图，详情也不堆头图，贴近真实企业站资料页习惯。</p>';
        }
        $bits[] = '<h2>适用场景</h2><ul><li>销售选型与招投标技术附件</li><li>现场调试与维保交底</li><li>渠道与会员专属资料分发</li></ul>';
        if ($long) {
            $bits[] = '<!--pagebreak-->';
            $bits[] = '<h2>详细说明（第 2 页）</h2>';
            $bits[] = '<p>以下为加长正文，用于验收文档正文分页（手动 pagebreak）。可在后台「内容增强」中切换自动/双模式分页策略。</p>';
            for ($p = 1; $p <= 4; $p++) {
                $bits[] = '<p>章节 ' . $p . '：量程核对、材质选项、防爆分区、输出协议与订货编码示例。演示数据仅供功能展示，请以正式手册为准。</p>';
            }
            $bits[] = '<!--pagebreak-->';
            $bits[] = '<h2>附录（第 3 页）</h2>';
            $bits[] = '<p>附录包含术语表、常见问答与版本修订记录。下载附件见文末资源区。</p>';
        }

        return implode("\n", $bits);
    }

    private static function productImage(int $n): string
    {
        $idx = (($n - 1) % 14) + 1;
        $base = '/uploads/demo-seed/product/' . str_pad((string) $idx, 2, '0', STR_PAD_LEFT);
        $candidates = [$base . '.jpg', $base . '-1.jpg', $base . '-2.jpg'];
        foreach ($candidates as $rel) {
            $abs = rtrim((string) ROOT_PATH, '/\\') . '/public' . $rel;
            if (is_file($abs)) {
                return $rel;
            }
        }

        return '/uploads/demo-seed/product/01.jpg';
    }

    /**
     * @param array{access_mode:string,member_level_id:int,points_cost:int} $access
     * @param list<array<string,mixed>> $files
     */
    private static function saveBundle(int $docId, string $title, array $access, array $files): bool
    {
        try {
            $existing = DownloadBundleQueryService::listForDocument($docId, true);
            $bundleId = (int) ($existing[0]['id'] ?? 0);
            $oldItems = is_array($existing[0]['items'] ?? null) ? $existing[0]['items'] : [];
            $items = [];
            foreach ($files as $idx => $file) {
                $oldId = (int) ($oldItems[$idx]['id'] ?? 0);
                $row = $file;
                if ($oldId > 0) {
                    $row['id'] = $oldId;
                }
                $items[] = $row;
            }
            $payload = [
                'id'               => $bundleId,
                'document_id'      => $docId,
                'title'            => $title . '（附件包）',
                'access_mode'      => $access['access_mode'],
                'member_level_id'  => $access['member_level_id'],
                'points_cost'      => $access['points_cost'],
                'price'            => $access['access_mode'] === 'paid' ? 9.9 : 0,
                'status'           => 1,
                'sort'             => 0,
                'items'            => $items,
            ];
            $result = DownloadBundleService::saveBundleAdmin($payload);

            return $result->isOk();
        } catch (\Throwable $e) {
            echo 'WARN bundle ' . $docId . ': ' . $e->getMessage() . "\n";

            return false;
        }
    }

    /**
     * @return list<array<string,mixed>>
     */
    private static function buildFiles(int $i, string $title): array
    {
        $relDir = '/' . self::SEED_UPLOADS_REL;
        $files = [];
        $mode = $i % 5;
        if ($mode === 0) {
            $zipName = 'demo-pack-' . str_pad((string) $i, 2, '0', STR_PAD_LEFT) . '.zip';
            $rel = self::writeSeedZip($zipName, [
                'README.txt'  => $title . "\nHuayi demo pack\n",
                'outline.txt' => "outline dimensions placeholder\n",
            ]);
            $files[] = [
                'label'       => '资料压缩包（ZIP）',
                'source_type' => 'local',
                'file_path'   => $rel !== '' ? '/' . $rel : $relDir . '/' . $zipName,
                'file_size'   => self::seedFileSize($rel),
                'sort'        => 0,
                'status'      => 1,
            ];
        } elseif ($mode === 1) {
            foreach (['A' => '主手册 PDF', 'B' => '补充说明 PDF'] as $suf => $label) {
                $name = 'demo-' . str_pad((string) $i, 2, '0', STR_PAD_LEFT) . '-' . $suf . '.pdf';
                $rel = self::writeSeedPdf($name, $title . ' · ' . $label);
                $files[] = [
                    'label'       => $label,
                    'source_type' => 'local',
                    'file_path'   => $rel !== '' ? '/' . $rel : $relDir . '/' . $name,
                    'file_size'   => self::seedFileSize($rel),
                    'sort'        => count($files),
                    'status'      => 1,
                ];
            }
        } elseif ($mode === 2) {
            $files[] = [
                'label'       => '在线预览（演示外链）',
                'source_type' => 'remote',
                'remote_url'  => 'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf',
                'file_path'   => '',
                'file_size'   => 0,
                'sort'        => 0,
                'status'      => 1,
            ];
        } else {
            $name = 'demo-' . str_pad((string) $i, 2, '0', STR_PAD_LEFT) . '.pdf';
            $rel = self::writeSeedPdf($name, $title);
            $files[] = [
                'label'       => 'PDF 附件',
                'source_type' => 'local',
                'file_path'   => $rel !== '' ? '/' . $rel : $relDir . '/' . $name,
                'file_size'   => self::seedFileSize($rel),
                'sort'        => 0,
                'status'      => 1,
            ];
        }

        return $files;
    }

    private static function writeSeedPdf(string $basename, string $title): string
    {
        $safe = preg_replace('/[^\x20-\x7E]/', '?', $title) ?: 'PivArk demo';
        $content = "BT /F1 12 Tf 50 750 Td (" . substr($safe, 0, 80) . ") Tj ET";
        $objects = [];
        $objects[] = "<< /Type /Catalog /Pages 2 0 R >>";
        $objects[] = "<< /Type /Pages /Kids [3 0 R] /Count 1 >>";
        $objects[] = "<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Contents 4 0 R /Resources << /Font << /F1 5 0 R >> >> >>";
        $objects[] = "<< /Length " . strlen($content) . " >>\nstream\n" . $content . "\nendstream";
        $objects[] = "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>";
        $pdf = "%PDF-1.4\n";
        $offsets = [0];
        foreach ($objects as $i => $obj) {
            $offsets[] = strlen($pdf);
            $pdf .= ($i + 1) . " 0 obj\n" . $obj . "\nendobj\n";
        }
        $xref = strlen($pdf);
        $pdf .= "xref\n0 " . (count($objects) + 1) . "\n";
        $pdf .= "0000000000 65535 f \n";
        for ($i = 1; $i <= count($objects); $i++) {
            $pdf .= sprintf("%010d 00000 n \n", $offsets[$i]);
        }
        $pdf .= "trailer << /Size " . (count($objects) + 1) . " /Root 1 0 R >>\nstartxref\n{$xref}\n%%EOF";

        return app(WeappUploadGateway::class)->putContentsUnderUploads(
            self::SEED_UPLOADS_REL . '/' . $basename,
            $pdf
        );
    }

    /**
     * @param array<string,string> $entries
     */
    private static function writeSeedZip(string $basename, array $entries): string
    {
        $tmp = rtrim(sys_get_temp_dir(), '/\\') . DIRECTORY_SEPARATOR
            . 'pv_demo_seed_' . bin2hex(random_bytes(4)) . '.zip';
        try {
            if (!class_exists(\ZipArchive::class)) {
                return app(WeappUploadGateway::class)->putContentsUnderUploads(
                    self::SEED_UPLOADS_REL . '/' . $basename,
                    "PK\x05\x06" . str_repeat("\0", 18)
                );
            }
            $zip = new \ZipArchive();
            if ($zip->open($tmp, \ZipArchive::CREATE | \ZipArchive::OVERWRITE) !== true) {
                return '';
            }
            foreach ($entries as $name => $body) {
                $zip->addFromString($name, $body);
            }
            $zip->close();

            return app(WeappUploadGateway::class)->putGeneratedUnderUploads(
                self::SEED_UPLOADS_REL . '/' . $basename,
                $tmp
            );
        } finally {
            if (is_file($tmp)) {
                @unlink($tmp);
            }
        }
    }

    private static function seedFileSize(string $relUnderUploads): int
    {
        if ($relUnderUploads === '') {
            return 0;
        }
        $abs = rtrim((string) ROOT_PATH, '/\\') . DIRECTORY_SEPARATOR . 'public'
            . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $relUnderUploads);

        return is_file($abs) ? (int) filesize($abs) : 0;
    }
}
