<?php
/**
 * 元舟 PivArk — 企业全域原子化数字资产中枢
 * (c) 2024-2026 pivark.com. All rights reserved.
 * Author: Angelo
 * 未经允许，不可用于商业用途。
 */
declare(strict_types=1);

namespace weapp\doc_bundle\service;

use weapp\doc_bundle\model\WeappDownloadBundle;
use weapp\doc_bundle\model\WeappDownloadItem;
use think\facade\Db;
use weapp\doc_bundle\service\DownloadRemoteUrlService;
use app\common\service\weapp\WeappEntitlementGateway;
use app\common\service\weapp\WeappDocumentGateway;
use app\common\service\weapp\WeappMemberGateway;
use app\common\service\weapp\WeappSupportGateway;

final class DownloadBundleService
{
    /** @var list<string> */
    private const PLATFORM_GROUP_ORDER = [
        '百度网盘', '夸克网盘', '阿里云盘', '天翼云盘', '蓝奏云', '123云盘',
        '奶牛快传', '飞机盘', '微云', 'Google Drive', 'OneDrive', '115网盘',
        '本地下载', '远程链接', '远程下载',
    ];
    /**
     * @param list<array<string, mixed>> $items
     * @return array{remote:int,worst:string,label:string}
     */
    public static function bundleLinkCheckSummary(array $items): array
    {
        $remote = 0;
        $worst  = 'unknown';
        $rank   = ['fail' => 3, 'warn' => 2, 'unknown' => 1, 'ok' => 0];
        foreach ($items as $item) {
            if ((string) ($item['source_type'] ?? '') !== 'remote' || trim((string) ($item['remote_url'] ?? '')) === '') {
                continue;
            }
            $remote++;
            $st = (string) ($item['link_check_status'] ?? 'unknown');
            if (($rank[$st] ?? 0) > ($rank[$worst] ?? 0)) {
                $worst = $st;
            }
        }
        if ($remote === 0) {
            return ['remote' => 0, 'worst' => '', 'label' => '—'];
        }
        DownloadPluginBootstrap::ensureAutoload();
        $label = \weapp\doc_bundle\service\DownloadLinkCheckService::statusLabel($worst);

        return ['remote' => $remote, 'worst' => $worst, 'label' => $label];
    }

    /**
     * @param array<string, mixed> $data
     * @return mixed
     */
    public static function saveBundleAdmin(array $data)
    {
        if (!app(WeappEntitlementGateway::class)->entitlementCan('doc_bundle')) {
            return app(WeappSupportGateway::class)->resultFail('插件未授权');
        }

        if (!empty($data['bundle_json']) && is_string($data['bundle_json'])) {
            $decoded = json_decode($data['bundle_json'], true);
            if (!is_array($decoded)) {
                return app(WeappSupportGateway::class)->resultFail('资源包数据无效');
            }
            $data = $decoded;
        }

        $documentId = max(0, (int) ($data['document_id'] ?? 0));
        $title = trim((string) ($data['title'] ?? ''));
        if ($title === '' && $documentId > 0) {
            $title = self::resolveDocumentTitle($documentId);
        }
        if ($title === '') {
            return app(WeappSupportGateway::class)->resultFail('请填写下载标题');
        }

        $items = self::normalizeItems($data['items'] ?? []);
        if ($items === [] && $documentId < 1) {
            return app(WeappSupportGateway::class)->resultFail('请至少添加一个本地文件或远程链接');
        }

        $id = (int) ($data['id'] ?? 0);
        $now = app(WeappSupportGateway::class)->appTimeNow();
        $bundle = [
            'document_id'     => $documentId,
            'title'           => $title,
            'access_mode'     => DownloadAccessService::normalizeAccessMode((string) ($data['access_mode'] ?? 'free')),
            'price'           => max(0, (float) ($data['price'] ?? 0)),
            'member_level_id' => max(0, (int) ($data['member_level_id'] ?? 0)),
            'points_cost'     => max(0, (int) ($data['points_cost'] ?? 0)),
            'sort'            => (int) ($data['sort'] ?? 0),
            'status'          => (int) ($data['status'] ?? 1) ? 1 : 0,
            'updated_at'      => $now,
        ];

        if ($bundle['access_mode'] === 'member' && $bundle['member_level_id'] < 1) {
            return app(WeappSupportGateway::class)->resultFail('请选择指定会员等级');
        }
        if ($bundle['access_mode'] === 'points') {
            if (!app(WeappMemberGateway::class)->memberConfigPointsEnabled()) {
                return app(WeappSupportGateway::class)->resultFail('请先在系统配置中启用会员积分');
            }
            if ($bundle['points_cost'] < 1) {
                return app(WeappSupportGateway::class)->resultFail('请填写消耗积分（至少 1）');
            }
            $bundle['member_level_id'] = 0;
            $bundle['price']           = 0;
        } else {
            $bundle['points_cost'] = 0;
        }

        Db::startTrans();
        try {
            if ($id > 0) {
                WeappDownloadBundle::where('id', $id)->update($bundle);
            } else {
                $bundle['created_at'] = $now;
                $id = (int) WeappDownloadBundle::insertGetId($bundle);
            }

            $keepIds = [];
            foreach ($items as $item) {
                $itemId = (int) ($item['id'] ?? 0);
                $row = [
                    'bundle_id'    => $id,
                    'source_type'  => (string) $item['source_type'],
                    'file_path'    => (string) ($item['file_path'] ?? ''),
                    'remote_url'   => (string) ($item['remote_url'] ?? ''),
                    'extract_code' => (string) ($item['extract_code'] ?? ''),
                    'label'        => (string) ($item['label'] ?? '本地下载'),
                    'file_size'    => (int) ($item['file_size'] ?? 0),
                    'sort'         => (int) ($item['sort'] ?? 0),
                    'status'       => (int) ($item['status'] ?? 1) ? 1 : 0,
                    'updated_at'   => $now,
                ];
                if ($itemId > 0) {
                    WeappDownloadItem::where('id', $itemId)->where('bundle_id', $id)->update($row);
                    $keepIds[] = $itemId;
                } else {
                    $row['created_at'] = $now;
                    $keepIds[] = (int) WeappDownloadItem::insertGetId($row);
                }
            }

            if ($keepIds !== []) {
                WeappDownloadItem::where('bundle_id', $id)->whereNotIn('id', $keepIds)->delete();
            } else {
                WeappDownloadItem::where('bundle_id', $id)->delete();
            }

            Db::commit();
        } catch (\Throwable $e) {
            Db::rollback();

            return app(WeappSupportGateway::class)->resultFail('保存失败：' . $e->getMessage());
        }

        return app(WeappSupportGateway::class)->resultOk(['id' => $id], '保存成功');
    }

    /** @return mixed */
    public static function deleteBundleAdmin(int $id)
    {
        if ($id < 1) {
            return app(WeappSupportGateway::class)->resultFail('参数错误');
        }
        Db::startTrans();
        try {
            WeappDownloadItem::where('bundle_id', $id)->delete();
            WeappDownloadBundle::where('id', $id)->delete();
            Db::commit();
        } catch (\Throwable $e) {
            Db::rollback();

            return app(WeappSupportGateway::class)->resultFail('删除失败：' . $e->getMessage());
        }

        return app(WeappSupportGateway::class)->resultOk(null, '已删除');
    }

    /**
     * @param list<array<string, mixed>> $bundles
     * @return mixed
     */
    public static function syncDocumentBundles(int $documentId, array $bundles)
    {
        if ($documentId < 1) {
            return app(WeappSupportGateway::class)->resultFail('参数错误');
        }

        $existingIds = array_map('intval', WeappDownloadBundle::where('document_id', $documentId)->column('id'));
        $keepIds = [];

        foreach ($bundles as $bundle) {
            if (!is_array($bundle)) {
                continue;
            }
            $bundle['document_id'] = $documentId;
            $res = self::saveBundleAdmin($bundle);
            if (!$res->isOk()) {
                return app(WeappSupportGateway::class)->resultFail((string) ($res->message() ?? '保存失败'));
            }
            $keepIds[] = (int) ($res['id'] ?? 0);
        }

        foreach ($existingIds as $oldId) {
            if (!in_array($oldId, $keepIds, true)) {
                self::deleteBundleAdmin($oldId);
            }
        }

        return app(WeappSupportGateway::class)->resultOk(['count' => count($keepIds)], 'ok');
    }

    public static function resolveDocumentTitle(int $documentId): string
    {
        if ($documentId < 1) {
            return '';
        }

        return app(WeappDocumentGateway::class)->documentTitleById($documentId);
    }

    /**
     * 前台按网盘/平台名分组（每条链接仍绑定原资源包权限）。
     *
     * @param list<array<string, mixed>> $bundles
     * @return list<array<string, mixed>>
     */
    public static function groupItemsByPlatform(array $bundles): array
    {
        $buckets = [];
        foreach ($bundles as $bundle) {
            if ((int) ($bundle['status'] ?? 0) !== 1) {
                continue;
            }
            foreach (($bundle['items'] ?? []) as $item) {
                if ((int) ($item['status'] ?? 0) !== 1) {
                    continue;
                }
                $platform = self::normalizeItemLabel(
                    (string) ($item['source_type'] ?? 'local'),
                    (string) ($item['label'] ?? '')
                );
                $key = $platform !== '' ? $platform : '其他';
                $buckets[$key][] = ['item' => $item, 'bundle' => $bundle];
            }
        }
        if ($buckets === []) {
            return [];
        }

        $orderedKeys = [];
        foreach (self::PLATFORM_GROUP_ORDER as $name) {
            if (isset($buckets[$name])) {
                $orderedKeys[] = $name;
            }
        }
        foreach (array_keys($buckets) as $name) {
            if (!in_array($name, $orderedKeys, true)) {
                $orderedKeys[] = $name;
            }
        }

        $out = [];
        foreach ($orderedKeys as $title) {
            $rows = $buckets[$title];
            $out[] = [
                'id'           => 0,
                'title'        => $title,
                'items'        => $rows,
                'item_count'   => count($rows),
                'access_mode'  => 'mixed',
                'access_label' => self::summarizePlatformAccessLabel($rows),
                'points_cost'  => 0,
                'price'        => '0.00',
            ];
        }

        return $out;
    }

    /**
     * @param list<array{item:array<string,mixed>,bundle:array<string,mixed>}> $rows
     */
    public static function summarizePlatformAccessLabel(array $rows): string
    {
        $labels = [];
        foreach ($rows as $row) {
            $bundle = is_array($row['bundle'] ?? null) ? $row['bundle'] : [];
            $labels[DownloadAccessService::bundleAccessLabel($bundle)] = true;
        }
        $keys = array_keys($labels);
        if ($keys === []) {
            return '';
        }
        if (count($keys) === 1) {
            return $keys[0];
        }

        return '多种获取方式';
    }

    /**
     * 同名资源包合并为一组（前台分组展示）
     *
     * @param list<array<string, mixed>> $bundles
     * @return list<array<string, mixed>>
     */
    public static function mergeBundlesByTitle(array $bundles): array
    {
        $merged = [];
        foreach ($bundles as $bundle) {
            if ((int) ($bundle['status'] ?? 0) !== 1) {
                continue;
            }
            $title = trim((string) ($bundle['title'] ?? ''));
            $key   = $title !== '' ? $title : '__default__';
            if (!isset($merged[$key])) {
                $merged[$key] = $bundle;
                $merged[$key]['items'] = [];
            }
            foreach (($bundle['items'] ?? []) as $item) {
                if ((int) ($item['status'] ?? 0) === 1) {
                    $merged[$key]['items'][] = $item;
                }
            }
        }
        $out = [];
        foreach ($merged as $bundle) {
            $items = is_array($bundle['items'] ?? null) ? $bundle['items'] : [];
            if ($items === []) {
                continue;
            }
            $bundle['item_count'] = count($items);
            $out[]                = $bundle;
        }

        return $out;
    }

    /**
     * @param list<array<string, mixed>> $bundles
     */

    public static function formatPublicBundle(array $bundle): array
    {
        $items = is_array($bundle['items'] ?? null) ? $bundle['items'] : [];

        return [
            'id'           => (int) ($bundle['id'] ?? 0),
            'title'        => (string) ($bundle['title'] ?? '资源下载'),
            'access_mode'  => (string) ($bundle['access_mode'] ?? 'free'),
            'access_label' => DownloadAccessService::bundleAccessLabel($bundle),
            'item_count'   => (int) ($bundle['item_count'] ?? count($items)),
            'points_cost'  => (int) ($bundle['points_cost'] ?? 0),
            'price'        => (string) ($bundle['price'] ?? '0.00'),
        ];
    }

    /**
     * @param array<string, scalar> $vars
     */

    public static function normalizeItemLabel(string $sourceType, string $label): string
    {
        $label = trim($label);
        if ($sourceType === 'remote') {
            return $label !== '' ? $label : '远程下载';
        }
        if ($label === '' || $label === '立即下载') {
            return '本地下载';
        }

        return $label;
    }

    public static function attachItemsToBundles(array $bundles): array
    {
        if ($bundles === []) {
            return [];
        }
        $ids = array_map(static fn (array $b): int => (int) ($b['id'] ?? 0), $bundles);
        $items = WeappDownloadItem::whereIn('bundle_id', $ids)
            ->order('sort', 'asc')
            ->order('id', 'asc')
            ->select()
            ->toArray();
        $grouped = [];
        foreach ($items as $item) {
            $grouped[(int) ($item['bundle_id'] ?? 0)][] = $item;
        }
        foreach ($bundles as &$bundle) {
            $bundle['items'] = $grouped[(int) ($bundle['id'] ?? 0)] ?? [];
            $bundle['item_count'] = count($bundle['items']);
            $bundle['access_label'] = DownloadAccessService::bundleAccessLabel($bundle);
        }
        unset($bundle);

        return $bundles;
    }

    /**
     * @param mixed $raw
     * @return list<array<string, mixed>>
     */
    public static function normalizeItems($raw): array
    {
        if (!is_array($raw)) {
            return [];
        }
        $out = [];
        $sort = 0;
        foreach ($raw as $row) {
            if (!is_array($row)) {
                continue;
            }
            $type = (string) ($row['source_type'] ?? 'local');
            if ($type === 'remote') {
                $url = trim((string) ($row['remote_url'] ?? ''));
                if ($url === '') {
                    continue;
                }
                $urlErr = DownloadRemoteUrlService::validate($url);
                if ($urlErr !== '') {
                    continue;
                }
                $out[] = [
                    'id'           => (int) ($row['id'] ?? 0),
                    'source_type'  => 'remote',
                    'remote_url'   => $url,
                    'extract_code' => trim((string) ($row['extract_code'] ?? '')),
                    'label'        => trim((string) ($row['label'] ?? '')) ?: '远程下载',
                    'file_path'    => '',
                    'file_size'    => 0,
                    'sort'         => (int) ($row['sort'] ?? $sort),
                    'status'       => (int) ($row['status'] ?? 1) ? 1 : 0,
                ];
            } else {
                $path = trim((string) ($row['file_path'] ?? ''));
                if ($path === '' || str_contains($path, '..')) {
                    continue;
                }
                $out[] = [
                    'id'           => (int) ($row['id'] ?? 0),
                    'source_type'  => 'local',
                    'file_path'    => $path,
                    'remote_url'   => '',
                    // 货架 kind（html/pivark/site）可落库，供 authorize 精确匹配
                    'extract_code' => preg_replace('/[^a-z0-9_-]/', '', strtolower(trim((string) ($row['extract_code'] ?? '')))) ?? '',
                    'label'        => self::normalizeItemLabel((string) ($row['source_type'] ?? 'local'), (string) ($row['label'] ?? '')),
                    'file_size'    => (int) ($row['file_size'] ?? 0),
                    'sort'         => (int) ($row['sort'] ?? $sort),
                    'status'       => (int) ($row['status'] ?? 1) ? 1 : 0,
                ];
            }
            $sort++;
        }

        return $out;
    }

}
