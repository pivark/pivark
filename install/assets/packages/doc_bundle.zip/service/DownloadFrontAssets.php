<?php
declare(strict_types=1);

namespace weapp\doc_bundle\service;

use app\common\service\weapp\WeappFrontGateway;

final class DownloadFrontAssets
{
    public static function registerBase(): void
    {
        app(WeappFrontGateway::class)->frontAssetRegisterWeappStylesheet('doc_bundle', 'pv-download-css', 'assets/css/download.css');
    }

    /** @param list<array<string, mixed>> $bundles */
    public static function registerBundles(array $bundles): void
    {
        if ($bundles === []) {
            return;
        }
        self::registerBase();
        $frontGw = app(WeappFrontGateway::class);
        $frontGw->frontAssetRegisterUrlModule('doc_bundle');
        $frontGw->frontAssetRegisterWeappScript('doc_bundle', 'pv-download-core', 'assets/js/core.js');
        $needsPoints = false;
        $needsPaid = false;
        foreach ($bundles as $bundle) {
            if (!is_array($bundle)) {
                continue;
            }
            $mode = strtolower(trim((string) ($bundle['access_mode'] ?? '')));
            if ($mode === 'points') {
                $needsPoints = true;
            }
            if (in_array($mode, ['paid', 'member_paid'], true)) {
                $needsPaid = true;
            }
            foreach ((array) ($bundle['items'] ?? []) as $row) {
                $src = is_array($row['bundle'] ?? null) ? $row['bundle'] : $bundle;
                if (!is_array($src)) {
                    continue;
                }
                $m = strtolower(trim((string) ($src['access_mode'] ?? '')));
                if ($m === 'points') {
                    $needsPoints = true;
                }
                if (in_array($m, ['paid', 'member_paid'], true)) {
                    $needsPaid = true;
                }
            }
        }
        if ($needsPoints) {
            $frontGw->frontAssetRegisterWeappScript('doc_bundle', 'pv-download-points', 'assets/js/points.js');
        }
        if ($needsPaid) {
            $frontGw->frontAssetRegisterWeappScript('doc_bundle', 'pv-download-paid', 'assets/js/paid.js');
        }
    }
}
