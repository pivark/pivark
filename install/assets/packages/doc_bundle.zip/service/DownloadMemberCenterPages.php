<?php
declare(strict_types=1);

namespace weapp\doc_bundle\service;

use think\Response;
use app\common\service\weapp\WeappEntitlementGateway;
use app\common\service\weapp\WeappMemberGateway;

/** 会员中心 download 页面（member.center.page） */
final class DownloadMemberCenterPages
{
    public static function register(): void
    {
        app(WeappMemberGateway::class)->memberCenterPageRegister(
            'doc_bundle',
            'downloads',
            [self::class, 'downloads'],
            'downloads',
            null,
            '我的下载',
        );
    }

    /**
     * @param array{
     *   member: array<string,mixed>,
     *   render: callable(string,string,string,string,array=): Response,
     *   redirect_unavailable: callable(string): Response
     * } $host
     */
    public static function downloads(array $host): Response
    {
        if (!app(WeappEntitlementGateway::class)->entitlementCan('doc_bundle')) {
            return ($host['redirect_unavailable'])('我的下载');
        }
        DownloadPluginBootstrap::ensureAutoload();
        $member = $host['member'];
        $items  = DownloadExportService::listItemsForMember((int) $member['id']);

        return ($host['render'])('member/downloads', 'doc_bundle', '我的下载', 'downloads', [
            'download_items'       => $items,
            'download_items_empty' => $items === [] ? 1 : 0,
        ]);
    }
}
