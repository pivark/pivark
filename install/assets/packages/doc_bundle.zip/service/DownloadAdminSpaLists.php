<?php
declare(strict_types=1);

namespace weapp\doc_bundle\service;

final class DownloadAdminSpaLists
{
    /** @param array<string, mixed> $query @return array<string, mixed> */
    public static function resourcesList(array $query): array
    {
        DownloadPluginBootstrap::ensureAutoload();
        if (!class_exists(DownloadBundleQueryService::class)) {
            return ['list' => [], 'total' => 0];
        }
        $paged = DownloadBundleQueryService::listAdminPaged($query);

        return [
            'total' => $paged['total'],
            'list'  => $paged['list'],
            'page'  => $paged['page'],
            'limit' => $paged['limit'],
        ];
    }

    /** @param array<string, mixed> $query @return array<string, mixed> */
    public static function linkCheckList(array $query): array
    {
        DownloadPluginBootstrap::ensureAutoload();
        $page   = max(1, (int) ($query['page'] ?? 1));
        $limit  = (int) ($query['limit'] ?? 20);
        $status = trim((string) ($query['status'] ?? ''));
        $data   = DownloadLinkCheckService::listAdmin($page, $limit, $status);

        return [
            'summary' => DownloadLinkCheckService::summary(),
            'list'    => $data['list'],
            'total'   => $data['total'],
            'page'    => $data['page'],
            'limit'   => $data['limit'],
        ];
    }
}