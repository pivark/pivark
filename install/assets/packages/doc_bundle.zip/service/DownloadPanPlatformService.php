<?php
declare(strict_types=1);

namespace weapp\doc_bundle\service;

/** 网盘平台识别与前台图标路径（与 admin pan-platform.ts 对齐） */
final class DownloadPanPlatformService
{
    private const ICON_BASE = '/weapp/doc_bundle/assets/pan';

    /** @var list<array{id:string,label:string,hosts:string}> */
    private const PLATFORMS = [
        ['id' => 'baidu', 'label' => '百度网盘', 'hosts' => 'pan\.baidu\.com|yun\.baidu\.com'],
        ['id' => 'quark', 'label' => '夸克网盘', 'hosts' => 'pan\.quark\.cn'],
        ['id' => 'aliyun', 'label' => '阿里云盘', 'hosts' => 'aliyundrive\.com|alipan\.com'],
        ['id' => 'tianyi', 'label' => '天翼云盘', 'hosts' => 'cloud\.189\.cn'],
        ['id' => 'lanzou', 'label' => '蓝奏云', 'hosts' => 'lanzou[a-z]*\.com|lanzoux\.com'],
        ['id' => '123pan', 'label' => '123云盘', 'hosts' => '123pan\.com|123684\.com|123865\.com|123912\.com'],
        ['id' => '115', 'label' => '115网盘', 'hosts' => '115\.com|115cdn\.com'],
        ['id' => 'onedrive', 'label' => 'OneDrive', 'hosts' => '1drv\.ms|onedrive\.live\.com'],
        ['id' => 'google', 'label' => 'Google Drive', 'hosts' => 'drive\.google\.com|docs\.google\.com'],
        ['id' => 'mega', 'label' => 'MEGA', 'hosts' => 'mega\.nz'],
        ['id' => 'weiyun', 'label' => '微云', 'hosts' => 'weiyun\.com'],
        ['id' => 'feishu', 'label' => '飞书', 'hosts' => 'feishu\.cn'],
        ['id' => 'cowtransfer', 'label' => '奶牛快传', 'hosts' => 'cowtransfer\.com'],
        ['id' => 'feijipan', 'label' => '飞机盘', 'hosts' => 'feijipan\.com|feijix\.com'],
        ['id' => 'terabox', 'label' => 'TeraBox', 'hosts' => 'terabox\.com|1024tera\.com'],
        ['id' => 'ctfile', 'label' => '城通网盘', 'hosts' => 'ctfile\.com'],
    ];

    /**
     * @return array{id:string,label:string,icon_url:string}
     */
    public static function detectFromUrl(string $url): array
    {
        $host = self::hostFromUrl($url);
        foreach (self::PLATFORMS as $row) {
            if ($host !== '' && preg_match('/' . $row['hosts'] . '/i', $host)) {
                return [
                    'id'       => $row['id'],
                    'label'    => $row['label'],
                    'icon_url' => self::iconUrl($row['id']),
                ];
            }
        }

        return ['id' => 'other', 'label' => '网盘链接', 'icon_url' => self::iconUrl('other')];
    }

    public static function iconUrl(string $platformId): string
    {
        $id = preg_replace('/[^a-z0-9_-]/', '', strtolower($platformId)) ?: 'other';

        return self::ICON_BASE . '/' . $id . '.svg';
    }

    /**
     * @return array{id:string,label:string,icon_url:string}
     */
    public static function fromItem(array $item): array
    {
        $type = (string) ($item['source_type'] ?? 'local');
        if ($type === 'remote') {
            $url = trim((string) ($item['remote_url'] ?? ''));

            return $url !== '' ? self::detectFromUrl($url) : [
                'id' => 'other', 'label' => '远程链接', 'icon_url' => self::iconUrl('other'),
            ];
        }

        return ['id' => 'local', 'label' => '本地文件', 'icon_url' => ''];
    }

    private static function hostFromUrl(string $url): string
    {
        $url = trim($url);
        if ($url === '') {
            return '';
        }
        $host = (string) parse_url($url, PHP_URL_HOST);

        return strtolower($host);
    }
    public static function platformLabel(string $platformId): string
    {
        return match ($platformId) {
            'baidu'        => '百度网盘',
            'quark'        => '夸克网盘',
            'aliyun'       => '阿里云盘',
            'tianyi'       => '天翼云盘',
            'lanzou'       => '蓝奏云',
            '123pan'       => '123云盘',
            '115'          => '115网盘',
            'onedrive'     => 'OneDrive',
            'google'       => 'Google Drive',
            'mega'         => 'MEGA',
            'weiyun'       => '微云',
            'feishu'       => '飞书',
            'cowtransfer'  => '奶牛快传',
            'feijipan'     => '飞机盘',
            'terabox'      => 'TeraBox',
            'ctfile'       => '城通网盘',
            'local'        => '本地文件',
            default        => '其它网盘',
        };
    }
}
