<?php
declare(strict_types=1);

namespace weapp\doc_bundle\service;

use app\common\service\weapp\WeappDocumentGateway;
use app\common\service\weapp\WeappPaymentGateway;
use app\common\service\weapp\WeappPluginGateway;

/** 文档领域事件（plugin.json subscribes） */
final class DownloadEventService
{
    /**
     * @param array<string, mixed> $payload
     */
    public static function onDocumentDeleted(array $payload): void
    {
        $documentId = (int) ($payload['document_id'] ?? 0);
        $docGw = app(WeappDocumentGateway::class);
        if ($documentId < 1 || !$docGw->documentDownloadBridgeEnabled()) {
            return;
        }
        $docGw->documentDownloadBridgePurgeForDocument($documentId);
    }

    /**
     * 账房退款后撤付费下载履约（蓝队 K-2）。
     *
     * @param array<string, mixed> $payload
     */
    public static function onPaymentRefunded(array $payload): void
    {
        $scene = trim((string) ($payload['scene'] ?? ''));
        $expected = app(WeappPaymentGateway::class)->paymentPluginDocumentPaidScene('doc_bundle');
        if ($scene === '' || $scene !== $expected) {
            return;
        }
        $userId   = (int) ($payload['user_id'] ?? 0);
        $bundleId = (int) ($payload['scene_id'] ?? 0);
        if ($userId < 1 || $bundleId < 1) {
            return;
        }
        if (!class_exists(DownloadPurchaseService::class)) {
            app(WeappPluginGateway::class)->pluginRegisterAutoloadPublic('doc_bundle');
        }
        if (class_exists(DownloadPurchaseService::class)) {
            DownloadPurchaseService::revokePurchase($userId, $bundleId);
        }
    }
}
