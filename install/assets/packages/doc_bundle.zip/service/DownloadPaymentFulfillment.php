<?php
declare(strict_types=1);

namespace weapp\doc_bundle\service;

use weapp\doc_bundle\model\WeappDownloadBundle;
use app\common\service\weapp\WeappPluginGateway;
use app\common\service\weapp\WeappPaymentGateway;
use app\common\service\weapp\WeappSupportGateway;

/** download pay scene */
final class DownloadPaymentFulfillment
{
    public static function register(): void
    {
        $payGw = app(WeappPaymentGateway::class);
        $scene = $payGw->paymentPluginDocumentPaidScene('doc_bundle');
        $payGw->paymentFulfillmentRegister($scene, [self::class, 'handle'], '付费下载');
    }

    /** @param array<string, mixed> $order @return mixed */
    public static function handle(array $order)
    {
        $userId   = (int) ($order['user_id'] ?? 0);
        $bundleId = (int) ($order['scene_id'] ?? 0);
        $amount   = (float) ($order['amount'] ?? 0);
        if ($userId < 1 || $bundleId < 1) {
            return app(WeappSupportGateway::class)->resultFail("\xe4\xbb\x98\xe8\xb4\xb9\xe8\xae\xa2\xe5\x8d\x95\xe5\x8f\x82\xe6\x95\xb0\xe6\x97\xa0\xe6\x95\x88");
        }
        if (!class_exists(DownloadPurchaseService::class)) {
            app(WeappPluginGateway::class)->pluginRegisterAutoloadPublic('doc_bundle');
        }
        if (!class_exists(DownloadPurchaseService::class)) {
            return app(WeappSupportGateway::class)->resultFail('download plugin not ready');
        }

        $bundle = WeappDownloadBundle::where('id', $bundleId)->where('status', 1)->find();
        if (!$bundle) {
            return app(WeappSupportGateway::class)->resultFail("\xe8\xb5\x84\xe6\xba\x90\xe5\x8c\x85\xe4\xb8\x8d\xe5\xad\x98\xe5\x9c\xa8\xe6\x88\x96\xe5\xb7\xb2\xe4\xb8\x8b\xe6\x9e\xb6");
        }
                $expected = app(WeappSupportGateway::class)->moneyMathToFloat((string) ($bundle['price'] ?? '0'));
        if ($expected <= 0) {
            return app(WeappSupportGateway::class)->resultFail("\xe8\xb5\x84\xe6\xba\x90\xe5\x8c\x85\xe9\x9d\x9e\xe4\xbb\x98\xe8\xb4\xb9");
        }
        if (!app(WeappSupportGateway::class)->moneyMathWithinTolerance($amount, $expected)) {
            app(WeappSupportGateway::class)->kernelOpsLog('download_fulfill_amount_mismatch', [
                'bundle_id' => $bundleId,
                'expected'  => $expected,
                'paid'      => $amount,
                'user_id'   => $userId,
                'order_no'  => (string) ($order['order_no'] ?? ''),
            ]);

            return app(WeappSupportGateway::class)->resultFail("\xe6\x94\xaf\xe4\xbb\x98\xe9\x87\x91\xe9\xa2\x9d\xe4\xb8\x8e\xe8\xb5\x84\xe6\xba\x90\xe5\x8c\x85\xe4\xbb\xb7\xe6\xa0\xbc\xe4\xb8\x8d\xe4\xb8\x80\xe8\x87\xb4");
        }

        return DownloadPurchaseService::recordPurchase($userId, $bundleId, $amount);
    }
}
