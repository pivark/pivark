<?php
declare(strict_types=1);

namespace weapp\doc_bundle\service;

use app\common\service\weapp\WeappSupportGateway;
use app\common\support\AppTime;
use weapp\doc_bundle\model\WeappDownloadToken;
class DownloadTokenService
{
    public static function issue(int $itemId, int $ttlSeconds = 600): string
    {
        if ($itemId < 1) {
            return '';
        }
        $token = bin2hex(random_bytes(16));
        $now   = app(WeappSupportGateway::class)->appTimeNow();
        WeappDownloadToken::insert([
            'item_id'    => $itemId,
            'token'      => $token,
            'expires_at' => AppTime::format('Y-m-d H:i:s', time() + max(60, $ttlSeconds)),
            'created_at' => $now,
        ]);

        return $token;
    }

    public static function consume(string $token): int
    {
        $token = trim($token);
        if ($token === '' || strlen($token) !== 32) {
            return 0;
        }
        $now = app(WeappSupportGateway::class)->appTimeNow();
        $affected = WeappDownloadToken::where('token', $token)
            ->whereNull('used_at')
            ->where('expires_at', '>', $now)
            ->update(['used_at' => $now]);
        if ($affected < 1) {
            return 0;
        }

        return (int) WeappDownloadToken::where('token', $token)->value('item_id');
    }
}
