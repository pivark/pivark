<?php
/**
 * 元舟 PivArk — 企业全域原子化数字资产中枢
 * (c) 2024-2026 pivark.com. All rights reserved.
 * Author: Angelo
 * 未经允许，不可用于商业用途。
 */
declare(strict_types=1);

namespace weapp\doc_bundle\service;

use weapp\doc_bundle\model\WeappDownloadBundle;
use weapp\doc_bundle\model\WeappDownloadItem;
use weapp\doc_bundle\model\WeappDownloadLog;
use app\common\support\ServiceResult;
use think\Response;
use think\response\File;
use weapp\doc_bundle\service\DownloadConfigService;
use weapp\doc_bundle\service\DownloadRateLimitService;
use weapp\doc_bundle\service\DownloadTokenService;
use app\common\service\weapp\WeappEntitlementGateway;
use app\common\service\weapp\WeappSupportGateway;

final class DownloadExportService
{
    /** @return mixed */
    public static function authorizeDownload(int $itemId, string $token = '')
    {
        
        DownloadPluginBootstrap::ensureAutoload();
if ($token !== '') {
            $itemId = DownloadTokenService::consume($token);
        }
        if (!DownloadRateLimitService::allow($itemId)) {
            return app(WeappSupportGateway::class)->resultFail('rate_limited');
        }
        if (!app(WeappEntitlementGateway::class)->entitlementCan('doc_bundle')) {
            return app(WeappSupportGateway::class)->resultFail('下载插件未启用');
        }

        $item = WeappDownloadItem::where('id', $itemId)->where('status', 1)->find();
        if (!$item) {
            return app(WeappSupportGateway::class)->resultFail('not_found');
        }

        $bundle = WeappDownloadBundle::where('id', (int) ($item['bundle_id'] ?? 0))->where('status', 1)->find();
        if (!$bundle) {
            return app(WeappSupportGateway::class)->resultFail('not_found');
        }

        $documentId = (int) ($bundle['document_id'] ?? 0);
        if ($documentId > 0 && !DownloadConfigService::documentEligible($documentId)) {
            return app(WeappSupportGateway::class)->resultFail('not_allowed');
        }

        $readCheck = DownloadAccessService::checkDocumentReadAccess($documentId);
        if (!$readCheck->isOk()) {
            return $readCheck;
        }

        $access = DownloadAccessService::checkBundleAccess($bundle);
        if (!$access->isOk()) {
            return $access;
        }

        if (DownloadAccessService::normalizeAccessMode((string) ($bundle['access_mode'] ?? 'free')) === 'points') {
            $unlock = DownloadAccessService::requirePointsUnlocked($bundle);
            if (!$unlock->isOk()) {
                return $unlock;
            }
        }

        $member = app(\app\common\service\weapp\WeappFrontGateway::class)->frontCurrent();
        $memberId = is_array($member) ? (int) ($member['id'] ?? 0) : 0;
        $levelId = is_array($member) ? (int) ($member['member_level_id'] ?? 0) : 0;

        $sourceType = (string) ($item['source_type'] ?? 'local');
        if ($sourceType === 'remote') {
            $url = trim((string) ($item['remote_url'] ?? ''));
            if ($url === '') {
                return app(WeappSupportGateway::class)->resultFail('remote_missing');
            }
            if ($memberId > 0) {
                $quota = DownloadDailyQuotaService::consume($memberId, $levelId, 'doc');
                if (empty($quota['ok'])) {
                    return app(WeappSupportGateway::class)->resultFail(
                        trim((string) ($quota['message'] ?? '')) !== ''
                            ? (string) $quota['message']
                            : 'rate_limited'
                    );
                }
            }
            DownloadAuditService::log($itemId, [
                'bundle_id'   => (int) ($bundle['id'] ?? 0),
                'document_id' => $documentId,
            ]);
            WeappDownloadItem::where('id', $itemId)->inc('download_count')->update();

            return app(WeappSupportGateway::class)->resultOk(['redirect_url' => $url, 'extract_code' => (string) ($item['extract_code'] ?? '')], 'redirect');
        }

        $path = trim((string) ($item['file_path'] ?? ''));
        if ($path === '' || str_contains($path, '..')) {
            return app(WeappSupportGateway::class)->resultFail('invalid_path');
        }
        $abs = self::resolveAbsolutePath($path);
        if ($abs === '' || !is_file($abs)) {
            return app(WeappSupportGateway::class)->resultFail('file_missing');
        }

        if ($memberId > 0) {
            $quota = DownloadDailyQuotaService::consume($memberId, $levelId, 'doc');
            if (empty($quota['ok'])) {
                return app(WeappSupportGateway::class)->resultFail(
                    trim((string) ($quota['message'] ?? '')) !== ''
                        ? (string) $quota['message']
                        : 'rate_limited'
                );
            }
        }

        DownloadAuditService::log($itemId, [
            'bundle_id'   => (int) ($bundle['id'] ?? 0),
            'document_id' => $documentId,
        ]);
        WeappDownloadItem::where('id', $itemId)->inc('download_count')->update();

        return app(WeappSupportGateway::class)->resultOk(['path' => $abs, 'filename' => basename($path) ?: (string) ($item['label'] ?? 'download')], 'ok');
    }

    public static function resolveAbsolutePath(string $path): string
    {
        $path = str_replace('\\', '/', trim($path));
        if ($path === '' || str_contains($path, '..')) {
            return '';
        }

        // 数字货私有包：private/market/packages/... → data/private/market/packages（禁公开 /static）
        if (str_starts_with($path, 'private/market/packages/')) {
            $rel = substr($path, strlen('private/market/packages/'));
            $privateRoot = rtrim((string) (defined('ROOT_PATH') ? ROOT_PATH : ''), '/\\')
                . DIRECTORY_SEPARATOR . 'data'
                . DIRECTORY_SEPARATOR . 'private'
                . DIRECTORY_SEPARATOR . 'market'
                . DIRECTORY_SEPARATOR . 'packages';
            $full = $privateRoot . DIRECTORY_SEPARATOR
                . str_replace('/', DIRECTORY_SEPARATOR, ltrim($rel, '/'));
            $real = realpath($full);
            $rootReal = realpath($privateRoot);
            if ($real === false || $rootReal === false) {
                return '';
            }
            $prefix = $rootReal . DIRECTORY_SEPARATOR;
            if ($real !== $rootReal && !str_starts_with($real, $prefix)) {
                return '';
            }

            return is_file($real) ? $real : '';
        }

        $publicRoot = rtrim((string) (defined('ROOT_PATH') ? ROOT_PATH : ''), '/\\')
            . DIRECTORY_SEPARATOR . 'public';
        $full = $publicRoot . DIRECTORY_SEPARATOR
            . str_replace('/', DIRECTORY_SEPARATOR, ltrim($path, '/'));
        $real = realpath($full);
        $publicReal = realpath($publicRoot);
        if ($real === false || $publicReal === false) {
            return '';
        }
        $prefix = $publicReal . DIRECTORY_SEPARATOR;
        if ($real !== $publicReal && !str_starts_with($real, $prefix)) {
            return '';
        }

        return $real;
    }

    /**
     * @return mixed|null
     */
    public static function streamDownloadFile(string $absPath, string $filename): Response|ServiceResult
    {
        if (!is_file($absPath) || !is_readable($absPath)) {
            return app(WeappSupportGateway::class)->resultFail('file_missing');
        }

        return (new File($absPath))->name($filename)->force(true);
    }

    /**
     * @return mixed
     */
    public static function downloadErrorPayload(string $msg)
    {
        return match ($msg) {
            'login_required' => app(WeappSupportGateway::class)->resultAuthRequired('请先登录会员账号', ''),
            'level_required' => app(WeappSupportGateway::class)->resultForbidden('会员等级不足，无法下载'),
            'read_required' => app(WeappSupportGateway::class)->resultForbidden('请先满足文档阅读权限'),
            'payment_required' => app(WeappSupportGateway::class)->resultFailPayment('该资源需付费后下载'),
            'points_disabled' => app(WeappSupportGateway::class)->resultForbidden('站点未开启会员积分功能'),
            'points_insufficient' => app(WeappSupportGateway::class)->resultFailPayment('积分不足，无法下载'),
            'points_cost_invalid' => app(WeappSupportGateway::class)->resultFail('下载积分配置无效，请联系管理员'),
            'points_deduct_failed' => app(WeappSupportGateway::class)->resultFail('积分扣减失败，请稍后重试'),
            'points_unlock_failed' => app(WeappSupportGateway::class)->resultFail('积分解锁失败，请稍后重试'),
            'rate_limited' => app(WeappSupportGateway::class)->resultRateLimited('下载过于频繁，请稍后再试'),
            default => app(WeappSupportGateway::class)->resultNotFound($msg !== '' ? $msg : '无法下载'),
        };
    }

    /** @return list<array<string,mixed>> */
    public static function listItemsForMember(int $userId, int $limit = 50): array
    {
        if ($userId < 1 || !app(WeappEntitlementGateway::class)->entitlementCan('doc_bundle')) {
            return [];
        }
        $links = WeappDownloadLog::where('user_id', $userId)
            ->order('id', 'desc')->limit($limit)->column('item_id');
        $links = array_values(array_unique(array_filter(array_map('intval', $links))));
        if ($links === []) {
            return [];
        }

        $itemRows = WeappDownloadItem::whereIn('id', $links)->where('status', 1)->select()->toArray();
        if ($itemRows === []) {
            return [];
        }
        $itemsById = [];
        $bundleIds = [];
        foreach ($itemRows as $row) {
            $id = (int) ($row['id'] ?? 0);
            if ($id < 1) {
                continue;
            }
            $itemsById[$id] = $row;
            $bundleIds[] = (int) ($row['bundle_id'] ?? 0);
        }
        $bundleIds = array_values(array_unique(array_filter($bundleIds, static fn (int $id): bool => $id > 0)));
        if ($bundleIds === []) {
            return [];
        }
        $bundlesById = [];
        foreach (WeappDownloadBundle::whereIn('id', $bundleIds)->where('status', 1)->select()->toArray() as $row) {
            $bid = (int) ($row['id'] ?? 0);
            if ($bid > 0) {
                $bundlesById[$bid] = $row;
            }
        }

        $out = [];
        foreach ($links as $itemId) {
            $item = $itemsById[$itemId] ?? null;
            if ($item === null) {
                continue;
            }
            $bundle = $bundlesById[(int) ($item['bundle_id'] ?? 0)] ?? null;
            if ($bundle === null) {
                continue;
            }
            if (!self::memberListItemAllowed($item, $bundle)->isOk()) {
                continue;
            }
            $out[] = self::formatPublicItem($item, $bundle);
        }

        return $out;
    }

    /**
     * 会员「我的下载」列表：不做 token 消费/限流，仅校验可读与权限。
     *
     * @param array<string, mixed> $item
     * @param array<string, mixed> $bundle
     */
    private static function memberListItemAllowed(array $item, array $bundle)
    {
        $documentId = (int) ($bundle['document_id'] ?? 0);
        if ($documentId > 0 && !DownloadConfigService::documentEligible($documentId)) {
            return app(WeappSupportGateway::class)->resultFail('not_allowed');
        }
        $readCheck = DownloadAccessService::checkDocumentReadAccess($documentId);
        if (!$readCheck->isOk()) {
            return $readCheck;
        }
        $access = DownloadAccessService::checkBundleAccess($bundle);
        if (!$access->isOk()) {
            return $access;
        }
        if (DownloadAccessService::normalizeAccessMode((string) ($bundle['access_mode'] ?? 'free')) === 'points') {
            $unlock = DownloadAccessService::requirePointsUnlocked($bundle);
            if (!$unlock->isOk()) {
                return $unlock;
            }
        }

        return app(WeappSupportGateway::class)->resultOk(null, 'ok');
    }

    private static function deleteLocalFileIfExists(string $path): void
    {
        $path = trim($path);
        if ($path === '' || str_contains($path, '..')) {
            return;
        }
        $abs = self::resolveAbsolutePath($path);
        if ($abs !== '' && is_file($abs)) {
            app(WeappSupportGateway::class)->localFileUnlinkIfExists($abs);
        }
    }

}
