<?php
declare(strict_types=1);

namespace weapp\doc_bundle\service;

use app\common\service\weapp\WeappEntitlementGateway;
use app\common\contract\PluginApiCallableTrait;
use app\common\contract\PluginApiInterface;

/** 下载插件对外 API（跨插件经 PluginApiRegistry 调用） */
final class DownloadPublicApi implements PluginApiInterface
{
    use PluginApiCallableTrait;
    public function pluginIdentifier(): string
    {
        return 'doc_bundle';
    }

    public function isActive(): bool
    {
        DownloadPluginBootstrap::ensureAutoload();

        return app(WeappEntitlementGateway::class)->entitlementCan('doc_bundle');
    }

    /** @return list<array<string, mixed>> */
    public function listForDocument(int $documentId, bool $forAdmin = false): array
    {
        DownloadPluginBootstrap::ensureAutoload();

        return DownloadBundleQueryService::listForDocument($documentId, $forAdmin);
    }

    /**
     * @param list<int> $bundleIds
     * @return list<array{path:string,name:string}>
     */
    public function listSearchAttachmentPaths(int $documentId, array $bundleIds): array
    {
        DownloadPluginBootstrap::ensureAutoload();

        return DownloadKernelBridgeService::listSearchAttachmentPaths($documentId, $bundleIds);
    }

    /**
     * 日下载配额状态（不扣次）。
     *
     * @return array{ok:bool,enabled:bool,limit:int,used:int,remaining:int,message:string}
     */
    public function dailyQuotaStatus(int $memberId, int $memberLevelId, string $scene): array
    {
        DownloadPluginBootstrap::ensureAutoload();
        if (!$this->isActive()) {
            return [
                'ok'        => true,
                'enabled'   => false,
                'limit'     => 0,
                'used'      => 0,
                'remaining' => -1,
                'message'   => '',
            ];
        }

        return DownloadDailyQuotaService::status($memberId, $memberLevelId, $scene);
    }

    /**
     * 鉴权通过后扣 1 次日配额；插件未启用则放行。
     *
     * @return array{ok:bool,enabled:bool,limit:int,used:int,remaining:int,message:string}
     */
    public function consumeDailyQuota(int $memberId, int $memberLevelId, string $scene): array
    {
        DownloadPluginBootstrap::ensureAutoload();
        if (!$this->isActive()) {
            return [
                'ok'        => true,
                'enabled'   => false,
                'limit'     => 0,
                'used'      => 0,
                'remaining' => -1,
                'message'   => '',
            ];
        }

        return DownloadDailyQuotaService::consume($memberId, $memberLevelId, $scene);
    }

    /** 货架模板/整站挂到「相关下载」的固定包标题（单管线，禁 attrs.download_seats）。 */
    public const MARKET_BUNDLE_TITLE = '模板下载';

    /** @var array<string, string> kind → 相关下载项 label */
    public const MARKET_KIND_LABELS = [
        'html'   => 'HTML模板',
        'pivark' => 'PivArk模板',
        'site'   => '整站源码',
    ];

    /**
     * 审包/sync：把私有包 zip 挂到文档「相关下载」（upsert 同名包）。
     *
     * @param list<array{kind?:string,label?:string,file_path:string,file_size?:int}> $seats
     * @return array{ok:bool,bundle_id?:int,message:string}
     */
    public function upsertMarketPackageBundle(int $documentId, array $seats): array
    {
        DownloadPluginBootstrap::ensureAutoload();
        if (!$this->isActive()) {
            return ['ok' => false, 'message' => 'doc_bundle 未启用'];
        }
        if ($documentId < 1) {
            return ['ok' => false, 'message' => 'document_id 无效'];
        }

        $bundleId = 0;
        foreach (DownloadBundleQueryService::listForDocument($documentId, true) as $bundle) {
            if (!is_array($bundle)) {
                continue;
            }
            if (trim((string) ($bundle['title'] ?? '')) === self::MARKET_BUNDLE_TITLE) {
                $bundleId = (int) ($bundle['id'] ?? 0);
                break;
            }
        }

        if ($seats === []) {
            if ($bundleId > 0) {
                $del = DownloadBundleService::deleteBundleAdmin($bundleId);
                if (is_object($del) && method_exists($del, 'isOk') && !$del->isOk()) {
                    return ['ok' => false, 'message' => (string) ($del->message() ?? '清空失败')];
                }
            }

            return ['ok' => true, 'bundle_id' => 0, 'message' => '无包可挂'];
        }

        $items = [];
        $sort = 0;
        foreach ($seats as $seat) {
            if (!is_array($seat)) {
                continue;
            }
            $path = trim((string) ($seat['file_path'] ?? ''));
            if ($path === '' || str_contains($path, '..') || !str_starts_with($path, 'private/market/packages/')) {
                continue;
            }
            $kind = strtolower(trim((string) ($seat['kind'] ?? '')));
            $label = trim((string) ($seat['label'] ?? ''));
            if ($label === '' && $kind !== '' && isset(self::MARKET_KIND_LABELS[$kind])) {
                $label = self::MARKET_KIND_LABELS[$kind];
            }
            if ($label === '') {
                $label = '本地下载';
            }
            $items[] = [
                'source_type'  => 'local',
                'file_path'    => $path,
                'file_size'    => max(0, (int) ($seat['file_size'] ?? 0)),
                'label'        => $label,
                'extract_code' => $kind,
                'sort'         => $sort++,
                'status'       => 1,
            ];
        }
        if ($items === []) {
            return ['ok' => false, 'message' => '无有效私有包路径'];
        }

        $saved = DownloadBundleService::saveBundleAdmin([
            'id'              => $bundleId,
            'document_id'     => $documentId,
            'title'           => self::MARKET_BUNDLE_TITLE,
            'access_mode'     => 'free',
            'price'           => 0,
            'member_level_id' => 0,
            'points_cost'     => 0,
            'sort'            => 0,
            'status'          => 1,
            'items'           => $items,
        ]);
        if (!is_object($saved) || !method_exists($saved, 'isOk') || !$saved->isOk()) {
            return [
                'ok'      => false,
                'message' => is_object($saved) && method_exists($saved, 'message')
                    ? (string) ($saved->message() ?? '保存失败')
                    : '保存失败',
            ];
        }
        $data = method_exists($saved, 'dataArray') ? ($saved->dataArray() ?? []) : [];

        return [
            'ok'        => true,
            'bundle_id' => (int) ($data['id'] ?? $bundleId),
            'message'   => 'ok',
        ];
    }

    /**
     * 买家出流：按 kind 从文档「模板下载」包解析绝对路径（禁 attrs.download_seats）。
     */
    public function resolveMarketPackageAbsolutePath(int $documentId, string $kind): string
    {
        DownloadPluginBootstrap::ensureAutoload();
        if (!$this->isActive() || $documentId < 1) {
            return '';
        }
        $kind = strtolower(trim($kind));
        if ($kind === '' || !isset(self::MARKET_KIND_LABELS[$kind])) {
            return '';
        }
        $wantLabel = self::MARKET_KIND_LABELS[$kind];

        foreach (DownloadBundleQueryService::listForDocument($documentId, true) as $bundle) {
            if (!is_array($bundle)) {
                continue;
            }
            if (trim((string) ($bundle['title'] ?? '')) !== self::MARKET_BUNDLE_TITLE) {
                continue;
            }
            $rows = is_array($bundle['items'] ?? null) ? $bundle['items'] : [];
            foreach ($rows as $row) {
                if (!is_array($row)) {
                    continue;
                }
                if ((int) ($row['status'] ?? 1) !== 1) {
                    continue;
                }
                $label = trim((string) ($row['label'] ?? ''));
                $code = strtolower(trim((string) ($row['extract_code'] ?? '')));
                $path = trim((string) ($row['file_path'] ?? ''));
                $match = $code === $kind
                    || $label === $wantLabel
                    || ($path !== '' && (str_contains($path, '-' . $kind . '-') || str_contains($path, '-' . $kind . '-latest')));
                if (!$match || $path === '' || !str_starts_with($path, 'private/market/packages/')) {
                    continue;
                }
                $abs = DownloadExportService::resolveAbsolutePath($path);
                if ($abs !== '' && is_file($abs)) {
                    return $abs;
                }
            }
        }

        return '';
    }
}