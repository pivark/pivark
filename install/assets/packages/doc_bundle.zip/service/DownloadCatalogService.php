<?php
declare(strict_types=1);

namespace weapp\doc_bundle\service;


use app\common\support\AppTime;
use weapp\doc_bundle\model\WeappDownloadItem;
use think\facade\Request;
use app\common\service\weapp\WeappEntitlementGateway;

/** 下载资源统计与 CSV 导出 */
final class DownloadCatalogService
{
    /**
     * @return list<array<string, mixed>>
     */
    public static function statsTopAdmin(int $limit = 10): array
    {
        if (!app(WeappEntitlementGateway::class)->entitlementCan('doc_bundle')) {
            return [];
        }
        $limit = min(50, max(5, $limit));
        $rows  = WeappDownloadItem::alias('i')
            ->join('weapp_doc_bundle_bundles b', 'b.id = i.bundle_id')
            ->field('i.id,i.label,i.source_type,i.download_count,b.title as bundle_title,b.document_id')
            ->order('i.download_count', 'desc')
            ->order('i.id', 'desc')
            ->limit($limit)
            ->select()
            ->toArray();

        return array_map(static fn (array $row): array => [
            'item_id'         => (int) ($row['id'] ?? 0),
            'label'           => (string) ($row['label'] ?? ''),
            'source_type'     => (string) ($row['source_type'] ?? ''),
            'download_count'  => (int) ($row['download_count'] ?? 0),
            'bundle_title'    => (string) ($row['bundle_title'] ?? ''),
            'document_id'     => (int) ($row['document_id'] ?? 0),
        ], $rows);
    }

    /**
     * @param array<string, mixed> $filters
     * @param list<int> $bundleIds
     * @return array{content:string,filename:string}
     */
    public static function exportCsvAdmin(array $filters = [], array $bundleIds = []): array
    {
        if (!app(WeappEntitlementGateway::class)->entitlementCan('doc_bundle')) {
            return ['content' => "\xEF\xBB\xBFcode,msg\n,-,插件未授权\n", 'filename' => 'download_stats.csv'];
        }

        DownloadPluginBootstrap::ensureAutoload();
        $params = array_merge($filters, ['page' => 1, 'limit' => 5000]);
        $paged  = DownloadBundleQueryService::listAdminPaged($params);
        $list   = $paged['list'] ?? [];
        if ($bundleIds !== []) {
            $idSet = array_flip(array_map('intval', $bundleIds));
            $list  = array_values(array_filter(
                $list,
                static fn (array $b): bool => isset($idSet[(int) ($b['id'] ?? 0)]),
            ));
        }

        $headers = [
            'bundle_id', 'bundle_title', 'document_id', 'access_mode', 'status', 'sort',
            'item_id', 'item_label', 'source_type', 'remote_url', 'download_count', 'link_check_status',
        ];
        $lines = [self::csvLine($headers)];
        foreach ($list as $bundle) {
            $items = (array) ($bundle['items'] ?? []);
            if ($items === []) {
                $lines[] = self::csvLine([
                    (string) ($bundle['id'] ?? ''),
                    (string) ($bundle['title'] ?? ''),
                    (string) ($bundle['document_id'] ?? ''),
                    (string) ($bundle['access_mode'] ?? ''),
                    (string) ($bundle['status'] ?? ''),
                    (string) ($bundle['sort'] ?? '0'),
                    '', '', '', '', '', '',
                ]);
                continue;
            }
            foreach ($items as $item) {
                $lines[] = self::csvLine([
                    (string) ($bundle['id'] ?? ''),
                    (string) ($bundle['title'] ?? ''),
                    (string) ($bundle['document_id'] ?? ''),
                    (string) ($bundle['access_mode'] ?? ''),
                    (string) ($bundle['status'] ?? ''),
                    (string) ($bundle['sort'] ?? '0'),
                    (string) ($item['id'] ?? ''),
                    (string) ($item['label'] ?? ''),
                    (string) ($item['source_type'] ?? ''),
                    (string) ($item['remote_url'] ?? ''),
                    (string) ($item['download_count'] ?? '0'),
                    (string) ($item['link_check_status'] ?? ''),
                ]);
            }
        }

        return [
            'content'  => "\xEF\xBB\xBF" . implode("\n", $lines) . "\n",
            'filename' => 'download_stats_' . AppTime::format('Ymd_His') . '.csv',
        ];
    }

    /** @param list<string|int|float|null> $cols */
    private static function csvLine(array $cols): string
    {
        $out = [];
        foreach ($cols as $v) {
            $s     = (string) $v;
            $s     = str_replace(["\r", "\n", '"'], [' ', ' ', '""'], $s);
            $out[] = str_contains($s, ',') || str_contains($s, '"') ? '"' . $s . '"' : $s;
        }

        return implode(',', $out);
    }

    /**
     * @return array<string, mixed>
     */
    public static function statsDashboardAdmin(): array
    {
        if (!app(WeappEntitlementGateway::class)->entitlementCan('doc_bundle')) {
            return ['platform_breakdown' => [], 'access_breakdown' => [], 'top' => []];
        }
        DownloadPluginBootstrap::ensureAutoload();

        $platform = [];
        $access   = [];
        $paged    = DownloadBundleQueryService::listAdminPaged(['page' => 1, 'limit' => 5000]);
        foreach ($paged['list'] ?? [] as $bundle) {
            $mode = (string) ($bundle['access_mode'] ?? 'free');
            $access[$mode] = ($access[$mode] ?? 0) + 1;
            foreach ((array) ($bundle['items'] ?? []) as $item) {
                if ((string) ($item['source_type'] ?? '') !== 'remote') {
                    continue;
                }
                $pid = DownloadPanPlatformService::fromItem($item)['id'] ?? 'other';
                $platform[$pid] = ($platform[$pid] ?? 0) + 1;
            }
        }

        $platformRows = [];
        foreach ($platform as $id => $count) {
            $platformRows[] = [
                'platform_id' => (string) $id,
                'label'       => DownloadPanPlatformService::platformLabel((string) $id),
                'count'       => $count,
            ];
        }
        usort($platformRows, static fn (array $a, array $b): int => ($b['count'] ?? 0) <=> ($a['count'] ?? 0));

        $accessRows = [];
        foreach ($access as $mode => $count) {
            $accessRows[] = ['access_mode' => $mode, 'count' => $count];
        }

        return [
            'platform_breakdown' => $platformRows,
            'access_breakdown'   => $accessRows,
            'top'                => self::statsTopAdmin(15),
        ];
    }

}
