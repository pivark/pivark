<?php
declare(strict_types=1);

namespace weapp\doc_bundle\service;

use app\common\service\weapp\WeappConfigGateway;
use app\common\service\weapp\WeappPluginGateway;
use app\common\service\weapp\WeappSiteGateway;

final class DownloadAdminSpaMeta
{
    /** @param array<string, mixed> $ctx @return array<string, mixed> */
    public static function build(array $ctx): array
    {
        DownloadPluginBootstrap::ensureAutoload();
        $configGw = app(WeappConfigGateway::class);
        $pluginGw = app(WeappPluginGateway::class);
        $cfg         = DownloadConfigService::all();
        $linkSummary = DownloadLinkCheckService::summary();
        $stats       = [
            'bundle_count'   => (int) $configGw->weappDb('doc_bundle', 'bundles')->count(),
            'item_count'     => (int) $configGw->weappDb('doc_bundle', 'items')->count(),
            'download_total' => (int) $configGw->weappDb('doc_bundle', 'items')->sum('download_count'),
            'scope_label'    => DownloadConfigService::scopeLabel(),
            'link_check'     => $linkSummary,
        ];

        return [
            'cfg'             => $cfg,
            'stats'           => $stats,
            'health'          => DownloadHealthService::healthCheckAdmin(),
            'stats_top'       => DownloadCatalogService::statsTopAdmin(10),
            'stats_dashboard' => DownloadCatalogService::statsDashboardAdmin(),
            'navOptions'      => app(WeappSiteGateway::class)->siteNavListContentCategoryOptions(),
            'slotCards'       => $pluginGw->pluginEditorSurfaceSlotCards('doc_bundle'),
            'editorSlot'      => $pluginGw->pluginEditorResolveSlot('doc_bundle'),
            'plugin'          => $pluginGw->pluginPresentationForAdmin('doc_bundle'),
        ];
    }
}
