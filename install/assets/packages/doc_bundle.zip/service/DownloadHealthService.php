<?php
declare(strict_types=1);

namespace weapp\doc_bundle\service;

use app\common\service\weapp\WeappEntitlementGateway;
use weapp\doc_bundle\model\WeappDownloadBundle;
use think\facade\Db;

/** 下载插件后台健康检查 */
final class DownloadHealthService
{
    /**
     * @return array{checks:list<array{key:string,label:string,count:int,severity:string,hint:string,route:string}>,score:int}
     */
    public static function healthCheckAdmin(): array
    {
        if (!app(WeappEntitlementGateway::class)->entitlementCan('doc_bundle')) {
            return ['checks' => [], 'score' => 0];
        }

        $checks = [];
        $link   = DownloadLinkCheckService::summary();
        $bad    = (int) ($link['fail'] ?? 0) + (int) ($link['warn'] ?? 0);
        $checks[] = [
            'key'      => 'link_fail',
            'label'    => '远程链接异常',
            'count'    => $bad,
            'severity' => $bad > 0 ? 'warning' : 'ok',
            'hint'     => '在资源列表勾选后「巡检选中」，或使用 scope=failed 批量巡检',
            'route'    => '/weapp/host/doc_bundle/resources',
        ];
        $unknown = (int) ($link['unknown'] ?? 0);
        if ($unknown > 0) {
            $checks[] = [
                'key'      => 'link_unknown',
                'label'    => '远程链接未巡检',
                'count'    => $unknown,
                'severity' => 'info',
                'hint'     => '建议对异常/陈旧项执行链接巡检',
                'route'    => '/weapp/host/doc_bundle/resources',
            ];
        }

        $pfx = (string) config('database.connections.mysql.prefix');
        $emptyBundles = (int) (Db::query(
            "SELECT COUNT(*) AS c FROM `{$pfx}weapp_doc_bundle_bundles` b
             WHERE b.status = 1 AND NOT EXISTS (
               SELECT 1 FROM `{$pfx}weapp_doc_bundle_items` i WHERE i.bundle_id = b.id
             )",
        )[0]['c'] ?? 0);
        $checks[] = [
            'key'      => 'empty_bundle',
            'label'    => '启用中的空资源包',
            'count'    => $emptyBundles,
            'severity' => $emptyBundles > 0 ? 'warning' : 'ok',
            'hint'     => '为资源包添加至少一条本地或远程资源项',
            'route'    => '/weapp/host/doc_bundle/resources',
        ];

        $orphan = (int) (Db::query(
            "SELECT COUNT(*) AS c FROM `{$pfx}weapp_doc_bundle_bundles` b
             WHERE b.document_id > 0 AND NOT EXISTS (
               SELECT 1 FROM `{$pfx}documents` d WHERE d.id = b.document_id
             )",
        )[0]['c'] ?? 0);
        $checks[] = [
            'key'      => 'orphan_document',
            'label'    => '绑定文档已不存在',
            'count'    => $orphan,
            'severity' => $orphan > 0 ? 'warning' : 'ok',
            'hint'     => '清理或重新绑定有效文档',
            'route'    => '/weapp/host/doc_bundle/resources',
        ];

        $paidZero = (int) WeappDownloadBundle::whereIn('access_mode', ['paid', 'member_paid'])
            ->where('price', '<=', 0)
            ->count();
        $checks[] = [
            'key'      => 'paid_zero',
            'label'    => '付费模式但未设价格',
            'count'    => $paidZero,
            'severity' => $paidZero > 0 ? 'warning' : 'ok',
            'hint'     => '设置 price 或改为免费/积分模式',
            'route'    => '/weapp/host/doc_bundle/resources',
        ];

        $score = 100;
        foreach ($checks as $c) {
            if (($c['severity'] ?? '') === 'warning' && (int) ($c['count'] ?? 0) > 0) {
                $score -= min(15, (int) ($c['count'] ?? 0) * 3);
            } elseif (($c['severity'] ?? '') === 'info' && (int) ($c['count'] ?? 0) > 0) {
                $score -= min(8, (int) ($c['count'] ?? 0));
            }
        }

        return ['checks' => $checks, 'score' => max(0, min(100, $score))];
    }
}
