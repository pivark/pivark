<?php
declare(strict_types=1);

namespace weapp\doc_bundle\service;

use app\common\service\weapp\WeappEntitlementGateway;

/** 前台展示增强：摘要条、链接角标、复制载荷 */
final class DownloadDisplayService
{
    /**
     * 标签 {pv:doc_bundle_meta}：输出资源摘要条 HTML
     *
     * @param array<string, string> $attrs
     * @param array<string, mixed> $pageVars
     */
    public static function renderMetaTag(array $attrs, array $pageVars, string $tpl): string
    {
        if (!app(WeappEntitlementGateway::class)->entitlementCan('doc_bundle')) {
            return '';
        }
        $documentId = (int) ($attrs['id'] ?? $attrs['aid'] ?? $attrs['document_id'] ?? $pageVars['document_id'] ?? 0);
        if ($documentId < 1) {
            return '';
        }
        $summary = self::documentSummary($documentId);
        if (($summary['item_count'] ?? 0) < 1) {
            return '';
        }

        DownloadFrontAssets::registerBase();

        $itemCount = (int) $summary['item_count'];
        $remote    = (int) $summary['remote_count'];
        $local     = (int) $summary['local_count'];
        $sizeText  = htmlspecialchars((string) ($summary['size_text'] ?? ''), ENT_QUOTES, 'UTF-8');
        $dlTotal   = (int) ($summary['download_total'] ?? 0);

        $parts = [
            '<span class="pv-doc-downloads__summary-stat"><strong>' . $itemCount . '</strong> 个资源</span>',
        ];
        if ($sizeText !== '' && $sizeText !== '0 B') {
            $parts[] = '<span class="pv-doc-downloads__summary-stat">Լ <strong>' . $sizeText . '</strong></span>';
        }
        if ($remote > 0) {
            $parts[] = '<span class="pv-doc-downloads__summary-stat"><strong>' . $remote . '</strong> 个网盘</span>';
        }
        if ($local > 0) {
            $parts[] = '<span class="pv-doc-downloads__summary-stat"><strong>' . $local . '</strong> 个本地</span>';
        }
        if ($dlTotal > 0) {
            $parts[] = '<span class="pv-doc-downloads__summary-stat">累计 <strong>' . $dlTotal . '</strong> 次下载</span>';
        }

        return '<div class="pv-doc-downloads__summary" role="status">'
            . implode('<span class="pv-doc-downloads__summary-sep" aria-hidden="true">·</span>', $parts)
            . '</div>';
    }

    /**
     * @return array{item_count:int,remote_count:int,local_count:int,download_total:int,size_bytes:int,size_text:string}
     */
    public static function documentSummary(int $documentId): array
    {
        $bundles = DownloadBundleQueryService::listForDocument($documentId);
        $itemCount = 0;
        $remote    = 0;
        $local     = 0;
        $dlTotal   = 0;
        $sizeBytes = 0;

        foreach ($bundles as $bundle) {
            if ((int) ($bundle['status'] ?? 0) !== 1) {
                continue;
            }
            foreach ((array) ($bundle['items'] ?? []) as $item) {
                if ((int) ($item['status'] ?? 0) !== 1) {
                    continue;
                }
                $itemCount++;
                $type = (string) ($item['source_type'] ?? 'local');
                if ($type === 'remote') {
                    $remote++;
                } else {
                    $local++;
                    $sizeBytes += (int) ($item['file_size'] ?? 0);
                }
                $dlTotal += (int) ($item['download_count'] ?? 0);
            }
        }

        return [
            'item_count'      => $itemCount,
            'remote_count'    => $remote,
            'local_count'     => $local,
            'download_total'  => $dlTotal,
            'size_bytes'      => $sizeBytes,
            'size_text'       => DownloadTemplateRenderService::formatSize($sizeBytes),
        ];
    }

    /**
     * @param array<string, mixed> $item
     * @return array<string, scalar>
     */
    public static function publicItemExtras(array $item): array
    {
        $pan   = DownloadPanPlatformService::fromItem($item);
        $badge = self::linkCheckBadge($item);

        $remote = trim((string) ($item['remote_url'] ?? ''));
        $code   = trim((string) ($item['extract_code'] ?? ''));
        $label  = trim((string) ($item['label'] ?? ''));
        $copy   = self::buildCopyText($remote, $code, $label);

        return [
            'platform_id'            => (string) $pan['id'],
            'platform_icon_url'      => (string) $pan['icon_url'],
            'platform_label'         => (string) $pan['label'],
            'link_check_status'      => (string) ($badge['status'] ?? 'unknown'),
            'link_check_label'       => (string) ($badge['label'] ?? ''),
            'link_check_hint'        => (string) ($badge['hint'] ?? ''),
            'link_check_badge_class' => (string) ($badge['class'] ?? ''),
            'copy_text'              => $copy,
        ];
    }

    /**
     * @param array<string, mixed> $item
     * @return array{status:string,label:string,hint:string,class:string}
     */
    public static function linkCheckBadge(array $item): array
    {
        if ((string) ($item['source_type'] ?? '') !== 'remote') {
            return ['status' => 'na', 'label' => '', 'hint' => '', 'class' => ''];
        }
        $status = (string) ($item['link_check_status'] ?? 'unknown');
        $at     = (string) ($item['link_check_at'] ?? '');
        $hintAt = $at !== '' ? ('最近检测：' . $at) : '尚未巡检';

        return match ($status) {
            'ok' => [
                'status' => 'ok',
                'label'  => '链接可用',
                'hint'   => $hintAt,
                'class'  => 'pv-dl-freshness--ok',
            ],
            'warn' => [
                'status' => 'warn',
                'label'  => '需关注',
                'hint'   => (string) ($item['link_check_message'] ?? $hintAt),
                'class'  => 'pv-dl-freshness--warn',
            ],
            'fail' => [
                'status' => 'fail',
                'label'  => '可能失效',
                'hint'   => (string) ($item['link_check_message'] ?? $hintAt),
                'class'  => 'pv-dl-freshness--fail',
            ],
            default => [
                'status' => 'unknown',
                'label'  => '未巡检',
                'hint'   => $hintAt,
                'class'  => 'pv-dl-freshness--unknown',
            ],
        };
    }

    public static function buildCopyText(string $remoteUrl, string $extractCode, string $label): string
    {
        $lines = [];
        if ($label !== '') {
            $lines[] = $label;
        }
        if ($remoteUrl !== '') {
            $lines[] = '链接：' . $remoteUrl;
        }
        if ($extractCode !== '') {
            $lines[] = '提取码：' . $extractCode;
        }

        return implode("\n", $lines);
    }
}
