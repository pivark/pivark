<?php
/**
 * 元舟 PivArk — document-addon bridge handler（weapp SSOT）
 */
declare(strict_types=1);

namespace weapp\doc_bundle\service;

use app\common\contract\DocumentAddonBridgeHandlerInterface;
use app\common\service\weapp\WeappSupportGateway;
use app\common\service\weapp\WeappTemplateGateway;
use weapp\doc_bundle\service\DownloadDisplayService;
use weapp\doc_bundle\service\DownloadPluginBootstrap;
use app\common\contract\WeappPluginBridgeTrait;


/** 文档 ↔ download 插件桥接（Core 调用 weapp，避免控制器直连表） */
final class DownloadDocumentAddonBridge implements DocumentAddonBridgeHandlerInterface
{
    use WeappPluginBridgeTrait;

    
    

    public function isEnabled(): bool
    {
        return $this->bridgeEnabled('doc_bundle');
    }

    public function identifier(): string
    {
        return 'doc_bundle';
    }
    /** resetExtensionTags 后须每请求重注册（同 comment document-addon） */
    public function bootTemplateTag(): void
    {
        app(WeappTemplateGateway::class)->templateRegisterExtensionTag('doc_bundle', [DownloadTemplateRenderService::class, 'renderTag']);
        app(WeappTemplateGateway::class)->templateRegisterExtensionTag('doc_bundle_meta', [DownloadDisplayService::class, 'renderMetaTag']);
    }


    /** @return array<string, mixed> */
    public function documentEditorSpaPayload(int $documentId): array
    {
        return [
            'save_field' => 'downloads_json',
            'editor_group_mode' => DownloadConfigService::editorGroupMode(),
            'front_group_mode'  => DownloadConfigService::frontGroupMode(),
            'bundles'    => $documentId > 0 ? $this->listForDocument($documentId, true) : [],
        ];
    }

    /**
     * @return list<array<string, mixed>>
     */
    public function listForDocument(int $documentId, bool $forAdmin = false): array
    {
        if (!$this->isEnabled() || $documentId < 1) {
            return [];
        }
        $this->ensurePluginLoaded();

        return \weapp\doc_bundle\service\DownloadBundleQueryService::listForDocument($documentId, $forAdmin);
    }

    /**
     * @param list<array<string, mixed>> $bundles
     * @return mixed
     */
    public function syncForDocument(int $documentId, array $bundles)
    {
        if (!$this->isEnabled() || $documentId < 1) {
            return app(WeappSupportGateway::class)->resultFail('参数错误');
        }
        $this->ensurePluginLoaded();

        return \weapp\doc_bundle\service\DownloadBundleService::syncDocumentBundles($documentId, $bundles);
    }

    public function documentEligible(int $documentId): bool
    {
        if (!$this->isEnabled() || $documentId < 1) {
            return false;
        }

        $this->ensurePluginLoaded();

        return \weapp\doc_bundle\service\DownloadConfigService::documentEligible($documentId);
    }

    /**
     * arclist has/nohas：挂有下载包的文档 ID。
     *
     * @return list<int>
     */
    public function documentIdsWithAvailability(): array
    {
        if (!$this->isEnabled()) {
            return [];
        }
        $this->ensurePluginLoaded();

        return \weapp\doc_bundle\service\DownloadBundleQueryService::documentIdsWithBundles();
    }

    /** 模板 flag：文档是否有可展示下载包 */
    public function hasAvailabilityForDocument(int $documentId): bool
    {
        if (!$this->isEnabled() || $documentId < 1) {
            return false;
        }
        $this->ensurePluginLoaded();

        return $this->listForDocument($documentId, false) !== [];
    }

    /** @param array<string, mixed> $data @return mixed */
    public function save(array $data)
    {
        if (!$this->isEnabled()) {
            return app(WeappSupportGateway::class)->resultFail('下载插件未启用');
        }
        $this->ensurePluginLoaded();

        return \weapp\doc_bundle\service\DownloadBundleService::saveBundleAdmin($data);
    }

    /** @return mixed */
    public function delete(int $id)
    {
        if (!$this->isEnabled()) {
            return app(WeappSupportGateway::class)->resultFail('下载插件未启用');
        }
        $this->ensurePluginLoaded();

        return \weapp\doc_bundle\service\DownloadBundleService::deleteBundleAdmin($id);
    }

    /** 删文档时移除本篇下载包（不删 uploads 实体，由影子引用释放） */
    public function listSearchAttachmentPaths(int $documentId, array $bundleIds): array
    {
        if (!$this->isEnabled() || $documentId < 1 || $bundleIds === []) {
            return [];
        }
        $this->ensurePluginLoaded();

        return DownloadKernelBridgeService::listSearchAttachmentPaths($documentId, $bundleIds);
    }

    public function purgeForDocument(int $documentId): void
    {
        if (!$this->isEnabled() || $documentId < 1) {
            return;
        }
        $this->ensurePluginLoaded();
        $bundles = \weapp\doc_bundle\service\DownloadBundleQueryService::listForDocument($documentId);
        foreach ($bundles as $bundle) {
            $bid = (int) ($bundle['id'] ?? 0);
            if ($bid > 0) {
                \weapp\doc_bundle\service\DownloadBundleService::deleteBundleAdmin($bid);
            }
        }
    }


    /** @return array<string, scalar> */
    public function packFieldsForGalleryBundle(int $bundleId): array
    {
        if (!$this->isEnabled() || $bundleId < 1) {
            return [
                'pack_download'           => 0,
                'pack_download_url'       => '',
                'pack_download_size_text' => '',
                'pack_download_label'     => '',
            ];
        }
        $this->ensurePluginLoaded();
        $item = \weapp\doc_bundle\model\WeappDownloadItem::where('bundle_id', $bundleId)
            ->where('status', 1)
            ->order('sort', 'asc')
            ->order('id', 'asc')
            ->find();
        if ($item === null) {
            return [
                'pack_download'           => 0,
                'pack_download_url'       => '',
                'pack_download_size_text' => '',
                'pack_download_label'     => '',
            ];
        }
        $row = is_object($item) && method_exists($item, 'toArray') ? $item->toArray() : (array) $item;
        $itemId = (int) ($row['id'] ?? 0);
        if ($itemId < 1) {
            return [
                'pack_download'           => 0,
                'pack_download_url'       => '',
                'pack_download_size_text' => '',
                'pack_download_label'     => '',
            ];
        }
        $size = (int) ($row['file_size'] ?? 0);
        $sizeText = $size > 0
            ? \weapp\doc_bundle\service\DownloadTemplateRenderService::formatSize($size)
            : '';

        return [
            'pack_download'           => 1,
            'pack_download_url'       => '/api/v1/plugins/doc_bundle/files/' . $itemId
                . '?token=' . \weapp\doc_bundle\service\DownloadTokenService::issue($itemId),
            'pack_download_size_text' => $sizeText,
            'pack_download_label'     => '打包下载',
        ];
    }

    private function ensurePluginLoaded(): void
    {
        $this->registerWeappAutoload('doc_bundle');
        \weapp\doc_bundle\service\DownloadPluginBootstrap::ensureAutoload();
    }
}
