<?php
declare(strict_types=1);

namespace weapp\doc_bundle\service;

use think\db\Query;
use weapp\doc_bundle\model\WeappDownloadBundle;
use weapp\doc_bundle\model\WeappDownloadItem;
use weapp\doc_bundle\model\WeappDownloadPurchase;
use app\common\service\weapp\WeappMemberGateway;
use app\common\service\weapp\WeappSupportGateway;

/** 内核经 DocumentDownloadService 调用的 download 读模型门面（附件/统计/会员消费） */
final class DownloadKernelBridgeService
{
    public static function schemaBundleReady(): bool
    {
        return app(WeappSupportGateway::class)->dbModelExists(WeappDownloadBundle::class)
            && app(WeappSupportGateway::class)->dbModelExists(WeappDownloadItem::class);
    }

    public static function schemaPurchaseReady(): bool
    {
        return app(WeappSupportGateway::class)->dbModelExists(WeappDownloadPurchase::class);
    }

    /**
     * @param list<int> $bundleIds
     * @return list<array{path:string,name:string}>
     */
    public static function listSearchAttachmentPaths(int $documentId, array $bundleIds): array
    {
        if ($documentId < 1 || $bundleIds === [] || !self::schemaBundleReady()) {
            return [];
        }

        $rows = WeappDownloadItem::alias('i')
            ->join('weapp_doc_bundle_bundles b', 'b.id = i.bundle_id')
            ->where('b.document_id', $documentId)
            ->whereIn('b.id', $bundleIds)
            ->where('b.status', 1)
            ->where('i.status', 1)
            ->where('i.source_type', 'local')
            ->field('i.file_path,i.label,b.title as bundle_title')
            ->select()
            ->toArray();

        $items = [];
        foreach ($rows as $row) {
            $path = trim((string) ($row['file_path'] ?? ''));
            if ($path === '') {
                continue;
            }
            $name = trim((string) ($row['label'] ?? ''));
            if ($name === '') {
                $name = trim((string) ($row['bundle_title'] ?? ''));
            }
            $items[] = ['path' => $path, 'name' => $name];
        }

        return $items;
    }

    public static function unionPurchaseSqlPart(int $branchLimit): string
    {
        if (!self::schemaPurchaseReady()) {
            return '';
        }
        $purchase = (new WeappDownloadPurchase())->getTable();
        $title    = "CONCAT('资源包 #', `p`.`bundle_id`)";
        $join     = '';
        if (app(WeappSupportGateway::class)->dbModelExists(WeappDownloadBundle::class)) {
            $bundle = (new WeappDownloadBundle())->getTable();
            $title  = "COALESCE(NULLIF(`b`.`title`, ''), CONCAT('资源包 #', `p`.`bundle_id`))";
            $join   = " LEFT JOIN `{$bundle}` AS `b` ON `b`.`id` = `p`.`bundle_id`";
        }

        return "(SELECT CONCAT('purchase-', `p`.`id`) AS row_key, 'doc_bundle_paid' AS biz_type, `p`.`id` AS ref_id,"
            . " `p`.`user_id`, `p`.`amount`, 'yuan' AS unit, {$title} AS title,"
            . " CONCAT('bundle:', `p`.`bundle_id`) AS extra, `p`.`created_at`"
            . " FROM `{$purchase}` AS `p`{$join}"
            . " WHERE `p`.`status` = 1 AND `p`.`user_id` > 0"
            . " ORDER BY `p`.`created_at` DESC, `p`.`id` DESC LIMIT {$branchLimit})";
    }

    public static function countPurchases(int $userId, string $keyword): int
    {
        if (!self::schemaPurchaseReady()) {
            return 0;
        }
        $q = WeappDownloadPurchase::where('status', 1)->where('user_id', '>', 0);
        self::applyUserScope($q, $userId, 'user_id');
        self::applyPurchaseKeyword($q, $keyword, 'user_id');

        return (int) $q->count();
    }

    /**
     * @return list<array<string, mixed>>
     */
    public static function fetchPurchaseConsumptionRows(int $userId, string $keyword): array
    {
        if (!self::schemaPurchaseReady()) {
            return [];
        }

        $with = ['user' => static function ($userQuery): void {
            $userQuery->field('id,username,nickname');
        }];
        if (app(WeappSupportGateway::class)->dbModelExists(WeappDownloadBundle::class)) {
            $with['bundle'] = static function ($bundleQuery): void {
                $bundleQuery->field('id,title');
            };
        }
        $q = WeappDownloadPurchase::with($with)
            ->where('status', 1)
            ->where('user_id', '>', 0)
            ->order('id', 'desc');
        self::applyUserScope($q, $userId, 'user_id');
        self::applyPurchaseKeyword($q, $keyword, 'user_id');

        $out = [];
        foreach ($q->field('id,user_id,amount,bundle_id,created_at')->select() as $item) {
            $row = ModelRelationLoad::mergeBelongsTo($item, 'user', ['username', 'nickname']);
            if (app(WeappSupportGateway::class)->dbModelExists(WeappDownloadBundle::class)) {
                $row = ModelRelationLoad::mergeBelongsTo($item, 'bundle', ['title' => 'bundle_title']);
            }
            $title = trim((string) ($row['bundle_title'] ?? ''));
            if ($title === '') {
                $title = '资源包 #' . (int) ($row['bundle_id'] ?? 0);
            }
            $out[] = [
                'row_key'    => 'purchase-' . $row['id'],
                'biz_type'   => 'doc_bundle_paid',
                'ref_id'     => (int) $row['id'],
                'user_id'    => (int) $row['user_id'],
                'amount'     => (float) ($row['amount'] ?? 0),
                'unit'       => 'yuan',
                'title'      => $title,
                'extra'      => 'bundle:' . (int) ($row['bundle_id'] ?? 0),
                'created_at' => (string) ($row['created_at'] ?? ''),
                'username'   => (string) ($row['username'] ?? ''),
                'nickname'   => (string) ($row['nickname'] ?? ''),
            ];
        }

        return $out;
    }

    /** @return list<int> */
    public static function bundleIdsMatchingTitleLike(string $likePattern): array
    {
        if (!app(WeappSupportGateway::class)->dbModelExists(WeappDownloadBundle::class)) {
            return [];
        }

        return array_values(array_filter(array_map(
            static fn (mixed $id): int => (int) $id,
            WeappDownloadBundle::whereLike('title', $likePattern)->column('id'),
        ), static fn (int $id): bool => $id > 0));
    }

    /**
     * @param list<int> $ids
     * @return array<int, array<string, mixed>>
     */
    public static function bundlesByIds(array $ids): array
    {
        if ($ids === [] || !app(WeappSupportGateway::class)->dbModelExists(WeappDownloadBundle::class)) {
            return [];
        }
        $out = [];
        foreach (WeappDownloadBundle::whereIn('id', array_values($ids))->select()->toArray() as $row) {
            if (!is_array($row)) {
                continue;
            }
            $id = (int) ($row['id'] ?? 0);
            if ($id > 0) {
                $out[$id] = $row;
            }
        }

        return $out;
    }

    private static function applyUserScope(Query $query, int $userId, string $field): void
    {
        if ($userId > 0) {
            $query->where($field, $userId);
        }
    }

    private static function applyPurchaseKeyword(Query $query, string $keyword, string $userIdField): void
    {
        if ($keyword === '') {
            return;
        }
        if (ctype_digit($keyword)) {
            $query->where($userIdField, (int) $keyword);

            return;
        }
        $like = '%' . addcslashes($keyword, '%_\\') . '%';
        $userIds = app(WeappMemberGateway::class)->memberUserIdsByUsernameNicknameLike($like);
        $query->where(function (Query $sub) use ($like, $userIdField, $userIds): void {
            $hasClause = false;
            if ($userIds !== []) {
                $sub->whereIn($userIdField, $userIds);
                $hasClause = true;
            }
            $bundleIds = self::bundleIdsMatchingTitleLike($like);
            if ($bundleIds !== []) {
                if ($hasClause) {
                    $sub->whereOr('bundle_id', 'in', $bundleIds);
                } else {
                    $sub->whereIn('bundle_id', $bundleIds);
                    $hasClause = true;
                }
            }
            if (!$hasClause) {
                $sub->where($userIdField, 0);
            }
        });
    }
}
