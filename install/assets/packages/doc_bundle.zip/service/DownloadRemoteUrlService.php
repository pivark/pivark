<?php
declare(strict_types=1);

namespace weapp\doc_bundle\service;

final class DownloadRemoteUrlService
{
    public static function validate(string $url): string
    {
        $url = trim($url);
        if ($url === '') {
            return '远程地址不能为空';
        }
        if (!preg_match('#^https?://#i', $url)) {
            return '远程地址须以 http:// 或 https:// 开头';
        }
        $host = strtolower((string) parse_url($url, PHP_URL_HOST));
        if ($host === '') {
            return '远程地址无效';
        }
        if (self::isBlockedHost($host)) {
            return '不允许内网或本地地址';
        }
        if (filter_var($host, FILTER_VALIDATE_IP)) {
            return self::isPublicIp($host) ? '' : '不允许内网或本地地址';
        }

        return '';
    }

    private static function isBlockedHost(string $host): bool
    {
        if ($host === 'localhost' || str_ends_with($host, '.local') || str_ends_with($host, '.localhost')) {
            return true;
        }
        $blocked = ['0.0.0.0', '127.0.0.1', '::1', 'metadata.google.internal'];
        if (in_array($host, $blocked, true)) {
            return true;
        }

        return false;
    }

    private static function isPublicIp(string $ip): bool
    {
        return filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) !== false;
    }
}
