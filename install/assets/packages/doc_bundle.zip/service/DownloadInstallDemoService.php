<?php
declare(strict_types=1);

namespace weapp\doc_bundle\service;

use app\common\service\weapp\WeappConfigGateway;
use app\common\service\weapp\WeappPluginGateway;

/** 下载插件：安装向导首次装插件时的默认演示数据 */
final class DownloadInstallDemoService
{
    public static function seed(): void
    {
        $cfg     = app(WeappConfigGateway::class);
        $tagSlug = 'pv-demo-download';
        $tagIds  = [
            $tagSlug => $cfg->installDemoUpsertTag([
                'slug'        => $tagSlug,
                'name'        => '资料下载',
                'tpl'         => 'list_document_download.php',

                'nav_sort'    => 7,
                'description' => '产品手册、安装指南、资质文件与 CAD 图纸',
                'url_path'    => 'downloads',
            ]),
        ];
        $docId = $cfg->installDemoUpsertDocument(
            'pv-demo-download-01',
            'HY-810 产品资料包',
            '演示下载插件：本页挂载示例资源包，含远程链接占位。',
            '<p>本篇为下载插件自带演示文档，可在后台替换为真实附件。</p>',
        );
        $cfg->installDemoLinkDocumentTags($docId, [$tagSlug], $tagIds);
        $cfg->installDemoAppendContentCategoryNav('downloads', '资料下载', 7);
        self::seedFreeBundle($docId, '演示附件包', '产品手册（演示远程）');
        self::seedBundlesForDownloadChannelDocs();
        $cfg->installDemoRefreshTagUseCounts();
    }

    /**
     * 为频道 pv-demo-download / html_name=pv-demo-download-* 挂免费附件包（缺则补）。
     *
     * @return int 新写入篇数
     */
    public static function seedBundlesForDownloadChannelDocs(): int
    {
        $cfg = app(WeappConfigGateway::class);
        $docIds = [];
        foreach ($cfg->installDemoDocumentIdsByTagSlug('pv-demo-download') as $id) {
            $docIds[$id] = true;
        }
        foreach ($cfg->installDemoDocumentIdsByHtmlPrefix('pv-demo-download-') as $id) {
            $docIds[$id] = true;
        }

        $written = 0;
        foreach (array_keys($docIds) as $documentId) {
            $documentId = (int) $documentId;
            if ($documentId < 1) {
                continue;
            }
            try {
                $existing = DownloadBundleQueryService::listForDocument($documentId, true);
                if ($existing !== []) {
                    continue;
                }
            } catch (\Throwable) {
                // continue seed attempt
            }
            $title = $cfg->installDemoDocumentField($documentId, 'title') ?: '资料附件包';
            if (self::seedFreeBundle($documentId, $title . '（附件包）', $title . '（演示下载）')) {
                $written++;
            }
        }

        return $written;
    }

    private static function seedFreeBundle(int $documentId, string $bundleTitle = '演示附件包', string $itemLabel = '产品手册（演示）'): bool
    {
        if ($documentId < 1) {
            return false;
        }
        try {
            app(WeappPluginGateway::class)->pluginRegisterAutoloadPublic('doc_bundle');
            $item = self::resolveSeedItem($documentId, $itemLabel);
            $result = DownloadBundleService::saveBundleAdmin([
                'document_id' => $documentId,
                'title'       => $bundleTitle,
                'access_mode' => 'free',
                'status'      => 1,
                'sort'        => 0,
                'items'       => [$item],
            ]);

            return $result->isOk();
        } catch (\Throwable) {
            return false;
        }
    }

    /**
     * Prefer local uploads seed files (`uploads/demo-seed/download-files`).
     * VolumeSeed / seed_download_channel_complete 同目录。
     *
     * @return array<string, mixed>
     */
    private static function resolveSeedItem(int $documentId, string $itemLabel): array
    {
        $htmlName = app(WeappConfigGateway::class)->installDemoDocumentField($documentId, 'html_name');
        $map = [
            'pv-demo-download-01' => ['file' => 'HY-810-selection-guide.pdf', 'label' => 'HY-810 选型手册（PDF）'],
            'pv-demo-download-02' => ['file' => 'HY-810-install-guide.pdf', 'label' => 'HY-810 安装调试指南（PDF）'],
            'pv-demo-download-03' => ['file' => 'HY-series-cad-outline.zip', 'label' => 'HY 系列外形图（ZIP）'],
            'pv-demo-download-04' => ['file' => 'HY-810-modbus-hart.pdf', 'label' => 'HY-810 通讯协议（PDF）'],
            'pv-demo-download-05' => ['file' => 'HY-810-certificates.pdf', 'label' => 'HY-810 证书包（PDF）'],
            'pv-demo-download-06' => ['file' => 'company-qualification-pack.pdf', 'label' => '企业资质文件包（PDF）'],
        ];
        $meta = $map[$htmlName] ?? ['file' => 'HY-810-selection-guide.pdf', 'label' => $itemLabel];
        $rel = '/uploads/demo-seed/download-files/' . $meta['file'];
        $abs = rtrim((string) ROOT_PATH, '/\\') . DIRECTORY_SEPARATOR . 'public'
            . str_replace('/', DIRECTORY_SEPARATOR, $rel);
        if (is_file($abs)) {
            return [
                'label'       => (string) $meta['label'],
                'source_type' => 'local',
                'file_path'   => $rel,
                'file_size'   => (int) filesize($abs),
                'sort'        => 0,
                'status'      => 1,
            ];
        }

        // Fallback only when seed files not published yet
        return [
            'label'       => $itemLabel,
            'source_type' => 'remote',
            'remote_url'  => 'https://example.com/pivark-download-demo.pdf',
            'sort'        => 0,
        ];
    }
}
