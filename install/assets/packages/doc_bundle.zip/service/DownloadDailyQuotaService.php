<?php
/**
 * 元舟 PivArk — 企业全域原子化数字资产中枢
 * (c) 2024-2026 pivark.com. All rights reserved.
 * Author: Angelo
 * 未经允许，不可用于商业用途。
 */
declare(strict_types=1);

namespace weapp\doc_bundle\service;

use think\facade\Cache;
use app\common\service\weapp\WeappConfigGateway;

/**
 * 会员等级日下载配额（跨场景可复用：template / site / plugin / doc）。
 * 配置键 download_daily_quota_json；未启用或未装插件时调用方自行放行。
 */
final class DownloadDailyQuotaService
{
    public const CONFIG_KEY = 'download_daily_quota_json';

    /** @var list<string> */
    public const SCENES = ['template', 'site', 'plugin', 'doc'];

    /** @return array{enabled:bool,scenes:array<string,array{default:int,by_level_id:array<string,int>}>} */
    public static function config(): array
    {
        $raw = (string) app(WeappConfigGateway::class)->configGet(self::CONFIG_KEY, self::defaultJson());
        $decoded = json_decode($raw, true);
        if (!is_array($decoded)) {
            $decoded = json_decode(self::defaultJson(), true);
        }

        $enabled = (bool) ($decoded['enabled'] ?? true);
        $scenesIn = is_array($decoded['scenes'] ?? null) ? $decoded['scenes'] : [];
        $scenes = [];
        foreach (self::SCENES as $scene) {
            $row = is_array($scenesIn[$scene] ?? null) ? $scenesIn[$scene] : [];
            $byLevel = [];
            $rawLevels = is_array($row['by_level_id'] ?? null) ? $row['by_level_id'] : [];
            foreach ($rawLevels as $lid => $lim) {
                $lid = (string) (int) $lid;
                $lim = max(0, (int) $lim);
                if ($lid !== '0' || $lim > 0) {
                    $byLevel[$lid] = $lim;
                }
            }
            $scenes[$scene] = [
                'default'      => max(0, (int) ($row['default'] ?? 50)),
                'by_level_id'  => $byLevel,
            ];
        }

        return ['enabled' => $enabled, 'scenes' => $scenes];
    }

    public static function defaultJson(): string
    {
        $scenes = [];
        foreach (self::SCENES as $scene) {
            $scenes[$scene] = [
                'default'     => $scene === 'doc' ? 100 : 50,
                'by_level_id' => new \stdClass(),
            ];
        }

        return (string) json_encode(
            ['enabled' => true, 'scenes' => $scenes],
            JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
        );
    }

    public static function normalizeScene(string $scene): string
    {
        $scene = strtolower(trim($scene));

        return in_array($scene, self::SCENES, true) ? $scene : 'doc';
    }

    public static function limitFor(string $scene, int $memberLevelId): int
    {
        $cfg = self::config();
        $scene = self::normalizeScene($scene);
        $row = $cfg['scenes'][$scene] ?? ['default' => 50, 'by_level_id' => []];
        $by = is_array($row['by_level_id'] ?? null) ? $row['by_level_id'] : [];
        $key = (string) max(0, $memberLevelId);
        if ($key !== '0' && isset($by[$key])) {
            return max(0, (int) $by[$key]);
        }
        if (isset($by['0'])) {
            return max(0, (int) $by['0']);
        }

        return max(0, (int) ($row['default'] ?? 50));
    }

    /**
     * @return array{ok:bool,enabled:bool,limit:int,used:int,remaining:int,message:string}
     */
    public static function status(int $memberId, int $memberLevelId, string $scene): array
    {
        $cfg = self::config();
        $scene = self::normalizeScene($scene);
        if (!$cfg['enabled']) {
            return [
                'ok'        => true,
                'enabled'   => false,
                'limit'     => 0,
                'used'      => 0,
                'remaining' => -1,
                'message'   => '',
            ];
        }
        $limit = self::limitFor($scene, $memberLevelId);
        if ($limit < 1) {
            return [
                'ok'        => false,
                'enabled'   => true,
                'limit'     => 0,
                'used'      => 0,
                'remaining' => 0,
                'message'   => '当前会员等级暂无下载配额',
            ];
        }
        if ($memberId < 1) {
            return [
                'ok'        => false,
                'enabled'   => true,
                'limit'     => $limit,
                'used'      => 0,
                'remaining' => $limit,
                'message'   => '请先登录',
            ];
        }
        $used = self::usedCount($memberId, $scene);
        $remaining = max(0, $limit - $used);

        return [
            'ok'        => $remaining > 0,
            'enabled'   => true,
            'limit'     => $limit,
            'used'      => $used,
            'remaining' => $remaining,
            'message'   => $remaining > 0 ? '' : ('今日「' . $scene . '」下载次数已达上限（' . $limit . '）'),
        ];
    }

    /**
     * 鉴权通过后扣 1 次；超限不扣。
     *
     * @return array{ok:bool,enabled:bool,limit:int,used:int,remaining:int,message:string}
     */
    public static function consume(int $memberId, int $memberLevelId, string $scene): array
    {
        $st = self::status($memberId, $memberLevelId, $scene);
        if (!$st['enabled']) {
            return $st;
        }
        if (!$st['ok']) {
            return $st;
        }
        $scene = self::normalizeScene($scene);
        $key = self::cacheKey($memberId, $scene);
        $used = (int) Cache::get($key, 0);
        $used++;
        Cache::set($key, $used, self::ttlSeconds());
        $limit = (int) $st['limit'];

        return [
            'ok'        => true,
            'enabled'   => true,
            'limit'     => $limit,
            'used'      => $used,
            'remaining' => max(0, $limit - $used),
            'message'   => '',
        ];
    }

    /**
     * @param array<string, mixed> $data
     * @return mixed
     */
    public static function saveAdmin(array $data)
    {
        if (!array_key_exists('download_daily_quota_json', $data)
            && !array_key_exists('daily_quota', $data)
            && !array_key_exists('enabled', $data)
        ) {
            return app(\app\common\service\weapp\WeappSupportGateway::class)->resultOk(null, 'ok');
        }

        $raw = $data['download_daily_quota_json'] ?? $data['daily_quota'] ?? null;
        if (is_string($raw) && $raw !== '') {
            $decoded = json_decode($raw, true);
            if (!is_array($decoded)) {
                return app(\app\common\service\weapp\WeappSupportGateway::class)->resultFail('日配额 JSON 无效');
            }
        } elseif (is_array($raw)) {
            $decoded = $raw;
        } else {
            $decoded = self::config();
            if (array_key_exists('enabled', $data)) {
                $decoded['enabled'] = (bool) $data['enabled'];
            }
        }

        $normalized = self::normalizeConfigArray($decoded);
        app(WeappConfigGateway::class)->configSet(
            self::CONFIG_KEY,
            (string) json_encode($normalized, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)
        );

        return app(\app\common\service\weapp\WeappSupportGateway::class)->resultOk(null, '日配额已保存');
    }

    /** @param array<string, mixed> $decoded @return array{enabled:bool,scenes:array<string,mixed>} */
    private static function normalizeConfigArray(array $decoded): array
    {
        $enabled = (bool) ($decoded['enabled'] ?? true);
        $scenesIn = is_array($decoded['scenes'] ?? null) ? $decoded['scenes'] : [];
        $scenes = [];
        foreach (self::SCENES as $scene) {
            $row = is_array($scenesIn[$scene] ?? null) ? $scenesIn[$scene] : [];
            $byLevel = [];
            $rawLevels = is_array($row['by_level_id'] ?? null) ? $row['by_level_id'] : [];
            foreach ($rawLevels as $lid => $lim) {
                $lidInt = (int) $lid;
                if ($lidInt < 1) {
                    continue;
                }
                $byLevel[(string) $lidInt] = max(0, (int) $lim);
            }
            $scenes[$scene] = [
                'default'     => max(0, (int) ($row['default'] ?? 50)),
                'by_level_id' => $byLevel,
            ];
        }

        return ['enabled' => $enabled, 'scenes' => $scenes];
    }

    private static function usedCount(int $memberId, string $scene): int
    {
        return max(0, (int) Cache::get(self::cacheKey($memberId, $scene), 0));
    }

    private static function cacheKey(int $memberId, string $scene): string
    {
        return 'dl_daily_quota:' . $scene . ':' . $memberId . ':' . date('Ymd');
    }

    private static function ttlSeconds(): int
    {
        $end = strtotime('tomorrow 00:00:00');
        if ($end === false) {
            return 86400;
        }

        return max(60, $end - time() + 5);
    }
}
