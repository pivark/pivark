<?php
declare(strict_types=1);

namespace weapp\doc_bundle\service;



use app\common\support\AppTime;
use weapp\doc_bundle\model\WeappDownloadItem;
use app\common\service\weapp\WeappConfigGateway;
use app\common\service\weapp\WeappEntitlementGateway;
use app\common\service\weapp\WeappDocumentGateway;
use app\common\service\weapp\WeappSupportGateway;

/** 远程下载链接 HTTP 可达性巡检（网盘口令是否仍有效需人工判断） */
class DownloadLinkCheckService
{
    public const STATUS_UNKNOWN = 'unknown';
    public const STATUS_OK      = 'ok';
    public const STATUS_WARN    = 'warn';
    public const STATUS_FAIL    = 'fail';

    public static function timeoutSec(): int
    {
        return min(30, max(3, (int) app(WeappConfigGateway::class)->configGet('download_link_check_timeout_sec', 10)));
    }

    public static function batchLimit(): int
    {
        return min(200, max(5, (int) app(WeappConfigGateway::class)->configGet('download_link_check_batch_size', 40)));
    }

    /**
     * @return array{status:string,http_code:int,message:string}
     */
    public static function probeUrl(string $url): array
    {
        $url = trim($url);
        $err = DownloadRemoteUrlService::validate($url);
        if ($err !== '') {
            return ['status' => self::STATUS_FAIL, 'http_code' => 0, 'message' => $err];
        }

        if (!function_exists('curl_init')) {
            return ['status' => self::STATUS_WARN, 'http_code' => 0, 'message' => '服务器未启用 curl，无法巡检'];
        }

        $timeout = self::timeoutSec();
        $codes   = [];
        foreach (['HEAD', 'GET'] as $method) {
            $res = self::curlProbe($url, $method, $timeout);
            if ($res !== null) {
                $codes[] = $res;
                if ($res['status'] !== self::STATUS_FAIL || $method === 'GET') {
                    return $res;
                }
            }
        }

        return $codes[0] ?? ['status' => self::STATUS_FAIL, 'http_code' => 0, 'message' => '无法连接目标地址'];
    }

    /**
     * @return array{status:string,http_code:int,message:string}|null
     */
    private static function curlProbe(string $url, string $method, int $timeout): ?array
    {
        $ch = curl_init($url);
        if ($ch === false) {
            return null;
        }
        $opts = [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_MAXREDIRS      => 5,
            CURLOPT_CONNECTTIMEOUT => $timeout,
            CURLOPT_TIMEOUT        => $timeout,
            CURLOPT_NOBODY         => $method === 'HEAD',
            CURLOPT_USERAGENT      => 'Mozilla/5.0 (compatible; PivArkDownloadLinkCheck/1.0)',
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
        ];
        if ($method === 'GET') {
            $opts[CURLOPT_RANGE] = '0-0';
        }
        curl_setopt_array($ch, $opts);
        curl_exec($ch);
        $errno = curl_errno($ch);
        $err   = curl_error($ch);
        $code  = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($errno !== 0) {
            $msg = $err !== '' ? $err : '连接失败';

            return ['status' => self::STATUS_FAIL, 'http_code' => 0, 'message' => mb_substr($msg, 0, 200)];
        }

        if ($code >= 200 && $code < 400) {
            $hint = self::isPanHost($url)
                ? 'HTTP 可达（网盘分享是否仍有效请打开链接人工确认）'
                : 'HTTP 可达';

            return ['status' => self::STATUS_OK, 'http_code' => $code, 'message' => $hint];
        }
        if ($code === 405 || $code === 501) {
            return null;
        }
        if ($code >= 400) {
            return ['status' => self::STATUS_FAIL, 'http_code' => $code, 'message' => 'HTTP ' . $code];
        }

        return ['status' => self::STATUS_WARN, 'http_code' => $code, 'message' => 'HTTP ' . $code];
    }

    private static function isPanHost(string $url): bool
    {
        $host = strtolower((string) parse_url($url, PHP_URL_HOST));

        return (bool) preg_match(
            '/(pan\.baidu|yun\.baidu|pan\.quark|aliyundrive|alipan|cloud\.189|lanzou|123pan|123684|cowtransfer|feijipan)/i',
            $host
        );
    }

    public static function statusLabel(string $status): string
    {
        return match ($status) {
            self::STATUS_OK   => '正常',
            self::STATUS_WARN => '待确认',
            self::STATUS_FAIL => 'ʧЧ',
            default           => '未检测',
        };
    }

    /** @return mixed */
    public static function checkItemById(int $itemId)
    {
        if (!app(WeappEntitlementGateway::class)->entitlementCan('doc_bundle') || $itemId < 1) {
            return app(WeappSupportGateway::class)->resultFail('参数错误');
        }
        $item = WeappDownloadItem::where('id', $itemId)->find();
        if (!$item || (string) ($item['source_type'] ?? '') !== 'remote') {
            return app(WeappSupportGateway::class)->resultFail('仅支持远程链接项');
        }

        return app(WeappSupportGateway::class)->resultOk(['item' => self::checkAndPersistRow($item)], '已检测');
    }

    /**
     * @param list<int> $itemIds 空=按策略批量
     * @return mixed
     */
    public static function checkItemsAdmin(array $itemIds, string $scope = 'selected')
    {
        if (!app(WeappEntitlementGateway::class)->entitlementCan('doc_bundle')) {
            return app(WeappSupportGateway::class)->resultFail('插件未授权');
        }

        $limit = self::batchLimit();
        $query = WeappDownloadItem::alias('i')
            ->join('weapp_doc_bundle_bundles b', 'b.id = i.bundle_id')
            ->where('i.source_type', 'remote')
            ->where('i.remote_url', '<>', '')
            ->where('b.status', 1)
            ->field('i.*');

        $itemIds = array_values(array_unique(array_filter(array_map('intval', $itemIds), static fn (int $id): bool => $id > 0)));
        if ($itemIds !== []) {
            $query->whereIn('i.id', $itemIds);
        } elseif ($scope === 'failed') {
            $query->whereIn('i.link_check_status', [self::STATUS_FAIL, self::STATUS_WARN]);
        } elseif ($scope === 'stale') {
            $staleBefore = AppTime::format('Y-m-d H:i:s', time() - 7 * 86400);
            $query->whereRaw('(i.link_check_at IS NULL OR i.link_check_at < ?)', [$staleBefore]);
        }

        $rows = $query->order('i.link_check_at', 'asc')->order('i.id', 'asc')->limit($limit)->select()->toArray();
        if ($rows === []) {
            return app(WeappSupportGateway::class)->resultOk(['checked' => 0, 'items' => []], '没有需要检测的远程链接');
        }

        $out = [];
        foreach ($rows as $row) {
            $out[] = self::checkAndPersistRow($row);
            usleep(200000);
        }

        return app(WeappSupportGateway::class)->resultOk(['checked' => count($out), 'items' => $out], '已检测 ' . count($out) . ' 条（单次最多 ' . $limit . ' 条）');
    }

    /** 定时任务入口 */
    public static function runCron(): string
    {
        if (!app(WeappEntitlementGateway::class)->entitlementCan('doc_bundle')) {
            return 'SKIP:下载插件未授权';
        }
        $res = self::checkItemsAdmin([], 'stale');

        return (string) ($res->message() ?? '完成');
    }

    /**
     * @param array<string, mixed> $row
     * @return array<string, mixed>
     */
    private static function checkAndPersistRow(array $row): array
    {
        $id   = (int) ($row['id'] ?? 0);
        $url  = trim((string) ($row['remote_url'] ?? ''));
        $probe = self::probeUrl($url);
        $now   = app(WeappSupportGateway::class)->appTimeNow();
        WeappDownloadItem::where('id', $id)->update([
            'link_check_status'    => $probe['status'],
            'link_check_http_code' => (int) $probe['http_code'],
            'link_check_message'   => mb_substr((string) $probe['message'], 0, 250),
            'link_check_at'        => $now,
            'updated_at'           => $now,
        ]);

        return [
            'id'                   => $id,
            'link_check_status'    => $probe['status'],
            'link_check_status_label' => self::statusLabel($probe['status']),
            'link_check_http_code' => (int) $probe['http_code'],
            'link_check_message'   => $probe['message'],
            'link_check_at'        => $now,
        ];
    }

    /** @return array{ok:int,warn:int,fail:int,unknown:int,remote_total:int} */
    public static function summary(): array
    {
        if (!app(WeappEntitlementGateway::class)->entitlementCan('doc_bundle')) {
            return ['ok' => 0, 'warn' => 0, 'fail' => 0, 'unknown' => 0, 'remote_total' => 0];
        }
        $base = static function () {
            return WeappDownloadItem::where('source_type', 'remote')->where('remote_url', '<>', '');
        };

        return [
            'remote_total' => (int) $base()->count(),
            'ok'           => (int) $base()->where('link_check_status', self::STATUS_OK)->count(),
            'warn'         => (int) $base()->where('link_check_status', self::STATUS_WARN)->count(),
            'fail'         => (int) $base()->where('link_check_status', self::STATUS_FAIL)->count(),
            'unknown'      => (int) $base()->where('link_check_status', self::STATUS_UNKNOWN)->count(),
        ];
    }

    /**
     * @return array{list:list<array<string,mixed>>,total:int,page:int,limit:int}
     */
    public static function listAdmin(int $page = 1, int $limit = 20, string $status = ''): array
    {
        if (!app(WeappEntitlementGateway::class)->entitlementCan('doc_bundle')) {
            return ['list' => [], 'total' => 0, 'page' => $page, 'limit' => $limit];
        }
        $page  = max(1, $page);
        $limit = min(100, max(10, $limit));
        $query = WeappDownloadItem::alias('i')
            ->join('weapp_doc_bundle_bundles b', 'b.id = i.bundle_id')
            ->where('i.source_type', 'remote')
            ->where('i.remote_url', '<>', '')
            ->field('i.id,i.bundle_id,i.label,i.remote_url,i.extract_code,i.link_check_status,i.link_check_http_code,i.link_check_message,i.link_check_at,b.title as bundle_title,b.document_id');

        if ($status !== '' && in_array($status, [self::STATUS_OK, self::STATUS_WARN, self::STATUS_FAIL, self::STATUS_UNKNOWN], true)) {
            $query->where('i.link_check_status', $status);
        }

        $total = (int) (clone $query)->count();
        $rows  = $query->order('i.link_check_at', 'asc')->order('i.id', 'desc')->page($page, $limit)->select()->toArray();
        $docIds = [];
        foreach ($rows as $row) {
            $did = (int) ($row['document_id'] ?? 0);
            if ($did > 0) {
                $docIds[$did] = $did;
            }
        }
        $docs = [];
        if ($docIds !== []) {
            foreach (app(WeappDocumentGateway::class)->documentRowsByIds(array_values($docIds), 'id,title') as $doc) {
                $docs[(int) ($doc['id'] ?? 0)] = (string) ($doc['title'] ?? '');
            }
        }

        $list = [];
        foreach ($rows as $row) {
            $documentId = (int) ($row['document_id'] ?? 0);
            $st         = (string) ($row['link_check_status'] ?? self::STATUS_UNKNOWN);
            $list[]     = [
                'id'                      => (int) ($row['id'] ?? 0),
                'bundle_id'               => (int) ($row['bundle_id'] ?? 0),
                'bundle_title'            => (string) ($row['bundle_title'] ?? ''),
                'document_id'             => $documentId,
                'document_title'          => $docs[$documentId] ?? '',
                'document_edit_path'      => $documentId > 0 ? '/content/document/edit/' . $documentId : '',
                'label'                   => (string) ($row['label'] ?? ''),
                'remote_url'              => (string) ($row['remote_url'] ?? ''),
                'extract_code'            => (string) ($row['extract_code'] ?? ''),
                'link_check_status'       => $st,
                'link_check_status_label' => self::statusLabel($st),
                'link_check_http_code'    => (int) ($row['link_check_http_code'] ?? 0),
                'link_check_message'      => (string) ($row['link_check_message'] ?? ''),
                'link_check_at'           => (string) ($row['link_check_at'] ?? ''),
            ];
        }

        return ['list' => $list, 'total' => $total, 'page' => $page, 'limit' => $limit];
    }
}
