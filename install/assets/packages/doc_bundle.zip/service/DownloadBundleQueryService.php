<?php
declare(strict_types=1);

namespace weapp\doc_bundle\service;

use weapp\doc_bundle\model\WeappDownloadBundle;
use app\common\service\weapp\WeappEntitlementGateway;
use app\common\service\weapp\WeappDocumentGateway;
use app\common\service\weapp\WeappSupportGateway;

/** 资源包列表/查询（后台分页、文档维度、公开 API） */
final class DownloadBundleQueryService
{
    /** @return list<array<string, mixed>> */
    public static function listAdmin(): array
    {
        if (!app(WeappEntitlementGateway::class)->entitlementCan('doc_bundle')) {
            return [];
        }

        return DownloadBundleService::attachItemsToBundles(
            WeappDownloadBundle::order('sort', 'asc')->order('id', 'desc')->select()->toArray()
        );
    }

    /** @return list<array<string, mixed>> */
    public static function listForDocument(int $documentId, bool $forAdmin = false): array
    {
        if (!app(WeappEntitlementGateway::class)->entitlementCan('doc_bundle') || $documentId < 1) {
            return [];
        }
        if (!$forAdmin && !DownloadConfigService::documentEligible($documentId)) {
            return [];
        }

        return DownloadBundleService::attachItemsToBundles(
            WeappDownloadBundle::where('document_id', $documentId)
                ->order('sort', 'asc')
                ->order('id', 'asc')
                ->select()
                ->toArray()
        );
    }

    /**
     * 挂有下载包的文档 ID（arclist has=doc_bundle / download）。
     *
     * @return list<int>
     */
    public static function documentIdsWithBundles(): array
    {
        if (!app(WeappEntitlementGateway::class)->entitlementCan('doc_bundle')) {
            return [];
        }
        try {
            $ids = WeappDownloadBundle::where('document_id', '>', 0)
                ->distinct(true)
                ->column('document_id');
        } catch (\Throwable $e) {
            app(WeappSupportGateway::class)->kernelOpsLog('download_document_ids_availability_failed', [
                'msg' => $e->getMessage(),
            ]);

            return [];
        }

        return array_values(array_unique(array_filter(array_map('intval', $ids ?: []), static fn (int $id): bool => $id > 0)));
    }

    /** @param list<array<string, mixed>> $bundles @return list<array<string, mixed>> */
    public static function enrichAdminBundlesWithDocuments(array $bundles): array
    {
        if ($bundles === []) {
            return [];
        }
        $docIds = [];
        foreach ($bundles as $bundle) {
            $did = (int) ($bundle['document_id'] ?? 0);
            if ($did > 0) {
                $docIds[$did] = $did;
            }
        }
        $docs = [];
        if ($docIds !== []) {
            $rows = app(WeappDocumentGateway::class)->documentRowsByIds(array_values($docIds), 'id,title,status');
            foreach ($rows as $row) {
                $docs[(int) ($row['id'] ?? 0)] = $row;
            }
        }
        foreach ($bundles as &$bundle) {
            $documentId = (int) ($bundle['document_id'] ?? 0);
            $doc        = $docs[$documentId] ?? null;
            $bundle['document_title']     = $doc ? (string) ($doc['title'] ?? '') : '';
            $bundle['document_edit_path'] = $documentId > 0 ? '/content/document/edit/' . $documentId : '';
            $bundle['document_status']    = $doc ? (int) ($doc['status'] ?? 0) : 0;
            $bundle['link_check_summary'] = DownloadBundleService::bundleLinkCheckSummary($bundle['items'] ?? []);
        }
        unset($bundle);

        return $bundles;
    }

    /**
     * @param array<string, mixed> $params
     * @return array{list:list<array<string,mixed>>,total:int,page:int,limit:int}
     */
    public static function listAdminPaged(array $params = []): array
    {
        if (!app(WeappEntitlementGateway::class)->entitlementCan('doc_bundle')) {
            return ['list' => [], 'total' => 0, 'page' => 1, 'limit' => 20];
        }

        $page      = max(1, (int) ($params['page'] ?? 1));
        $limit     = min(max((int) ($params['limit'] ?? 20), 1), 100);
        $keyword   = trim((string) ($params['keyword'] ?? $params['q'] ?? ''));
        $status    = ($params['status'] ?? '') !== '' && ($params['status'] ?? '') !== null
            ? (int) $params['status']
            : null;
        $documentId = (int) ($params['document_id'] ?? 0);

        $query = WeappDownloadBundle::order('sort', 'asc')->order('id', 'desc');
        if ($keyword !== '') {
            if (ctype_digit($keyword)) {
                $id = (int) $keyword;
                $query->where(function ($sub) use ($id, $keyword): void {
                    $sub->where('id', $id)->whereOr('document_id', $id);
                    $like = '%' . addcslashes($keyword, '%_\\') . '%';
                    $sub->whereOr('title', 'like', $like);
                });
            } else {
                $like = '%' . addcslashes($keyword, '%_\\') . '%';
                $query->whereLike('title', $like);
            }
        }
        if ($status !== null) {
            $query->where('status', $status);
        }
        if ($documentId > 0) {
            $query->where('document_id', $documentId);
        }

        $total = (int) $query->count();
        $rows  = $query->page($page, $limit)->select()->toArray();
        $list  = self::enrichAdminBundlesWithDocuments(DownloadBundleService::attachItemsToBundles($rows));

        return ['list' => $list, 'total' => $total, 'page' => $page, 'limit' => $limit];
    }

    /** @return list<array<string, mixed>> */
    public static function listAdminForSpa(): array
    {
        $all  = [];
        $page = 1;
        do {
            $paged = self::listAdminPaged(['page' => $page, 'limit' => 100]);
            foreach ($paged['list'] as $row) {
                $all[] = $row;
            }
            $total = (int) ($paged['total'] ?? 0);
            if ($paged['list'] === [] || count($all) >= $total) {
                break;
            }
            ++$page;
        } while ($page <= 500);

        return $all;
    }

    public static function listApiForDocument(int $documentId)
    {
        if ($documentId < 1 || !app(WeappEntitlementGateway::class)->entitlementCan('doc_bundle')) {
            return app(WeappSupportGateway::class)->resultFail('invalid');
        }
        $bundles = self::listForDocument($documentId);
        $list    = [];
        foreach ($bundles as $bundle) {
            foreach (($bundle['items'] ?? []) as $item) {
                if ((int) ($item['status'] ?? 0) !== 1) {
                    continue;
                }
                $list[] = DownloadTemplateRenderService::formatPublicItem($item, $bundle);
            }
        }

        return app(WeappSupportGateway::class)->resultOk($list);
    }
}
