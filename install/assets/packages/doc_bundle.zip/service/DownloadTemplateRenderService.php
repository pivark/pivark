<?php
declare(strict_types=1);

namespace weapp\doc_bundle\service;

use app\common\support\ServiceResult;
use weapp\doc_bundle\model\WeappDownloadBundle;
use weapp\doc_bundle\model\WeappDownloadItem;
use weapp\doc_bundle\service\DownloadTokenService;
use app\common\service\weapp\WeappEntitlementGateway;
use app\common\service\weapp\WeappFrontGateway;
use app\common\service\weapp\WeappMemberGateway;

/** 前台 {pv:doc_bundle} 标签渲染（与 bridge/其它插件解耦） */
final class DownloadTemplateRenderService
{
    private static function bundleRow(array|WeappDownloadBundle $bundle): array
    {
        return $bundle instanceof WeappDownloadBundle ? $bundle->toArray() : $bundle;
    }

    private static function itemRow(array|WeappDownloadItem $item): array
    {
        return $item instanceof WeappDownloadItem ? $item->toArray() : $item;
    }

private const TAG_BUNDLE_OPEN  = '[[pv-dl-bundle]]';
    private const TAG_BUNDLE_CLOSE = '[[/pv-dl-bundle]]';

    /** @var list<string> */
    private const PLATFORM_GROUP_ORDER = [
        '百度网盘', '夸克网盘', '阿里云盘', '天翼云盘', '蓝奏云', '123云盘',
        '奶牛快传', '飞机盘', '微云', 'Google Drive', 'OneDrive', '115网盘',
        '本地下载', '远程链接', '远程下载',
    ];
    private const TAG_ITEM_OPEN    = '[[pv-dl-item]]';
    private const TAG_ITEM_CLOSE   = '[[/pv-dl-item]]';

    /** @param array<string, string> $attrs @param array<string, mixed> $pageVars */
    public static function renderTag(array $attrs, array $pageVars, string $tpl): string
    {
        if (!app(WeappEntitlementGateway::class)->entitlementCan('doc_bundle')) {
            return '';
        }

        $documentId = (int) ($attrs['id'] ?? $attrs['aid'] ?? $attrs['document_id'] ?? $pageVars['document_id'] ?? 0);
        if ($documentId < 1) {
            return '';
        }

        $rawBundles = DownloadBundleQueryService::listForDocument($documentId);
        $bundles = DownloadConfigService::frontGroupMode() === DownloadConfigService::GROUP_BY_PLATFORM
            ? DownloadBundleService::groupItemsByPlatform($rawBundles)
            : DownloadBundleService::attachItemsToBundles($rawBundles);
        if ($bundles === []) {
            return '';
        }

        app(WeappFrontGateway::class)->frontAssetRegisterDocBundles($bundles, 'doc_bundle');

        $layout = strtolower(trim((string) ($attrs['layout'] ?? '')));
        if (DownloadFrontLayout::isCardsLayout($layout) && trim($tpl) === '') {
            return DownloadFrontLayout::renderCards(
                $documentId,
                $attrs,
                $pageVars,
                $bundles,
                static fn (string $groupTpl, array $bundleRows): string => self::renderTagGrouped($groupTpl, $bundleRows)
            );
        }

        $defaultTpl = '<a href="{$field.url}" class="pv-download-link">{$field.label}</a>';
        $tpl        = trim($tpl) !== '' ? $tpl : $defaultTpl;
        if (str_contains($tpl, self::TAG_BUNDLE_OPEN) && str_contains($tpl, self::TAG_ITEM_OPEN)) {
            return self::renderTagGrouped($tpl, $bundles);
        }

        return self::renderTagFlat($tpl, $bundles);
    }


    public static function groupItemsByPlatform(array $bundles): array
    {
        return DownloadBundleService::groupItemsByPlatform($bundles);
    }


    private static function previewItemAccess(array|WeappDownloadItem $item, array|WeappDownloadBundle $bundle)
    {
        return DownloadAccessService::previewItemAccess($item, $bundle);
    }

    /**
     * @param array<string, mixed> $item
     * @param array<string, mixed> $bundle
     * @return array<string, scalar>
     */
    public static function formatPublicItemForDisplay(array|WeappDownloadItem $item, array|WeappDownloadBundle $bundle): array
    {
        $item = self::itemRow($item);
        $bundle = self::bundleRow($bundle);
        $field      = self::formatPublicItem($item, $bundle);
        $access     = DownloadAccessService::previewItemAccess($item, $bundle);
        $canAccess  = $access->isOk();
        $mode       = DownloadAccessService::normalizeAccessMode((string) ($bundle['access_mode'] ?? 'free'));
        $sourceType = (string) ($item['source_type'] ?? 'local');
        $isRemote   = $sourceType === 'remote';
        $gateLabel  = DownloadAccessService::gateButtonLabel($bundle, $access);

        $field['access_label']  = DownloadAccessService::bundleAccessLabel($bundle);
        $field['show_open_btn'] = '0';
        $field['show_dl_btn']   = '0';
        $field['open_href']     = '';
        $field['open_text']     = '打开网盘';
        $field['dl_href']       = '';
        $field['dl_text']       = '下载';
        $field['is_gated']      = $mode !== 'free' ? '1' : '0';
        $bundleId = (int) ($bundle['id'] ?? 0);
        $userId   = app(WeappFrontGateway::class)->frontIsLoggedIn() ? (int) (app(WeappFrontGateway::class)->frontCurrent()['id'] ?? 0) : 0;
        $unlocked = $mode === 'points' && $userId > 0 && $bundleId > 0 && DownloadAccessService::hasPointsUnlock($userId, $bundleId);
        $cost     = max(0, (int) ($bundle['points_cost'] ?? 0));
        $field['bundle_id']       = $bundleId;
        $field['points_unlocked'] = $unlocked ? '1' : '0';
        $field['points_cost']     = $cost;
        $field['points_balance']  = $userId > 0 ? app(WeappMemberGateway::class)->memberPointBalance($userId) : 0;
        $field['dl_action']       = '';
        if ($mode === 'points' && $unlocked) {
            $field['access_label'] = "\xe5\xb7\xb2\xe8\xb4\xad\xe4\xb9\xb0";
            $canAccess             = true;
        }

        if ($isRemote) {
            $remote = trim((string) ($field['remote_url'] ?? ''));
            if ($mode === 'points' && $unlocked && $remote !== '') {
                $field['show_open_btn'] = '1';
                $field['open_href']     = $remote;
                $field['show_dl_btn']   = '1';
                $field['dl_href']       = (string) ($field['url'] ?? '');
                $field['dl_text']       = '下载';
            } elseif ($mode === 'points' && !$unlocked) {
                $field['show_dl_btn'] = '1';
                $field['dl_href']     = '#pv-points-unlock';
                $field['dl_text']     = $cost > 0 ? ('积分购买（' . $cost . ' 积分）') : '积分购买';
                $field['dl_action']   = 'points_unlock';
            } elseif ($canAccess && $remote !== '') {
                $field['show_open_btn'] = '1';
                $field['open_href']     = $remote;
                if ($mode !== 'free') {
                    $field['show_dl_btn'] = '1';
                    $field['dl_href']     = (string) ($field['url'] ?? '');
                    $field['dl_text']     = $gateLabel;
                }
            } else {
                $field['show_dl_btn'] = '1';
                $field['dl_href']     = DownloadAccessService::gateButtonHref($bundle, $access, (string) ($field['url'] ?? ''));
                $field['dl_text']     = $gateLabel;
            }
        } else {
            $field['show_dl_btn'] = '1';
            $field['dl_href']     = $canAccess
                ? (string) ($field['url'] ?? '')
                : DownloadAccessService::gateButtonHref($bundle, $access, (string) ($field['url'] ?? ''));
            $field['dl_text']     = $canAccess ? '下载' : $gateLabel;
        }

        return array_merge($field, DownloadDisplayService::publicItemExtras($item));
    }

    private static function gateButtonLabel(array $bundle, ServiceResult $access): string
    {
        return DownloadAccessService::gateButtonLabel($bundle, $access);
    }

    private static function gateButtonHref(array $bundle, ServiceResult $access, string $downloadUrl): string
    {
        return DownloadAccessService::gateButtonHref($bundle, $access, $downloadUrl);
    }
    public static function mergeBundlesByTitle(array $bundles): array
    {
        return DownloadBundleService::mergeBundlesByTitle($bundles);
    }
    private static function renderTagFlat(string $tpl, array $bundles): string
    {
        $out = '';
        foreach ($bundles as $bundle) {
            foreach (($bundle['items'] ?? []) as $row) {
                if (is_array($row['item'] ?? null) && is_array($row['bundle'] ?? null)) {
                    $item      = $row['item'];
                    $srcBundle = $row['bundle'];
                } else {
                    $item      = $row;
                    $srcBundle = $bundle;
                }
                $field = self::formatPublicItemForDisplay($item, $srcBundle);
                $out  .= self::replaceFieldVars($tpl, $field);
            }
        }

        return $out;
    }

    /**
     * @param list<array<string, mixed>> $bundles
     */
    /**
     * @return array{bundleTpl:string,itemTpl:string}|null
     */
    private static function splitGroupedTemplate(string $tpl): ?array
    {
        $b0 = strpos($tpl, self::TAG_BUNDLE_OPEN);
        $i0 = strpos($tpl, self::TAG_ITEM_OPEN);
        $i1 = strpos($tpl, self::TAG_ITEM_CLOSE);
        $b1 = strpos($tpl, self::TAG_BUNDLE_CLOSE);
        if ($b0 === false || $i0 === false || $i1 === false || $b1 === false) {
            return null;
        }
        if (!($b0 < $i0 && $i0 < $i1 && $i1 < $b1)) {
            return null;
        }

        return [
            'bundleBefore' => substr($tpl, $b0 + strlen(self::TAG_BUNDLE_OPEN), $i0 - $b0 - strlen(self::TAG_BUNDLE_OPEN)),
            'itemTpl'      => substr($tpl, $i0 + strlen(self::TAG_ITEM_OPEN), $i1 - $i0 - strlen(self::TAG_ITEM_OPEN)),
            'bundleAfter'  => substr($tpl, $i1 + strlen(self::TAG_ITEM_CLOSE), $b1 - $i1 - strlen(self::TAG_ITEM_CLOSE)),
        ];
    }

    private static function renderTagGrouped(string $tpl, array $bundles): string
    {
        $parts = self::splitGroupedTemplate($tpl);
        if ($parts === null) {
            return self::renderTagFlat($tpl, $bundles);
        }

        $out = '';

        foreach ($bundles as $bundle) {
            $bundleVars = DownloadBundleService::formatPublicBundle($bundle);
            $itemsHtml  = '';
            foreach (($bundle['items'] ?? []) as $row) {
                if (is_array($row['item'] ?? null) && is_array($row['bundle'] ?? null)) {
                    $item      = $row['item'];
                    $srcBundle = $row['bundle'];
                } else {
                    $item      = $row;
                    $srcBundle = $bundle;
                }
                $field     = self::formatPublicItemForDisplay($item, $srcBundle);
                $itemsHtml .= self::replaceFieldVars($parts['itemTpl'], $field);
            }
            $out .= self::replaceBundleVars($parts['bundleBefore'], $bundleVars)
                . $itemsHtml
                . self::replaceBundleVars($parts['bundleAfter'], $bundleVars);
        }

        return $out;
    }

    /**
     * @param array<string, mixed> $bundle
     * @return array<string, scalar>
     */
    public static function formatPublicBundle(array $bundle): array
    {
        return DownloadBundleService::formatPublicBundle($bundle);
    }
    private static function replaceBundleVars(string $tpl, array $vars): string
    {
        foreach ($vars as $key => $val) {
            if (is_scalar($val)) {
                $tpl = str_replace('{$bundle.' . $key . '}', htmlspecialchars((string) $val), $tpl);
            }
        }

        return $tpl;
    }

    /**
     * @param array<string, scalar> $field
     */
    private static function replaceFieldVars(string $tpl, array $field): string
    {
        foreach ($field as $key => $val) {
            if (is_scalar($val)) {
                $tpl = str_replace('{$field.' . $key . '}', htmlspecialchars((string) $val), $tpl);
            }
        }

        return $tpl;
    }

    /**
     * @param array<string, mixed> $item
     * @param array<string, mixed> $bundle
     * @return array<string, scalar>
     */


    public static function formatPublicItem(array|WeappDownloadItem $item, array|WeappDownloadBundle $bundle): array
    {
        $item = self::itemRow($item);
        $bundle = self::bundleRow($bundle);
        $id = (int) ($item['id'] ?? 0);

        return [
            'id'              => $id,
            'title'           => (string) ($bundle['title'] ?? ''),
            'label'           => DownloadBundleService::normalizeItemLabel((string) ($item['source_type'] ?? 'local'), (string) ($item['label'] ?? '')),
            'source_type'     => (string) ($item['source_type'] ?? 'local'),
            'url'             => '/api/v1/plugins/doc_bundle/files/' . $id . '?token=' . DownloadTokenService::issue($id),
            'remote_url'      => (string) ($item['remote_url'] ?? ''),
            'extract_code'    => (string) ($item['extract_code'] ?? ''),
            'file_size'       => (int) ($item['file_size'] ?? 0),
            'file_size_text'  => self::formatSize((int) ($item['file_size'] ?? 0)),
            'download_count'  => (int) ($item['download_count'] ?? 0),
            'access_mode'     => (string) ($bundle['access_mode'] ?? 'free'),
            'points_cost'     => (int) ($bundle['points_cost'] ?? 0),
            'access_label'    => DownloadAccessService::bundleAccessLabel($bundle),
            'price'           => (string) ($bundle['price'] ?? '0.00'),
        ];
    }

    
    public static function formatSize(int $bytes): string
    {
        if ($bytes < 1) {
            return '0 B';
        }
        if ($bytes < 1024) {
            return $bytes . ' B';
        }
        if ($bytes < 1048576) {
            return round($bytes / 1024, 1) . ' KB';
        }
        if ($bytes < 1073741824) {
            return round($bytes / 1048576, 2) . ' MB';
        }

        return round($bytes / 1073741824, 2) . ' GB';
    }

}
