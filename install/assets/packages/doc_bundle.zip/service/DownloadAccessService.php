<?php
/**
 * 元舟 PivArk — 企业全域原子化数字资产中枢
 * (c) 2024-2026 pivark.com. All rights reserved.
 * Author: Angelo
 * 未经允许，不可用于商业用途。
 */
declare(strict_types=1);

namespace weapp\doc_bundle\service;

use weapp\doc_bundle\model\WeappDownloadBundle;
use weapp\doc_bundle\model\WeappDownloadItem;
use weapp\doc_bundle\model\WeappDownloadPointUnlock;
use app\common\support\ServiceResult;
use weapp\doc_bundle\service\DownloadConfigService;
use weapp\doc_bundle\service\DownloadOrderValidator;
use weapp\doc_bundle\service\DownloadPurchaseService;
use app\common\service\weapp\WeappDocumentGateway;
use app\common\service\weapp\WeappFrontGateway;
use app\common\service\weapp\WeappMemberGateway;
use app\common\service\weapp\WeappPaymentGateway;
use app\common\service\weapp\WeappSupportGateway;

final class DownloadAccessService
{
    /** @var list<string> */
    public const ACCESS_MODES = ['free', 'login', 'member', 'points', 'paid', 'member_paid'];
    public static function normalizeAccessMode(string $mode): string
    {
        $mode = strtolower(trim($mode));

        return in_array($mode, self::ACCESS_MODES, true) ? $mode : 'free';
    }

    /**
     * 下载前须满足文档阅读权限；阅读为前置门槛，下载权限另判（可读不可下）。
     *
     * @return mixed
     */
    public static function checkDocumentReadAccess(int $documentId)
    {
        if ($documentId < 1) {
            return app(WeappSupportGateway::class)->resultOk(null, 'ok');
        }

        $doc = app(WeappDocumentGateway::class)->documentRowById($documentId, true);
        if ($doc === null) {
            return app(WeappSupportGateway::class)->resultFail('not_found');
        }
        if (!app(WeappFrontGateway::class)->frontCanReadDocument($doc)) {
            if ((int) ($doc['read_perm'] ?? 0) === 0) {
                return app(WeappSupportGateway::class)->resultFail('read_required');
            }
            if (!app(WeappFrontGateway::class)->frontIsLoggedIn()) {
                return app(WeappSupportGateway::class)->resultFail('login_required');
            }

            return app(WeappSupportGateway::class)->resultFail('level_required');
        }

        return app(WeappSupportGateway::class)->resultOk(null, 'ok');
    }

    /**
     * @param array<string, mixed> $bundle
     * @return mixed
     */
    public static function checkBundleAccess(array|WeappDownloadBundle $bundle)
    {
        $bundle = self::bundleRow($bundle);
        $mode = self::normalizeAccessMode((string) ($bundle['access_mode'] ?? 'free'));
        if ($mode === 'free') {
            return app(WeappSupportGateway::class)->resultOk(null, 'ok');
        }

        if ($mode === 'login') {
            return app(WeappFrontGateway::class)->frontIsLoggedIn()
                ? app(WeappSupportGateway::class)->resultOk(null, 'ok')
                : app(WeappSupportGateway::class)->resultFail('login_required');
        }

        if ($mode === 'member') {
            if (!app(WeappFrontGateway::class)->frontIsLoggedIn()) {
                return app(WeappSupportGateway::class)->resultFail('login_required');
            }
            $member = app(WeappFrontGateway::class)->frontCurrent();
            $needId = (int) ($bundle['member_level_id'] ?? 0);
            if ($needId > 0) {
                $memberLevelId = (int) ($member['member_level_id'] ?? 0);
                if ($memberLevelId < 1) {
                    $memberLevelId = app(WeappMemberGateway::class)->memberLevelDefaultId();
                }
                if (app(WeappMemberGateway::class)->memberLevelRank($memberLevelId) < app(WeappMemberGateway::class)->memberLevelRank($needId)) {
                    return app(WeappSupportGateway::class)->resultFail('level_required');
                }
            }

            return app(WeappSupportGateway::class)->resultOk(null, 'ok');
        }

        if ($mode === 'points') {
            if (!app(WeappMemberGateway::class)->memberConfigPointsEnabled()) {
                return app(WeappSupportGateway::class)->resultFail('points_disabled');
            }
            if (!app(WeappFrontGateway::class)->frontIsLoggedIn()) {
                return app(WeappSupportGateway::class)->resultFail('login_required');
            }
            $member = app(WeappFrontGateway::class)->frontCurrent();
            $userId = (int) ($member['id'] ?? 0);
            $bundleId = (int) ($bundle['id'] ?? 0);
            if ($bundleId > 0 && self::hasPointsUnlock($userId, $bundleId)) {
                return app(WeappSupportGateway::class)->resultOk(null, 'ok');
            }
            $cost = max(0, (int) ($bundle['points_cost'] ?? 0));
            if ($cost < 1) {
                return app(WeappSupportGateway::class)->resultFail('points_cost_invalid');
            }
            if (app(WeappMemberGateway::class)->memberPointBalance($userId) < $cost) {
                return app(WeappSupportGateway::class)->resultFail('points_insufficient');
            }

            return app(WeappSupportGateway::class)->resultFail('points_unlock_required');
        }

        if ($mode === 'paid' || $mode === 'member_paid') {
            if (!app(WeappPaymentGateway::class)->paymentDocumentEnabled()) {
                return app(WeappSupportGateway::class)->resultFail('payment_disabled');
            }
            if ($mode === 'member_paid' && !app(WeappFrontGateway::class)->frontIsLoggedIn()) {
                return app(WeappSupportGateway::class)->resultFail('login_required');
            }
            if ($mode === 'paid' && !app(WeappFrontGateway::class)->frontIsLoggedIn()) {
                return app(WeappSupportGateway::class)->resultFail('login_required');
            }
            $userId   = (int) (app(WeappFrontGateway::class)->frontCurrent()['id'] ?? 0);
            $bundleId = (int) ($bundle['id'] ?? 0);
            if ($userId > 0 && $bundleId > 0 && DownloadPurchaseService::hasPurchased($userId, $bundleId)) {
                return app(WeappSupportGateway::class)->resultOk(null, 'ok');
            }

            return app(WeappSupportGateway::class)->resultFail('payment_required');
        }

        return app(WeappSupportGateway::class)->resultOk(null, 'ok');
    }

    /**
     * @param array<string, mixed> $item
     * @param array<string, mixed> $bundle
     * @return mixed
     */
    public static function previewItemAccess(array|WeappDownloadItem $item, array|WeappDownloadBundle $bundle)
    {
        $item = self::itemRow($item);
        $bundle = self::bundleRow($bundle);
        $documentId = (int) ($bundle['document_id'] ?? 0);
        if ($documentId > 0 && !DownloadConfigService::documentEligible($documentId)) {
            return app(WeappSupportGateway::class)->resultFail('not_allowed');
        }
        $readCheck = self::checkDocumentReadAccess($documentId);
        if (!$readCheck->isOk()) {
            return $readCheck;
        }

        return self::checkBundleAccess($bundle);
    }

    /**
     * @param array<string, mixed> $bundle
     * @param array{code:int,msg:string} $access
     */
    public static function gateButtonLabel(array $bundle, ServiceResult $access): string
    {
        if ($access->isOk()) {
            return self::bundleAccessLabel($bundle);
        }
        $msg = (string) ($access->message() ?? '');
        if (in_array($msg, ['login_required', 'read_required'], true)) {
            return '登录后下载';
        }
        if ($msg === 'level_required') {
            return self::bundleAccessLabel($bundle);
        }
        if ($msg === 'points_insufficient') {
            return '积分不足';
        }
        if ($msg === 'payment_required') {
            return '付费下载';
        }

        return self::bundleAccessLabel($bundle);
    }

    /**
     * @param array<string, mixed> $bundle
     * @param array{code:int,msg:string} $access
     */
    public static function gateButtonHref(array $bundle, ServiceResult $access, string $downloadUrl): string
    {
        if ($access->isOk()) {
            return $downloadUrl;
        }
        $msg = (string) ($access->message() ?? '');
        if (in_array($msg, ['login_required', 'read_required'], true)) {
            return app(WeappFrontGateway::class)->frontLoginRedirectUrl('');
        }

        return $downloadUrl;
    }

    public static function accessLabel(string $mode): string
    {
        return match (self::normalizeAccessMode($mode)) {
            'login'        => '须登录下载',
            'member'       => '指定会员',
            'points'       => '积分下载',
            'paid'         => '付费下载（预留）',
            'member_paid'  => '会员付费（预留）',
            default        => '免费下载',
        };
    }

    /**
     * @param array<string, mixed> $bundle
     */
    public static function bundleAccessLabel(array|WeappDownloadBundle $bundle): string
    {
        $bundle = self::bundleRow($bundle);
        $mode = self::normalizeAccessMode((string) ($bundle['access_mode'] ?? 'free'));
        if ($mode === 'points') {
            $cost = max(0, (int) ($bundle['points_cost'] ?? 0));

            return $cost > 0 ? "积分下载（{$cost} 积分）" : '积分下载';
        }
        if ($mode === 'member') {
            $levelId = (int) ($bundle['member_level_id'] ?? 0);
            if ($levelId > 0) {
                $name = app(WeappMemberGateway::class)->memberLevelGetName($levelId);
                if ($name !== '') {
                    return $name . '及以上';
                }
            }
        }

        return self::accessLabel($mode);
    }

    public static function hasPointsUnlock(int $userId, int $bundleId): bool
    {
        if ($userId < 1 || $bundleId < 1) {
            return false;
        }

        return (int) WeappDownloadPointUnlock::where('user_id', $userId)
            ->where('bundle_id', $bundleId)
            ->count() > 0;
    }

    /**
     * @param array<string, mixed> $bundle
     * @return mixed
     */
    public static function requirePointsUnlocked(array|WeappDownloadBundle $bundle)
    {
        $bundle = self::bundleRow($bundle);
        $member = app(WeappFrontGateway::class)->frontCurrent();
        $userId = (int) ($member['id'] ?? 0);
        $bundleId = (int) ($bundle['id'] ?? 0);
        if ($userId < 1 || $bundleId < 1) {
            return app(WeappSupportGateway::class)->resultFail('login_required');
        }
        if (self::hasPointsUnlock($userId, $bundleId)) {
            return app(WeappSupportGateway::class)->resultOk(null, 'ok');
        }

        return app(WeappSupportGateway::class)->resultFail('points_unlock_required');
    }

    /**
     * @return mixed
     */

    /**
     * @return mixed
     */
    public static function getPaidPreview(int $bundleId)
    {
        $bundleCheck = DownloadOrderValidator::bundleId($bundleId);
        if (!$bundleCheck['ok']) {
            return app(WeappSupportGateway::class)->resultFail((string) ($bundleCheck['msg'] ?? 'invalid'));
        }
        if (!app(WeappPaymentGateway::class)->paymentDocumentEnabled()) {
            return app(WeappSupportGateway::class)->resultFail('payment_disabled');
        }
        $bundle = WeappDownloadBundle::where('id', $bundleId)->where('status', 1)->find();
        if (!$bundle) {
            return app(WeappSupportGateway::class)->resultFail('not_found');
        }
        $modeCheck = DownloadOrderValidator::paidAccessMode((string) ($bundle['access_mode'] ?? 'free'));
        if (!$modeCheck['ok']) {
            return app(WeappSupportGateway::class)->resultFail((string) ($modeCheck['msg'] ?? 'invalid'));
        }
        $documentId = (int) ($bundle['document_id'] ?? 0);
        $readCheck  = self::checkDocumentReadAccess($documentId);
        if (!$readCheck->isOk()) {
            return $readCheck;
        }
        $priceCheck = DownloadOrderValidator::price((float) ($bundle['price'] ?? 0));
        if (!$priceCheck['ok']) {
            return app(WeappSupportGateway::class)->resultFail((string) ($priceCheck['msg'] ?? 'invalid'));
        }
        $price = $priceCheck['price'];
        $loggedIn = app(WeappFrontGateway::class)->frontIsLoggedIn();
        $userId   = $loggedIn ? (int) (app(WeappFrontGateway::class)->frontCurrent()['id'] ?? 0) : 0;
        $unlocked = $userId > 0 && DownloadPurchaseService::hasPurchased($userId, $bundleId);

        return app(WeappSupportGateway::class)->resultOk([
                'bundle_id'    => $bundleId,
                'bundle_title' => (string) ($bundle['title'] ?? ''),
                'price'        => $price,
                'price_text'   => number_format($price, 2, '.', ''),
                'unlocked'     => $unlocked,
                'logged_in'    => $loggedIn,
                'login_url'    => app(WeappFrontGateway::class)->frontLoginRedirectUrl(''),
                'demo_mode'    => app(WeappPaymentGateway::class)->paymentIsDemoMode(),
                'channels'     => ['alipay', 'wechat'],
            ], 'ok');
    }

    /**
     * @return mixed
     */
    public static function createPaidOrder(int $bundleId, string $channel = 'alipay')
    {
        $bundleCheck = DownloadOrderValidator::bundleId($bundleId);
        if (!$bundleCheck['ok']) {
            return app(WeappSupportGateway::class)->resultFail((string) ($bundleCheck['msg'] ?? 'invalid'));
        }
        if (!app(WeappPaymentGateway::class)->paymentDocumentEnabled()) {
            return app(WeappSupportGateway::class)->resultFail('payment_disabled');
        }
        if (!app(WeappFrontGateway::class)->frontIsLoggedIn()) {
            return app(WeappSupportGateway::class)->resultFail('login_required');
        }
        $bundle = WeappDownloadBundle::where('id', $bundleId)->where('status', 1)->find();
        if (!$bundle) {
            return app(WeappSupportGateway::class)->resultFail('not_found');
        }
        $modeCheck = DownloadOrderValidator::paidAccessMode((string) ($bundle['access_mode'] ?? 'free'));
        if (!$modeCheck['ok']) {
            return app(WeappSupportGateway::class)->resultFail((string) ($modeCheck['msg'] ?? 'invalid'));
        }
        $documentId = (int) ($bundle['document_id'] ?? 0);
        $readCheck  = self::checkDocumentReadAccess($documentId);
        if (!$readCheck->isOk()) {
            return $readCheck;
        }
        $userId = (int) (app(WeappFrontGateway::class)->frontCurrent()['id'] ?? 0);
        if (DownloadPurchaseService::hasPurchased($userId, $bundleId)) {
            return app(WeappSupportGateway::class)->resultOk(['already_unlocked' => true, 'bundle_id' => $bundleId], 'already_unlocked');
        }
        $priceCheck = DownloadOrderValidator::price((float) ($bundle['price'] ?? 0));
        if (!$priceCheck['ok']) {
            return app(WeappSupportGateway::class)->resultFail((string) ($priceCheck['msg'] ?? 'invalid'));
        }
        $price = $priceCheck['price'];
        $title = (string) ($bundle['title'] ?? '下载资源');

        return app(WeappPaymentGateway::class)->paymentCreateDocumentOrder(
            $userId,
            app(WeappPaymentGateway::class)->paymentPluginDocumentPaidScene('doc_bundle'),
            $bundleId,
            $channel,
            [
                'title'       => '付费下载：' . $title,
                'amount'      => $price,
                'bundle_id'   => $bundleId,
                'document_id' => $documentId,
            ]
        );
    }

    public static function getPointsUnlockPreview(int $bundleId)
    {
        $bundleCheck = DownloadOrderValidator::bundleId($bundleId);
        if (!$bundleCheck['ok']) {
            return app(WeappSupportGateway::class)->resultFail((string) ($bundleCheck['msg'] ?? 'invalid'));
        }
        if (!app(WeappMemberGateway::class)->memberConfigPointsEnabled()) {
            return app(WeappSupportGateway::class)->resultFail('points_disabled');
        }
        $bundle = WeappDownloadBundle::where('id', $bundleId)->where('status', 1)->find();
        if (!$bundle) {
            return app(WeappSupportGateway::class)->resultFail('not_found');
        }
        $modeCheck = DownloadOrderValidator::pointsAccessMode((string) ($bundle['access_mode'] ?? 'free'));
        if (!$modeCheck['ok']) {
            return app(WeappSupportGateway::class)->resultFail((string) ($modeCheck['msg'] ?? 'invalid'));
        }
        $documentId = (int) ($bundle['document_id'] ?? 0);
        $readCheck  = self::checkDocumentReadAccess($documentId);
        if (!$readCheck->isOk()) {
            return $readCheck;
        }
        $costCheck = DownloadOrderValidator::pointsCost((int) ($bundle['points_cost'] ?? 0));
        if (!$costCheck['ok']) {
            return app(WeappSupportGateway::class)->resultFail((string) ($costCheck['msg'] ?? 'invalid'));
        }
        $cost = $costCheck['cost'];
        $pointsName = app(WeappMemberGateway::class)->memberConfigPointsLabel();
        $userId     = 0;
        $balance    = 0;
        $unlocked   = false;
        if (app(WeappFrontGateway::class)->frontIsLoggedIn()) {
            $userId   = (int) (app(WeappFrontGateway::class)->frontCurrent()['id'] ?? 0);
            $balance  = app(WeappMemberGateway::class)->memberPointBalance($userId);
            $unlocked = self::hasPointsUnlock($userId, $bundleId);
        }

        return app(WeappSupportGateway::class)->resultOk([
                'bundle_id'    => $bundleId,
                'bundle_title' => (string) ($bundle['title'] ?? ''),
                'points_cost'  => $cost,
                'points_name'  => $pointsName,
                'balance'      => $balance,
                'can_afford'   => $balance >= $cost,
                'unlocked'     => $unlocked,
                'logged_in'    => app(WeappFrontGateway::class)->frontIsLoggedIn(),
                'login_url'    => app(WeappFrontGateway::class)->frontLoginRedirectUrl(''),
            ], 'ok');
    }

    /**
     * @return mixed
     */
    public static function purchasePointsUnlock(int $bundleId)
    {
        $bundleCheck = DownloadOrderValidator::bundleId($bundleId);
        if (!$bundleCheck['ok']) {
            return app(WeappSupportGateway::class)->resultFail((string) ($bundleCheck['msg'] ?? 'invalid'));
        }
        if (!app(WeappMemberGateway::class)->memberConfigPointsEnabled()) {
            return app(WeappSupportGateway::class)->resultFail('points_disabled');
        }
        if (!app(WeappFrontGateway::class)->frontIsLoggedIn()) {
            return app(WeappSupportGateway::class)->resultFail('login_required');
        }
        $bundle = WeappDownloadBundle::where('id', $bundleId)->where('status', 1)->find();
        if (!$bundle) {
            return app(WeappSupportGateway::class)->resultFail('not_found');
        }
        $modeCheck = DownloadOrderValidator::pointsAccessMode((string) ($bundle['access_mode'] ?? 'free'));
        if (!$modeCheck['ok']) {
            return app(WeappSupportGateway::class)->resultFail((string) ($modeCheck['msg'] ?? 'invalid'));
        }
        $documentId = (int) ($bundle['document_id'] ?? 0);
        $readCheck  = self::checkDocumentReadAccess($documentId);
        if (!$readCheck->isOk()) {
            return $readCheck;
        }

        $member       = app(WeappFrontGateway::class)->frontCurrent();
        $userId       = (int) ($member['id'] ?? 0);
        $cost         = max(0, (int) ($bundle['points_cost'] ?? 0));
        $pointsName   = app(WeappMemberGateway::class)->memberConfigPointsLabel();
        $balanceBefore = app(WeappMemberGateway::class)->memberPointBalance($userId);
        if ($cost < 1) {
            return app(WeappSupportGateway::class)->resultFail('points_cost_invalid');
        }
        if (self::hasPointsUnlock($userId, $bundleId)) {
            return app(WeappSupportGateway::class)->resultOk([
                    'already_unlocked' => true,
                    'points_cost'      => $cost,
                    'points_name'      => $pointsName,
                    'balance_before'   => $balanceBefore,
                    'balance_after'    => $balanceBefore,
                    'bundle_title'     => (string) ($bundle['title'] ?? ''),
                ], 'already_unlocked');
        }
        if ($balanceBefore < $cost) {
            return app(WeappSupportGateway::class)->resultFail('points_insufficient');
        }

        $deduct = self::deductPointsForUnlock($userId, $bundle, $cost);
        if (!$deduct->isOk()) {
            return $deduct;
        }

        return app(WeappSupportGateway::class)->resultOk([
                'already_unlocked' => false,
                'points_cost'      => $cost,
                'points_name'      => $pointsName,
                'balance_before'   => $balanceBefore,
                'balance_after'    => app(WeappMemberGateway::class)->memberPointBalance($userId),
                'bundle_title'     => (string) ($bundle['title'] ?? ''),
            ], 'ok');
    }

    /**
     * @param array<string, mixed> $bundle
     * @return mixed
     */
    
    /**
     * @param array<string, mixed> $bundle
     */
    public static function buildPointsUnlockReason(array $bundle): string
    {
        $bundleId = (int) ($bundle['id'] ?? 0);
        $title    = trim((string) ($bundle['title'] ?? ''));
        if ($title === '') {
            $title = '资源包 #' . $bundleId;
        }
        $docId = (int) ($bundle['document_id'] ?? 0);
        $text  = '下载解锁：' . $title;
        if ($docId > 0) {
            $text .= '（文档#' . $docId . '）';
        }

        return mb_substr($text, 0, 200);
    }

    public static function deductPointsForUnlock(int $userId, array $bundle, int $cost)
    {
        $bundleId = (int) ($bundle['id'] ?? 0);
        if ($userId < 1 || $bundleId < 1 || $cost < 1) {
            return app(WeappSupportGateway::class)->resultFail('invalid');
        }
        if (self::hasPointsUnlock($userId, $bundleId)) {
            return app(WeappSupportGateway::class)->resultOk(null, 'ok');
        }

        $now = app(WeappSupportGateway::class)->appTimeNow();
        try {
            WeappDownloadPointUnlock::insert([
                'user_id'     => $userId,
                'bundle_id'   => $bundleId,
                'points_cost' => 0,
                'created_at'  => $now,
            ]);
        } catch (\Throwable) {
            if (self::hasPointsUnlock($userId, $bundleId)) {
                return app(WeappSupportGateway::class)->resultOk(null, 'ok');
            }

            return app(WeappSupportGateway::class)->resultFail('points_unlock_failed');
        }

        $reason = self::buildPointsUnlockReason($bundle);
        $deduct = app(WeappMemberGateway::class)->memberPointAdjust($userId, -$cost, $reason, 0);
        if (!$deduct->isOk()) {
            WeappDownloadPointUnlock::where('user_id', $userId)
                ->where('bundle_id', $bundleId)
                ->where('points_cost', 0)
                ->delete();
            $msg = (string) ($deduct->message() ?? '');
            if (str_contains($msg, '积分不足') || str_contains($msg, 'insufficient')) {
                return app(WeappSupportGateway::class)->resultFail('points_insufficient');
            }

            return app(WeappSupportGateway::class)->resultFail('points_deduct_failed');
        }

        WeappDownloadPointUnlock::where('user_id', $userId)
            ->where('bundle_id', $bundleId)
            ->update(['points_cost' => $cost]);

        return app(WeappSupportGateway::class)->resultOk(null, 'ok');
    }


    /**
     * @param array<string, mixed>|WeappDownloadItem $item
     * @return array<string, mixed>
     */
    private static function itemRow(array|WeappDownloadItem $item): array
    {
        return $item instanceof WeappDownloadItem ? $item->toArray() : $item;
    }

    /**
     * @param array<string, mixed>|WeappDownloadBundle $bundle
     * @return array<string, mixed>
     */
    private static function bundleRow(array|WeappDownloadBundle $bundle): array
    {
        return $bundle instanceof WeappDownloadBundle ? $bundle->toArray() : $bundle;
    }
}
