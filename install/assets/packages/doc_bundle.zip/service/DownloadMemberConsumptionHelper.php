<?php
declare(strict_types=1);

namespace weapp\doc_bundle\service;

use think\db\Query;
use app\common\service\weapp\WeappConfigGateway;
use app\common\service\weapp\WeappSupportGateway;

/** 会员消费记录 · download 数据源（内核经 PluginWeappRuntime 调用） */
final class DownloadMemberConsumptionHelper
{
    public static function purchaseTable(): ?string
    {
        $table = app(WeappConfigGateway::class)->weappTable('doc_bundle', 'purchases');

        return app(WeappSupportGateway::class)->dbTableExists($table) ? $table : null;
    }

    public static function bundleTable(): ?string
    {
        $table = app(WeappConfigGateway::class)->weappTable('doc_bundle', 'bundles');

        return app(WeappSupportGateway::class)->dbTableExists($table) ? $table : null;
    }

    public static function unionPurchasePart(int $branchLimit): string
    {
        $purchase = self::purchaseTable();
        if ($purchase === null) {
            return '';
        }
        $title = "CONCAT('资源包 #', `p`.`bundle_id`)";
        $join  = '';
        $bundle = self::bundleTable();
        if ($bundle !== null) {
            $title = "COALESCE(NULLIF(`b`.`title`, ''), CONCAT('资源包 #', `p`.`bundle_id`))";
            $join  = " LEFT JOIN `{$bundle}` AS `b` ON `b`.`id` = `p`.`bundle_id`";
        }

        return "(SELECT CONCAT('purchase-', `p`.`id`) AS row_key, 'doc_bundle_paid' AS biz_type, `p`.`id` AS ref_id,"
            . " `p`.`user_id`, `p`.`amount`, 'yuan' AS unit, {$title} AS title,"
            . " CONCAT('bundle:', `p`.`bundle_id`) AS extra, `p`.`created_at`"
            . " FROM `{$purchase}` AS `p`{$join}"
            . " WHERE `p`.`status` = 1 AND `p`.`user_id` > 0"
            . " ORDER BY `p`.`created_at` DESC, `p`.`id` DESC LIMIT {$branchLimit})";
    }

    public static function countPurchases(int $userId, string $keyword, callable $applyUserScope, callable $applyKeyword): int
    {
        if (self::purchaseTable() === null) {
            return 0;
        }
        $q = DbTable::query(self::purchaseTable())->where('status', 1)->where('user_id', '>', 0);
        $applyUserScope($q, $userId, 'user_id');
        $applyKeyword($q, $keyword, null, 'user_id', self::bundleTable() !== null ? 'bundle' : null);

        return (int) $q->count();
    }

    /** @return list<array<string, mixed>> */
    public static function fetchPurchaseRows(int $userId, string $keyword, callable $applyUserScope, callable $applyKeyword): array
    {
        if (self::purchaseTable() === null) {
            return [];
        }
        $purchase = self::purchaseTable();
        $bundle   = self::bundleTable();
        $q        = DbTable::query($purchase)->alias('p')->where('p.status', 1)->where('p.user_id', '>', 0);
        if ($bundle !== null) {
            $q->leftJoin($bundle . ' b', 'b.id = p.bundle_id');
        }
        $applyUserScope($q, $userId, 'p.user_id');
        $applyKeyword($q, $keyword, null, 'p.user_id', $bundle !== null ? 'bundle' : null);
        $q->order('p.id', 'desc');

        $out = [];
        foreach ($q->field('p.id,p.user_id,p.amount,p.bundle_id,p.created_at' . ($bundle !== null ? ',b.title as bundle_title' : ''))->select()->toArray() as $row) {
            $title = trim((string) ($row['bundle_title'] ?? ''));
            if ($title === '') {
                $title = '资源包 #' . (int) ($row['bundle_id'] ?? 0);
            }
            $out[] = [
                'row_key'    => 'purchase-' . $row['id'],
                'biz_type'   => 'doc_bundle_paid',
                'ref_id'     => (int) $row['id'],
                'user_id'    => (int) $row['user_id'],
                'amount'     => (float) ($row['amount'] ?? 0),
                'unit'       => 'yuan',
                'title'      => $title,
                'extra'      => 'bundle:' . (int) ($row['bundle_id'] ?? 0),
                'created_at' => (string) ($row['created_at'] ?? ''),
                'username'   => '',
                'nickname'   => '',
            ];
        }
        if ($out !== []) {
            $userIds = array_values(array_unique(array_map(static fn (array $r): int => (int) ($r['user_id'] ?? 0), $out)));
            $users   = app(WeappSupportGateway::class)->modelRelationIndexUsersBasicByIds($userIds);
            foreach ($out as &$row) {
                $uid = (int) ($row['user_id'] ?? 0);
                if ($uid > 0 && isset($users[$uid])) {
                    $row['username'] = (string) ($users[$uid]['username'] ?? '');
                    $row['nickname'] = (string) ($users[$uid]['nickname'] ?? '');
                }
            }
            unset($row);
        }

        return $out;
    }

    /** @return list<int> */
    public static function bundleIdsByTitleLike(string $like): array
    {
        $bundle = self::bundleTable();
        if ($bundle === null) {
            return [];
        }

        return array_values(array_filter(array_map(
            static fn (mixed $id): int => (int) $id,
            DbTable::query($bundle)->whereLike('title', $like)->column('id'),
        ), static fn (int $id): bool => $id > 0));
    }

    /** @param list<int> $ids @return array<int, array<string, mixed>> */
    public static function bundlesByIds(array $ids): array
    {
        $bundle = self::bundleTable();
        if ($bundle === null || $ids === []) {
            return [];
        }
        $out = [];
        foreach (DbTable::query($bundle)->whereIn('id', array_values($ids))->select()->toArray() as $bundleRow) {
            if (!is_array($bundleRow)) {
                continue;
            }
            $out[(int) ($bundleRow['id'] ?? 0)] = $bundleRow;
        }

        return $out;
    }

    public static function bundleTableReady(): bool
    {
        return self::bundleTable() !== null;
    }

    public static function matchesPointUnlockReason(string $reason): bool
    {
        return str_starts_with($reason, '下载解锁')
            || str_starts_with($reason, 'download unlock');
    }

    public static function pointBizTypeForReason(string $reason): string
    {
        return self::matchesPointUnlockReason($reason) ? 'doc_bundle_points' : '';
    }

    /**
     * @return array{bundle_id:int,document_id:int,bundle_title:string}|null
     */
    public static function parsePointUnlockReason(string $reason): ?array
    {
        if (!self::matchesPointUnlockReason($reason)) {
            return null;
        }
        $out = ['bundle_id' => 0, 'document_id' => 0, 'bundle_title' => ''];
        if (preg_match('/下载解锁[：:]\s*(.+?)（文档#(\d+)）/u', $reason, $m) === 1) {
            $out['bundle_title'] = trim($m[1]);
            $out['document_id']  = (int) $m[2];

            return $out;
        }
        if (preg_match('/下载解锁[：:]\s*(.+)$/u', $reason, $m) === 1) {
            $out['bundle_title'] = trim($m[1]);

            return $out;
        }
        if (preg_match('/download unlock #(\d+)(?:\s+doc#(\d+))?/i', $reason, $m) === 1) {
            $out['bundle_id']   = (int) $m[1];
            $out['document_id'] = isset($m[2]) ? (int) $m[2] : 0;

            return $out;
        }

        return $out;
    }
    /**
     * @param array<string, mixed> $row
     * @param array{bundles: array<int, array<string, mixed>>, documents: array<int, array<string, mixed>>} $ctx
     * @return array<string, mixed>
     */
    public static function enrichConsumptionRow(array $row, array $ctx): array
    {
        $reason = (string) ($row['title'] ?? '');
        $biz    = (string) ($row['biz_type'] ?? '');
        if (!self::matchesPointUnlockReason($reason) && !in_array($biz, ['doc_bundle_points'], true)) {
            return $row;
        }
        $parsed = self::parsePointUnlockReason($reason) ?? ['bundle_id' => 0, 'document_id' => 0, 'bundle_title' => ''];
        $bundleId   = (int) ($parsed['bundle_id'] ?? 0);
        $documentId = (int) ($parsed['document_id'] ?? 0);
        $bundleTitle = trim((string) ($parsed['bundle_title'] ?? ''));
        if ($bundleId > 0 && isset($ctx['bundles'][$bundleId]) && is_array($ctx['bundles'][$bundleId])) {
            $bundle = $ctx['bundles'][$bundleId];
            if ($bundleTitle === '') {
                $bundleTitle = trim((string) ($bundle['title'] ?? ''));
            }
            if ($documentId < 1) {
                $documentId = (int) ($bundle['document_id'] ?? 0);
            }
        }
        $row['bundle_id']    = $bundleId;
        $row['document_id']  = $documentId;
        $row['bundle_title'] = $bundleTitle;
        if ($documentId > 0 && isset($ctx['documents'][$documentId]) && is_array($ctx['documents'][$documentId])) {
            $doc = $ctx['documents'][$documentId];
            $row['document_title'] = trim((string) ($doc['title'] ?? ''));
        }
        return $row;
    }
}
