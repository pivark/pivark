<?php
declare(strict_types=1);

namespace weapp\doc_bundle\service;

/** 前台默认 cards 布局（{pv:doc_bundle layout="cards"}） */
final class DownloadFrontLayout
{
    public static function isCardsLayout(string $layout): bool
    {
        $layout = strtolower(trim($layout));

        return in_array($layout, ['cards', 'card', 'default', 'default-cards'], true);
    }

    /**
     * @param array<string, string> $attrs
     * @param array<string, mixed> $pageVars
     * @param list<array<string, mixed>> $bundles
     */
    public static function renderCards(int $documentId, array $attrs, array $pageVars, array $bundles, callable $renderGrouped): string
    {
        $title = trim((string) ($attrs['title'] ?? '资源下载'));
        $hint  = trim((string) ($attrs['hint'] ?? '按网盘平台分组；每条链接的积分或会员权限以卡片标注为准。'));
        $meta  = DownloadDisplayService::renderMetaTag(['id' => (string) $documentId], $pageVars, '');
        $inner = $renderGrouped(self::cardsGroupedTemplate(), $bundles);
        if ($inner === '') {
            return '';
        }

        $titleEsc = htmlspecialchars($title, ENT_QUOTES, 'UTF-8');
        $hintEsc  = htmlspecialchars($hint, ENT_QUOTES, 'UTF-8');

        return '<section class="pv-doc-downloads" id="pv-doc-downloads" aria-label="资源下载">'
            . '<header class="pv-doc-downloads__head">'
            . '<h2 class="pv-doc-downloads__title">'
            . '<i class="bi bi-cloud-download" aria-hidden="true"></i> '
            . $titleEsc
            . '</h2>'
            . ($hintEsc !== ''
                ? '<p class="pv-doc-downloads__hint">' . $hintEsc . '</p>'
                : '')
            . $meta
            . '</header>'
            . '<div class="pv-doc-downloads__groups">'
            . $inner
            . '</div>'
            . '</section>';
    }

    public static function cardsGroupedTemplate(): string
    {
        return <<<'HTML'
[[pv-dl-bundle]]
<section class="pv-doc-download-group">
    <header class="pv-doc-download-group__head">
        <h3 class="pv-doc-download-group__title">{$bundle.title}</h3>
        <div class="pv-doc-download-group__meta">
            <span class="pv-doc-download-group__access" data-access="{$bundle.access_label}">{$bundle.access_label}</span>
            <span class="pv-doc-download-group__count">{$bundle.item_count} 个链接</span>
        </div>
    </header>
    <ul class="pv-doc-downloads__grid list-unstyled mb-0">
[[pv-dl-item]]
        <li
            class="pv-doc-download-card"
            data-platform="{$field.platform_label}"
            data-source="{$field.source_type}"
            data-bundle-id="{$field.bundle_id}"
            data-access-mode="{$field.access_mode}"
            data-points-unlocked="{$field.points_unlocked}"
            data-download-url="{$field.url}"
            data-remote-url="{$field.remote_url}"
            data-show-open="{$field.show_open_btn}"
            data-show-dl="{$field.show_dl_btn}"
            data-gated="{$field.is_gated}"
            data-dl-action="{$field.dl_action}"
            data-copy-text="{$field.copy_text}"
        >
            <div class="pv-doc-download-card__head">
                <div class="pv-doc-download-card__icon" aria-hidden="true">
                    <img
                        class="pv-doc-download-card__platform-img pv-doc-dl-icon--remote"
                        src="{$field.platform_icon_url}"
                        alt="{$field.platform_label}"
                        width="28"
                        height="28"
                        loading="lazy"
                    />
                    <i class="bi bi-file-earmark-arrow-down pv-doc-dl-icon pv-doc-dl-icon--local"></i>
                </div>
                <p class="pv-doc-download-card__platform">{$field.platform_label}</p>
            </div>
            <div class="pv-doc-download-card__badges">
                <span
                    class="pv-doc-download-card__freshness {$field.link_check_badge_class}"
                    title="{$field.link_check_hint}"
                >{$field.link_check_label}</span>
                <span class="pv-doc-download-card__access" data-mode="{$field.access_mode}">{$field.access_label}</span>
            </div>
            <div class="pv-doc-download-card__meta">
                <span class="pv-doc-download-card__code" data-extract="{$field.extract_code}">
                    <i class="bi bi-key" aria-hidden="true"></i>
                    提取码 <strong>{$field.extract_code}</strong>
                </span>
                <span class="pv-doc-download-card__size" data-size="{$field.file_size_text}">
                    <i class="bi bi-file-earmark" aria-hidden="true"></i>
                    {$field.file_size_text}
                </span>
            </div>
            <div class="pv-doc-download-card__actions">
                <button
                    type="button"
                    class="btn btn-outline-secondary btn-sm pv-doc-download-card__btn pv-doc-download-card__btn--copy"
                    data-pv-dl-copy
                    data-copy-text="{$field.copy_text}"
                >
                    <i class="bi bi-clipboard" aria-hidden="true"></i>
                    复制
                </button>
                <button
                    type="button"
                    class="btn btn-outline-secondary btn-sm pv-doc-download-card__btn pv-doc-download-card__btn--qr"
                    data-pv-dl-qr
                    data-qr-url="{$field.remote_url}"
                >
                    <i class="bi bi-qr-code" aria-hidden="true"></i>
                    扫码
                </button>
                <a
                    href="{$field.open_href}"
                    class="btn btn-primary btn-sm pv-doc-download-card__btn pv-doc-download-card__btn--open"
                    target="_blank"
                    rel="noopener noreferrer"
                >
                    <i class="bi bi-box-arrow-up-right" aria-hidden="true"></i>
                    {$field.open_text}
                </a>
                <a
                    href="{$field.dl_href}"
                    class="btn btn-outline-primary btn-sm pv-doc-download-card__btn pv-doc-download-card__btn--dl"
                    data-dl-action="{$field.dl_action}"
                >
                    <i class="bi bi-download" aria-hidden="true"></i>
                    {$field.dl_text}
                </a>
            </div>
        </li>
[[/pv-dl-item]]
    </ul>
</section>
[[/pv-dl-bundle]]
HTML;
    }
}