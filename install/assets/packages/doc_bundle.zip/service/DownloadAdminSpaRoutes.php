<?php
declare(strict_types=1);

namespace weapp\doc_bundle\service;

use app\common\service\weapp\WeappAdminGateway;

final class DownloadAdminSpaRoutes
{
    public static function register(): void
    {
        $gw = app(WeappAdminGateway::class);
        $id = 'doc_bundle';

        $indexRedirect = $gw->adminSpaHostPath($id, 'settings');

        $gw->adminSpaHostRegisterPluginPage(
            $id,
            'settings',
            'WeappDownloadSettings',
            ['title' => '基础设置'],
        );
        $gw->adminSpaHostRegisterPluginPage(
            $id,
            'resources',
            'WeappDownloadResources',
            ['title' => '下载资源'],
        );
        $gw->adminSpaHostRegisterPluginPage(
            $id,
            'link-check',
            'WeappDownloadLinkCheck',
            ['title' => '链接巡检'],
        );
        $gw->adminSpaHostRegisterPluginPage(
            $id,
            'stats',
            'WeappDownloadStats',
            ['title' => '下载统计'],
        );

        $indexPath = $gw->adminSpaHostPath($id, 'index');
        $gw->adminSpaExplicitRouteRegister($indexPath, [
            'name'     => 'WeappDownloadIndex',
            'path'     => $indexPath,
            'redirect' => $indexRedirect,
            'meta'     => ['title' => '基础设置', 'hideInMenu' => true, 'pivarkWeapp' => $id],
        ]);

        foreach (['usage' => ['WeappDownloadUsage', '前台调用说明', '/weapp/usage/index'], 'guide' => ['WeappDownloadGuide', '功能介绍', '/weapp/guide/index']] as $seg => [$name, $title, $component]) {
            $path = $gw->adminSpaHostPath($id, $seg);
            $gw->adminSpaExplicitRouteRegister($path, [
                'name'      => $name,
                'path'      => $path,
                'component' => $component,
                'meta'      => ['pivarkWeapp' => $id, 'title' => $title],
            ]);
        }

        $gw->adminSpaRouteIconRegister($gw->adminSpaHostPath($id, 'resources'), 'lucide:folder-open');
        $gw->adminSpaRouteIconRegister($gw->adminSpaHostPath($id, 'link-check'), 'lucide:link-2');
        $gw->adminSpaRouteIconRegister($gw->adminSpaHostPath($id, 'stats'), 'lucide:bar-chart-2');
        $gw->adminWeappNavTabsRegister($id, [
            $gw->adminWeappNavTab('settings', '基础设置', 'settings'),
            $gw->adminWeappNavTab('resources', '下载资源', 'resources'),
            $gw->adminWeappNavTab('link-check', '链接巡检', 'link-check'),
            $gw->adminWeappNavTab('stats', '下载统计', 'stats'),
        ]);
    }
}
