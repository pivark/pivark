<?php
declare(strict_types=1);

namespace weapp\doc_bundle\service;

use weapp\doc_bundle\model\WeappDownloadBundle;
use app\common\service\weapp\WeappSupportGateway;

/** 后台资源包写操作（不含跨插件总线） */
final class DownloadBundleAdminService
{
    /** @param list<int> $ids */
    public static function batchDeleteAdmin(array $ids)
    {
        $ids = array_values(array_unique(array_filter(array_map(static fn ($v): int => (int) $v, $ids), static fn (int $id): bool => $id > 0)));
        if ($ids === []) {
            return app(WeappSupportGateway::class)->resultFail('请选择要删除的资源');
        }
        $count = 0;
        foreach ($ids as $id) {
            if (self::deleteAdmin($id)->isOk()) {
                ++$count;
            }
        }

        return app(WeappSupportGateway::class)->resultOk(['count' => $count], '已删除 ' . $count . ' 项');
    }

    /** @param list<int> $ids */
    public static function batchUpdateStatusAdmin(array $ids, int $status)
    {
        $ids = array_values(array_unique(array_filter(array_map(static fn ($v): int => (int) $v, $ids), static fn (int $id): bool => $id > 0)));
        if ($ids === []) {
            return app(WeappSupportGateway::class)->resultFail('请选择资源');
        }
        $status = $status ? 1 : 0;
        $count  = 0;
        foreach ($ids as $id) {
            if (self::updateStatusAdmin($id, $status)->isOk()) {
                ++$count;
            }
        }

        return app(WeappSupportGateway::class)->resultOk(['count' => $count], ($status ? '已启用 ' : '已禁用 ') . $count . ' 项');
    }

    public static function updateSortAdmin(int $id, int $sort)
    {
        if ($id < 1) {
            return app(WeappSupportGateway::class)->resultFail('参数错误');
        }
        WeappDownloadBundle::where('id', $id)->update([
            'sort'       => $sort,
            'updated_at' => app(WeappSupportGateway::class)->appTimeNow(),
        ]);

        return app(WeappSupportGateway::class)->resultOk(null, '排序已更新');
    }

    public static function saveAdmin(array $data)
    {
        if (isset($data['items']) || isset($data['bundle_json'])) {
            return DownloadBundleService::saveBundleAdmin($data);
        }

        $access = !empty($data['require_login']) ? 'login' : DownloadAccessService::normalizeAccessMode((string) ($data['access_mode'] ?? 'free'));

        return DownloadBundleService::saveBundleAdmin([
            'id'              => (int) ($data['id'] ?? 0),
            'document_id'     => (int) ($data['document_id'] ?? 0),
            'title'           => (string) ($data['title'] ?? ''),
            'access_mode'     => $access,
            'price'           => (float) ($data['price'] ?? 0),
            'member_level_id' => (int) ($data['member_level_id'] ?? 0),
            'points_cost'     => max(0, (int) ($data['points_cost'] ?? 0)),
            'sort'            => (int) ($data['sort'] ?? 0),
            'status'          => (int) ($data['status'] ?? 1),
            'items'           => [[
                'source_type'  => 'local',
                'file_path'    => (string) ($data['file_path'] ?? ''),
                'file_size'    => (int) ($data['file_size'] ?? 0),
                'label'        => '本地下载',
                'remote_url'   => '',
                'extract_code' => '',
                'sort'         => 0,
                'status'       => 1,
            ]],
        ]);
    }

    public static function deleteAdmin(int $id)
    {
        return DownloadBundleService::deleteBundleAdmin($id);
    }

    public static function updateStatusAdmin(int $id, int $status)
    {
        if ($id < 1) {
            return app(WeappSupportGateway::class)->resultFail('参数错误');
        }
        WeappDownloadBundle::where('id', $id)->update([
            'status'     => $status ? 1 : 0,
            'updated_at' => app(WeappSupportGateway::class)->appTimeNow(),
        ]);

        return app(WeappSupportGateway::class)->resultOk(null, '状态已更新');
    }
}
