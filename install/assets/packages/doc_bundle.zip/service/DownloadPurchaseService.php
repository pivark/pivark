<?php
declare(strict_types=1);

namespace weapp\doc_bundle\service;

use weapp\doc_bundle\model\WeappDownloadPurchase;
use think\facade\Db;
use app\common\service\weapp\WeappSupportGateway;

class DownloadPurchaseService
{
    public static function hasPurchased(int $userId, int $bundleId): bool
    {
        if ($userId < 1 || $bundleId < 1) {
            return false;
        }

        return WeappDownloadPurchase::where('user_id', $userId)
            ->where('bundle_id', $bundleId)
            ->where('status', 1)
            ->count() > 0;
    }

    public static function recordPurchase(int $userId, int $bundleId, float $amount = 0.0)
    {
        if ($userId < 1 || $bundleId < 1) {
            return app(WeappSupportGateway::class)->resultFail('参数错误');
        }

        try {
            Db::transaction(function () use ($userId, $bundleId, $amount): void {
                $exists = WeappDownloadPurchase::where('user_id', $userId)
                    ->where('bundle_id', $bundleId)
                    ->lock(true)
                    ->find();
                if ($exists) {
                    WeappDownloadPurchase::where('id', (int) $exists['id'])->update([
                        'status'     => 1,
                        'amount'     => $amount,
                        'created_at' => app(WeappSupportGateway::class)->appTimeNow(),
                    ]);
                } else {
                    WeappDownloadPurchase::insert([
                        'user_id'    => $userId,
                        'bundle_id'  => $bundleId,
                        'amount'     => $amount,
                        'status'     => 1,
                        'created_at' => app(WeappSupportGateway::class)->appTimeNow(),
                    ]);
                }
            });
        } catch (\Throwable $e) {
            return app(WeappSupportGateway::class)->resultFail('购买记录写入失败');
        }

        return app(WeappSupportGateway::class)->resultOk(null, 'ok');
    }

    /** 退款后撤购买：status=0，hasPurchased 不再放行 */
    public static function revokePurchase(int $userId, int $bundleId): void
    {
        if ($userId < 1 || $bundleId < 1) {
            return;
        }
        WeappDownloadPurchase::where('user_id', $userId)
            ->where('bundle_id', $bundleId)
            ->where('status', 1)
            ->update(['status' => 0]);
    }
}
