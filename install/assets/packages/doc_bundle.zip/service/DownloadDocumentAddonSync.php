<?php
declare(strict_types=1);

namespace weapp\doc_bundle\service;

use app\common\service\weapp\WeappDocumentGateway;
use app\common\service\weapp\WeappSupportGateway;

/** document_save manifest handler（文档 Tab POST → 下载包同步） */
final class DownloadDocumentAddonSync
{
    /** @param list<array<string, mixed>> $rows */
    public static function syncForDocument(int $documentId, array $rows)
    {
        $bridge = new DownloadDocumentAddonBridge();
        if (!$bridge->isEnabled()) {
            return app(WeappSupportGateway::class)->resultOk(null, 'ok');
        }

        return $bridge->syncForDocument($documentId, $rows);
    }

    public static function syncAssets(int $documentId): void
    {
        app(WeappDocumentGateway::class)->documentAssetSyncDownload($documentId);
    }
}
