<?php
declare(strict_types=1);

namespace weapp\doc_bundle\service;

/** 插件 autoload 引导（唯一全局入口；不含业务） */
final class DownloadPluginBootstrap
{
    private static bool $booted = false;

    public static function ensureAutoload(): void
    {
        if (self::$booted) {
            return;
        }
        self::$booted = true;
        $base = dirname(__DIR__);
        spl_autoload_register(static function (string $class) use ($base): void {
            if (!str_starts_with($class, 'weapp\\doc_bundle\\')) {
                return;
            }
            $rel  = str_replace('weapp\\doc_bundle\\', '', $class);
            $file = $base . '/' . str_replace('\\', '/', $rel) . '.php';
            if (is_file($file)) {
                require_once $file;
            }
        });
    }
}
