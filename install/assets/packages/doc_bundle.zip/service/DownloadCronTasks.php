<?php
declare(strict_types=1);

namespace weapp\doc_bundle\service;

use app\common\service\weapp\WeappEntitlementGateway;
use app\common\service\weapp\WeappPluginGateway;

final class DownloadCronTasks
{
    public static function register(): void
    {
        $pluginGw = app(WeappPluginGateway::class);
        $pluginGw->pluginCronTaskRegister(
            'doc_bundle',
            'remote_link_check',
            [self::class, 'runRemoteLinkCheck'],
        );
        $pluginGw->pluginCronLegacyHandlerRegister(
            'doc_bundle_remote_link_check',
            'doc_bundle',
            'remote_link_check',
            '巡检下载插件远程链接可达性（需启用 download）',
        );
    }

    /** @param array<string, mixed> $payload */
    public static function runRemoteLinkCheck(array $payload): string
    {
        if (!app(WeappEntitlementGateway::class)->entitlementCan('doc_bundle')) {
            return 'SKIP:下载插件未授权或未启用';
        }
        DownloadPluginBootstrap::ensureAutoload();

        return DownloadLinkCheckService::runCron();
    }
}
