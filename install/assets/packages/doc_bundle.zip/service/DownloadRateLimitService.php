<?php
declare(strict_types=1);

namespace weapp\doc_bundle\service;

use think\facade\Cache;
use think\facade\Request;

class DownloadRateLimitService
{
    public static function allow(int $itemId, int $maxPerMinute = 30): bool
    {
        $ip = trim((string) Request::ip());
        if ($ip === '' || $ip === 'unknown') {
            $ip = '0.0.0.0';
        }
        $window = date('YmdHi');
        $key    = 'dl_rate:' . $ip . ':' . $itemId . ':' . $window;
        $count  = (int) Cache::get($key, 0);
        if ($count >= $maxPerMinute) {
            return false;
        }
        Cache::set($key, $count + 1, 90);

        return true;
    }
}
