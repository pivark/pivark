<?php
/**
 * 元舟 PivArk — 企业全域原子化数字资产中枢
 * (c) 2024-2026 pivark.com. All rights reserved.
 * Author: Angelo
 * 未经允许，不可用于商业用途。
 */
declare(strict_types=1);

namespace weapp\doc_bundle\service;

use weapp\doc_bundle\service\DownloadDocumentSearchContributor;
use app\common\service\weapp\WeappPluginGateway;
use app\common\service\weapp\WeappConfigGateway;
use app\common\service\weapp\WeappDocumentGateway;
use app\common\service\weapp\WeappSiteGateway;
use app\common\service\weapp\WeappSupportGateway;

/** 下载插件全局配置（configs.download_*） */
class DownloadConfigService
{
    public const SCOPE_ALL = 'all';
    public const SCOPE_NAVS = 'navs';

    public const GROUP_BY_FILE = 'by_file';
    public const GROUP_BY_PLATFORM = 'by_platform';

    /** @return list<string> */
    public static function keys(): array
    {
        return [
            'download_nav_scope',
            'download_allowed_nav_ids',
            'download_document_editor_slot',
            'download_editor_group_mode',
            'download_front_group_mode',
            'download_link_check_batch_size',
            'download_search_index_scope',
            'download_link_check_timeout_sec',
            DownloadDailyQuotaService::CONFIG_KEY,
        ];
    }

    /** @return array<string, string> */
    public static function all(): array
    {
        $out = [];
        foreach (self::keys() as $key) {
            $out[$key] = (string) app(WeappConfigGateway::class)->configGet($key, self::defaultFor($key));
        }
        $out['download_document_editor_slot'] = app(WeappPluginGateway::class)->pluginEditorResolveSlot('doc_bundle');

        return $out;
    }

    public static function editorGroupMode(): string
    {
        return self::normalizeGroupMode(
            (string) app(WeappConfigGateway::class)->configGet('download_editor_group_mode', self::GROUP_BY_FILE)
        );
    }

    public static function frontGroupMode(): string
    {
        return self::normalizeGroupMode(
            (string) app(WeappConfigGateway::class)->configGet('download_front_group_mode', self::GROUP_BY_PLATFORM)
        );
    }

    public static function defaultFor(string $key): string
    {
        return match ($key) {
            'download_nav_scope' => self::SCOPE_ALL,
            'download_allowed_nav_ids' => '[]',
            'download_document_editor_slot' => app(WeappPluginGateway::class)->pluginEditorManifestDefaultSlot('doc_bundle'),
            'download_editor_group_mode' => self::GROUP_BY_FILE,
            'download_front_group_mode' => self::GROUP_BY_PLATFORM,
            'download_link_check_batch_size' => '40',
            'download_search_index_scope' => DownloadDocumentSearchContributor::SCOPE_PUBLIC_FULL,
            'download_link_check_timeout_sec' => '10',
            DownloadDailyQuotaService::CONFIG_KEY => DownloadDailyQuotaService::defaultJson(),
            default => '',
        };
    }

    public static function scope(): string
    {
        $scope = (string) app(WeappConfigGateway::class)->configGet('download_nav_scope', self::SCOPE_ALL);

        return in_array($scope, [self::SCOPE_ALL, self::SCOPE_NAVS], true)
            ? $scope
            : self::SCOPE_ALL;
    }

    /** @return list<int> */
    public static function allowedNavIds(): array
    {
        return self::decodeIdList((string) app(WeappConfigGateway::class)->configGet('download_allowed_nav_ids', '[]'));
    }

    /** @return list<int> 勾选栏目含子孙 */
    public static function allowedNavIdsExpanded(): array
    {
        return app(WeappSiteGateway::class)->siteNavExpandWithDescendants(self::allowedNavIds());
    }

    public static function scopeLabel(): string
    {
        return match (self::scope()) {
            self::SCOPE_NAVS => '指定栏目',
            default          => '全部文档',
        };
    }

    public static function documentEligible(int $documentId): bool
    {
        if ($documentId < 1) {
            return false;
        }

        if (self::scope() === self::SCOPE_ALL) {
            return true;
        }

        $navId = app(WeappDocumentGateway::class)->documentPrimaryNavId($documentId);
        if ($navId < 1) {
            return false;
        }

        return in_array($navId, self::allowedNavIdsExpanded(), true);
    }

    /**
     * @param array<string, mixed> $data
     * @return mixed
     */
    public static function saveAdmin(array $data)
    {
        $scope = (string) ($data['download_nav_scope'] ?? self::SCOPE_ALL);
        if (!in_array($scope, [self::SCOPE_ALL, self::SCOPE_NAVS], true)) {
            return app(WeappSupportGateway::class)->resultFail('使用范围无效');
        }

        $navIds = self::normalizePostedIds($data['download_allowed_nav_ids'] ?? []);
        if ($scope === self::SCOPE_NAVS && $navIds === []) {
            return app(WeappSupportGateway::class)->resultFail('请至少选择一个栏目');
        }

        app(WeappConfigGateway::class)->configSet('download_nav_scope', $scope);
        app(WeappConfigGateway::class)->configSet('download_allowed_nav_ids', json_encode($navIds, JSON_UNESCAPED_UNICODE));
        // 禁兼容：退役旧 Tag 圈选键（真删行，不留空值壳）
        app(WeappConfigGateway::class)->configDeleteKeys([
            'download_tag_scope',
            'download_allowed_tag_group_ids',
            'download_allowed_tag_ids',
        ]);

        if (array_key_exists('download_document_editor_slot', $data)) {
            $slotRes = app(WeappPluginGateway::class)->pluginEditorSaveSiteSlot(
                'doc_bundle',
                (string) ($data['download_document_editor_slot'] ?? '')
            );
            if (!$slotRes->isOk()) {
                return $slotRes;
            }
        }
        if (array_key_exists('download_editor_group_mode', $data)) {
            app(WeappConfigGateway::class)->configSet(
                'download_editor_group_mode',
                self::normalizeGroupMode((string) ($data['download_editor_group_mode'] ?? ''))
            );
        }
        if (array_key_exists('download_front_group_mode', $data)) {
            app(WeappConfigGateway::class)->configSet(
                'download_front_group_mode',
                self::normalizeGroupMode((string) ($data['download_front_group_mode'] ?? ''))
            );
        }
        if (array_key_exists('download_link_check_batch_size', $data)) {
            $batch = max(1, min(200, (int) $data['download_link_check_batch_size']));
            app(WeappConfigGateway::class)->configSet('download_link_check_batch_size', (string) $batch);
        }
        if (array_key_exists('download_link_check_timeout_sec', $data)) {
            $timeout = max(3, min(60, (int) $data['download_link_check_timeout_sec']));
            app(WeappConfigGateway::class)->configSet('download_link_check_timeout_sec', (string) $timeout);
        }
        if (array_key_exists('download_search_index_scope', $data)) {
            $scopeSearch = strtolower(trim((string) ($data['download_search_index_scope'] ?? '')));
            app(WeappConfigGateway::class)->configSet(
                'download_search_index_scope',
                $scopeSearch === DownloadDocumentSearchContributor::SCOPE_PUBLIC_ONLY
                    ? DownloadDocumentSearchContributor::SCOPE_PUBLIC_ONLY
                    : DownloadDocumentSearchContributor::SCOPE_PUBLIC_FULL
            );
        }

        $quotaSave = DownloadDailyQuotaService::saveAdmin($data);
        if (!$quotaSave->isOk()) {
            return $quotaSave;
        }

        return app(WeappSupportGateway::class)->resultOk(null, '配置已保存');
    }

    public static function normalizeGroupMode(string $mode): string
    {
        $mode = strtolower(trim($mode));

        return $mode === self::GROUP_BY_PLATFORM ? self::GROUP_BY_PLATFORM : self::GROUP_BY_FILE;
    }

    /** @param mixed $raw @return list<int> */
    private static function normalizePostedIds($raw): array
    {
        if (is_string($raw) && $raw !== '') {
            $decoded = json_decode($raw, true);
            if (is_array($decoded)) {
                $raw = $decoded;
            } else {
                $raw = array_filter(array_map('trim', explode(',', $raw)));
            }
        }
        if (!is_array($raw)) {
            return [];
        }
        $out = [];
        foreach ($raw as $id) {
            $id = (int) $id;
            if ($id > 0) {
                $out[] = $id;
            }
        }

        return array_values(array_unique($out));
    }

    /** @return list<int> */
    private static function decodeIdList(string $json): array
    {
        $decoded = json_decode($json, true);

        return is_array($decoded) ? self::normalizePostedIds($decoded) : [];
    }
}
