<?php
/**
 * 元舟 PivArk — download 插件：超级搜索 / 附件索引贡献者（SSOT 在 weapp）
 */
declare(strict_types=1);

namespace weapp\doc_bundle\service;

use app\common\contract\DocumentAddonSearchContributorInterface;
use app\common\service\weapp\WeappConfigGateway;
use app\common\service\weapp\WeappSearchGateway;
use weapp\doc_bundle\service\DownloadBundleQueryService;
use weapp\doc_bundle\service\DownloadKernelBridgeService;

final class DownloadDocumentSearchContributor implements DocumentAddonSearchContributorInterface
{
    public const SCOPE_PUBLIC_FULL = 'public_full';
    public const SCOPE_PUBLIC_ONLY = 'public_only';
    public const CONFIG_KEY = 'download_search_index_scope';

    public function searchSections(int $documentId): array
    {
        $bundles = $this->bundlesForSearchIndex($documentId);
        if ($bundles === []) {
            return [];
        }
        $lines = app(WeappSearchGateway::class)->searchDocumentAddonPlainTextFromPayload($bundles);
        if ($lines === []) {
            return [];
        }

        return [['label' => '相关下载', 'text' => implode("\n", $lines)]];
    }

    public function searchAttachments(int $documentId): array
    {
        if ($documentId < 1) {
            return [];
        }
        $bundleIds = [];
        foreach ($this->bundlesForSearchIndex($documentId) as $bundle) {
            $bid = (int) ($bundle['id'] ?? 0);
            if ($bid > 0) {
                $bundleIds[] = $bid;
            }
        }
        if ($bundleIds === []) {
            return [];
        }
        DownloadPluginBootstrap::ensureAutoload();

        return DownloadKernelBridgeService::listSearchAttachmentPaths($documentId, $bundleIds);
    }

    /** @return list<array<string, mixed>> */
    public function bundlesForSearchIndex(int $documentId): array
    {
        if ($documentId < 1) {
            return [];
        }
        DownloadPluginBootstrap::ensureAutoload();
        $bundles = DownloadBundleQueryService::listForDocument($documentId, true);
        if ($bundles === []) {
            return [];
        }

        return $this->filterBundles($bundles);
    }

    public function scope(): string
    {
        $v = strtolower(trim((string) app(WeappConfigGateway::class)->configGet(self::CONFIG_KEY, self::SCOPE_PUBLIC_FULL)));

        return in_array($v, [self::SCOPE_PUBLIC_FULL, self::SCOPE_PUBLIC_ONLY], true)
            ? $v
            : self::SCOPE_PUBLIC_FULL;
    }

    /** @param list<array<string, mixed>> $bundles @return list<array<string, mixed>> */
    public function filterBundles(array $bundles): array
    {
        $scope = $this->scope();
        $out   = [];
        foreach ($bundles as $bundle) {
            if ((int) ($bundle['status'] ?? 1) !== 1) {
                continue;
            }
            $public = $this->bundleIsPublic($bundle);
            if ($scope === self::SCOPE_PUBLIC_ONLY) {
                if ($public) {
                    $out[] = $bundle;
                }
                continue;
            }
            if ($public) {
                $out[] = $bundle;
            } else {
                $titleOnly = $this->titleOnlyBundle($bundle);
                if ($titleOnly !== []) {
                    $out[] = $titleOnly;
                }
            }
        }

        return $out;
    }

    /** @param array<string, mixed> $bundle */
    public function bundleIsPublic(array $bundle): bool
    {
        $mode = strtolower(trim((string) ($bundle['access_mode'] ?? 'free')));

        return $mode === '' || $mode === 'free' || $mode === 'login';
    }

    /** @param array<string, mixed> $bundle @return array<string, mixed> */
    private function titleOnlyBundle(array $bundle): array
    {
        $title = trim((string) ($bundle['title'] ?? ''));
        if ($title === '') {
            return [];
        }

        return [
            'id'          => (int) ($bundle['id'] ?? 0),
            'title'       => $title,
            'access_mode' => (string) ($bundle['access_mode'] ?? ''),
            'items'       => [],
        ];
    }
}
