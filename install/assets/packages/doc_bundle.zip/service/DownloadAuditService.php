<?php
declare(strict_types=1);

namespace weapp\doc_bundle\service;



use weapp\doc_bundle\model\WeappDownloadLog;
use app\common\service\weapp\WeappFrontGateway;
use app\common\service\weapp\WeappSupportGateway;
class DownloadAuditService
{
    /** @param array<string, mixed> $ctx */
    public static function log(int $itemId, array $ctx = []): void
    {
        if ($itemId < 1) {
            return;
        }
        $userId = (int) (app(WeappFrontGateway::class)->frontCurrent()['id'] ?? 0);
        try {
            WeappDownloadLog::insert([
                'item_id'     => $itemId,
                'user_id'     => $userId,
                'bundle_id'   => (int) ($ctx['bundle_id'] ?? 0),
                'document_id' => (int) ($ctx['document_id'] ?? 0),
                'ip'          => (string) request()->ip(),
                'created_at'  => app(WeappSupportGateway::class)->appTimeNow(),
            ]);
        } catch (\Throwable $e) {
            app(WeappSupportGateway::class)->kernelOpsLog('download_audit_log_failed', ['msg' => $e->getMessage()]);
        }
    }
}
