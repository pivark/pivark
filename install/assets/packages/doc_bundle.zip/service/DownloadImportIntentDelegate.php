<?php
/**
 * 元舟 PivArk — 企业全域原子化数字资产中枢
 * (c) 2024-2026 pivark.com. All rights reserved.
 * Author: Angelo
 * 未经允许，不可用于商业用途。
 */
declare(strict_types=1);

namespace weapp\doc_bundle\service;

use app\common\contract\ImportIntentDelegateInterface;
use app\common\service\weapp\WeappEntitlementGateway;

/** download 导入意图 delegate（网盘/压缩包/远程链接/本地附件） */
final class DownloadImportIntentDelegate implements ImportIntentDelegateInterface
{
    public function identifier(): string
    {
        return 'doc_bundle';
    }

    public function isEnabled(): bool
    {
        return app(WeappEntitlementGateway::class)->entitlementCan('doc_bundle')
            && is_dir(ROOT_PATH . 'weapp/download');
    }

    public function supportedIntentKinds(): array
    {
        return [
            'pan_share',
            'local_archive',
            'local_image',
            'local_other',
            'generic_url',
        ];
    }

    public function supportedChannels(): array
    {
        return ['paste', 'drop', 'scan', 'import', 'voice', 'chat'];
    }

    public function priority(): int
    {
        return 100;
    }

    public function label(): string
    {
        return '下载插件';
    }
}