<?php
declare(strict_types=1);

namespace weapp\doc_bundle\service;

/** 付费/积分下载下单入参校验（纯逻辑，可单测；DownloadAccessService 委托） */
final class DownloadOrderValidator
{
    /**
     * @return array{ok:true,bundle_id:int}|array{ok:false,code:int,msg:string}
     */
    public static function bundleId(int $bundleId): array
    {
        if ($bundleId < 1) {
            return ['ok' => false, 'msg' => 'invalid'];
        }

        return ['ok' => true, 'bundle_id' => $bundleId];
    }

    /**
     * @return array{ok:true,mode:string}|array{ok:false,code:int,msg:string}
     */
    public static function paidAccessMode(string $accessMode): array
    {
        $mode = DownloadAccessService::normalizeAccessMode($accessMode);
        if ($mode !== 'paid' && $mode !== 'member_paid') {
            return ['ok' => false, 'msg' => 'not_paid_bundle'];
        }

        return ['ok' => true, 'mode' => $mode];
    }

    /**
     * @return array{ok:true,mode:string}|array{ok:false,code:int,msg:string}
     */
    public static function pointsAccessMode(string $accessMode): array
    {
        $mode = DownloadAccessService::normalizeAccessMode($accessMode);
        if ($mode !== 'points') {
            return ['ok' => false, 'msg' => 'not_points_bundle'];
        }

        return ['ok' => true, 'mode' => $mode];
    }

    /**
     * @return array{ok:true,price:float}|array{ok:false,code:int,msg:string}
     */
    public static function price(float $price): array
    {
        $price = max(0, round($price, 2));
        if ($price <= 0) {
            return ['ok' => false, 'msg' => 'price_invalid'];
        }

        return ['ok' => true, 'price' => $price];
    }

    /**
     * @return array{ok:true,cost:int}|array{ok:false,code:int,msg:string}
     */
    public static function pointsCost(int $cost): array
    {
        $cost = max(0, $cost);
        if ($cost < 1) {
            return ['ok' => false, 'msg' => 'points_cost_invalid'];
        }

        return ['ok' => true, 'cost' => $cost];
    }
}