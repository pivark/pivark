/** SSOT: download document-editor.html（文档 Tab：按文件 / 按网盘双视图） */
export function buildDownloadDocumentEditorHtml() {
  return `<!DOCTYPE html>
<html lang="zh-CN" data-iframe-theme="light">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>相关下载 · 文档编辑</title>
  <style>
    :root {
      font-family: var(--pv-font-family, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif);
      font-size: var(--pv-font-size, 14px);
      --pv-radius-base: 4px;
      --pv-radius-lg: calc(var(--pv-radius-base) + 4px);
      --pv-primary: rgb(64, 158, 255);
      --pv-primary-soft: rgb(236, 245, 255);
      --pv-primary-border: rgb(179, 216, 255);
      --pv-primary-hover: rgb(102, 177, 255);
      --pv-danger: rgb(245, 108, 108);
      --pv-danger-soft: rgb(254, 240, 240);
      --pv-danger-border: rgb(251, 196, 196);
      --pv-card-bg: rgb(255, 255, 255);
      --pv-fill: rgb(245, 247, 250);
      --pv-border: rgb(228, 231, 237);
      --pv-text: rgb(48, 49, 51);
      --pv-text-secondary: rgb(144, 147, 153);
      --pv-input-bg: rgb(255, 255, 255);
    }
    html[data-iframe-theme='light'] {
      color-scheme: light;
      --pv-primary-soft: color-mix(in srgb, var(--pv-primary) 12%, var(--pv-card-bg));
      --pv-primary-border: color-mix(in srgb, var(--pv-primary) 35%, var(--pv-border));
      --pv-primary-hover: color-mix(in srgb, var(--pv-primary) 88%, #000);
      --pv-danger-soft: color-mix(in srgb, var(--pv-danger) 12%, var(--pv-card-bg));
      --pv-danger-border: color-mix(in srgb, var(--pv-danger) 40%, var(--pv-border));
    }
    html[data-iframe-theme='dark'] {
      color-scheme: dark;
      --pv-danger-soft: color-mix(in srgb, var(--pv-danger) 16%, var(--pv-card-bg));
      --pv-danger-border: color-mix(in srgb, var(--pv-danger) 40%, var(--pv-border));
      --pv-primary-soft: color-mix(in srgb, var(--pv-primary) 14%, var(--pv-card-bg));
      --pv-primary-border: color-mix(in srgb, var(--pv-primary) 35%, var(--pv-border));
      --pv-primary-hover: color-mix(in srgb, var(--pv-primary) 82%, #fff);
    }
    body { margin: 0; padding: 8px 4px 12px; background: transparent; color: var(--pv-text); font-size: inherit; }
    body.embed-tab { padding: 14px 20px 28px; box-sizing: border-box; overflow: auto; background: transparent; }
    html.embed-tab, body.embed-tab { min-height: 100%; height: auto; }
    body.embed-tab .pv-dl-page-title { display: none; }
    .hint { color: var(--pv-text-secondary); margin: 0 0 12px; line-height: 1.5; font-size: 0.857em; }
    .hint.err { color: var(--pv-danger); font-weight: 500; }
    .actions { display: flex; gap: 10px; flex-wrap: wrap; margin-bottom: 12px; align-items: center; }
    button {
      padding: var(--pv-btn-padding, 8px 15px); border-radius: var(--pv-radius-base);
      border: 1px solid var(--pv-border); background: var(--pv-card-bg); color: var(--pv-text);
      cursor: pointer; font-size: inherit; line-height: 1.4;
    }
    button:hover { background: var(--pv-fill); }
    button.primary { background: var(--pv-primary); color: #fff; border-color: var(--pv-primary); }
    button.primary:hover { background: var(--pv-primary-hover); border-color: var(--pv-primary-hover); }
    button.plain { color: var(--pv-primary); border-color: var(--pv-primary-border); background: var(--pv-primary-soft); }
    button.danger { color: var(--pv-danger); border-color: var(--pv-danger-border); background: var(--pv-danger-soft); }
    button.icon-btn { padding: 4px 8px; min-width: 28px; line-height: 1; }
    a { color: var(--pv-primary); font-size: inherit; text-decoration: none; }
    a:hover { opacity: 0.85; }
    .link-sep { color: var(--pv-text-secondary); margin: 0 4px; opacity: 0.65; }
    .is-hidden { display: none !important; }
    input[type="text"], input[type="number"], select {
      box-sizing: border-box; padding: var(--pv-input-padding, 7px 11px);
      border: 1px solid var(--pv-border); border-radius: var(--pv-radius-base); font-size: inherit;
      background: var(--pv-input-bg, var(--pv-card-bg)); color: var(--pv-text);
    }
    input[type="text"]:focus, input[type="number"]:focus, select:focus {
      outline: none; border-color: var(--pv-primary);
      box-shadow: 0 0 0 2px color-mix(in srgb, var(--pv-primary) 18%, transparent);
    }
    input[type="file"] { display: none; }
    .toolbar-add { margin-bottom: 14px; }
    .file-list { display: flex; flex-direction: column; gap: 12px; }
    .file-card {
      border: 1px solid var(--pv-border); border-radius: var(--pv-radius-lg); background: var(--pv-card-bg);
      box-shadow: 0 1px 2px color-mix(in srgb, var(--pv-text) 6%, transparent); overflow: hidden;
    }
    html[data-iframe-theme='dark'] .file-card { box-shadow: none; }
    .file-head {
      display: flex; align-items: center; gap: 8px; flex-wrap: wrap;
      padding: 12px 14px; background: var(--pv-fill);
      border-bottom: 1px solid var(--pv-border); cursor: pointer; user-select: none;
    }
    .file-head-main { display: flex; align-items: center; gap: 8px; flex: 1; min-width: 0; }
    .chevron { color: var(--pv-text-secondary); font-size: 0.786em; width: 16px; text-align: center; flex-shrink: 0; }
    .file-card.is-open .chevron { transform: rotate(90deg); }
    .file-title-input {
      flex: 1; min-width: 120px; max-width: 280px; font-weight: 600; font-size: 1em;
      border: 1px solid transparent; background: transparent; padding: 4px 8px; border-radius: var(--pv-radius-base);
    }
    .file-title-input:hover, .file-title-input:focus { border-color: var(--pv-border); background: var(--pv-card-bg); }
    .file-meta { font-size: 0.857em; color: var(--pv-text-secondary); white-space: nowrap; }
    .file-body { padding: 10px 14px 14px; display: none; }
    .file-card.is-open .file-body { display: block; }
    .file-paste { display: flex; gap: 8px; flex-wrap: wrap; margin-bottom: 12px; align-items: center; }
    .file-paste input[type="text"] { flex: 1 1 180px; min-width: 140px; }
    .plat-block { margin-top: 10px; border: 1px solid var(--pv-border); border-radius: var(--pv-radius-base); background: var(--pv-fill); }
    .plat-block:first-child { margin-top: 0; }
    .plat-head {
      display: flex; align-items: center; justify-content: space-between; gap: 8px; flex-wrap: wrap;
      padding: 8px 10px; cursor: pointer; border-bottom: 1px solid transparent;
    }
    .plat-block.is-open .plat-head { border-bottom-color: var(--pv-border); }
    .plat-head-main { display: flex; align-items: center; gap: 6px; font-size: 0.857em; font-weight: 600; color: var(--pv-text); }
    .plat-head-main img { width: 18px; height: 18px; flex-shrink: 0; }
    .plat-head-actions {
      display: flex; align-items: center; gap: 8px; flex-wrap: wrap; margin-left: auto;
    }
    .plat-batch-label { font-size: 0.857em; color: var(--pv-text-secondary); font-weight: 500; white-space: nowrap; }
    .plat-batch-access { width: 108px; }
    .access-ctrl { display: inline-flex; align-items: center; gap: 4px; }
    .plat-body { padding: 4px 10px 10px; display: none; }
    .plat-block.is-open .plat-body { display: block; }
    .item-row {
      display: flex; flex-wrap: wrap; gap: 6px; align-items: center;
      padding: 8px 0; border-bottom: 1px dashed var(--pv-border); font-size: 0.857em;
    }
    .item-row:last-child { border-bottom: none; }
    .item-row-head {
      padding: 6px 0 2px; border-bottom: none; font-size: 0.786em; font-weight: 600;
      color: var(--pv-text-secondary);
    }
    .item-row-head .item-action { visibility: hidden; }
    .item-label { width: 92px; flex: 0 1 92px; min-width: 72px; }
    .item-main {
      flex: 1 1 160px; min-width: 120px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
    }
    .item-main:focus { white-space: normal; }
    .item-code { width: 72px; flex: 0 0 72px; }
    .item-access { width: 108px; flex: 0 0 108px; font-size: inherit; }
    .item-points { width: 62px; flex: 0 0 62px; font-variant-numeric: tabular-nums; }
    .item-action { flex: 0 0 auto; }
    .plat-quick { display: flex; flex-wrap: wrap; gap: 6px; margin-top: 10px; }
    .empty-tip {
      padding: 20px; text-align: center; color: var(--pv-text-secondary); font-size: 0.857em;
      border: 1px dashed var(--pv-border); border-radius: var(--pv-radius-base); background: var(--pv-fill);
    }
    .empty-state { display: flex; flex-direction: column; align-items: center; gap: 12px; }
    .mode-bar {
      display: flex; flex-wrap: wrap; gap: 8px; align-items: center; margin-bottom: 12px;
      padding: 10px 12px; border: 1px solid var(--pv-border); border-radius: var(--pv-radius-base);
      background: var(--pv-fill);
    }
    .mode-bar label { font-size: 0.857em; color: var(--pv-text-secondary); margin-right: 4px; }
    .mode-bar button.is-active { background: var(--pv-primary-soft); border-color: var(--pv-primary-border); color: var(--pv-primary); font-weight: 600; }
    .item-file-title { width: 108px; flex: 0 1 108px; min-width: 88px; }
    .err { color: var(--pv-danger); }
    @media (max-width: 640px) {
      body.embed-tab { padding: 10px 12px 20px; }
      .item-row, .item-row-head { flex-direction: column; align-items: stretch; }
      .item-label, .item-main, .item-code, .item-access, .item-points, .item-action { width: 100%; flex: 1 1 auto; max-width: none; }
      .item-row-head { display: none; }
      .plat-head-actions { width: 100%; margin-left: 0; justify-content: flex-start; }
      .file-title-input { max-width: none; }
    }
  </style>
</head>
<body>
  <p class="hint" id="status">加载中…</p>
  <p class="hint" id="layout-hint" style="margin-top:-6px"></p>
  <div class="actions" id="toolbar">
    <button type="button" class="primary is-hidden" id="add-bundle" data-testid="download-add-bundle">添加资源包</button>
    <span id="plugin-admin-links" class="is-hidden">
      <a href="/admin/weapp/host/doc_bundle/settings" target="_blank" rel="noopener">插件设置</a>
      <span class="link-sep" aria-hidden="true">·</span>
      <a href="/admin/weapp/host/doc_bundle/link-check" target="_blank" rel="noopener">链接巡检</a>
    </span>
  </div>
  <div id="root"></div>
  <script>
    const PLUGIN_ID = 'doc_bundle';
    const PREPARE = 'pivark:document-editor-prepare-save';
    const EXPORT = 'pivark:document-editor-export';
    const PREFILL = 'pivark:document-editor-prefill';
    const INIT = 'pivark:document-editor-init';
    const THEME = 'pivark:document-editor-theme';
    const RESIZE = 'pivark:document-editor-resize';
    const PAN_ICON_BASE = '/static/admin/images/pan';
    const GENERIC_REMOTE_LABELS = { '远程下载':1,'远程链接':1,'本地下载':1,'立即下载':1,'远程资源':1 };
    const PLATFORM_KEY_ORDER = [
      'baidu','quark','aliyun','tianyi','lanzou','123pan','cowtransfer','feijipan',
      'weiyun','google','onedrive','115','mega','feishu','terabox','ctfile','local','other',
    ];
    const PLATFORMS = [
      { id:'baidu', label:'百度网盘', hosts:/(?:^|\\.)pan\\.baidu\\.com|yun\\.baidu\\.com/i },
      { id:'quark', label:'夸克网盘', hosts:/pan\\.quark\\.cn/i },
      { id:'aliyun', label:'阿里云盘', hosts:/aliyundrive\\.com|alipan\\.com/i },
      { id:'tianyi', label:'天翼云盘', hosts:/cloud\\.189\\.cn/i },
      { id:'lanzou', label:'蓝奏云', hosts:/lanzou[a-z0-9]*\\.com/i },
      { id:'123pan', label:'123云盘', hosts:/123pan\\.com|123684\\.com/i },
      { id:'115', label:'115网盘', hosts:/115\\.com/i },
      { id:'onedrive', label:'OneDrive', hosts:/onedrive\\.live\\.com|sharepoint\\.com/i },
      { id:'google', label:'Google Drive', hosts:/drive\\.google\\.com/i },
      { id:'mega', label:'MEGA', hosts:/mega\\.nz/i },
      { id:'weiyun', label:'微云', hosts:/share\\.weiyun\\.com/i },
      { id:'feishu', label:'飞书', hosts:/feishu\\.cn/i },
      { id:'cowtransfer', label:'奶牛快传', hosts:/cowtransfer\\.com/i },
      { id:'feijipan', label:'飞机盘', hosts:/feijipan\\.com/i },
      { id:'terabox', label:'TeraBox', hosts:/terabox\\.com/i },
      { id:'ctfile', label:'城通网盘', hosts:/ctfile\\.com/i },
    ];
    const OTHER_PLATFORM = { id:'other', label:'远程链接' };

    const params = new URLSearchParams(location.search);
    const editorSlot = String(params.get('slot') || '');
    let documentId = Number(params.get('document_id') || 0);
    const isDocTab = editorSlot === 'tab';
    let bundles = [];
    let fileGroups = [];
    let platformGroups = [];
    let editorGroupMode = 'by_file';
    let nextFgSeq = 1;
    let nextPgSeq = 1;
    let memberLevels = [];
    let memberPointsEnabled = true;
    let dataDirty = false;
    let bundlesHadItemsOnLoad = false;
    let loadSeq = 0;
    let dataReady = false;
    const statusEl = document.getElementById('status');
    const rootEl = document.getElementById('root');

    if (!isDocTab) document.getElementById('add-bundle').classList.remove('is-hidden');
    else document.getElementById('plugin-admin-links').classList.remove('is-hidden');
    if (editorSlot === 'tab') {
      document.documentElement.classList.add('embed-tab');
      document.body.classList.add('embed-tab');
    }

    function themePreset(mode) {
      if (mode === 'dark') {
        return {
          contentTheme: 'dark',
          canvas: 'rgb(9, 9, 11)',
          card: 'rgb(24, 24, 27)',
          fill: 'rgb(39, 39, 42)',
          border: 'rgb(63, 63, 70)',
          text: 'rgb(228, 228, 231)',
          textSecondary: 'rgb(161, 161, 170)',
          inputBg: 'rgb(24, 24, 27)',
        };
      }
      return {
        contentTheme: 'light',
        canvas: 'rgb(245, 247, 250)',
        card: 'rgb(255, 255, 255)',
        fill: 'rgb(245, 247, 250)',
        border: 'rgb(228, 231, 237)',
        text: 'rgb(48, 49, 51)',
        textSecondary: 'rgb(144, 147, 153)',
        inputBg: 'rgb(255, 255, 255)',
      };
    }

    function pickParentComputed(el, prop) {
      if (!el || !window.parent) return '';
      const val = window.parent.getComputedStyle(el)[prop];
      if (!val || val === 'transparent' || val === 'rgba(0, 0, 0, 0)') return '';
      return String(val).trim();
    }

    function readParentAccent(content, pRoot) {
      const primaryBtn =
        content.querySelector('.el-button--primary:not(.is-link):not(.is-text)') ||
        content.querySelector('.pv-sticky-save-bar .el-button--primary') ||
        content.querySelector('.el-button--primary');
      const plainPrimary = content.querySelector('.el-button--primary.is-plain');
      const dangerPlain =
        content.querySelector('.el-button--danger.is-plain') ||
        content.querySelector('.el-button--danger');
      const pStyle = window.parent.getComputedStyle(pRoot);
      return {
        primary:
          pickParentComputed(primaryBtn, 'backgroundColor') ||
          pStyle.getPropertyValue('--el-color-primary').trim(),
        primarySoft: pickParentComputed(plainPrimary, 'backgroundColor'),
        primaryBorder: pickParentComputed(plainPrimary, 'borderColor'),
        danger:
          pickParentComputed(dangerPlain, 'color') ||
          pickParentComputed(content.querySelector('.el-button--danger:not(.is-plain)'), 'backgroundColor') ||
          pStyle.getPropertyValue('--el-color-danger').trim(),
        dangerSoft: pickParentComputed(dangerPlain, 'backgroundColor'),
        dangerBorder: pickParentComputed(dangerPlain, 'borderColor'),
      };
    }

    function readParentMetrics(content, pRoot) {
      const primaryBtn =
        content.querySelector('.el-button--primary:not(.is-link):not(.is-text)') ||
        content.querySelector('.el-button--primary');
      const inputWrap = content.querySelector('.el-input__wrapper');
      const btnSt = primaryBtn ? window.parent.getComputedStyle(primaryBtn) : null;
      const inSt = inputWrap ? window.parent.getComputedStyle(inputWrap) : null;
      const rootSt = window.parent.getComputedStyle(pRoot);
      return {
        fontFamily: rootSt.fontFamily,
        fontSize: (btnSt && btnSt.fontSize) || (inSt && inSt.fontSize) || rootSt.fontSize,
        radiusBase: (btnSt && btnSt.borderRadius) || (inSt && inSt.borderRadius) || '4px',
        btnPadding: btnSt ? btnSt.padding : '',
        inputPadding: inSt ? inSt.padding : '',
      };
    }

    function syncParentThemeBootstrap() {
      try {
        if (!window.parent || window.parent === window) return;
        const pDoc = window.parent.document;
        const pRoot = pDoc.documentElement;
        const content = pDoc.getElementById('__pivark_main_content');
        if (!content) return;
        const contentTheme =
          pRoot.dataset.adminContentTheme === 'dark' || pRoot.classList.contains('dark')
            ? 'dark'
            : 'light';
        const cardEl =
          content.querySelector('.pv-form-page-card-wrap') ||
          content.querySelector('.pv-admin-field-block') ||
          content.querySelector('.el-input__wrapper') ||
          content.querySelector('.el-card');
        const inputEl =
          content.querySelector('.pv-content-document-form .el-input__wrapper') ||
          content.querySelector('.el-input__wrapper');
        const fillEl = inputEl || cardEl;
        const labelEl =
          content.querySelector('.pv-content-document-form .el-form-item__label') ||
          content.querySelector('.hint, .el-text');
        applyThemeTokens(Object.assign({
          contentTheme: contentTheme,
          canvas: pickParentComputed(content, 'backgroundColor'),
          card:
            pickParentComputed(cardEl, 'backgroundColor') ||
            pickParentComputed(content, 'backgroundColor'),
          fill:
            pickParentComputed(fillEl, 'backgroundColor') ||
            pickParentComputed(cardEl, 'backgroundColor'),
          inputBg: pickParentComputed(inputEl, 'backgroundColor'),
          border:
            pickParentComputed(inputEl, 'borderColor') ||
            pickParentComputed(cardEl, 'borderColor'),
          text:
            pickParentComputed(cardEl, 'color') ||
            pickParentComputed(content, 'color'),
          textSecondary: pickParentComputed(labelEl, 'color'),
        }, readParentAccent(content, pRoot), readParentMetrics(content, pRoot)));
      } catch (e) { /* ignore */ }
    }

    let parentThemeObserver = null;
    let themeSyncTimer = 0;
    function scheduleParentThemeSync() {
      if (themeSyncTimer) window.clearTimeout(themeSyncTimer);
      themeSyncTimer = window.setTimeout(function () {
        themeSyncTimer = 0;
        syncParentThemeBootstrap();
      }, 32);
      window.requestAnimationFrame(function () {
        window.requestAnimationFrame(function () { syncParentThemeBootstrap(); });
      });
    }
    function watchParentTheme() {
      if (editorSlot !== 'tab') return;
      try {
        if (!window.parent || window.parent === window) return;
        const pDoc = window.parent.document;
        const pRoot = pDoc.documentElement;
        const pMain = pDoc.getElementById('__pivark_main_content');
        parentThemeObserver = new MutationObserver(function () { scheduleParentThemeSync(); });
        parentThemeObserver.observe(pRoot, {
          attributes: true,
          attributeFilter: ['data-admin-content-theme', 'data-theme', 'class', 'style'],
        });
        if (pMain) {
          parentThemeObserver.observe(pMain, {
            attributes: true,
            attributeFilter: ['class', 'style'],
          });
        }
      } catch (e) { /* ignore */ }
    }

    function notifyParentHeight() {
      if (editorSlot !== 'tab') return;
      const h = Math.max(document.documentElement.scrollHeight, document.body.scrollHeight, document.documentElement.offsetHeight);
      try { parent.postMessage({ type: RESIZE, identifier: PLUGIN_ID, height: h }, '*'); } catch (e) {}
    }
    function panIconSrc(id) { return PAN_ICON_BASE + '/' + (id || 'other') + '.svg'; }
    function hostFromUrl(url) {
      try { return new URL(url).hostname.toLowerCase(); } catch (e) {
        const m = String(url).match(/^([a-z0-9][-a-z0-9.]*\\.[a-z]{2,})/i);
        return m ? m[1].toLowerCase() : '';
      }
    }
    function detectPanPlatform(url) {
      const host = hostFromUrl(url);
      if (!host) return Object.assign({}, OTHER_PLATFORM, { iconSrc: panIconSrc('other') });
      for (let i = 0; i < PLATFORMS.length; i++) {
        if (PLATFORMS[i].hosts.test(host)) {
          return { id: PLATFORMS[i].id, label: PLATFORMS[i].label, iconSrc: panIconSrc(PLATFORMS[i].id) };
        }
      }
      return Object.assign({}, OTHER_PLATFORM, { iconSrc: panIconSrc('other') });
    }
    function platformMeta(key) {
      if (key === 'local') return { id: 'local', label: '本地文件', iconSrc: '' };
      for (let i = 0; i < PLATFORMS.length; i++) {
        if (PLATFORMS[i].id === key) return { id: key, label: PLATFORMS[i].label, iconSrc: panIconSrc(key) };
      }
      return { id: 'other', label: '远程链接', iconSrc: panIconSrc('other') };
    }
    function isGenericRemoteLabel(label) {
      const t = String(label || '').trim();
      return !t || GENERIC_REMOTE_LABELS[t];
    }
    function parseReadAccess(val) {
      if (val === 'login') return { access_mode: 'login', member_level_id: 0 };
      if (val === 'points') return { access_mode: 'points', member_level_id: 0 };
      if (String(val).indexOf('level:') === 0) {
        return { access_mode: 'member', member_level_id: parseInt(String(val).slice(6), 10) || 0 };
      }
      return { access_mode: 'free', member_level_id: 0 };
    }
    function readAccessValue(item) {
      if (item.access_mode === 'login') return 'login';
      if (item.access_mode === 'points') return 'points';
      if (item.access_mode === 'member' && item.member_level_id > 0) return 'level:' + item.member_level_id;
      return '0';
    }
    function applyReadAccess(item, val) {
      const parsed = parseReadAccess(val);
      item.access_mode = parsed.access_mode;
      item.member_level_id = parsed.member_level_id;
      if (parsed.access_mode !== 'points') item.points_cost = 0;
      else if ((item.points_cost || 0) < 1) item.points_cost = 1;
    }
    function uniformAccessValue(items) {
      if (!items || !items.length) return '';
      const first = readAccessValue(items[0]);
      if (first === 'points') {
        const pts = Math.max(1, Number(items[0].points_cost || 1));
        for (let i = 1; i < items.length; i++) {
          if (readAccessValue(items[i]) !== first) return '';
          if (Math.max(1, Number(items[i].points_cost || 1)) !== pts) return '';
        }
        return first;
      }
      for (let i = 1; i < items.length; i++) {
        if (readAccessValue(items[i]) !== first) return '';
      }
      return first;
    }
    function uniformPointsCost(items) {
      if (!items || !items.length) return 1;
      return Math.max(1, Number(items[0].points_cost || 1));
    }
    function fillAccessSelectOptions(sel, withBatchPlaceholder) {
      sel.innerHTML = '';
      if (withBatchPlaceholder) {
        const ph = document.createElement('option');
        ph.value = '';
        ph.textContent = '批量设置…';
        sel.appendChild(ph);
      }
      const free = document.createElement('option');
      free.value = '0';
      free.textContent = '开放';
      sel.appendChild(free);
      const login = document.createElement('option');
      login.value = 'login';
      login.textContent = '须登录';
      sel.appendChild(login);
      memberLevels.forEach(function (lv) {
        const opt = document.createElement('option');
        opt.value = 'level:' + lv.id;
        opt.textContent = lv.name + '及以上';
        sel.appendChild(opt);
      });
      if (memberPointsEnabled !== false) {
        const opt = document.createElement('option');
        opt.value = 'points';
        opt.textContent = '积分';
        sel.appendChild(opt);
      }
    }
    function createAccessControls(opts) {
      const items = opts.items || (opts.item ? [opts.item] : []);
      const isBatch = !!opts.isBatch;
      const rerender = opts.rerender || function () {};
      const wrap = document.createElement('span');
      wrap.className = 'access-ctrl';
      const sel = document.createElement('select');
      sel.className = opts.className || 'item-access';
      sel.setAttribute('aria-label', isBatch ? '批量设置下载权限' : '下载权限');
      fillAccessSelectOptions(sel, isBatch);
      const initVal = isBatch ? uniformAccessValue(items) : readAccessValue(items[0] || defaultAccess());
      sel.value = initVal || (isBatch ? '' : '0');
      let pointsInput = null;
      function stopBubble(ev) { ev.stopPropagation(); }
      function ensurePointsInput(refItem) {
        if (pointsInput) return pointsInput;
        pointsInput = document.createElement('input');
        pointsInput.type = 'number';
        pointsInput.className = 'item-points';
        pointsInput.min = '1';
        pointsInput.placeholder = '分';
        pointsInput.setAttribute('aria-label', '积分数');
        pointsInput.addEventListener('click', stopBubble);
        pointsInput.addEventListener('input', function () {
          dataDirty = true;
          const pts = Math.max(1, parseInt(pointsInput.value, 10) || 1);
          items.forEach(function (it) { it.points_cost = pts; });
        });
        wrap.appendChild(pointsInput);
        return pointsInput;
      }
      function syncPointsField(val) {
        if (val === 'points') {
          const pi = ensurePointsInput(items[0] || {});
          pi.value = String(isBatch ? uniformPointsCost(items) : Math.max(1, Number((items[0] || {}).points_cost || 1)));
          pi.style.display = '';
        } else if (pointsInput) {
          pointsInput.style.display = 'none';
        }
      }
      sel.addEventListener('click', stopBubble);
      sel.addEventListener('change', function () {
        const val = sel.value;
        if (isBatch && !val) return;
        dataDirty = true;
        items.forEach(function (it) { applyReadAccess(it, val); });
        if (val === 'points') {
          const pi = ensurePointsInput(items[0] || {});
          const pts = Math.max(1, parseInt(pi.value, 10) || 1);
          items.forEach(function (it) { it.points_cost = pts; });
        }
        rerender();
      });
      syncPointsField(initVal);
      wrap.appendChild(sel);
      return wrap;
    }

    function normalizeGroupMode(mode) {
      return String(mode || '').trim() === 'by_platform' ? 'by_platform' : 'by_file';
    }

    function layoutHintText() {
      if (editorGroupMode === 'by_platform') {
        return '按网盘分组录入：每个网盘一组，组内填写文件名与链接；保存时仍按「文件包 + 链接项」入库。';
      }
      return '按文件分组录入：每个文件一组，组内按网盘添加链接；网盘组头可批量设权限。';
    }

    function refreshLayoutHint() {
      const el = document.getElementById('layout-hint');
      if (el) el.textContent = layoutHintText();
    }

    function countFilledBundles(list) {
      return (list || []).some(function (b) {
        return (b.items || []).some(function (it) {
          return String(it.remote_url || it.file_path || '').trim() !== '';
        });
      });
    }

    function ensureViewsFromBundles() {
      const hasFilled = fileGroups.some(function (fg) {
        return (fg.items || []).some(itemFilled);
      });
      if (!hasFilled && countFilledBundles(bundles)) {
        fileGroups = bundlesToFileGroups(bundles);
        platformGroups = fileGroupsToPlatformGroups(fileGroups);
      }
    }

    function setEditorGroupMode(mode, skipRender) {
      const next = normalizeGroupMode(mode);
      if (next === editorGroupMode) return;
      ensureViewsFromBundles();
      if (editorGroupMode === 'by_platform') {
        fileGroups = platformGroupsToFileGroups(platformGroups);
      }
      if (next === 'by_platform') {
        platformGroups = fileGroupsToPlatformGroups(fileGroups);
      } else {
        fileGroups = platformGroupsToFileGroups(platformGroups);
        platformGroups = fileGroupsToPlatformGroups(fileGroups);
      }
      editorGroupMode = next;
      bundles = fileGroupsToBundles();
      if (countFilledBundles(bundles)) {
        bundlesHadItemsOnLoad = true;
      }
      dataDirty = true;
      refreshLayoutHint();
      if (!skipRender) render();
    }

    function createPlatformGroup(opts) {
      const pk = String(opts.platformKey || 'baidu');
      return {
        id: 'pg-' + (nextPgSeq++),
        platformKey: pk,
        open: opts.open !== false,
        items: Array.isArray(opts.items) ? opts.items : [],
      };
    }

    function fileGroupsToPlatformGroups(fgs) {
      const merged = {};
      (fgs || []).forEach(function (fg) {
        (fg.items || []).forEach(function (item) {
          const pk = platformKeyForItem(item);
          if (!merged[pk]) merged[pk] = createPlatformGroup({ platformKey: pk, items: [] });
          const row = Object.assign({}, item, {
            fileTitle: String(fg.title || '').trim() || '文件1',
          });
          merged[pk].items.push(row);
        });
      });
      const groups = [];
      PLATFORM_KEY_ORDER.forEach(function (k) {
        if (merged[k]) { groups.push(merged[k]); delete merged[k]; }
      });
      Object.keys(merged).forEach(function (k) { groups.push(merged[k]); });
      return groups.length ? groups : [createPlatformGroup({ platformKey: 'baidu', open: true, items: [] })];
    }

    function platformGroupsToFileGroups(pgs) {
      const merged = {};
      const order = [];
      (pgs || []).forEach(function (pg) {
        (pg.items || []).forEach(function (item) {
          const title = String(item.fileTitle || '').trim() || '文件1';
          if (!merged[title]) {
            merged[title] = createFileGroup({ title: title, items: [] });
            order.push(title);
          }
          const copy = normalizeItem(item, {
            access_mode: item.access_mode || 'free',
            member_level_id: item.member_level_id || 0,
            points_cost: item.points_cost || 0,
          });
          merged[title].items.push(copy);
        });
      });
      return order.length ? order.map(function (t) { return merged[t]; }) : [createFileGroup({ title: '文件1', open: true, items: [] })];
    }

    function syncViewBeforeExport() {
      if (editorGroupMode === 'by_platform') {
        fileGroups = platformGroupsToFileGroups(platformGroups);
      } else {
        platformGroups = fileGroupsToPlatformGroups(fileGroups);
      }
    }

    function renderModeBar(container) {
      const bar = document.createElement('div');
      bar.className = 'mode-bar';
      bar.setAttribute('role', 'group');
      bar.setAttribute('aria-label', '录入分组方式');
      const label = document.createElement('label');
      label.textContent = '录入分组';
      bar.appendChild(label);
      [['by_file', '按文件分网盘'], ['by_platform', '按网盘分文件']].forEach(function (pair) {
        const btn = document.createElement('button');
        btn.type = 'button';
        btn.textContent = pair[1];
        if (editorGroupMode === pair[0]) btn.classList.add('is-active');
        btn.addEventListener('click', function () { setEditorGroupMode(pair[0]); });
        bar.appendChild(btn);
      });
      container.appendChild(bar);
    }

    function platformKeyForItem(item) {
      if (item.source_type === 'local') return 'local';
      const url = String(item.remote_url || '').trim();
      if (url) return detectPanPlatform(url).id;
      return String(item.platform_hint || 'other');
    }
    function itemFilled(item) {
      if (item.source_type === 'remote') return String(item.remote_url || '').trim() !== '';
      return String(item.file_path || '').trim() !== '';
    }
    function parseLuma(val) {
      const m = String(val).match(/rgba?\\(\\s*([\\d.]+)\\s*,\\s*([\\d.]+)\\s*,\\s*([\\d.]+)/i);
      if (!m) return null;
      return (Number(m[1]) + Number(m[2]) + Number(m[3])) / 3;
    }

    function surfaceForMode(mode, candidate, presetVal) {
      const lum = parseLuma(candidate);
      if (lum === null) return presetVal;
      if (mode === 'dark') return lum > 170 ? presetVal : candidate;
      return lum < 200 ? candidate : presetVal;
    }

    function applyThemeTokens(theme) {
      if (!theme || typeof theme !== 'object') return;
      const root = document.documentElement;
      const st = root.style;
      const resolvedMode = theme.contentTheme === 'dark' ? 'dark' : 'light';
      const preset = themePreset(resolvedMode);
      const merged = Object.assign({}, preset, theme);
      merged.contentTheme = resolvedMode;

      [
        '--pv-card-bg', '--pv-fill', '--pv-border', '--pv-text', '--pv-text-secondary',
        '--pv-input-bg', '--pv-primary', '--pv-primary-hover', '--pv-primary-soft', '--pv-primary-border',
        '--pv-danger', '--pv-danger-soft', '--pv-danger-border',
        '--pv-font-family', '--pv-font-size', '--pv-radius-base', '--pv-btn-padding', '--pv-input-padding',
      ].forEach(function (key) { st.removeProperty(key); });

      root.setAttribute('data-iframe-theme', merged.contentTheme);

      const pick = function (val, fallback) {
        if (!val || val === 'transparent' || val === 'rgba(0, 0, 0, 0)') return fallback;
        return String(val).trim();
      };
      const set = function (key, val) {
        if (val) st.setProperty(key, val);
      };
      const card = surfaceForMode(
        resolvedMode,
        pick(merged.card || merged.bg || merged.canvas, preset.card),
        preset.card,
      );
      const fill = surfaceForMode(resolvedMode, pick(merged.fill, preset.fill), preset.fill);
      const inputBg = surfaceForMode(
        resolvedMode,
        pick(merged.inputBg || merged.card, preset.inputBg),
        preset.inputBg,
      );
      set('--pv-card-bg', card);
      set('--pv-fill', fill);
      set('--pv-border', pick(merged.border, preset.border));
      set('--pv-text', pick(merged.text, preset.text));
      set('--pv-text-secondary', pick(merged.textSecondary, preset.textSecondary));
      set('--pv-input-bg', inputBg);
      set('--pv-primary', pick(merged.primary, ''));
      if (merged.primarySoft) set('--pv-primary-soft', merged.primarySoft);
      if (merged.primaryBorder) set('--pv-primary-border', merged.primaryBorder);
      set('--pv-danger', pick(merged.danger, ''));
      if (merged.dangerSoft) set('--pv-danger-soft', merged.dangerSoft);
      if (merged.dangerBorder) set('--pv-danger-border', merged.dangerBorder);
      if (merged.fontFamily) set('--pv-font-family', merged.fontFamily);
      if (merged.fontSize) set('--pv-font-size', merged.fontSize);
      if (merged.radiusBase) set('--pv-radius-base', merged.radiusBase);
      if (merged.btnPadding) set('--pv-btn-padding', merged.btnPadding);
      if (merged.inputPadding) set('--pv-input-padding', merged.inputPadding);
    }

    function hasIncomingBundles(list) {
      return Array.isArray(list) && list.length > 0;
    }

    function hasLocalFilledItems() {
      if (editorGroupMode === 'by_platform') {
        return platformGroups.some(function (pg) {
          return (pg.items || []).some(itemFilled);
        });
      }
      return fileGroups.some(function (fg) {
        return (fg.items || []).some(itemFilled);
      });
    }

    function applyBundleSnapshot(list) {
      bundles = list.map(normalizeBundle);
      bundlesHadItemsOnLoad = countFilledBundles(bundles);
      fileGroups = bundlesToFileGroups(bundles);
      platformGroups = fileGroupsToPlatformGroups(fileGroups);
      dataReady = true;
      dataDirty = false;
      refreshLayoutHint();
      render();
    }

    function defaultAccess() { return { access_mode: 'free', member_level_id: 0, points_cost: 0 }; }

    function normalizeItem(raw, access) {
      const row = {
        id: Number(raw.id || 0),
        label: String(raw.label || '').trim(),
        sort: Number(raw.sort != null ? raw.sort : 0),
        source_type: raw.source_type === 'remote' ? 'remote' : 'local',
        status: raw.status === 0 || raw.status === '0' ? 0 : 1,
        remote_url: String(raw.remote_url || ''),
        extract_code: String(raw.extract_code || ''),
        file_path: String(raw.file_path || ''),
        file_size: Number(raw.file_size || 0),
        platform_hint: String(raw.platform_hint || ''),
        access_mode: access.access_mode || 'free',
        member_level_id: Number(access.member_level_id || 0),
        points_cost: Number(access.points_cost || 0),
      };
      if (!row.platform_hint) row.platform_hint = platformKeyForItem(row);
      return row;
    }

    function nextPlatformItemLabel(fg, platformKey, sourceType, excludeIndex) {
      if (sourceType === 'local') {
        const n = fg.items.filter(function (it, idx) {
          if (excludeIndex >= 0 && idx === excludeIndex) return false;
          return it.source_type === 'local';
        }).length;
        return n === 0 ? '本地下载' : '本地下载' + (n + 1);
      }
      const base = platformMeta(platformKey).label;
      const n = fg.items.filter(function (it, idx) {
        if (excludeIndex >= 0 && idx === excludeIndex) return false;
        return it.source_type === 'remote' && platformKeyForItem(it) === platformKey;
      }).length;
      return n === 0 ? base : base + (n + 1);
    }

    function createFileGroup(opts) {
      const fg = {
        id: 'fg-' + (nextFgSeq++),
        bundleId: Number(opts.bundleId || 0),
        title: String(opts.title || '').trim() || ('文件' + fileGroups.length + 1),
        open: opts.open !== false,
        platOpen: opts.platOpen || {},
        items: Array.isArray(opts.items) ? opts.items : [],
      };
      return fg;
    }

    function bundlesToFileGroups(list) {
      const merged = {};
      const order = [];
      (list || []).forEach(function (bundle, i) {
        const title = String(bundle.title || '').trim() || ('文件' + (i + 1));
        const access = {
          access_mode: bundle.access_mode || 'free',
          member_level_id: bundle.member_level_id || 0,
          points_cost: bundle.points_cost || 0,
        };
        if (!merged[title]) {
          merged[title] = createFileGroup({ bundleId: bundle.id, title: title, items: [] });
          order.push(title);
        }
        (bundle.items || []).forEach(function (it) {
          merged[title].items.push(normalizeItem(it, access));
        });
      });
      const groups = order.map(function (t) { return merged[t]; });
      return groups.length ? groups : [createFileGroup({ title: '文件1', items: [] })];
    }

    function stripItemForExport(item, sort, opts) {
      const bundleId = Number(opts && opts.bundleId ? opts.bundleId : 0);
      let itemId = Number(item.id || 0);
      if (bundleId < 1) {
        itemId = 0;
      }
      const base = {
        id: itemId,
        label: String(item.label || '').trim(),
        sort: sort,
        source_type: item.source_type,
        status: item.status ? 1 : 0,
      };
      if (item.source_type === 'remote') {
        base.remote_url = item.remote_url || '';
        base.extract_code = item.extract_code || '';
        base.file_path = '';
        base.file_size = 0;
      } else {
        base.file_path = item.file_path || '';
        base.file_size = item.file_size || 0;
        base.remote_url = '';
        base.extract_code = '';
      }
      return base;
    }

    function fileGroupsToBundles() {
      const out = [];
      let sort = 0;
      fileGroups.forEach(function (fg) {
        const buckets = {};
        fg.items.filter(itemFilled).forEach(function (item) {
          const accessVal = readAccessValue(item);
          const points = item.access_mode === 'points' ? Math.max(1, Number(item.points_cost || 1)) : 0;
          const key = accessVal + '::' + points;
          if (!buckets[key]) {
            buckets[key] = {
              id: fg.bundleId > 0 && Object.keys(buckets).length === 0 ? fg.bundleId : 0,
              document_id: documentId,
              title: fg.title,
              access_mode: item.access_mode || 'free',
              member_level_id: item.member_level_id || 0,
              points_cost: points,
              sort: sort++,
              status: 1,
              items: [],
            };
          }
          buckets[key].items.push(stripItemForExport(item, buckets[key].items.length, { bundleId: Number(buckets[key].id || 0) }));
        });
        Object.keys(buckets).forEach(function (k) { out.push(buckets[k]); });
      });
      return out;
    }

    function normalizeBundle(raw) {
      const items = Array.isArray(raw && raw.items) ? raw.items : [];
      return {
        access_mode: raw && raw.access_mode ? raw.access_mode : 'free',
        document_id: Number(raw && raw.document_id ? raw.document_id : documentId),
        id: Number(raw && raw.id ? raw.id : 0),
        items: items.map(function (it, i) {
          return {
            id: Number(it.id || 0),
            label: String(it.label || ''),
            sort: Number(it.sort != null ? it.sort : i),
            source_type: it.source_type === 'remote' ? 'remote' : 'local',
            status: Number(it.status) ? 1 : 0,
            remote_url: String(it.remote_url || ''),
            extract_code: String(it.extract_code || ''),
            file_path: String(it.file_path || ''),
            file_size: Number(it.file_size || 0),
          };
        }),
        member_level_id: Number(raw && raw.member_level_id ? raw.member_level_id : 0),
        points_cost: Number(raw && raw.points_cost ? raw.points_cost : 0),
        sort: Number(raw && raw.sort ? raw.sort : 0),
        status: Number(raw && raw.status ? raw.status : 1) ? 1 : 0,
        title: String(raw && raw.title ? raw.title : ''),
      };
    }

    function exportBundle(row) {
      return {
        access_mode: row.access_mode || 'free',
        document_id: row.document_id || documentId,
        id: row.id > 0 ? row.id : 0,
        items: (row.items || []).map(function (it, i) { return stripItemForExport(it, i, { bundleId: Number(row.id || 0) }); }),
        member_level_id: row.member_level_id || 0,
        points_cost: row.access_mode === 'points' ? Math.max(0, Number(row.points_cost || 0)) : 0,
        sort: row.sort || 0,
        status: row.status ? 1 : 0,
        title: row.title,
      };
    }

    function resolveExportBundles() {
      if (!isDocTab) {
        return (bundles || []).filter(function (b) { return (b.items || []).length; });
      }
      ensureViewsFromBundles();
      syncViewBeforeExport();
      let list = fileGroupsToBundles();
      let filtered = list.filter(function (b) { return (b.items || []).length; });
      if (!filtered.length && countFilledBundles(bundles)) {
        list = bundles.map(function (b) {
          return Object.assign({}, b, {
            items: (b.items || []).filter(itemFilled),
          });
        });
        filtered = list.filter(function (b) { return (b.items || []).length; });
      }
      return filtered;
    }

    function exportFields() {
      const filtered = resolveExportBundles();
      const localHas = isDocTab && (hasLocalFilledItems() || countFilledBundles(bundles));
      if (isDocTab && documentId > 0 && !filtered.length && (bundlesHadItemsOnLoad || localHas)) {
        return {};
      }
      if (isDocTab && documentId > 0 && !dataReady && !filtered.length) {
        return {};
      }
      return { downloads_json: JSON.stringify(filtered.map(exportBundle)) };
    }

    function groupItemsInFile(fg) {
      const buckets = {};
      fg.items.forEach(function (item, index) {
        const key = platformKeyForItem(item);
        if (!buckets[key]) buckets[key] = { key: key, platform: platformMeta(key), rows: [] };
        buckets[key].rows.push({ item: item, index: index });
      });
      const ordered = [];
      PLATFORM_KEY_ORDER.forEach(function (key) {
        if (buckets[key]) { ordered.push(buckets[key]); delete buckets[key]; }
      });
      Object.keys(buckets).forEach(function (key) { ordered.push(buckets[key]); });
      return ordered;
    }

    function fileSummary(fg) {
      const filled = fg.items.filter(itemFilled).length;
      const plats = groupItemsInFile(fg).filter(function (g) {
        return g.rows.some(function (r) { return itemFilled(r.item); });
      });
      return filled + ' 项 · ' + plats.length + ' 个网盘组';
    }

    let errorTimer = 0;

    function updateStatus() {
      if (statusEl.dataset.stickyErr === '1') return;
      if (!isDocTab) {
        statusEl.textContent = documentId > 0 ? '文档 #' + documentId : '新建文档';
        statusEl.className = 'hint';
        return;
      }
      let total = 0;
      if (editorGroupMode === 'by_platform') {
        platformGroups.forEach(function (pg) { total += pg.items.filter(itemFilled).length; });
        statusEl.textContent = (documentId > 0 ? '文档 #' + documentId + ' · ' : '新建文档 · ')
          + platformGroups.length + ' 个网盘组 · ' + total + ' 个下载项';
      } else {
        fileGroups.forEach(function (fg) { total += fg.items.filter(itemFilled).length; });
        statusEl.textContent = (documentId > 0 ? '文档 #' + documentId + ' · ' : '新建文档 · ')
          + fileGroups.length + ' 个文件 · ' + total + ' 个下载项';
      }
      statusEl.className = 'hint';
    }

    function showInlineError(message) {
      statusEl.textContent = String(message || '操作失败');
      statusEl.className = 'hint err';
      statusEl.dataset.stickyErr = '1';
      window.clearTimeout(errorTimer);
      errorTimer = window.setTimeout(function () {
        delete statusEl.dataset.stickyErr;
        updateStatus();
      }, 6000);
    }

    function restOk(data) {
      return data && typeof data === 'object' && !data.error && Object.prototype.hasOwnProperty.call(data, 'data');
    }
    async function api(path) {
      const restPath = String(path || '')
        .replace(/^document-form-meta/, 'meta/documents/form')
        .replace(/^upload\\/file/, 'upload/file');
      const res = await fetch('/api/v1/admin/' + restPath, {
        credentials: 'same-origin',
        headers: { 'X-Requested-With': 'XMLHttpRequest', Accept: 'application/json' },
      });
      const text = await res.text();
      try { return JSON.parse(text); } catch (e) {
        const looksHtml = /^\\s*</.test(text) || /<!doctype/i.test(text);
        return { error: { message: looksHtml
          ? ('接口非 JSON（HTTP ' + res.status + '）。请确认已登录且 REST 路径可用。')
          : String(text || '加载失败').slice(0, 240) } };
      }
    }
    async function uploadFile(file) {
      const fd = new FormData();
      fd.append('file', file);
      const res = await fetch('/api/v1/admin/upload/file', {
        method: 'POST', credentials: 'same-origin',
        headers: { 'X-Requested-With': 'XMLHttpRequest' }, body: fd,
      });
      const text = await res.text();
      let data;
      try { data = JSON.parse(text); } catch (e) {
        throw new Error('上传接口非 JSON（请确认 REST /api/v1/admin/upload/file）');
      }
      if (data.error) throw new Error((data.error && data.error.message) || '上传失败');
      return data.data || {};
    }

    function buildAccessSelect(item, rerender) {
      return createAccessControls({ item: item, rerender: rerender });
    }

    function addFileGroup() {
      dataDirty = true;
      const n = fileGroups.length + 1;
      fileGroups.push(createFileGroup({ title: '文件' + n, open: true, items: [] }));
      render();
      window.requestAnimationFrame(function () {
        const cards = rootEl.querySelectorAll('.file-card');
        const last = cards[cards.length - 1];
        if (last && last.scrollIntoView) last.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
      });
    }

    function removeFileGroup(fgIndex) {
      dataDirty = true;
      fileGroups.splice(fgIndex, 1);
      if (!fileGroups.length) fileGroups.push(createFileGroup({ title: '文件1', open: true, items: [] }));
      render();
    }

    function addRemoteItem(fg, platformKey, url, extractCode, skipRender) {
      dataDirty = true;
      const trimmed = String(url || '').trim();
      const pk = trimmed ? detectPanPlatform(trimmed).id : platformKey;
      const label = nextPlatformItemLabel(fg, pk, 'remote');
      fg.items.push(normalizeItem({
        source_type: 'remote',
        label: label,
        remote_url: trimmed,
        extract_code: String(extractCode || ''),
        platform_hint: pk,
      }, defaultAccess()));
      fg.platOpen[pk] = true;
      fg.open = true;
      if (!skipRender) render();
    }

    async function addLocalFiles(fg, fileList) {
      const files = Array.from(fileList || []).filter(function (f) { return f && (f.name || f.size > 0); });
      if (!files.length) return;
      dataDirty = true;
      fg.open = true;
      fg.platOpen.local = true;
      for (let i = 0; i < files.length; i++) {
        const file = files[i];
        const item = normalizeItem({
          source_type: 'local',
          label: nextPlatformItemLabel(fg, 'local', 'local'),
          file_path: '', file_size: 0, platform_hint: 'local',
        }, defaultAccess());
        fg.items.push(item);
        try {
          const result = await uploadFile(file);
          item.file_path = result.path || result.url || '';
          item.file_size = file.size;
          if (!String(item.label || '').trim() || item.label.indexOf('本地下载') === 0) {
            item.label = file.name;
          }
        } catch (err) {
          showInlineError((file.name || '文件') + ' 上传失败：' + (err.message || ''));
        }
      }
      render();
    }

    function itemDeleteLabel(item) {
      const raw = String(item.label || item.remote_url || item.file_path || '此项').trim();
      return raw.length > 48 ? raw.slice(0, 48) + '…' : raw;
    }

    function createItemRowHeader(isLocal) {
      const head = document.createElement('div');
      head.className = 'item-row item-row-head';
      head.setAttribute('aria-hidden', 'true');
      function col(cls, text) {
        const span = document.createElement('span');
        span.className = cls;
        span.textContent = text;
        head.appendChild(span);
      }
      col('item-label', '名称');
      col('item-main', isLocal ? '文件路径' : '下载链接');
      if (!isLocal) col('item-code', '提取码');
      col('item-access', '权限');
      col('item-action', '操作');
      return head;
    }

    function renderItemRow(fg, itemIndex) {
      const item = fg.items[itemIndex];
      const line = document.createElement('div');
      line.className = 'item-row';
      const labelInput = document.createElement('input');
      labelInput.type = 'text';
      labelInput.className = 'item-label';
      labelInput.value = item.label || '';
      labelInput.setAttribute('aria-label', '下载项名称');
      labelInput.addEventListener('input', function () { dataDirty = true; item.label = labelInput.value; });
      line.appendChild(labelInput);

      if (item.source_type === 'local') {
        const pathInput = document.createElement('input');
        pathInput.type = 'text';
        pathInput.className = 'item-main';
        pathInput.placeholder = '文件路径';
        pathInput.setAttribute('aria-label', '文件路径');
        pathInput.title = item.file_path || '';
        pathInput.value = item.file_path || '';
        pathInput.addEventListener('input', function () {
          dataDirty = true;
          item.file_path = pathInput.value;
          pathInput.title = pathInput.value;
        });
        line.appendChild(pathInput);
        const uploadBtn = document.createElement('button');
        uploadBtn.type = 'button';
        uploadBtn.textContent = '上传';
        uploadBtn.setAttribute('aria-label', '上传本地文件');
        const fileInput = document.createElement('input');
        fileInput.type = 'file';
        uploadBtn.addEventListener('click', function () { fileInput.click(); });
        fileInput.addEventListener('change', async function () {
          const file = fileInput.files && fileInput.files[0];
          fileInput.value = '';
          if (!file) return;
          try {
            const result = await uploadFile(file);
            item.file_path = result.path || result.url || '';
            item.file_size = file.size;
            dataDirty = true;
            render();
          } catch (err) { showInlineError(err.message || '上传失败'); }
        });
        line.appendChild(uploadBtn);
        line.appendChild(fileInput);
      } else {
        const urlInput = document.createElement('input');
        urlInput.type = 'text';
        urlInput.className = 'item-main';
        urlInput.placeholder = '下载链接';
        urlInput.setAttribute('aria-label', '下载链接');
        urlInput.title = item.remote_url || '';
        urlInput.value = item.remote_url || '';
        urlInput.addEventListener('input', function () {
          dataDirty = true;
          item.remote_url = urlInput.value;
          urlInput.title = urlInput.value;
        });
        urlInput.addEventListener('blur', function () {
          const pk = platformKeyForItem(item);
          if (pk !== item.platform_hint && String(item.remote_url || '').trim()) {
            item.platform_hint = pk;
            if (isGenericRemoteLabel(item.label)) item.label = nextPlatformItemLabel(fg, pk, 'remote', itemIndex);
          }
          render();
        });
        line.appendChild(urlInput);
        const codeInput = document.createElement('input');
        codeInput.type = 'text';
        codeInput.className = 'item-code';
        codeInput.placeholder = '提取码';
        codeInput.setAttribute('aria-label', '提取码');
        codeInput.value = item.extract_code || '';
        codeInput.addEventListener('input', function () { dataDirty = true; item.extract_code = codeInput.value; });
        line.appendChild(codeInput);
      }
      line.appendChild(buildAccessSelect(item, render));
      const del = document.createElement('button');
      del.type = 'button';
      del.className = 'danger item-action';
      del.textContent = '删除';
      del.setAttribute('aria-label', '删除下载项 ' + itemDeleteLabel(item));
      del.addEventListener('click', function () {
        if (!confirm('确定删除「' + itemDeleteLabel(item) + '」？')) return;
        dataDirty = true;
        fg.items.splice(itemIndex, 1);
        render();
      });
      line.appendChild(del);
      return line;
    }

    function renderPlatformBlock(fg, platGroup) {
      const key = platGroup.key;
      const isOpen = fg.platOpen[key] !== false;
      const block = document.createElement('div');
      block.className = 'plat-block' + (isOpen ? ' is-open' : '');
      const head = document.createElement('div');
      head.className = 'plat-head';
      head.addEventListener('click', function (ev) {
        if (ev.target.closest('button') || ev.target.closest('input') || ev.target.closest('select')) return;
        fg.platOpen[key] = !isOpen;
        render();
      });
      const main = document.createElement('div');
      main.className = 'plat-head-main';
      const chev = document.createElement('span');
      chev.className = 'chevron';
      chev.setAttribute('aria-hidden', 'true');
      chev.textContent = '▶';
      main.appendChild(chev);
      if (platGroup.platform.iconSrc) {
        const img = document.createElement('img');
        img.src = platGroup.platform.iconSrc;
        img.alt = '';
        img.setAttribute('aria-hidden', 'true');
        main.appendChild(img);
      }
      const title = document.createElement('span');
      title.textContent = platGroup.platform.label + '（' + platGroup.rows.length + '）';
      main.appendChild(title);
      head.appendChild(main);
      const actions = document.createElement('div');
      actions.className = 'plat-head-actions';
      const platItems = platGroup.rows.map(function (row) { return fg.items[row.index]; });
      const batchLabel = document.createElement('span');
      batchLabel.className = 'plat-batch-label';
      batchLabel.textContent = '批量权限';
      actions.appendChild(batchLabel);
      actions.appendChild(createAccessControls({
        items: platItems,
        rerender: render,
        isBatch: true,
        className: 'item-access plat-batch-access',
      }));
      const addBtn = document.createElement('button');
      addBtn.type = 'button';
      addBtn.className = 'plain';
      addBtn.textContent = key === 'local' ? '添加文件' : '添加链接';
      addBtn.addEventListener('click', function (ev) {
        ev.stopPropagation();
        if (key === 'local') {
          const inp = document.createElement('input');
          inp.type = 'file';
          inp.multiple = true;
          inp.addEventListener('change', function () { addLocalFiles(fg, inp.files); });
          inp.click();
        } else {
          addRemoteItem(fg, key, '', '');
        }
      });
      actions.appendChild(addBtn);
      head.appendChild(actions);
      block.appendChild(head);
      const body = document.createElement('div');
      body.className = 'plat-body';
      const isLocalPlat = key === 'local';
      if (platGroup.rows.length) body.appendChild(createItemRowHeader(isLocalPlat));
      platGroup.rows.forEach(function (row) {
        body.appendChild(renderItemRow(fg, row.index));
      });
      block.appendChild(body);
      return block;
    }

    function renderFileCard(fg, fgIndex) {
      const card = document.createElement('div');
      card.className = 'file-card' + (fg.open ? ' is-open' : '');
      const head = document.createElement('div');
      head.className = 'file-head';
      head.addEventListener('click', function (ev) {
        if (ev.target.closest('input') || ev.target.closest('button')) return;
        fg.open = !fg.open;
        render();
      });
      const main = document.createElement('div');
      main.className = 'file-head-main';
      const chev = document.createElement('span');
      chev.className = 'chevron';
      chev.setAttribute('aria-hidden', 'true');
      chev.textContent = '▶';
      main.appendChild(chev);
      const titleInput = document.createElement('input');
      titleInput.type = 'text';
      titleInput.className = 'file-title-input';
      titleInput.value = fg.title;
      titleInput.placeholder = '文件名称';
      titleInput.setAttribute('aria-label', '文件组名称');
      titleInput.addEventListener('click', function (ev) { ev.stopPropagation(); });
      titleInput.addEventListener('input', function () { dataDirty = true; fg.title = titleInput.value; updateStatus(); });
      main.appendChild(titleInput);
      const meta = document.createElement('span');
      meta.className = 'file-meta';
      meta.textContent = fileSummary(fg);
      main.appendChild(meta);
      head.appendChild(main);
      const delFg = document.createElement('button');
      delFg.type = 'button';
      delFg.className = 'danger';
      delFg.textContent = '删除文件';
      delFg.setAttribute('aria-label', '删除文件组 ' + (fg.title || ''));
      delFg.addEventListener('click', function (ev) {
        ev.stopPropagation();
        if (fileGroups.length <= 1 && fg.items.length) {
          if (!confirm('确定清空此文件下所有下载项？')) return;
          fg.items = [];
        } else if (fileGroups.length > 1) {
          if (!confirm('确定删除「' + fg.title + '」？')) return;
          removeFileGroup(fgIndex);
          return;
        } else {
          fg.items = [];
        }
        dataDirty = true;
        render();
      });
      head.appendChild(delFg);
      card.appendChild(head);

      const body = document.createElement('div');
      body.className = 'file-body';
      const pasteRow = document.createElement('div');
      pasteRow.className = 'file-paste';
      const pasteInput = document.createElement('input');
      pasteInput.type = 'text';
      pasteInput.placeholder = '粘贴网盘链接到此文件，回车添加';
      pasteInput.setAttribute('aria-label', '粘贴网盘链接');
      const codeInput = document.createElement('input');
      codeInput.type = 'text';
      codeInput.className = 'item-code';
      codeInput.placeholder = '提取码';
      codeInput.setAttribute('aria-label', '粘贴链接的提取码');
      pasteInput.addEventListener('keydown', function (ev) {
        if (ev.key === 'Enter') {
          ev.preventDefault();
          if (String(pasteInput.value || '').trim()) {
            addRemoteItem(fg, 'other', pasteInput.value, codeInput.value);
            pasteInput.value = '';
            codeInput.value = '';
          }
        }
      });
      pasteRow.appendChild(pasteInput);
      pasteRow.appendChild(codeInput);
      body.appendChild(pasteRow);

      const plats = groupItemsInFile(fg);
      if (!plats.length) {
        const tip = document.createElement('p');
        tip.className = 'empty-tip';
        tip.style.padding = '12px';
        tip.textContent = '暂无下载项，请用下方快捷按钮或粘贴链接';
        body.appendChild(tip);
      } else {
        plats.forEach(function (pg) { body.appendChild(renderPlatformBlock(fg, pg)); });
      }

      const quick = document.createElement('div');
      quick.className = 'plat-quick';
      ['baidu', 'quark', 'aliyun', 'local'].forEach(function (pk) {
        const btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'plain';
        btn.textContent = '+ ' + platformMeta(pk).label;
        btn.addEventListener('click', function () {
          if (pk === 'local') {
            const inp = document.createElement('input');
            inp.type = 'file';
            inp.multiple = true;
            inp.addEventListener('change', function () { addLocalFiles(fg, inp.files); });
            inp.click();
          } else {
            addRemoteItem(fg, pk, '', '');
          }
        });
        quick.appendChild(btn);
      });
      body.appendChild(quick);
      card.appendChild(body);
      return card;
    }


    function createPlatformItemRowHeader(isRemote) {
      const head = document.createElement('div');
      head.className = 'item-row item-row-head';
      head.setAttribute('aria-hidden', 'true');
      function col(cls, text) {
        const span = document.createElement('span');
        span.className = cls;
        span.textContent = text;
        head.appendChild(span);
      }
      col('item-file-title', '文件名');
      col('item-label', '显示名');
      col('item-main', isRemote ? '下载链接' : '文件路径');
      if (isRemote) col('item-code', '提取码');
      col('item-access', '权限');
      col('item-action', '操作');
      return head;
    }

    function renderPlatformItemRow(pg, itemIndex) {
      const item = pg.items[itemIndex];
      const line = document.createElement('div');
      line.className = 'item-row';
      const fileTitleInput = document.createElement('input');
      fileTitleInput.type = 'text';
      fileTitleInput.className = 'item-file-title';
      fileTitleInput.value = item.fileTitle || '';
      fileTitleInput.placeholder = '文件名';
      fileTitleInput.setAttribute('aria-label', '文件名');
      fileTitleInput.addEventListener('input', function () {
        dataDirty = true;
        item.fileTitle = fileTitleInput.value;
      });
      line.appendChild(fileTitleInput);
      const labelInput = document.createElement('input');
      labelInput.type = 'text';
      labelInput.className = 'item-label';
      labelInput.value = item.label || '';
      labelInput.setAttribute('aria-label', '显示名称');
      labelInput.addEventListener('input', function () { dataDirty = true; item.label = labelInput.value; });
      line.appendChild(labelInput);
      if (item.source_type === 'local') {
        const pathInput = document.createElement('input');
        pathInput.type = 'text';
        pathInput.className = 'item-main';
        pathInput.placeholder = '文件路径';
        pathInput.value = item.file_path || '';
        pathInput.addEventListener('input', function () { dataDirty = true; item.file_path = pathInput.value; });
        line.appendChild(pathInput);
      } else {
        const urlInput = document.createElement('input');
        urlInput.type = 'text';
        urlInput.className = 'item-main';
        urlInput.placeholder = '下载链接';
        urlInput.value = item.remote_url || '';
        urlInput.addEventListener('input', function () { dataDirty = true; item.remote_url = urlInput.value; });
        line.appendChild(urlInput);
        const codeInput = document.createElement('input');
        codeInput.type = 'text';
        codeInput.className = 'item-code';
        codeInput.placeholder = '提取码';
        codeInput.value = item.extract_code || '';
        codeInput.addEventListener('input', function () { dataDirty = true; item.extract_code = codeInput.value; });
        line.appendChild(codeInput);
      }
      line.appendChild(buildAccessSelect(item, render));
      const del = document.createElement('button');
      del.type = 'button';
      del.className = 'danger item-action';
      del.textContent = '删除';
      del.addEventListener('click', function () {
        if (!confirm('确定删除「' + itemDeleteLabel(item) + '」？')) return;
        dataDirty = true;
        pg.items.splice(itemIndex, 1);
        render();
      });
      line.appendChild(del);
      return line;
    }

    function platformSummary(pg) {
      const filled = pg.items.filter(itemFilled).length;
      const files = {};
      pg.items.forEach(function (it) {
        if (itemFilled(it)) files[String(it.fileTitle || '').trim() || '文件'] = true;
      });
      return filled + ' 项 · ' + Object.keys(files).length + ' 个文件';
    }

    function addPlatformGroup(platformKey) {
      dataDirty = true;
      const pk = platformKey || 'baidu';
      platformGroups.push(createPlatformGroup({ platformKey: pk, open: true, items: [] }));
      render();
    }

    function removePlatformGroup(pgIndex) {
      dataDirty = true;
      platformGroups.splice(pgIndex, 1);
      if (!platformGroups.length) platformGroups.push(createPlatformGroup({ platformKey: 'baidu', open: true, items: [] }));
      render();
    }

    function addRemoteItemToPlatform(pg, url, extractCode, fileTitle) {
      dataDirty = true;
      const trimmed = String(url || '').trim();
      const pk = pg.platformKey;
      const n = pg.items.filter(itemFilled).length + 1;
      const title = String(fileTitle || '').trim() || ('文件' + n);
      pg.items.push(normalizeItem({
        source_type: 'remote',
        label: platformMeta(pk).label,
        remote_url: trimmed,
        extract_code: String(extractCode || ''),
        platform_hint: pk,
        fileTitle: title,
      }, defaultAccess()));
      pg.open = true;
      render();
    }

    function renderPlatformCard(pg, pgIndex) {
      const meta = platformMeta(pg.platformKey);
      const card = document.createElement('div');
      card.className = 'file-card' + (pg.open ? ' is-open' : '');
      const head = document.createElement('div');
      head.className = 'file-head';
      head.addEventListener('click', function (ev) {
        if (ev.target.closest('button') || ev.target.closest('input')) return;
        pg.open = !pg.open;
        render();
      });
      const main = document.createElement('div');
      main.className = 'file-head-main';
      const chev = document.createElement('span');
      chev.className = 'chevron';
      chev.textContent = '▶';
      main.appendChild(chev);
      if (meta.iconSrc) {
        const img = document.createElement('img');
        img.src = meta.iconSrc;
        img.alt = '';
        img.width = 18;
        img.height = 18;
        main.appendChild(img);
      }
      const title = document.createElement('span');
      title.textContent = meta.label;
      main.appendChild(title);
      head.appendChild(main);
      const metaSpan = document.createElement('span');
      metaSpan.className = 'file-meta';
      metaSpan.textContent = platformSummary(pg);
      head.appendChild(metaSpan);
      const delBtn = document.createElement('button');
      delBtn.type = 'button';
      delBtn.className = 'danger icon-btn';
      delBtn.textContent = '删组';
      delBtn.setAttribute('aria-label', '删除网盘组 ' + meta.label);
      delBtn.addEventListener('click', function (ev) {
        ev.stopPropagation();
        if (platformGroups.length <= 1 && pg.items.some(itemFilled)) {
          if (!confirm('确定删除「' + meta.label + '」组？')) return;
        } else if (platformGroups.length > 1) {
          if (!confirm('确定删除「' + meta.label + '」组？')) return;
        }
        removePlatformGroup(pgIndex);
      });
      head.appendChild(delBtn);
      card.appendChild(head);
      const body = document.createElement('div');
      body.className = 'file-body';
      const pasteRow = document.createElement('div');
      pasteRow.className = 'file-paste item-row';
      const fileTitlePaste = document.createElement('input');
      fileTitlePaste.type = 'text';
      fileTitlePaste.className = 'item-file-title';
      fileTitlePaste.placeholder = '文件名';
      fileTitlePaste.setAttribute('aria-label', '文件名');
      const pasteInput = document.createElement('input');
      pasteInput.type = 'text';
      pasteInput.className = 'item-main';
      pasteInput.placeholder = '粘贴链接到此网盘组，回车添加';
      const codeInput = document.createElement('input');
      codeInput.type = 'text';
      codeInput.className = 'item-code';
      codeInput.placeholder = '提取码';
      pasteInput.addEventListener('keydown', function (ev) {
        if (ev.key === 'Enter') {
          ev.preventDefault();
          if (String(pasteInput.value || '').trim()) {
            addRemoteItemToPlatform(pg, pasteInput.value, codeInput.value, fileTitlePaste.value);
            pasteInput.value = '';
            codeInput.value = '';
            fileTitlePaste.value = '';
          }
        }
      });
      pasteRow.appendChild(fileTitlePaste);
      pasteRow.appendChild(pasteInput);
      pasteRow.appendChild(codeInput);
      body.appendChild(pasteRow);
      if (!pg.items.length) {
        const tip = document.createElement('p');
        tip.className = 'empty-tip';
        tip.style.padding = '12px';
        tip.textContent = '暂无文件，请粘贴链接或点击下方添加';
        body.appendChild(tip);
      } else {
        body.appendChild(createPlatformItemRowHeader(pg.platformKey !== 'local'));
        pg.items.forEach(function (_it, idx) { body.appendChild(renderPlatformItemRow(pg, idx)); });
      }
      const addBtn = document.createElement('button');
      addBtn.type = 'button';
      addBtn.className = 'plain';
      addBtn.textContent = '+ 添加文件';
      addBtn.addEventListener('click', function () { addRemoteItemToPlatform(pg, '', ''); });
      body.appendChild(addBtn);
      card.appendChild(body);
      return card;
    }

    function renderPlatformDocTab() {
      rootEl.innerHTML = '';
      updateStatus();
      renderModeBar(rootEl);
      const toolbar = document.createElement('div');
      toolbar.className = 'toolbar-add';
      const quick = document.createElement('div');
      quick.className = 'plat-quick';
      ['baidu', 'quark', 'aliyun', 'local'].forEach(function (pk) {
        const btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'plain';
        btn.textContent = '+ ' + platformMeta(pk).label;
        btn.addEventListener('click', function () {
          let pg = platformGroups.find(function (g) { return g.platformKey === pk; });
          if (!pg) {
            addPlatformGroup(pk);
            return;
          }
          pg.open = true;
          if (pk === 'local') {
            const inp = document.createElement('input');
            inp.type = 'file';
            inp.multiple = true;
            inp.addEventListener('change', function () {
              Array.from(inp.files || []).forEach(function (file, i) {
                pg.items.push(normalizeItem({
                  source_type: 'local',
                  label: file.name,
                  file_path: '',
                  file_size: file.size,
                  platform_hint: 'local',
                  fileTitle: file.name || ('文件' + (i + 1)),
                }, defaultAccess()));
              });
              dataDirty = true;
              render();
            });
            inp.click();
          } else {
            addRemoteItemToPlatform(pg, '', '');
          }
        });
        quick.appendChild(btn);
      });
      toolbar.appendChild(quick);
      rootEl.appendChild(toolbar);
      const list = document.createElement('div');
      list.className = 'file-list';
      if (!platformGroups.length) {
        platformGroups.push(createPlatformGroup({ platformKey: 'baidu', open: true, items: [] }));
      }
      platformGroups.forEach(function (pg, i) { list.appendChild(renderPlatformCard(pg, i)); });
      rootEl.appendChild(list);
      notifyParentHeight();
    }

    function renderDocTab() {
      if (editorGroupMode === 'by_platform') {
        renderPlatformDocTab();
        return;
      }
      rootEl.innerHTML = '';
      updateStatus();
      renderModeBar(rootEl);
      const toolbar = document.createElement('div');
      toolbar.className = 'toolbar-add';
      const addFgBtn = document.createElement('button');
      addFgBtn.type = 'button';
      addFgBtn.className = 'primary';
      addFgBtn.textContent = '+ 添加文件';
      addFgBtn.addEventListener('click', addFileGroup);
      toolbar.appendChild(addFgBtn);
      rootEl.appendChild(toolbar);

      const list = document.createElement('div');
      list.className = 'file-list';
      if (!fileGroups.length) {
        const empty = document.createElement('div');
        empty.className = 'empty-tip empty-state';
        const msg = document.createElement('p');
        msg.style.margin = '0';
        msg.textContent = '暂无下载文件组，点击下方按钮开始配置';
        empty.appendChild(msg);
        const cta = document.createElement('button');
        cta.type = 'button';
        cta.className = 'primary';
        cta.textContent = '添加文件';
        cta.addEventListener('click', addFileGroup);
        empty.appendChild(cta);
        list.appendChild(empty);
      } else {
        fileGroups.forEach(function (fg, i) { list.appendChild(renderFileCard(fg, i)); });
      }
      rootEl.appendChild(list);
      notifyParentHeight();
    }

    function render() {
      if (isDocTab) renderDocTab();
      else { rootEl.innerHTML = '<div class="empty-tip">插件模式</div>'; notifyParentHeight(); }
    }

    function extractDownloadBundles(meta) {
      const surfaces = meta && meta.editorSurfaces ? meta.editorSurfaces : {};
      const rows = [].concat(surfaces.tabs || [], surfaces.inlines || []);
      let best = [];
      rows.forEach(function (row) {
        if (String(row.identifier || '') !== 'doc_bundle') return;
        const list = Array.isArray((row.payload || {}).bundles) ? row.payload.bundles : [];
        if (list.length >= best.length) best = list;
      });
      return best.map(normalizeBundle);
    }

    function applyInitPayload(payload) {
      const body = payload && typeof payload === 'object' ? payload : {};
      applyThemeTokens(body.theme);
      memberLevels = Array.isArray(body.memberLevels) ? body.memberLevels : memberLevels;
      memberPointsEnabled = body.memberPointsEnabled !== false;
      const docFromParent = Number(body.document_id || body.documentId || 0);
      if (docFromParent > 0) documentId = docFromParent;
      const modeFromParent = body.editor_group_mode ? normalizeGroupMode(body.editor_group_mode) : '';

      if (dataDirty) {
        if (modeFromParent) setEditorGroupMode(modeFromParent, true);
        else refreshLayoutHint();
        dataReady = dataReady || documentId < 1;
        render();
        return;
      }

      if (Array.isArray(body.bundles)) {
        if (hasIncomingBundles(body.bundles)) {
          applyBundleSnapshot(body.bundles);
          if (modeFromParent && modeFromParent !== editorGroupMode) {
            setEditorGroupMode(modeFromParent, true);
          }
          return;
        }
        if (documentId < 1) {
          applyBundleSnapshot([]);
          if (modeFromParent) setEditorGroupMode(modeFromParent, true);
          return;
        }
        if (dataReady && hasLocalFilledItems()) {
          if (modeFromParent) setEditorGroupMode(modeFromParent, true);
          else refreshLayoutHint();
          render();
          return;
        }
      }

      if (modeFromParent) setEditorGroupMode(modeFromParent, true);
      else refreshLayoutHint();

      if (documentId > 0 && !dataReady) {
        load();
      } else {
        render();
      }
    }

    function applyRemotePrefill(payload) {
      const body = payload && typeof payload === 'object' ? payload : {};
      const entries = Array.isArray(body.remote_entries) ? body.remote_entries : (Array.isArray(payload) ? payload : []);
      if (body.editor_group_mode) setEditorGroupMode(body.editor_group_mode, true);
      if (!entries.length) return;
      dataDirty = true;
      if (editorGroupMode === 'by_platform') {
        entries.forEach(function (entry, idx) {
          const url = String(entry.url || '').trim();
          if (!url) return;
          const pk = detectPanPlatform(url).id;
          let pg = platformGroups.find(function (g) { return g.platformKey === pk; });
          if (!pg) {
            pg = createPlatformGroup({ platformKey: pk, open: true, items: [] });
            platformGroups.push(pg);
          }
          pg.items.push(normalizeItem({
            source_type: 'remote',
            label: platformMeta(pk).label,
            remote_url: url,
            extract_code: String(entry.extractCode || entry.extract_code || ''),
            platform_hint: pk,
            fileTitle: '文件' + (idx + 1),
          }, defaultAccess()));
        });
      } else {
        entries.forEach(function (entry, idx) {
          let fg = fileGroups[idx];
          if (!fg) {
            fg = createFileGroup({ title: '文件' + (idx + 1), open: true, items: [] });
            fileGroups.push(fg);
          }
          const url = String(entry.url || '').trim();
          if (!url) return;
          addRemoteItem(fg, detectPanPlatform(url).id, url, entry.extractCode || entry.extract_code || '', true);
        });
      }
      render();
    }

    async function load() {
      const seq = ++loadSeq;
      if (documentId < 1) {
        if (!dataDirty && !fileGroups.length) {
          fileGroups = bundlesToFileGroups([]);
        }
        dataReady = true;
        render();
        return;
      }
      if (isDocTab) {
        statusEl.textContent = '正在同步…';
        statusEl.className = 'hint';
      }
      try {
        const data = await api('document-form-meta?id=' + encodeURIComponent(String(documentId)));
        if (seq !== loadSeq || dataDirty) return;
        if (!restOk(data)) {
          statusEl.textContent = (data.error && data.error.message) || '加载失败';
          statusEl.className = 'err';
          return;
        }
        const meta = data.data || {};
        memberLevels = Array.isArray(meta.memberLevels) ? meta.memberLevels : memberLevels;
        memberPointsEnabled = meta.memberPointsEnabled !== false;
        applyBundleSnapshot(extractDownloadBundles(meta));
      } catch (err) {
        if (seq !== loadSeq || dataDirty) return;
        statusEl.textContent = '加载失败';
        statusEl.className = 'err';
        renderDocTab();
      }
    }

    window.addEventListener('message', function (ev) {
      const data = ev.data || {};
      if (data.type === INIT && String(data.identifier || '').toLowerCase() === PLUGIN_ID) {
        applyInitPayload(data.payload || {});
        return;
      }
      if (data.type === THEME && String(data.identifier || '').toLowerCase() === PLUGIN_ID) {
        applyThemeTokens(data.theme || {});
        scheduleParentThemeSync();
        return;
      }
      if (data.type === PREPARE && String(data.identifier || '').toLowerCase() === PLUGIN_ID) {
        parent.postMessage({ type: EXPORT, identifier: PLUGIN_ID, fields: exportFields() }, '*');
      }
      if (data.type === PREFILL && String(data.identifier || '').toLowerCase() === PLUGIN_ID) {
        applyRemotePrefill(data.payload || {});
      }
    });

    if (editorSlot === 'tab' && typeof ResizeObserver !== 'undefined') {
      new ResizeObserver(function () { notifyParentHeight(); }).observe(document.body);
    }
    window.addEventListener('load', notifyParentHeight);
    if (isDocTab) {
      syncParentThemeBootstrap();
      watchParentTheme();
      refreshLayoutHint();
      statusEl.textContent = '正在就绪…';
      renderDocTab();
      window.setTimeout(function () { if (!dataReady && !dataDirty) load(); }, 160);
    } else {
      load();
    }
  </script>
</body>
</html>`;
}
