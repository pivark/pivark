import {
  fetchSpaWeappPluginListApi,
  fetchSpaWeappPluginMetaApi,
} from '#/api/pivark/core/spa';

export const DOWNLOAD_PLUGIN_ID = 'doc_bundle' as const;

export function fetchDownloadPluginMetaApi() {
  return fetchSpaWeappPluginMetaApi<Record<string, unknown>>(DOWNLOAD_PLUGIN_ID);
}

export async function fetchDownloadPluginResourcesListApi(
  params: {
    document_id?: number;
    keyword?: string;
    limit?: number;
    page?: number;
    status?: number | '';
  } = {},
) {
  const result = await fetchSpaWeappPluginListApi(
    DOWNLOAD_PLUGIN_ID,
    'resources',
    params,
  );
  return { list: result.list, total: result.total };
}

export async function fetchDownloadPluginLinkCheckListApi(params: {
  limit?: number;
  page?: number;
  status?: string;
} = {}) {
  const payload = await fetchSpaWeappPluginListApi(
    DOWNLOAD_PLUGIN_ID,
    'link-check',
    params,
  );
  return {
    summary: (payload.summary as Record<string, unknown>) ?? {},
    list: payload.list,
    total: payload.total,
    page: Number(payload.page ?? params.page ?? 1),
    limit: Number(payload.limit ?? params.limit ?? 20),
  };
}
