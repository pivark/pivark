<script lang="ts" setup>
import { computed, onMounted, ref } from 'vue';
import { useRouter } from 'vue-router';

import { ElMessage } from 'element-plus';

import { fetchDownloadPluginMetaApi } from '@weapp-doc-bundle/spa-api';
import { pivarkMutation } from '#/api/pivark/core/mutation';
import PvModuleSection from '#/components/pivark/shell/PvModuleSection.vue';
import WeappPluginShell from '#/components/pivark/weapp/WeappPluginShell.vue';
import WeappPluginKpiRow from '#/components/pivark/weapp/WeappPluginKpiRow.vue';
import WeappPluginPageCard from '#/components/pivark/weapp/WeappPluginPageCard.vue';
import WeappPluginSlotCards from '#/components/pivark/weapp/WeappPluginSlotCards.vue';
import {
  cfgString,
  useWeappSettingsLoading,
  type WeappSlotCard,
} from '#/composables/use-weapp-plugin-settings';
import type { DownloadEditorGroupMode } from '@weapp-doc-bundle/utils/download-editor-group-mode';
import { normalizeDownloadEditorGroupMode } from '@weapp-doc-bundle/utils/download-editor-group-mode';

import '@weapp-doc-bundle/styles/doc-bundle-admin-shell.css';

defineOptions({ name: 'WeappDownloadSettings' });

type NavOption = {
  id: number;
  label: string;
  title?: string;
  content_kind?: string;
};

type HealthCheck = {
  count?: number;
  hint?: string;
  key?: string;
  label?: string;
  route?: string;
  severity?: string;
};

const router = useRouter();
const { loading, saving, withLoading, withSaving } = useWeappSettingsLoading();
const scope = ref('all');
const editorSlot = ref('tab');
const editorGroupMode = ref<DownloadEditorGroupMode>('by_file');
const frontGroupMode = ref<DownloadEditorGroupMode>('by_platform');
const navIds = ref<number[]>([]);
const navOptions = ref<NavOption[]>([]);
const slotCards = ref<WeappSlotCard[]>([]);
const stats = ref({
  bundle_count: 0,
  download_total: 0,
  item_count: 0,
  scope_label: '',
});
const healthChecks = ref<HealthCheck[]>([]);
const healthScore = ref(0);

const kpiItems = computed(() => [
  { label: '下载资源包', value: stats.value.bundle_count },
  { label: '资源项', value: stats.value.item_count },
  { label: '累计下载', value: stats.value.download_total },
]);

const healthAttentionCount = computed(() =>
  healthChecks.value.filter((item) => {
    const count = Number(item.count ?? 0);
    const severity = String(item.severity ?? '');
    return count > 0 && severity !== 'ok';
  }).length,
);

const healthScoreTagType = computed(() => {
  if (healthScore.value >= 90) return 'success';
  if (healthScore.value >= 70) return 'warning';
  return 'danger';
});

function healthItemStatus(item: HealthCheck): 'info' | 'ok' | 'warn' {
  const count = Number(item.count ?? 0);
  if (count <= 0) return 'ok';
  return String(item.severity ?? '') === 'info' ? 'info' : 'warn';
}

function healthCountTagType(
  item: HealthCheck,
): 'danger' | 'info' | 'success' | 'warning' {
  const status = healthItemStatus(item);
  if (status === 'ok') return 'success';
  if (status === 'info') return 'info';
  return 'warning';
}

function goHealthRoute(route?: string) {
  const path = String(route ?? '').trim();
  if (path) {
    router.push(path);
  }
}

function parseIdJson(raw: unknown): number[] {
  const text = String(raw ?? '').trim();
  if (text === '') return [];
  try {
    const parsed = JSON.parse(text);
    if (!Array.isArray(parsed)) return [];
    return parsed
      .map((v) => Number(v))
      .filter((n) => Number.isFinite(n) && n > 0);
  } catch {
    return [];
  }
}

async function loadMeta() {
  await withLoading(async () => {
    const meta = await fetchDownloadPluginMetaApi();
    const cfg = meta.cfg ?? {};
    scope.value = cfgString(cfg, 'download_nav_scope', 'all');
    if (scope.value !== 'all' && scope.value !== 'navs') {
      scope.value = 'all';
    }
    editorSlot.value = cfgString(
      cfg,
      'download_document_editor_slot',
      String(meta.editorSlot ?? 'tab'),
    );
    editorGroupMode.value = normalizeDownloadEditorGroupMode(
      cfg.download_editor_group_mode,
    );
    frontGroupMode.value = normalizeDownloadEditorGroupMode(
      cfg.download_front_group_mode || 'by_platform',
    );
    navIds.value = parseIdJson(cfg.download_allowed_nav_ids);
    navOptions.value = meta.navOptions ?? [];
    slotCards.value = meta.slotCards ?? [];
    stats.value = {
      bundle_count: meta.stats?.bundle_count ?? 0,
      item_count: meta.stats?.item_count ?? 0,
      download_total: meta.stats?.download_total ?? 0,
      scope_label: meta.stats?.scope_label ?? '',
    };
    healthChecks.value = meta.health?.checks ?? [];
    healthScore.value = meta.health?.score ?? 0;
  });
}

async function handleSave() {
  await withSaving(async () => {
    await pivarkMutation('/weapp/doc_bundle/configSave', {
      download_allowed_nav_ids: JSON.stringify(navIds.value),
      download_document_editor_slot: editorSlot.value,
      download_editor_group_mode: editorGroupMode.value,
      download_front_group_mode: frontGroupMode.value,
      download_nav_scope: scope.value,
    });
    ElMessage.success('保存成功');
    await loadMeta();
  });
}

function goResources() {
  router.push('/weapp/host/doc_bundle/resources');
}

onMounted(loadMeta);
</script>

<template>
  <WeappPluginShell nav-key="settings">
    <WeappPluginPageCard :loading="loading" title="基础设置">
      <template #actions>
        <el-button @click="goResources">下载资源</el-button>
        <el-button :loading="saving" type="primary" @click="handleSave">
          保存配置
        </el-button>
      </template>

      <WeappPluginKpiRow :items="kpiItems" />

      <PvModuleSection title="发布页展现">
        <p class="pv-weapp-hint mb-3">
          控制文档发布页中下载配置出现的位置，保存后全站生效。
        </p>
        <WeappPluginSlotCards v-model="editorSlot" :cards="slotCards" />
      </PvModuleSection>

      <PvModuleSection title="资源分组方式">
        <p class="pv-weapp-hint mb-3">
          后台录入与前台展示可分别选择「按文件」或「按网盘」分组；发布页 iframe 内仍可临时切换录入方式。
        </p>
        <div class="mb-4">
          <div class="mb-1 text-sm font-medium">后台录入默认</div>
          <el-radio-group v-model="editorGroupMode">
            <el-radio value="by_file">按文件分网盘</el-radio>
            <el-radio value="by_platform">按网盘分文件</el-radio>
          </el-radio-group>
        </div>
        <div>
          <div class="mb-1 text-sm font-medium">前台展示默认</div>
          <el-radio-group v-model="frontGroupMode">
            <el-radio value="by_file">按文件名分组</el-radio>
            <el-radio value="by_platform">按网盘平台分组</el-radio>
          </el-radio-group>
        </div>
      </PvModuleSection>

      <PvModuleSection title="使用范围">
        <el-radio-group v-model="scope" class="pv-weapp-scope-radios">
          <el-radio value="all">全部文档</el-radio>
          <el-radio value="navs">指定栏目</el-radio>
        </el-radio-group>
        <p class="pv-weapp-hint mt-2">
          仅主栏目在圈选范围内的文档可配置下载并在前台渲染
          <code v-pre>{pv:doc_bundle}</code>
          。勾选父栏目时含子栏目。
          <span v-if="stats.scope_label" class="ml-1">
            当前：{{ stats.scope_label }}
          </span>
        </p>
      </PvModuleSection>

      <PvModuleSection v-show="scope === 'navs'" title="可用栏目">
        <el-empty
          v-if="navOptions.length === 0"
          description="请先在「网站栏目」中创建内容栏目"
        />
        <el-checkbox-group
          v-else
          v-model="navIds"
          class="pv-weapp-check-grid"
        >
          <el-checkbox v-for="n in navOptions" :key="n.id" :value="n.id">
            {{ n.label || n.title }}
          </el-checkbox>
        </el-checkbox-group>
      </PvModuleSection>

      <PvModuleSection v-if="healthChecks.length > 0" title="健康检查">
        <template #tools>
          <el-tag
            :type="healthScoreTagType"
            effect="plain"
            round
            size="small"
          >
            {{ healthScore }} 分
          </el-tag>
          <span
            v-if="healthAttentionCount > 0"
            class="text-muted-foreground ml-2 text-xs"
          >
            {{ healthAttentionCount }} 项待关注
          </span>
          <span v-else class="text-muted-foreground ml-2 text-xs">
            全部正常
          </span>
        </template>
        <ul class="pv-weapp-health-list">
          <li
            v-for="item in healthChecks"
            :key="item.key || item.label"
            class="pv-weapp-health-item"
            :class="`is-${healthItemStatus(item)}`"
          >
            <span class="pv-weapp-health-item__dot" aria-hidden="true" />
            <div class="pv-weapp-health-item__main">
              <div class="pv-weapp-health-item__top">
                <span class="pv-weapp-health-item__label">{{
                  item.label
                }}</span>
                <div class="pv-weapp-health-item__actions">
                  <el-tag
                    :type="healthCountTagType(item)"
                    effect="plain"
                    round
                    size="small"
                  >
                    {{ item.count ?? 0 }}
                  </el-tag>
                  <el-button
                    v-if="item.route && Number(item.count ?? 0) > 0"
                    link
                    size="small"
                    type="primary"
                    @click="goHealthRoute(item.route)"
                  >
                    去处理
                  </el-button>
                </div>
              </div>
              <p v-if="item.hint" class="pv-weapp-health-item__hint">
                {{ item.hint }}
              </p>
            </div>
          </li>
        </ul>
      </PvModuleSection>
    </WeappPluginPageCard>
  </WeappPluginShell>
</template>
