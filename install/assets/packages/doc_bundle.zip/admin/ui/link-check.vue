<script lang="ts" setup>
import { ref } from 'vue';
import { RouterLink } from 'vue-router';

import { ElMessage } from 'element-plus';

import { pivarkMutation } from '#/api/pivark/core/mutation';
import PvAdminGridLoadingSkeleton from '#/components/pivark/PvAdminGridLoadingSkeleton.vue';
import PvModuleSection from '#/components/pivark/shell/PvModuleSection.vue';
import WeappPluginShell from '#/components/pivark/weapp/WeappPluginShell.vue';
import WeappPluginPageCard from '#/components/pivark/weapp/WeappPluginPageCard.vue';

import type { DownloadLinkCheckRow } from './list/link-check-data';
import {
  documentLinkTitle,
  linkCheckStatusTagType,
} from './list/link-check-data';
import { useDownloadLinkCheckList } from './list/use-download-link-check-list';

import '@weapp-doc-bundle/styles/doc-bundle-admin-shell.css';

defineOptions({ name: 'WeappDownloadLinkCheck' });

const checking = ref(false);
const { Grid, refreshGrid, summary } = useDownloadLinkCheckList();

async function runCheck(scope: 'failed' | 'stale') {
  checking.value = true;
  try {
    const result = await pivarkMutation('/weapp/doc_bundle/checkLinks', {
      ids: [],
      scope,
    });
    ElMessage.success(result?.msg || '巡检完成');
    await refreshGrid();
  } finally {
    checking.value = false;
  }
}
</script>

<template>
  <WeappPluginShell nav-key="link-check">
    <WeappPluginPageCard
      title="链接检测"
      class="min-h-0 flex flex-1 flex-col"
      :body-style="{ padding: '16px 20px 20px' }"
    >
      <template #actions>
        <el-button
          :loading="checking"
          type="warning"
          @click="runCheck('failed')"
        >
          巡检异常项
        </el-button>
        <el-button :loading="checking" @click="runCheck('stale')">
          巡检陈旧项
        </el-button>
      </template>

      <PvModuleSection title="巡检概览">
        <div class="flex flex-wrap gap-4 text-sm">
          <span>远程 <strong>{{ summary.remote_total }}</strong></span>
          <span>正常 <strong>{{ summary.ok }}</strong></span>
          <span>异常 <strong>{{ summary.fail + summary.warn }}</strong></span>
          <span>未检 <strong>{{ summary.unknown }}</strong></span>
        </div>
        <p class="text-muted-foreground mt-2 text-xs">
          仅统计含远程 URL 的下载项；下方列表可按巡检状态筛选并查看 HTTP 详情。
        </p>
      </PvModuleSection>

      <PvModuleSection title="远程链接列表" class="mt-4 min-h-0 flex-1">
        <Grid table-title="远程链接" class="min-h-0 flex-1">
          <template #loading>
            <PvAdminGridLoadingSkeleton fill />
          </template>
          <template #linkStatus="{ row }">
            <el-tag
              v-if="row"
              size="small"
              :type="
                linkCheckStatusTagType(
                  (row as DownloadLinkCheckRow).link_check_status || '',
                )
              "
            >
              {{
                (row as DownloadLinkCheckRow).link_check_status_label || '—'
              }}
            </el-tag>
          </template>
          <template #remoteUrl="{ row }">
            <a
              v-if="row && (row as DownloadLinkCheckRow).remote_url"
              :href="(row as DownloadLinkCheckRow).remote_url"
              target="_blank"
              rel="noopener noreferrer"
              class="text-[var(--el-color-primary)]"
              >{{ (row as DownloadLinkCheckRow).remote_url }}</a
            >
          </template>
          <template #document="{ row }">
            <RouterLink
              v-if="row && (row as DownloadLinkCheckRow).document_edit_path"
              :to="(row as DownloadLinkCheckRow).document_edit_path!"
              class="text-[var(--el-color-primary)] hover:underline"
            >
              {{ documentLinkTitle(row as DownloadLinkCheckRow) }}
            </RouterLink>
            <span v-else class="text-muted-foreground">—</span>
          </template>
        </Grid>
      </PvModuleSection>
    </WeappPluginPageCard>
  </WeappPluginShell>
</template>
