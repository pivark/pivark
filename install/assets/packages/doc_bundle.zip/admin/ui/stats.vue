<script lang="ts" setup>
import { computed, onMounted, ref } from 'vue';
import { RouterLink } from 'vue-router';

import { fetchDownloadPluginMetaApi } from '@weapp-doc-bundle/spa-api';
import { useAdminDataExport } from '#/composables/use-admin-data-export';
import PvModuleSection from '#/components/pivark/shell/PvModuleSection.vue';
import WeappPluginShell from '#/components/pivark/weapp/WeappPluginShell.vue';
import WeappPluginKpiRow from '#/components/pivark/weapp/WeappPluginKpiRow.vue';
import WeappPluginPageCard from '#/components/pivark/weapp/WeappPluginPageCard.vue';

import '@weapp-doc-bundle/styles/doc-bundle-admin-shell.css';

defineOptions({ name: 'WeappDownloadStats' });

type TopRow = {
  bundle_title: string;
  document_id: number;
  download_count: number;
  item_id: number;
  label: string;
};

type PlatformRow = {
  count: number;
  label: string;
  platform_id: string;
};

type AccessRow = {
  access_mode: string;
  count: number;
};

const loading = ref(false);
const stats = ref({
  bundle_count: 0,
  download_total: 0,
  item_count: 0,
  scope_label: '',
});
const linkCheck = ref({ fail: 0, ok: 0, remote_total: 0, unknown: 0, warn: 0 });
const top = ref<TopRow[]>([]);
const platformBreakdown = ref<PlatformRow[]>([]);
const accessBreakdown = ref<AccessRow[]>([]);

const kpiItems = computed(() => [
  { label: '资源包', value: stats.value.bundle_count },
  { label: '资源项', value: stats.value.item_count },
  { label: '累计下载', value: stats.value.download_total },
  { label: '远程链接', value: linkCheck.value.remote_total },
]);

const accessLabel = (mode: string) => {
  const map: Record<string, string> = {
    free: '开放下载',
    login: '须登录',
    member: '会员等级',
    points: '积分下载',
    paid: '付费下载',
    member_paid: '会员付费',
  };
  return map[mode] || mode || '—';
};

const maxPlatform = computed(() =>
  Math.max(1, ...platformBreakdown.value.map((r) => r.count)),
);

const { exportAll: exportCsv } = useAdminDataExport({
  permission: 'plugin.doc_bundle.use',
  path: '/weapp/doc_bundle/exportCsv',
  profile: 'doc_bundle.stats',
  requireSelection: false,
  transport: 'download',
  successMessage: '下载统计 CSV 导出已开始',
});

async function loadMeta() {
  loading.value = true;
  try {
    const meta = await fetchDownloadPluginMetaApi();
    stats.value = {
      bundle_count: meta.stats?.bundle_count ?? 0,
      item_count: meta.stats?.item_count ?? 0,
      download_total: meta.stats?.download_total ?? 0,
      scope_label: meta.stats?.scope_label ?? '',
    };
    linkCheck.value = {
      fail: meta.stats?.link_check?.fail ?? 0,
      ok: meta.stats?.link_check?.ok ?? 0,
      remote_total: meta.stats?.link_check?.remote_total ?? 0,
      unknown: meta.stats?.link_check?.unknown ?? 0,
      warn: meta.stats?.link_check?.warn ?? 0,
    };
    top.value = meta.stats_top ?? [];
    const dash = meta.stats_dashboard ?? {};
    platformBreakdown.value = dash.platform_breakdown ?? [];
    accessBreakdown.value = dash.access_breakdown ?? [];
  } finally {
    loading.value = false;
  }
}

onMounted(loadMeta);
</script>

<template>
  <WeappPluginShell nav-key="stats">
    <WeappPluginPageCard :loading="loading" title="下载统计">
      <template #actions>
        <el-button @click="loadMeta">刷新</el-button>
        <el-button @click="exportCsv">导出 CSV</el-button>
      </template>

      <WeappPluginKpiRow :cols="4" :items="kpiItems" />

      <PvModuleSection title="链接巡检">
        <div class="flex flex-wrap gap-4 text-sm">
          <span>正常 <strong>{{ linkCheck.ok }}</strong></span>
          <span>需关注 <strong>{{ linkCheck.warn }}</strong></span>
          <span>失效 <strong>{{ linkCheck.fail }}</strong></span>
          <span>未检 <strong>{{ linkCheck.unknown }}</strong></span>
        </div>
        <p v-if="stats.scope_label" class="text-muted-foreground mt-2 text-xs">
          统计范围：{{ stats.scope_label }}
        </p>
      </PvModuleSection>

      <el-row :gutter="16" class="mt-4">
        <el-col :lg="12" :xs="24">
          <PvModuleSection :title="'下载 Top ' + top.length">
            <el-empty v-if="top.length === 0" description="暂无数据" />
            <ul v-else class="space-y-2 text-sm">
              <li v-for="row in top" :key="row.item_id">
                <span class="font-medium">{{ row.label || '—' }}</span>
                <span class="text-muted-foreground ml-1"
                  >{{ row.download_count }} 次</span
                >
                <p class="text-muted-foreground text-xs">
                  {{ row.bundle_title }}
                  <RouterLink
                    v-if="row.document_id"
                    :to="`/content/document/edit/${row.document_id}`"
                    class="text-[var(--el-color-primary)]"
                    >文档 #{{ row.document_id }}</RouterLink
                  >
                </p>
              </li>
            </ul>
          </PvModuleSection>
        </el-col>
        <el-col :lg="12" :xs="24">
          <PvModuleSection title="网盘平台分布">
            <el-empty
              v-if="platformBreakdown.length === 0"
              description="暂无远程链接"
            />
            <ul v-else class="pv-dl-stats-bars space-y-2">
              <li v-for="row in platformBreakdown" :key="row.platform_id">
                <div class="flex justify-between text-sm">
                  <span>{{ row.label }}</span>
                  <span>{{ row.count }}</span>
                </div>
                <div class="pv-dl-stats-bar">
                  <span
                    class="pv-dl-stats-bar__fill"
                    :style="{
                      width: `${Math.round((row.count / maxPlatform) * 100)}%`,
                    }"
                  />
                </div>
              </li>
            </ul>
          </PvModuleSection>

          <PvModuleSection class="mt-4" title="权限模式分布">
            <el-table :data="accessBreakdown" size="small">
              <el-table-column label="模式">
                <template #default="scope">
                  {{ accessLabel(scope?.row?.access_mode || '') }}
                </template>
              </el-table-column>
              <el-table-column label="资源包数" prop="count" width="100" />
            </el-table>
          </PvModuleSection>
        </el-col>
      </el-row>
    </WeappPluginPageCard>
  </WeappPluginShell>
</template>

<style scoped>
.pv-dl-stats-bar {
  height: 6px;
  margin-top: 4px;
  background: var(--el-fill-color);
  border-radius: var(--pv-radius-xs);
  overflow: hidden;
}

.pv-dl-stats-bar__fill {
  display: block;
  height: 100%;
  background: var(--el-color-primary);
  border-radius: var(--pv-radius-xs);
}
</style>
