import type { PvFormSchema } from '#/adapter/form';
import type { VxeTableGridColumns } from '#/adapter/vxe-table';

import { fetchDownloadPluginLinkCheckListApi } from '@weapp-doc-bundle/spa-api';
import {
  PV_COL_ID,
  PV_COL_NUM,
  PV_COL_TEXT,
} from '#/composables/pv-admin-list-column-presets';
import { usePvAdminListSearchFormOptions } from '#/composables/pv-admin-list-form-layout';

export type DownloadLinkCheckRow = {
  bundle_title?: string;
  document_edit_path?: string;
  document_id?: number;
  document_title?: string;
  extract_code?: string;
  id: number;
  label?: string;
  link_check_at?: string;
  link_check_http_code?: number;
  link_check_message?: string;
  link_check_status?: string;
  link_check_status_label?: string;
  remote_url?: string;
};

export type DownloadLinkCheckSummary = {
  fail: number;
  ok: number;
  remote_total: number;
  unknown: number;
  warn: number;
};

const STATUS_OPTIONS = [
  { label: '可用', value: 'ok' },
  { label: '需关注', value: 'warn' },
  { label: '失效', value: 'fail' },
  { label: '未巡检', value: 'unknown' },
];

export function emptyLinkCheckSummary(): DownloadLinkCheckSummary {
  return {
    fail: 0,
    ok: 0,
    remote_total: 0,
    unknown: 0,
    warn: 0,
  };
}

export function linkCheckStatusTagType(
  status: string,
): 'danger' | 'info' | 'success' | 'warning' {
  if (status === 'ok') return 'success';
  if (status === 'fail') return 'danger';
  if (status === 'warn') return 'warning';
  return 'info';
}

export function useDownloadLinkCheckGridFormSchema(): PvFormSchema[] {
  return [
    {
      component: 'Select',
      fieldName: 'status',
      label: '巡检状态',
      componentProps: {
        clearable: true,
        options: STATUS_OPTIONS,
        placeholder: '全部',
      },
    },
  ];
}

export function useDownloadLinkCheckListGridFormOptions() {
  return usePvAdminListSearchFormOptions(useDownloadLinkCheckGridFormSchema());
}

export function mapDownloadLinkCheckQueryParams(
  formValues: Record<string, unknown>,
) {
  const status = String(formValues.status ?? '').trim();
  return {
    status: status || undefined,
  };
}

export function documentLinkTitle(row: DownloadLinkCheckRow): string {
  const title = String(row.document_title ?? '').trim();
  if (title) {
    return title;
  }
  const docId = Number(row.document_id ?? 0);
  return docId > 0 ? `#${docId}` : '—';
}

export function useDownloadLinkCheckGridColumns(): VxeTableGridColumns<DownloadLinkCheckRow> {
  return [
    {
      field: 'link_check_status',
      title: '状态',
      width: 100,
      slots: { default: 'linkStatus' },
    },
    {
      field: 'label',
      title: '平台/标签',
      minWidth: 120,
      ...PV_COL_TEXT,
    },
    {
      field: 'remote_url',
      title: '远程链接',
      minWidth: 220,
      ...PV_COL_TEXT,
      slots: { default: 'remoteUrl' },
    },
    {
      field: 'extract_code',
      title: '提取码',
      width: 88,
      ...PV_COL_TEXT,
    },
    {
      field: 'bundle_title',
      title: '资源包',
      minWidth: 120,
      ...PV_COL_TEXT,
    },
    {
      field: 'document_id',
      title: '文档',
      minWidth: 140,
      ...PV_COL_TEXT,
      slots: { default: 'document' },
    },
    {
      field: 'link_check_http_code',
      title: 'HTTP',
      width: 72,
      ...PV_COL_NUM,
      formatter: ({ row }) => String(row.link_check_http_code || '—'),
    },
    {
      field: 'link_check_message',
      title: '说明',
      minWidth: 160,
      ...PV_COL_TEXT,
    },
    {
      field: 'link_check_at',
      title: '检测时间',
      width: 160,
      ...PV_COL_TEXT,
    },
    {
      field: 'id',
      title: 'ID',
      width: 72,
      ...PV_COL_ID,
    },
  ];
}

export async function fetchDownloadLinkCheckListPage(
  page: { currentPage: number; pageSize: number },
  formValues: Record<string, unknown>,
) {
  const result = await fetchDownloadPluginLinkCheckListApi({
    ...mapDownloadLinkCheckQueryParams(formValues),
    page: page.currentPage,
    limit: page.pageSize,
  });
  return {
    items: result.list as DownloadLinkCheckRow[],
    summary: {
      fail: Number(result.summary?.fail ?? 0),
      ok: Number(result.summary?.ok ?? 0),
      remote_total: Number(result.summary?.remote_total ?? 0),
      unknown: Number(result.summary?.unknown ?? 0),
      warn: Number(result.summary?.warn ?? 0),
    } satisfies DownloadLinkCheckSummary,
    total: result.total,
  };
}
