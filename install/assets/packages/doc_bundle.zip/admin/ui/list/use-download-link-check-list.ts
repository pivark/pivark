import type { DownloadLinkCheckRow, DownloadLinkCheckSummary } from './link-check-data';

import type { VxeTableGridOptions } from '#/adapter/vxe-table';

import { ref, shallowRef } from 'vue';

import {
  PV_ADMIN_LIST_GRID_CLASS,
  PV_ADMIN_LIST_GRID_OPTIONS,
  usePvAdminListGrid,
} from '#/composables/use-pv-admin-list-grid';

import {
  emptyLinkCheckSummary,
  fetchDownloadLinkCheckListPage,
  useDownloadLinkCheckGridColumns,
  useDownloadLinkCheckListGridFormOptions,
} from './link-check-data';

export function useDownloadLinkCheckList() {
  const summary = ref<DownloadLinkCheckSummary>(emptyLinkCheckSummary());

  const gridApiRef = shallowRef<
    | ReturnType<typeof usePvAdminListGrid<DownloadLinkCheckRow>>['gridApi']
    | null
  >(null);

  function getGridApi() {
    return gridApiRef.value!;
  }

  async function refreshGrid() {
    await getGridApi().query();
  }

  const { Grid, gridApi } = usePvAdminListGrid<DownloadLinkCheckRow>(() => ({
    formOptions: useDownloadLinkCheckListGridFormOptions(),
    gridClass: PV_ADMIN_LIST_GRID_CLASS,
    gridOptions: {
      ...PV_ADMIN_LIST_GRID_OPTIONS,
      columns: useDownloadLinkCheckGridColumns(),
      proxyConfig: {
        ...PV_ADMIN_LIST_GRID_OPTIONS.proxyConfig,
        ajax: {
          query: async ({ page }, formValues) => {
            const result = await fetchDownloadLinkCheckListPage(
              page,
              formValues ?? {},
            );
            summary.value = result.summary;
            return {
              items: result.items,
              total: result.total,
            };
          },
        },
      },
      rowConfig: {
        keyField: 'id',
      },
    } as VxeTableGridOptions,
  }));
  gridApiRef.value = gridApi;

  return {
    Grid,
    refreshGrid,
    summary,
  };
}
