import type { DownloadResourceRow } from './data';

import type { VxeTableGridOptions } from '#/adapter/vxe-table';

import { ref, shallowRef } from 'vue';

import { ElMessage } from 'element-plus';

import { pivarkMutation } from '#/api/pivark/core/mutation';
import {
  confirmAdminBatchAction,
  confirmAdminBatchDelete,
  confirmAdminRowDelete,
} from '#/composables/use-admin-batch-actions';
import { runAdminSwitchField } from '#/composables/use-admin-switch-field';
import {
  PV_ADMIN_LIST_GRID_CLASS,
  PV_ADMIN_LIST_GRID_OPTIONS,
  usePvAdminListGrid,
} from '#/composables/use-pv-admin-list-grid';

import {
  fetchDownloadResourcesListPage,
  useDownloadResourcesGridColumns,
  useDownloadResourcesListGridFormOptions,
} from './data';

type DownloadResourcesHandlers = {
  onEdit: (row: DownloadResourceRow) => void;
};

export function useDownloadResourcesList(handlers: DownloadResourcesHandlers) {
  const selectedCount = ref(0);
  const batchBusy = ref(false);

  const gridApiRef = shallowRef<
    ReturnType<typeof usePvAdminListGrid<DownloadResourceRow>>['gridApi'] | null
  >(null);

  function getGridApi() {
    return gridApiRef.value!;
  }

  function selectedIds(): number[] {
    return (
      (getGridApi().grid?.getCheckboxRecords?.() ?? []) as DownloadResourceRow[]
    )
      .map((row) => Number(row.id))
      .filter((id) => id > 0);
  }

  function syncSelectedCount() {
    const next = selectedIds().length;
    if (selectedCount.value !== next) {
      selectedCount.value = next;
    }
  }

  async function refreshGrid() {
    await getGridApi().query();
    syncSelectedCount();
  }

  async function onStatusChange(newStatus: number, row: DownloadResourceRow) {
    const id = Number(row.id ?? 0);
    if (id < 1) {
      return false;
    }
    try {
      await pivarkMutation('/weapp/doc_bundle/status', { id, status: newStatus });
      ElMessage.success(newStatus === 1 ? '已启用' : '已停用');
      row.status = newStatus;
      return true;
    } catch {
      return false;
    }
  }

  async function saveSort(row: DownloadResourceRow) {
    const id = Number(row.id ?? 0);
    if (id < 1) {
      return;
    }
    await runAdminSwitchField(
      row,
      'sort',
      Number(row.sort ?? 0),
      () =>
        pivarkMutation('/weapp/doc_bundle/sort', {
          id,
          sort: Number(row.sort ?? 0),
        }),
      '排序已保存',
    );
  }

  async function handleRowDelete(row: DownloadResourceRow) {
    await confirmAdminRowDelete({
      message: `确定删除「${row.title}」？`,
      title: '删除',
      action: async () => {
        await pivarkMutation('/weapp/doc_bundle/delete', { id: Number(row.id) });
        await refreshGrid();
      },
      successMessage: '已删除',
    });
  }

  function onActionClick(e: { code: string; row: DownloadResourceRow }) {
    if (e.code === 'edit') {
      handlers.onEdit(e.row);
      return;
    }
    if (e.code === 'delete') {
      void handleRowDelete(e.row);
    }
  }

  async function handleBatchDelete() {
    const res = await confirmAdminBatchDelete({
      ids: selectedIds(),
      entityLabel: '下载资源',
      emptyMessage: '请先选择资源',
      action: (batchIds) =>
        pivarkMutation('/weapp/doc_bundle/batchDelete', { ids: batchIds }),
    });
    if (res) {
      await refreshGrid();
    }
  }

  async function handleBatchStatus(status: number) {
    const label = status === 1 ? '启用' : '禁用';
    await confirmAdminBatchAction({
      ids: selectedIds(),
      title: `批量${label}`,
      emptyMessage: '请先选择资源',
      confirmMessage: (n) => `确定${label}选中的 ${n} 条资源？`,
      action: (ids) =>
        pivarkMutation('/weapp/doc_bundle/batchStatus', { ids, status }),
      onSuccess: async (result) => {
        const count = Number(result?.count ?? 0);
        ElMessage.success(
          count > 0
            ? result?.msg || `${label}成功（${count} 条）`
            : result?.msg || '操作成功',
        );
        await refreshGrid();
      },
    });
  }

  const { Grid, gridApi } = usePvAdminListGrid<DownloadResourceRow>(() => ({
    formOptions: useDownloadResourcesListGridFormOptions(),
    gridClass: PV_ADMIN_LIST_GRID_CLASS,
    gridEvents: {
      checkboxAll: syncSelectedCount,
      checkboxChange: syncSelectedCount,
    },
    gridOptions: {
      ...PV_ADMIN_LIST_GRID_OPTIONS,
      columns: useDownloadResourcesGridColumns(onActionClick, onStatusChange),
      checkboxConfig: {
        highlight: true,
        reserve: true,
      },
      proxyConfig: {
        ...PV_ADMIN_LIST_GRID_OPTIONS.proxyConfig,
        ajax: {
          query: async ({ page }, formValues) => {
            const result = await fetchDownloadResourcesListPage(
              page,
              formValues ?? {},
            );
            syncSelectedCount();
            return {
              items: result.items,
              total: result.total,
            };
          },
        },
      },
      rowConfig: {
        keyField: 'id',
      },
    } as VxeTableGridOptions,
  }));
  gridApiRef.value = gridApi;

  return {
    Grid,
    batchBusy,
    batchDisable: () => handleBatchStatus(0),
    batchEnable: () => handleBatchStatus(1),
    handleBatchDelete,
    refreshGrid,
    saveSort,
    selectedCount,
  };
}
