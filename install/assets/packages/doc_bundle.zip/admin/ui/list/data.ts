import type { DownloadBundle } from '@weapp-doc-bundle/utils/download-bundle';

import type { PvFormSchema } from '#/adapter/form';
import type {
  OnActionClickFn,
  VxeTableGridColumns,
} from '#/adapter/vxe-table';

import { fetchDownloadPluginResourcesListApi } from '@weapp-doc-bundle/spa-api';
import {
  PV_COL_FLAG,
  PV_COL_ID,
  PV_COL_NUM,
  PV_COL_OPS,
  PV_COL_TEXT,
} from '#/composables/pv-admin-list-column-presets';
import { usePvAdminListSearchFormOptions } from '#/composables/pv-admin-list-form-layout';

export interface DownloadResourceRow extends DownloadBundle {
  access_label?: string;
  item_count?: number;
  document_title?: string;
  document_edit_path?: string;
}

const STATUS_OPTIONS = [
  { label: '启用', value: '1' },
  { label: '停用', value: '0' },
];

export function useDownloadResourcesGridFormSchema(): PvFormSchema[] {
  return [
    {
      component: 'Input',
      fieldName: 'keyword',
      label: '关键词',
      componentProps: {
        clearable: true,
        placeholder: '标题 / ID / 文档 ID',
      },
    },
    {
      component: 'Select',
      fieldName: 'status',
      label: '状态',
      componentProps: {
        clearable: true,
        options: STATUS_OPTIONS,
        placeholder: '全部',
      },
    },
  ];
}

export function useDownloadResourcesListGridFormOptions() {
  return usePvAdminListSearchFormOptions(useDownloadResourcesGridFormSchema());
}

export function mapDownloadResourcesQueryParams(
  formValues: Record<string, unknown>,
) {
  const status = formValues.status;
  return {
    keyword: String(formValues.keyword ?? '').trim() || undefined,
    status:
      status === '' || status === null || status === undefined
        ? undefined
        : Number(status),
  };
}

export function downloadResourceItemCount(row: DownloadResourceRow): number {
  const fromItems = row.items?.length ?? 0;
  if (fromItems > 0) {
    return fromItems;
  }
  return Number(row.item_count ?? 0);
}

export function downloadResourceDownloadCount(row: DownloadResourceRow): number {
  let total = 0;
  for (const item of row.items ?? []) {
    total += Number((item as { download_count?: number }).download_count ?? 0);
  }
  return total;
}

export function documentLinkTitle(row: DownloadResourceRow): string {
  const title = String(row.document_title ?? '').trim();
  if (title) {
    return title;
  }
  const docId = Number(row.document_id ?? 0);
  return docId > 0 ? `文档 #${docId}` : '';
}

export function useDownloadResourcesGridColumns(
  onActionClick: OnActionClickFn<DownloadResourceRow>,
  onStatusChange?: (
    newStatus: number,
    row: DownloadResourceRow,
  ) => PromiseLike<boolean | undefined>,
): VxeTableGridColumns<DownloadResourceRow> {
  return [
    {
      field: 'id',
      title: 'ID',
      width: 72,
      sortable: true,
      ...PV_COL_ID,
    },
    {
      field: 'title',
      title: '标题',
      minWidth: 200,
      ...PV_COL_TEXT,
      slots: { default: 'title' },
    },
    {
      field: 'item_count',
      title: '资源',
      width: 72,
      ...PV_COL_NUM,
      slots: { default: 'resourceCount' },
    },
    {
      field: 'access_label',
      title: '下载权限',
      width: 140,
      ...PV_COL_TEXT,
    },
    {
      field: 'document_id',
      title: '文档 ID',
      width: 88,
      sortable: true,
      ...PV_COL_ID,
    },
    {
      field: 'download_count',
      title: '下载量',
      width: 88,
      ...PV_COL_NUM,
      slots: { default: 'downloadCount' },
    },
    {
      field: 'sort',
      title: '排序',
      width: 116,
      ...PV_COL_NUM,
      fixed: 'right',
      slots: { default: 'sort' },
    },
    {
      field: 'status',
      title: '状态',
      width: 88,
      ...PV_COL_FLAG,
      fixed: 'right',
      cellRender: {
        attrs: { beforeChange: onStatusChange },
        name: 'CellSwitch',
      },
    },
    {
      ...PV_COL_OPS,
      cellRender: {
        attrs: {
          nameField: 'title',
          nameTitle: '下载资源',
          onClick: onActionClick,
          skipDeleteConfirm: true,
          variant: 'capsule',
        },
        name: 'CellOperation',
        options: [
          { code: 'edit', text: '编辑' },
          { code: 'delete', text: '删除', type: 'danger' },
        ],
      },
      field: 'operation',
      fixed: 'right',
      showOverflow: false,
      title: '操作',
      width: 140,
    },
  ];
}

export async function fetchDownloadResourcesListPage(
  page: { currentPage: number; pageSize: number },
  formValues: Record<string, unknown>,
) {
  const result = await fetchDownloadPluginResourcesListApi({
    ...mapDownloadResourcesQueryParams(formValues),
    page: page.currentPage,
    limit: page.pageSize,
  });
  return {
    items: result.list as DownloadResourceRow[],
    total: result.total,
  };
}
