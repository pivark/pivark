<script lang="ts" setup>
import type { DownloadBundle } from '@weapp-doc-bundle/utils/download-bundle';

import { onMounted, ref } from 'vue';
import { RouterLink } from 'vue-router';

import { ElMessage } from 'element-plus';

import { fetchDownloadPluginMetaApi } from '@weapp-doc-bundle/spa-api';
import { fetchSpaMemberFormMetaApi } from '#/api/pivark/core/spa';
import { pivarkMutation } from '#/api/pivark/core/mutation';
import { exportBundle } from '@weapp-doc-bundle/utils/download-bundle';

import DownloadBundleDialog from '@weapp-doc-bundle/components/DownloadBundleDialog.vue';
import PvAdminGridLoadingSkeleton from '#/components/pivark/PvAdminGridLoadingSkeleton.vue';
import PvAdminListBatchBar from '#/components/pivark/PvAdminListBatchBar.vue';
import WeappPluginShell from '#/components/pivark/weapp/WeappPluginShell.vue';
import WeappPluginPageCard from '#/components/pivark/weapp/WeappPluginPageCard.vue';

import type { DownloadResourceRow } from './list/data';
import {
  documentLinkTitle,
  downloadResourceDownloadCount,
  downloadResourceItemCount,
} from './list/data';
import { useDownloadResourcesList } from './list/use-download-resources-list';

defineOptions({ name: 'WeappDownloadResources' });

const memberLevels = ref<Array<{ id: number; name: string }>>([]);
const memberPointsEnabled = ref(false);
const dialogVisible = ref(false);
const editing = ref<DownloadResourceRow | null>(null);
const linkCheckSummary = ref<Record<string, number>>({});
const linkCheckLoading = ref(false);

function openForm(row?: DownloadResourceRow) {
  editing.value = row ?? null;
  dialogVisible.value = true;
}

const {
  Grid,
  batchDisable,
  batchEnable,
  handleBatchDelete,
  refreshGrid,
  saveSort,
  selectedCount,
} = useDownloadResourcesList({ onEdit: openForm });

async function loadLinkCheckSummary() {
  const meta = await fetchDownloadPluginMetaApi();
  linkCheckSummary.value = (meta.stats?.link_check ?? {}) as Record<
    string,
    number
  >;
}

async function runLinkCheck() {
  linkCheckLoading.value = true;
  try {
    const result = await pivarkMutation('/weapp/doc_bundle/checkLinks', {
      ids: [],
      scope: 'failed',
    });
    ElMessage.success(result?.msg || '巡检完成');
    await loadLinkCheckSummary();
    await refreshGrid();
  } finally {
    linkCheckLoading.value = false;
  }
}

async function handleSave(bundle: DownloadBundle) {
  await pivarkMutation('/weapp/doc_bundle/save', {
    bundle_json: JSON.stringify(exportBundle(bundle)),
  });
  ElMessage.success('保存成功');
  await refreshGrid();
}

onMounted(async () => {
  const meta = await fetchSpaMemberFormMetaApi();
  memberLevels.value = meta.memberLevels ?? [];
  memberPointsEnabled.value = Boolean(meta.memberPointsEnabled);
  await loadLinkCheckSummary();
});
</script>

<template>
  <WeappPluginShell nav-key="resources">
    <WeappPluginPageCard
      title="下载资源"
      :body-style="{ padding: '16px 20px 20px' }"
      class="pv-download-resources-list min-h-0 flex flex-1 flex-col"
    >
      <template #actions>
        <el-button type="primary" @click="openForm()">新增资源</el-button>
      </template>

      <div
        v-if="Object.keys(linkCheckSummary).length"
        class="pv-download-resources-link-summary mb-3 flex flex-wrap items-center gap-3 text-sm"
      >
        <span
          >远程
          <strong>{{ linkCheckSummary.remote_total ?? 0 }}</strong></span
        >
        <span>正常 <strong>{{ linkCheckSummary.ok ?? 0 }}</strong></span>
        <span
          >异常
          <strong>{{
            (linkCheckSummary.fail ?? 0) + (linkCheckSummary.warn ?? 0)
          }}</strong></span
        >
        <span>未检 <strong>{{ linkCheckSummary.unknown ?? 0 }}</strong></span>
        <el-button
          :loading="linkCheckLoading"
          size="small"
          type="warning"
          @click="runLinkCheck"
          >巡检异常项</el-button
        >
      </div>

      <Grid table-title="下载资源" class="min-h-0 flex-1">
        <template #loading>
          <PvAdminGridLoadingSkeleton fill />
        </template>
        <template #title="{ row }">
          <template v-if="row">
            <div class="font-medium">{{ row.title }}</div>
            <div v-if="row.document_id" class="mt-0.5 text-xs">
              <RouterLink
                v-if="row.document_edit_path"
                :to="row.document_edit_path"
                class="text-[var(--el-color-primary)] hover:underline"
              >
                {{ documentLinkTitle(row as DownloadResourceRow) }}
              </RouterLink>
              <span v-else class="text-muted-foreground"
                >文档 #{{ row.document_id }}</span
              >
            </div>
          </template>
        </template>
        <template #resourceCount="{ row }">
          {{ downloadResourceItemCount(row as DownloadResourceRow) }} 项
        </template>
        <template #downloadCount="{ row }">
          {{ downloadResourceDownloadCount(row as DownloadResourceRow) }}
        </template>
        <template #sort="{ row }">
          <el-input-number
            v-if="row"
            v-model="(row as DownloadResourceRow).sort"
            :controls="false"
            :max="99999"
            :min="0"
            class="!w-[72px]"
            size="small"
            @change="saveSort(row as DownloadResourceRow)"
          />
        </template>
        <template #bottom>
          <PvAdminListBatchBar :count="selectedCount">
            <el-button size="small" type="primary" @click="batchEnable"
              >批量启用</el-button
            >
            <el-button size="small" @click="batchDisable">批量禁用</el-button>
            <el-button size="small" type="danger" @click="handleBatchDelete"
              >批量删除</el-button
            >
          </PvAdminListBatchBar>
        </template>
      </Grid>
    </WeappPluginPageCard>

    <DownloadBundleDialog
      v-model="dialogVisible"
      :bundle="editing"
      :member-levels="memberLevels"
      :member-points-enabled="memberPointsEnabled"
      show-document-id
      @save="handleSave"
    />
  </WeappPluginShell>
</template>
