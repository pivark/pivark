<?php
declare(strict_types=1);

namespace weapp\doc_bundle\admin;

use weapp\doc_bundle\service\DownloadConfigService;
use app\common\contract\PluginAdminBaseTrait;
use app\common\contract\PluginAdminUsageTrait;
use think\facade\Request;
use think\Response;
use weapp\doc_bundle\service\DownloadLinkCheckService;
use weapp\doc_bundle\service\DownloadPluginBootstrap;
use weapp\doc_bundle\service\DownloadBundleAdminService;
use weapp\doc_bundle\service\DownloadBundleQueryService;
use app\common\service\weapp\WeappPluginGateway;
use app\common\service\weapp\WeappConfigGateway;
use app\common\service\weapp\WeappMemberGateway;
use app\common\service\weapp\WeappSiteGateway;
use app\common\service\weapp\WeappSupportGateway;

class AdminController
{
    use PluginAdminBaseTrait;
    use PluginAdminUsageTrait;

    public function __construct()
    {
        $this->pluginIdentifier = 'doc_bundle';
    }

    public function index(): Response
    {
        if (!$this->entitled()) {
            return $this->renderDisabled();
        }
        $manifest = app(WeappPluginGateway::class)->pluginReadManifest('doc_bundle') ?? [];

        return $this->renderPluginView('index', array_merge(
            $this->pluginContext($manifest),
            [
                'cfg'        => DownloadConfigService::all(),
                'navOptions' => app(WeappSiteGateway::class)->siteNavListContentCategoryOptions(),
                'stats'      => $this->stats(),
            ]
        ));
    }

    public function resources(): Response
    {
        if (!$this->entitled()) {
            return $this->renderDisabled();
        }
        DownloadPluginBootstrap::ensureAutoload();
        $manifest = app(WeappPluginGateway::class)->pluginReadManifest('doc_bundle') ?? [];

        if (Request::isAjax()) {
            $list = DownloadBundleQueryService::listAdmin();
            return app(WeappSupportGateway::class)->apiFromServiceResult(app(WeappSupportGateway::class)->resultList($list, count($list)));
        }

        return $this->renderPluginView('resources', array_merge(
            $this->pluginContext($manifest),
            [
                'list'         => DownloadBundleQueryService::listAdmin(),
                'memberLevels' => app(WeappMemberGateway::class)->memberLevelsActive(),
                'memberPointsEnabled' => app(WeappMemberGateway::class)->memberConfigPointsEnabled(),
            ]
        ));
    }

    public function configSave(): Response
    {
        if (!Request::isPost() && !Request::isGet()) {
            return app(WeappSupportGateway::class)->apiMethodNotAllowed();
        }
        if (!$this->entitled()) {
            return app(WeappSupportGateway::class)->apiFromServiceResult(app(WeappSupportGateway::class)->resultForbidden('插件未授权'));
        }

        return app(WeappSupportGateway::class)->apiFromServiceResult(DownloadConfigService::saveAdmin(Request::post()));
    }

    public function save(): Response
    {
        if (!Request::isPost() && !Request::isGet()) {
            return app(WeappSupportGateway::class)->apiMethodNotAllowed();
        }
        if (!$this->entitled()) {
            return app(WeappSupportGateway::class)->apiFromServiceResult(app(WeappSupportGateway::class)->resultForbidden('插件未授权'));
        }
        DownloadPluginBootstrap::ensureAutoload();

        return app(WeappSupportGateway::class)->apiFromServiceResult(DownloadBundleAdminService::saveAdmin(Request::post()));
    }

    public function delete(): Response
    {
        if (!Request::isPost() && !Request::isGet()) {
            return app(WeappSupportGateway::class)->apiMethodNotAllowed();
        }
        DownloadPluginBootstrap::ensureAutoload();

        return app(WeappSupportGateway::class)->apiFromServiceResult(DownloadBundleAdminService::deleteAdmin((int) Request::post('id', 0)));
    }

    public function status(): Response
    {
        if (!Request::isPost() && !Request::isGet()) {
            return app(WeappSupportGateway::class)->apiMethodNotAllowed();
        }
        DownloadPluginBootstrap::ensureAutoload();

        return app(WeappSupportGateway::class)->apiFromServiceResult(DownloadBundleAdminService::updateStatusAdmin(
            (int) Request::post('id', 0),
            (int) Request::post('status', 0)
        ));
    }
    public function batchDelete(): Response
    {
        if (!Request::isPost() && !Request::isGet()) {
            return app(WeappSupportGateway::class)->apiMethodNotAllowed();
        }
        DownloadPluginBootstrap::ensureAutoload();
        $ids = app(WeappSupportGateway::class)->parseIdsFromMixed(Request::param('ids/a', Request::param('ids', '')));

        return app(WeappSupportGateway::class)->apiFromServiceResult(DownloadBundleAdminService::batchDeleteAdmin($ids));
    }

    public function batchStatus(): Response
    {
        if (!Request::isPost() && !Request::isGet()) {
            return app(WeappSupportGateway::class)->apiMethodNotAllowed();
        }
        DownloadPluginBootstrap::ensureAutoload();
        $ids = app(WeappSupportGateway::class)->parseIdsFromMixed(Request::param('ids/a', Request::param('ids', '')));
        $status = (int) Request::post('status', 1) === 1 ? 1 : 0;

        return app(WeappSupportGateway::class)->apiFromServiceResult(DownloadBundleAdminService::batchUpdateStatusAdmin($ids, $status));
    }

    public function sort(): Response
    {
        if (!Request::isPost() && !Request::isGet()) {
            return app(WeappSupportGateway::class)->apiMethodNotAllowed();
        }
        DownloadPluginBootstrap::ensureAutoload();

        return app(WeappSupportGateway::class)->apiFromServiceResult(DownloadBundleAdminService::updateSortAdmin(
            (int) Request::post('id', 0),
            (int) Request::post('sort', 0)
        ));
    }


    public function linkCheckList(): Response
    {
        if (!$this->entitled()) {
            return app(WeappSupportGateway::class)->apiFromServiceResult(app(WeappSupportGateway::class)->resultForbidden('插件未授权'));
        }
        DownloadPluginBootstrap::ensureAutoload();
        $page   = max(1, (int) Request::get('page', 1));
        $limit  = (int) Request::get('limit', 20);
        $status = trim((string) Request::get('status', ''));
        $data   = DownloadLinkCheckService::listAdmin($page, $limit, $status);

        $list = is_array($data['list'] ?? null) ? $data['list'] : [];
        $meta = ['summary' => DownloadLinkCheckService::summary()] + $data;
        unset($meta['list']);

        return app(WeappSupportGateway::class)->apiFromServiceResult(app(WeappSupportGateway::class)->resultList($list, (int) ($meta['total'] ?? count($list)), $meta));
    }

    public function checkLinks(): Response
    {
        if (!Request::isPost() && !Request::isGet()) {
            return app(WeappSupportGateway::class)->apiMethodNotAllowed();
        }
        if (!$this->entitled()) {
            return app(WeappSupportGateway::class)->apiFromServiceResult(app(WeappSupportGateway::class)->resultForbidden('插件未授权'));
        }
        DownloadPluginBootstrap::ensureAutoload();
        $ids = app(WeappSupportGateway::class)->parseIdsFromMixed(Request::param('ids/a', Request::param('ids', '')));
        $scope = trim((string) Request::post('scope', 'selected'));

        return app(WeappSupportGateway::class)->apiFromServiceResult(DownloadLinkCheckService::checkItemsAdmin($ids, $scope !== '' ? $scope : 'selected'));
    }

    /** @return array<string, int|string> */
    private function stats(): array
    {
        return [
            'bundle_count'   => (int) app(WeappConfigGateway::class)->weappDb('doc_bundle', 'bundles')->count(),
            'item_count'     => (int) app(WeappConfigGateway::class)->weappDb('doc_bundle', 'items')->count(),
            'download_total' => (int) app(WeappConfigGateway::class)->weappDb('doc_bundle', 'items')->sum('download_count'),
            'scope_label'    => DownloadConfigService::scopeLabel(),
        ];
    }

    public function exportCsv(): Response
    {
        if (!Request::isPost() && !Request::isGet()) {
            return app(WeappSupportGateway::class)->apiMethodNotAllowed();
        }
        if (!$this->entitled()) {
            return app(WeappSupportGateway::class)->apiFromServiceResult(app(WeappSupportGateway::class)->resultForbidden('插件未授权'));
        }
        DownloadPluginBootstrap::ensureAutoload();
        $raw = Request::param('ids', Request::param('ids/a', []));
        $ids = is_array($raw) ? array_map('intval', $raw) : [];
        $pack = \weapp\doc_bundle\service\DownloadCatalogService::exportCsvAdmin(
            [
                'keyword' => trim((string) Request::param('keyword', '')),
                'status'  => Request::param('status', ''),
            ],
            $ids,
        );

        return Response::create($pack['content'], 'html', 200, [
            'Content-Type'        => 'text/csv; charset=UTF-8',
            'Content-Disposition' => 'attachment; filename="' . $pack['filename'] . '"',
        ]);
    }

    public function statsTop(): Response
    {
        if (!$this->entitled()) {
            return app(WeappSupportGateway::class)->apiFromServiceResult(app(WeappSupportGateway::class)->resultForbidden('插件未授权'));
        }
        $limit = max(5, min(50, (int) Request::get('limit', 10)));

        $list = \weapp\doc_bundle\service\DownloadCatalogService::statsTopAdmin($limit);

        return app(WeappSupportGateway::class)->apiFromServiceResult(app(WeappSupportGateway::class)->resultList($list, count($list)));
    }

}
