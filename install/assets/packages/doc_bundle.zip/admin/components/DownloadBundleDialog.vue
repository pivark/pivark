<script lang="ts" setup>
import type { DownloadBundle } from '@weapp-doc-bundle/utils/download-bundle';

import { ref, watch } from 'vue';

import DownloadBundleInlineForm from '@weapp-doc-bundle/components/DownloadBundleInlineForm.vue';

const props = defineProps<{
  bundle?: Partial<DownloadBundle> | null;
  documentContext?: boolean;
  memberLevels?: Array<{ id: number; name: string }>;
  memberPointsEnabled?: boolean;
  modelValue: boolean;
  showDocumentId?: boolean;
}>();

const emit = defineEmits<{
  save: [bundle: DownloadBundle];
  'update:modelValue': [visible: boolean];
}>();

const inlineFormRef = ref<InstanceType<typeof DownloadBundleInlineForm> | null>(
  null,
);

function close() {
  emit('update:modelValue', false);
}

function handleSave() {
  const saved = inlineFormRef.value?.submit();
  if (!saved) {
    return;
  }
  emit('save', saved);
  emit('update:modelValue', false);
}

watch(
  () => props.modelValue,
  (open) => {
    if (!open) {
      inlineFormRef.value = null;
    }
  },
);
</script>

<template>
  <el-dialog
    :model-value="modelValue"
    :title="bundle?.id ? '编辑下载资源' : '新增下载资源'"
    width="720px"
    destroy-on-close
    @close="close"
  >
    <DownloadBundleInlineForm
      ref="inlineFormRef"
      :bundle="bundle"
      :document-context="documentContext"
      :member-levels="memberLevels"
      :member-points-enabled="memberPointsEnabled"
      :show-document-id="showDocumentId"
    />
    <template #footer>
      <el-button @click="close">取消</el-button>
      <el-button type="primary" @click="handleSave">保存</el-button>
    </template>
  </el-dialog>
</template>
