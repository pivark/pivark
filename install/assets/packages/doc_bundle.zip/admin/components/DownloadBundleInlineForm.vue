<script lang="ts" setup>
import type {
  DownloadBundle,
  DownloadItem,
} from '@weapp-doc-bundle/utils/download-bundle';

import { reactive, ref, watch } from 'vue';

import { ElMessage } from 'element-plus';

import { normalizeBundle, parseReadAccess } from '@weapp-doc-bundle/utils/download-bundle';
import { uploadFileApi } from '#/api/pivark/system/upload';
import {
  isGenericRemoteLabel,
  normalizeRemoteUrlKey,
  remoteItemLabel,
} from '#/utils/pan-platform';

import PanPlatformIcon from '#/components/pivark/PanPlatformIcon.vue';

import MediaPickerDialog from '#/components/pivark/MediaPickerDialog.vue';

const props = defineProps<{
  bundle?: Partial<DownloadBundle> | null;
  documentContext?: boolean;
  memberLevels?: Array<{ id: number; name: string }>;
  memberPointsEnabled?: boolean;
  showDocumentId?: boolean;
}>();

const form = reactive<DownloadBundle>(normalizeBundle(null));
const readAccess = ref('0');
const filePickerIndex = ref<number | null>(null);
const filePickerVisible = ref(false);

function loadBundle(raw: Partial<DownloadBundle> | null | undefined) {
  const row = normalizeBundle(raw ?? null);
  form.id = row.id;
  form.document_id = row.document_id;
  form.title = row.title;
  form.access_mode = row.access_mode;
  form.member_level_id = row.member_level_id;
  form.points_cost = row.points_cost;
  form.sort = row.sort;
  form.status = row.status;
  form.items.splice(
    0,
    form.items.length,
    ...row.items.map((it) => ({ ...it })),
  );
  if (row.access_mode === 'login') {
    readAccess.value = 'login';
  } else if (row.access_mode === 'points') {
    readAccess.value = 'points';
  } else if (row.access_mode === 'member' && (row.member_level_id ?? 0) > 0) {
    readAccess.value = `level:${row.member_level_id}`;
  } else {
    readAccess.value = '0';
  }
}

watch(
  () => props.bundle,
  (row) => {
    if (row) {
      loadBundle(row);
    }
  },
  { immediate: true },
);

const emit = defineEmits<{
  draftChange: [DownloadBundle];
}>();

function applyAccess() {
  const parsed = parseReadAccess(readAccess.value);
  form.access_mode = parsed.access_mode;
  form.member_level_id = parsed.member_level_id;
  if (parsed.access_mode !== 'points') {
    form.points_cost = 0;
  } else if ((form.points_cost ?? 0) < 1) {
    form.points_cost = 1;
  }
}

function onAccessFieldChange() {
  applyAccess();
  if (props.documentContext) {
    emit('draftChange', normalizeBundle({ ...form, items: [...form.items] }));
  }
}

watch(readAccess, () => {
  onAccessFieldChange();
});

watch(
  () => form.points_cost,
  () => {
    if (readAccess.value === 'points') {
      onAccessFieldChange();
    }
  },
);

function addItem(type: 'local' | 'remote') {
  form.items.push({
    label: type === 'remote' ? '' : '本地下载',
    sort: form.items.length,
    source_type: type,
    status: 1,
  });
}

function syncRemoteItemLabel(item: DownloadItem) {
  const url = String(item.remote_url ?? '').trim();
  if (!url) {
    return;
  }
  const label = String(item.label ?? '').trim();
  if (!label || isGenericRemoteLabel(label)) {
    item.label = remoteItemLabel(url);
  }
}

function onRemoteUrlBlur(item: DownloadItem, index: number) {
  const url = String(item.remote_url ?? '').trim();
  if (!url) {
    return;
  }
  syncRemoteItemLabel(item);
  const key = normalizeRemoteUrlKey(url);
  const duplicate = form.items.some(
    (row, rowIndex) =>
      rowIndex !== index &&
      row.source_type === 'remote' &&
      normalizeRemoteUrlKey(String(row.remote_url ?? '')) === key,
  );
  if (duplicate) {
    ElMessage.warning('该链接已添加');
  }
}

function removeItem(index: number) {
  form.items.splice(index, 1);
}

async function uploadLocal(index: number, file: File) {
  try {
    const result = await uploadFileApi(file);
    const item = form.items[index];
    if (item) {
      item.file_path = result.path || result.url;
      item.file_size = file.size;
      if (!item.label?.trim()) {
        item.label = file.name;
      }
    }
    ElMessage.success('已上传');
  } catch (error) {
    ElMessage.error(error instanceof Error ? error.message : '上传失败');
  }
  return false;
}

/** 智能导入：批量建本地项并自动上传 */
async function stageLocalFiles(files: File[]) {
  const list = files.filter((f) => f.name || f.size > 0);
  if (!list.length) {
    return;
  }
  form.items = list.map((file, sort) => ({
    label: file.name,
    sort,
    source_type: 'local' as const,
    status: 1,
  }));
  for (let i = 0; i < list.length; i++) {
    await uploadLocal(i, list[i]!);
  }
}

function openFilePicker(index: number) {
  filePickerIndex.value = index;
  filePickerVisible.value = true;
}

function onFilePicked(payload: { path: string; size: number; url: string }) {
  const index = filePickerIndex.value;
  if (index === null) return;
  const item = form.items[index];
  if (item) {
    item.file_path = payload.path || payload.url;
    item.file_size = payload.size;
  }
  filePickerIndex.value = null;
}

function itemFilled(item: DownloadItem): boolean {
  if (item.source_type === 'remote') {
    return !!String(item.remote_url ?? '').trim();
  }
  return !!String(item.file_path ?? '').trim();
}

function validItems(): DownloadItem[] {
  return form.items.filter(itemFilled);
}

function isEmpty(): boolean {
  return validItems().length === 0;
}

function submit(): DownloadBundle | null {
  if (!form.title.trim() && !props.documentContext) {
    ElMessage.warning('请填写下载标题');
    return null;
  }
  const items = validItems();
  if (!props.documentContext && items.length === 0) {
    ElMessage.warning('请至少添加一个有效的下载资源');
    return null;
  }
  applyAccess();
  if (form.access_mode === 'points') {
    if (props.memberPointsEnabled === false) {
      ElMessage.warning('请先在「会员中心 → 会员配置」中启用会员积分');
      return null;
    }
    if ((form.points_cost ?? 0) < 1) {
      ElMessage.warning('请填写消耗积分（至少 1，');
      return null;
    }
  }
  return normalizeBundle({ ...form, items });
}

defineExpose({ isEmpty, stageLocalFiles, submit });
</script>

<template>
  <div
    class="pv-dl-inline-panel"
    :class="{ 'pv-dl-inline-panel--doc': documentContext }"
  >
    <el-form :label-width="documentContext ? '72px' : '100px'" size="small">
      <el-form-item v-if="!documentContext" label="标题" required>
        <el-input v-model="form.title" placeholder="如：产品白皮书" />
      </el-form-item>
      <el-form-item v-if="showDocumentId && !documentContext" label="文档 ID">
        <el-input-number
          v-model="form.document_id"
          :controls="false"
          class="w-full"
        />
      </el-form-item>
      <el-form-item label="下载权限" class="pv-dl-access-row">
        <el-select
          :key="`dl-access-${props.memberPointsEnabled ? 1 : 0}-${(props.memberLevels ?? []).length}`"
          v-model="readAccess"
          class="pv-dl-access-select"
          @change="onAccessFieldChange"
        >
          <el-option label="开放浏览" value="0" />
          <el-option label="须登录" value="login" />
          <el-option
            v-for="lv in props.memberLevels ?? []"
            :key="lv.id"
            :label="`${lv.name}及以上`"
            :value="`level:${lv.id}`"
          />
          <el-option
            v-if="props.memberPointsEnabled !== false"
            label="积分下载"
            value="points"
          />
        </el-select>
        <el-input-number
          v-if="readAccess === 'points'"
          v-model="form.points_cost"
          :min="1"
          :max="999999"
          :controls="false"
          class="pv-dl-points-cost"
          placeholder="消费积分"
          @change="onAccessFieldChange"
        />
        <span
          v-if="documentContext"
          class="pv-dl-access-hint pv-dl-access-hint--inline"
        >
          与阅读权限独立，可「可读不可下」</span>
        <p v-else class="pv-dl-access-hint">
          与文档、阅读权限独立，可配置为可读但不可下载。</p>
      </el-form-item>
      <el-form-item v-if="!documentContext" label="排序">
        <el-input-number v-model="form.sort" :controls="false" />
      </el-form-item>
      <el-form-item v-if="!documentContext" label="状态">
        <el-switch
          v-model="form.status"
          :active-value="1"
          :inactive-value="0"
        />
      </el-form-item>
    </el-form>

    <div class="pv-dl-inline-actions">
      <el-button size="small" type="primary" plain @click="addItem('local')"
        >本地文件</el-button
      >
      <el-button size="small" @click="addItem('remote')">远程链接</el-button>
    </div>

    <p v-if="!form.items.length" class="pv-dl-inline-empty">
      暂无下载项，可点「本地文件」或「远程链接」添加</p>

    <ul v-else class="pv-dl-item-list">
      <li
        v-for="(item, index) in form.items"
        :key="`${item.id ?? 0}-${index}-${item.source_type}`"
        class="pv-dl-item-row"
      >
        <span
          class="pv-dl-item-type"
          :class="
            item.source_type === 'local'
              ? 'pv-dl-item-type--local'
              : 'pv-dl-item-type--remote'
          "
        >
          <template v-if="item.source_type === 'local'">本地</template>
          <PanPlatformIcon
            v-else
            :url="String(item.remote_url ?? '')"
            :size="18"
          />
        </span>
        <el-input
          v-model="item.label"
          class="pv-dl-item-label"
          :placeholder="item.source_type === 'remote' ? '网盘名称' : '显示名'"
          size="small"
        />
        <template v-if="item.source_type === 'local'">
          <el-input
            v-model="item.file_path"
            class="pv-dl-item-main"
            placeholder="文件路径"
            size="small"
          />
          <el-button size="small" @click="openFilePicker(index)"
            >素材库</el-button>
          <el-upload
            :show-file-list="false"
            :before-upload="(f) => uploadLocal(index, f as File)"
          >
            <el-button size="small">上传</el-button>
          </el-upload>
        </template>
        <template v-else>
          <el-input
            v-model="item.remote_url"
            class="pv-dl-item-main"
            placeholder="下载链接"
            size="small"
            @blur="onRemoteUrlBlur(item, index)"
          />
          <el-input
            v-model="item.extract_code"
            class="pv-dl-item-code"
            placeholder="提取码"
            size="small"
          />
        </template>
        <el-button link size="small" type="danger" @click="removeItem(index)"
          >ɾ</el-button>
      </li>
    </ul>

    <MediaPickerDialog
      v-model="filePickerVisible"
      kind="software"
      title="选择附件"
      @pick="onFilePicked"
    />
  </div>
</template>

<style scoped>
.pv-dl-inline-panel {
  margin-top: 8px;
  padding: 10px 12px 6px;
  background: var(--el-fill-color-light);
  border: 1px solid var(--el-border-color-lighter);
  border-radius: var(--pv-radius-xs);
}

.pv-dl-inline-panel--doc {
  margin-top: 4px;
  padding: 8px 10px 4px;
  background: transparent;
  border: none;
}

.pv-dl-inline-panel--doc :deep(.el-form-item) {
  margin-bottom: 8px;
}

.pv-dl-access-select {
  width: 200px;
  max-width: 100%;
}

.pv-dl-points-cost {
  width: 120px;
  margin-left: 8px;
}

.pv-dl-access-hint {
  margin: 6px 0 0;
  font-size: 12px;
  line-height: 1.5;
  color: var(--el-text-color-secondary);
}

.pv-dl-access-hint--inline {
  margin: 0 0 0 8px;
  font-size: 12px;
  color: var(--el-text-color-placeholder);
}

.pv-dl-access-row :deep(.el-form-item__content) {
  flex-wrap: wrap;
  align-items: center;
}

.pv-dl-inline-actions {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  margin-bottom: 8px;
}

.pv-dl-inline-empty {
  margin: 0 0 8px;
  font-size: 12px;
  color: var(--el-text-color-secondary);
}

.pv-dl-item-list {
  margin: 0;
  padding: 0;
  list-style: none;
}

.pv-dl-item-row {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
  align-items: center;
  padding: 4px 0;
  border-bottom: 1px dashed var(--el-border-color-extra-light);
}

.pv-dl-item-row:last-child {
  border-bottom: none;
}

.pv-dl-item-type {
  flex-shrink: 0;
  min-width: 32px;
  font-size: 12px;
  line-height: 22px;
  color: var(--el-text-color-secondary);
}

.pv-dl-item-type--local {
  color: var(--el-color-success);
}

.pv-dl-item-type--remote {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  min-width: 24px;
}

.pv-dl-item-label {
  width: 88px;
  flex-shrink: 0;
}

.pv-dl-item-main {
  flex: 1 1 160px;
  min-width: 120px;
}

.pv-dl-item-code {
  width: 72px;
  flex-shrink: 0;
}
</style>

