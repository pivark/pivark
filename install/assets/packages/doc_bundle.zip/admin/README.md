# doc_bundle 后台 UI（SSOT）

Vue SFC：`weapp/doc_bundle/admin/ui/`。

**零外放**：禁止 junction；glob pageMap + `/weapp/host/doc_bundle/{page}` 通用 Host 加载。后台专用样式 SSOT：`admin/styles/doc-bundle-admin-shell.css`。
