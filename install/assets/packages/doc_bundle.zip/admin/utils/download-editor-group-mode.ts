/** 下载插件发布页录入 / 剪贴板预填：按文件 vs 按网盘分组 */

export type DownloadEditorGroupMode = 'by_file' | 'by_platform';

const STORAGE_KEY = 'pv-download-editor-group-mode';

export function normalizeDownloadEditorGroupMode(
  raw: unknown,
): DownloadEditorGroupMode {
  return String(raw ?? '').trim() === 'by_platform'
    ? 'by_platform'
    : 'by_file';
}

export function getDownloadEditorGroupModePreference(): DownloadEditorGroupMode {
  try {
    return normalizeDownloadEditorGroupMode(
      localStorage.getItem(STORAGE_KEY),
    );
  } catch {
    return 'by_file';
  }
}

export function setDownloadEditorGroupModePreference(
  mode: DownloadEditorGroupMode,
) {
  try {
    localStorage.setItem(
      STORAGE_KEY,
      normalizeDownloadEditorGroupMode(mode),
    );
  } catch {
    /* ignore */
  }
}

export function downloadEditorGroupModeLabel(
  mode: DownloadEditorGroupMode,
): string {
  return mode === 'by_platform' ? '按网盘分文件' : '按文件分网盘';
}
