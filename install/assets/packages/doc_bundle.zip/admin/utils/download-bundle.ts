import {
  detectPanPlatform,
  isGenericRemoteLabel,
  remoteItemLabel,
} from '#/utils/pan-platform';

export interface DownloadItem {
  extract_code?: string;
  file_path?: string;
  file_size?: number;
  id?: number;
  label?: string;
  remote_url?: string;
  sort?: number;
  source_type: 'local' | 'remote';
  status?: number;
}

export interface DownloadBundle {
  access_mode?: string;
  document_id?: number;
  id?: number;
  items: DownloadItem[];
  member_level_id?: number;
  points_cost?: number;
  sort?: number;
  status?: number;
  title: string;
}

/** 本地默认「本地下载」；兼容旧数据「立即下载」 */
export function normalizeItemLabel(it: Partial<DownloadItem>): string {
  const type = it.source_type === 'remote' ? 'remote' : 'local';
  const raw = String(it.label ?? '').trim();
  if (type === 'remote') {
    const url = String(it.remote_url ?? '').trim();
    if (url && (!raw || isGenericRemoteLabel(raw))) {
      return remoteItemLabel(url);
    }
    return raw || (url ? detectPanPlatform(url).label : '远程链接');
  }
  if (raw === '' || raw === '立即下载') {
    return '本地下载';
  }
  return raw;
}

export function normalizeBundle(
  raw: Partial<DownloadBundle> | null,
): DownloadBundle {
  const items = Array.isArray(raw?.items) ? raw!.items! : [];
  return {
    access_mode: raw?.access_mode ?? 'free',
    document_id: Number(raw?.document_id ?? 0),
    id: Number(raw?.id ?? 0),
    items: items.map((it, i) => ({
      extract_code: it.extract_code ?? '',
      file_path: it.file_path ?? '',
      file_size: Number(it.file_size ?? 0),
      id: Number(it.id ?? 0),
      label: normalizeItemLabel(it),
      remote_url: it.remote_url ?? '',
      sort: Number(it.sort ?? i),
      source_type: it.source_type === 'remote' ? 'remote' : 'local',
      status: Number(it.status ?? 1) ? 1 : 0,
    })),
    member_level_id: Number(raw?.member_level_id ?? 0),
    points_cost: Number(raw?.points_cost ?? 0),
    sort: Number(raw?.sort ?? 0),
    status: Number(raw?.status ?? 1) ? 1 : 0,
    title: raw?.title ?? '',
  };
}

export function exportBundle(row: DownloadBundle): Record<string, unknown> {
  return {
    access_mode: row.access_mode || 'free',
    document_id: row.document_id || 0,
    id: row.id && row.id > 0 ? row.id : 0,
    items: (row.items || []).map((it) => {
      const base: Record<string, unknown> = {
        id: it.id || 0,
        label: it.label || '',
        sort: it.sort || 0,
        source_type: it.source_type,
        status: it.status ? 1 : 0,
      };
      if (it.source_type === 'remote') {
        base.remote_url = it.remote_url || '';
        base.extract_code = it.extract_code || '';
        base.file_path = '';
        base.file_size = 0;
      } else {
        base.file_path = it.file_path || '';
        base.file_size = it.file_size || 0;
        base.remote_url = '';
        base.extract_code = '';
      }
      return base;
    }),
    member_level_id: row.member_level_id || 0,
    points_cost:
      row.access_mode === 'points'
        ? Math.max(0, Number(row.points_cost ?? 0))
        : 0,
    sort: row.sort || 0,
    status: row.status ? 1 : 0,
    title: row.title,
  };
}

export function encodeReadAccess(
  accessMode: string,
  memberLevelId: number,
  pointsCost = 0,
): string {
  if (accessMode === 'login') return 'login';
  if (accessMode === 'points') return 'points';
  if (accessMode === 'member' && memberLevelId > 0)
    return `level:${memberLevelId}`;
  return '0';
}

export function parseReadAccess(val: string): {
  access_mode: string;
  member_level_id: number;
  points_cost: number;
} {
  if (val === 'login')
    return { access_mode: 'login', member_level_id: 0, points_cost: 0 };
  if (val === 'points')
    return { access_mode: 'points', member_level_id: 0, points_cost: 0 };
  if (val.startsWith('level:')) {
    return {
      access_mode: 'member',
      member_level_id: Number.parseInt(val.slice(6), 10) || 0,
      points_cost: 0,
    };
  }
  return { access_mode: 'free', member_level_id: 0, points_cost: 0 };
}

export function downloadAccessLabel(
  accessMode: string | undefined,
  memberLevelId: number | undefined,
  levels: Array<{ id: number; name: string }>,
  pointsCost?: number,
): string {
  const mode = String(accessMode ?? 'free');
  const levelId = Number(memberLevelId ?? 0);
  const cost = Number(pointsCost ?? 0);
  if (mode === 'login') {
    return '须登录';
  }
  if (mode === 'points') {
    return cost > 0 ? `积分下载（${cost} 积分）` : '积分下载';
  }
  if (mode === 'member' && levelId > 0) {
    const level = levels.find((item) => item.id === levelId);
    return level ? `${level.name}及以上` : '会员等级';
  }
  return '开放下载';
}

/** 表格/列表中单条资源的可读标题 */
export function itemLineLabel(item: DownloadItem): string {
  if (item.source_type === 'remote') {
    const url = String(item.remote_url ?? '').trim();
    const label = String(item.label ?? '').trim();
    if (label && url && label !== url) {
      return `${label} (${url})`;
    }
    return label || url || '远程链接';
  }
  const path = String(item.file_path ?? '').trim();
  const label = String(item.label ?? '').trim();
  if (label && path && label !== path) {
    return `${label} (${path})`;
  }
  return label || path || '本地文件';
}

/** 资源摘要行：按网盘平台计数，如「百度网盘 3 项」 */
export function itemSummary(items: DownloadItem[] | undefined): string {
  const list = Array.isArray(items) ? items : [];
  if (!list.length) {
    return '未配置资源';
  }
  let local = 0;
  const remoteByPlatform = new Map<string, { count: number; label: string }>();
  const remoteOrder: string[] = [];

  for (const item of list) {
    if (item.source_type === 'remote') {
      const url = String(item.remote_url ?? '').trim();
      if (!url) {
        continue;
      }
      const platform = detectPanPlatform(url);
      const key = platform.id;
      const existing = remoteByPlatform.get(key);
      if (existing) {
        existing.count += 1;
      } else {
        remoteByPlatform.set(key, {
          count: 1,
          label: key === 'other' ? '远程' : platform.label,
        });
        remoteOrder.push(key);
      }
    } else if (String(item.file_path ?? '').trim()) {
      local += 1;
    }
  }

  const parts: string[] = [];
  if (local > 0) {
    parts.push(`本地 ${local} 项`);
  }
  for (const key of remoteOrder) {
    const row = remoteByPlatform.get(key);
    if (row && row.count > 0) {
      parts.push(`${row.label} ${row.count} 项`);
    }
  }
  return parts.length ? parts.join('、') : '未配置资源';
}
