/** download 剪贴板/import 意图标识（handler 自注册 SSOT · 仅 weapp/download 内引用） */
export const DOWNLOAD_PLUGIN_ID = 'doc_bundle' as const;
