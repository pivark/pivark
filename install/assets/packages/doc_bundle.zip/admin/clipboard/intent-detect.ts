import { PAN_HOST_PATTERN } from '#/utils/pan-platform';
import {
  extractUrlCandidatesFromText,
  sanitizePanEntriesFromText,
} from '#/utils/clipboard-link-sanitize';
import {
  extractPanExtractCode,
  type ClipboardIntent,
} from '#/utils/clipboard-intent';
import { registerImportIntentDetectRule } from '#/utils/import-intent-detect-registry';
import { DOWNLOAD_PLUGIN_ID } from '@weapp-doc-bundle/clipboard/plugin-id';

const PLUGIN = DOWNLOAD_PLUGIN_ID;

const PAN_TEXT_RE =
  /百度网盘|夸克网盘|阿里云盘|天翼云盘|蓝奏云|提取码|访问码|pan\.baidu/i;

const ARCHIVE_EXT_RE = /\.(zip|rar|7z|tar|gz|bz2|xz|tgz)(\?|#|$)/i;
const IMAGE_EXT_RE = /\.(jpg|jpeg|png|gif|webp|svg|bmp|ico)(\?|#|$)/i;
/** 与 video-intent-detect 对齐：generic_url 不得吞视频网站/直链 */
const VIDEO_FILE_RE = /\.(mp4|webm|m3u8|mov|mkv|avi|flv|ts)(\?|#|$)/i;
const VIDEO_PAGE_RE =
  /(?:bilibili\.com|youtu\.be|youtube\.com|vimeo\.com|iqiyi\.com|youku\.com|v\.qq\.com|mgtv\.com|acfun\.cn)/i;

function cleanUrl(raw: string): string {
  return raw.replace(/[.,;，。；)\]】]+$/u, '');
}

function extractFirstUrl(text: string): string | null {
  const candidates = extractUrlCandidatesFromText(text);
  if (candidates.length) {
    return candidates[0] ?? null;
  }
  const matches = text.match(/https?:\/\/[^\s<>"'`，。；]]+/gi) ?? [];
  for (const match of matches) {
    const url = cleanUrl(match);
    if (url) {
      return url;
    }
  }
  return null;
}

function fileExt(name: string): string {
  const base = name.split(/[/\\]/).pop() ?? name;
  const dot = base.lastIndexOf('.');
  return dot >= 0 ? base.slice(dot).toLowerCase() : '';
}

function summarizeFileNames(files: File[]): string {
  if (files.length === 1) {
    return files[0]!.name;
  }
  return `${files[0]!.name} 等${files.length} 个文件`;
}

function titleFromFileName(name: string): string {
  const base = name.split(/[/\\]/).pop() ?? name;
  const dot = base.lastIndexOf('.');
  return (dot > 0 ? base.slice(0, dot) : base).trim() || '未命名文档';
}

function detectPanShareText(text: string): ClipboardIntent | null {
  const sanitized = sanitizePanEntriesFromText(text);
  if (sanitized.entries.length > 0) {
    const first = sanitized.entries[0]!;
    return {
      kind: 'pan_share',
      plugins: [PLUGIN],
      url: first.url,
      extractCode: first.extractCode,
      entries: sanitized.entries.map((row) => ({
        url: row.url,
        extractCode: row.extractCode,
        platformId: row.platformId,
        platformLabel: row.platformLabel,
      })),
      sanitizeDropped: sanitized.dropped,
      raw: text,
    };
  }

  const url = extractFirstUrl(text);
  if (!url) {
    return null;
  }

  const extractCode = extractPanExtractCode(text);
  if (
    PAN_HOST_PATTERN.test(url) ||
    PAN_HOST_PATTERN.test(text) ||
    PAN_TEXT_RE.test(text)
  ) {
    const normalized = sanitizePanEntriesFromText(text);
    const first = normalized.entries[0];
    return {
      kind: 'pan_share',
      plugins: [PLUGIN],
      url: first?.url ?? url,
      extractCode: first?.extractCode ?? extractCode,
      entries: normalized.entries.length
        ? normalized.entries.map((row) => ({
            url: row.url,
            extractCode: row.extractCode,
            platformId: row.platformId,
            platformLabel: row.platformLabel,
          }))
        : [{ url, extractCode }],
      sanitizeDropped: normalized.dropped,
      raw: text,
    };
  }

  return null;
}

function detectDownloadUrlText(text: string): ClipboardIntent | null {
  const url = extractFirstUrl(text);
  if (!url) {
    return null;
  }
  if (VIDEO_FILE_RE.test(url) || VIDEO_PAGE_RE.test(url)) {
    return null;
  }

  return {
    kind: 'generic_url',
    plugins: [PLUGIN],
    url,
    extractCode: '',
    raw: text,
  };
}

function detectArchiveFiles(files: File[]): ClipboardIntent | null {
  const names = files.map((f) => f.name);
  const exts = names.map(fileExt);
  const primary = files[0]!;
  const allArchive = exts.every(
    (e) => ARCHIVE_EXT_RE.test(e) || /\.(zip|rar|7z)/i.test(e),
  );
  if (!allArchive && !(files.length === 1 && ARCHIVE_EXT_RE.test(primary.name))) {
    return null;
  }
  const summary = summarizeFileNames(files);
  return {
    kind: 'local_archive',
    plugins: [PLUGIN],
    url: summary,
    extractCode: '',
    raw: summary,
    files,
    titleHint: titleFromFileName(primary.name),
  };
}

function detectImageOrOtherFiles(files: File[]): ClipboardIntent | null {
  const names = files.map((f) => f.name);
  const exts = names.map(fileExt);
  const summary = summarizeFileNames(files);
  const primary = files[0]!;

  const allImage = exts.every((e) => IMAGE_EXT_RE.test(e));
  if (allImage || (files.length === 1 && IMAGE_EXT_RE.test(primary.name))) {
    return {
      kind: 'local_image',
      plugins: [PLUGIN],
      url: summary,
      extractCode: '',
      raw: summary,
      files,
      titleHint: titleFromFileName(primary.name),
    };
  }

  return {
    kind: 'local_other',
    plugins: [PLUGIN],
    url: summary,
    extractCode: '',
    raw: summary,
    files,
    titleHint: titleFromFileName(primary.name),
  };
}

registerImportIntentDetectRule({
  pluginId: PLUGIN,
  priority: 100,
  detectText: detectPanShareText,
  detectFiles: detectArchiveFiles,
});

registerImportIntentDetectRule({
  pluginId: PLUGIN,
  priority: 80,
  detectText(text) {
    if (detectPanShareText(text)) {
      return null;
    }
    return detectDownloadUrlText(text);
  },
  detectFiles: detectImageOrOtherFiles,
});

export {};
