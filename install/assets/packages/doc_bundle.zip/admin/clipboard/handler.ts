import type {
  ImportIntentDocumentFormContext,
  ImportIntentStashContext,
} from '#/utils/import-intent-registry';
import {
  intentRemoteEntries,
  type ClipboardIntentKind,
} from '#/utils/clipboard-intent';
import {
  stashClipboardRaw,
  stashPendingAttachSourceFile,
  stashPendingDocumentMeta,
  stashPendingLocalImport,
  stashPendingRemoteEntries,
  takePendingEditorGroupMode,
} from '#/utils/clipboard-pending-flow';

import { resolveDocumentMeta } from '#/utils/import-intent-core-stash';
import { registerImportIntentHandler } from '#/utils/import-intent-registry';

import {
  downloadEditorGroupModeLabel,
  getDownloadEditorGroupModePreference,
  normalizeDownloadEditorGroupMode,
  setDownloadEditorGroupModePreference,
} from '@weapp-doc-bundle/utils/download-editor-group-mode';

import { DOWNLOAD_PLUGIN_ID } from '@weapp-doc-bundle/clipboard/plugin-id';

const KINDS: ClipboardIntentKind[] = [
  'pan_share',
  'local_archive',
  'local_image',
  'local_other',
  'generic_url',
];

registerImportIntentHandler({
  pluginId: DOWNLOAD_PLUGIN_ID,
  supportedKinds: KINDS,
  priority: 100,
  supportsEditorGroupMode: true,
  editorGroupModeApi: {
    choices: ['by_file', 'by_platform'],
    getPreference: getDownloadEditorGroupModePreference,
    setPreference: setDownloadEditorGroupModePreference,
    label: downloadEditorGroupModeLabel,
    normalize: normalizeDownloadEditorGroupMode,
  },
  clipboardLocalFilesLabel: '去发布文档并上传附件',
  clipboardRemoteLabel: '去发布文档并添加链接',
  async applyDocumentFormClipboard(ctx, intent) {
    if (!ctx.hasSurface(DOWNLOAD_PLUGIN_ID)) {
      return false;
    }
    if (intent.files?.length) {
      await ctx.ensureSurfaceVisible(DOWNLOAD_PLUGIN_ID);
      await ctx.prefillLocalFiles(intent.files);
      return true;
    }
    const entries = ctx.collectPendingRemoteEntries();
    const list =
      entries.length > 0
        ? entries
        : intent.url.trim()
          ? [{ url: intent.url.trim(), extractCode: '' }]
          : [];
    if (!list.length) {
      return false;
    }
    await ctx.ensureSurfaceVisible(DOWNLOAD_PLUGIN_ID);
    await ctx.prefillRemoteUrls(list, takePendingEditorGroupMode() ?? undefined);
    return true;
  },
  buildDocumentCreateQuery(ctx) {
    const entries =
      ctx.remoteEntries.length > 0
        ? ctx.remoteEntries
        : ctx.url
          ? [{ url: ctx.url, extractCode: ctx.extractCode }]
          : [];
    const query: Record<string, string> = {};
    if (entries.length === 1) {
      query.pv_remote_url = entries[0]!.url;
      if (entries[0]!.extractCode) {
        query.pv_extract_code = entries[0]!.extractCode;
      }
    } else if (entries.length > 1) {
      query.pv_remote_count = String(entries.length);
    }
    return query;
  },
  async stash(ctx: ImportIntentStashContext) {
    stashClipboardRaw(ctx.intent.raw);
    stashPendingDocumentMeta(resolveDocumentMeta(ctx));
    if (ctx.intent.files?.length) {
      stashPendingLocalImport(
        ctx.intent.files,
        ctx.intent.kind,
        ctx.intent.titleHint ?? '',
        DOWNLOAD_PLUGIN_ID,
      );
      if (ctx.intent.kind === 'local_document') {
        stashPendingAttachSourceFile(ctx.attachSourceFile ?? null);
      }
      return;
    }
    const entries = intentRemoteEntries(ctx.intent);
    if (entries.length) {
      stashPendingRemoteEntries(entries);
    }
  },
});

export {};
