CREATE TABLE IF NOT EXISTS `{{prefix}}weapp_doc_bundle_bundles` (
    `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
    `document_id` int unsigned NOT NULL DEFAULT 0 COMMENT '绑定文档 ID，0 为独立资源包仅后台',
    `title` varchar(200) NOT NULL DEFAULT '' COMMENT '下载标题',
    `access_mode` varchar(20) NOT NULL DEFAULT 'free' COMMENT 'free/login/member/paid/member_paid',
    `price` decimal(10,2) NOT NULL DEFAULT 0.00 COMMENT '付费价格（需支付插件）',
    `points_cost` int unsigned NOT NULL DEFAULT 0 COMMENT '积分下载消耗（access_mode=points）',
    `member_level_id` int unsigned NOT NULL DEFAULT 0 COMMENT '指定会员等级 ID',
    `sort` int NOT NULL DEFAULT 0 COMMENT '排序',
    `status` tinyint NOT NULL DEFAULT 1 COMMENT '0禁用 1启用',
    `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    PRIMARY KEY (`id`),
    KEY `idx_dl_bundle_document` (`document_id`),
    KEY `idx_dl_bundle_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='下载插件资源包';

CREATE TABLE IF NOT EXISTS `{{prefix}}weapp_doc_bundle_items` (
    `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
    `bundle_id` int unsigned NOT NULL DEFAULT 0 COMMENT '资源包 ID',
    `source_type` varchar(10) NOT NULL DEFAULT 'local' COMMENT 'local/remote',
    `file_path` varchar(500) NOT NULL DEFAULT '' COMMENT '本地文件路径',
    `remote_url` varchar(1000) NOT NULL DEFAULT '' COMMENT '远程下载地址',
    `extract_code` varchar(64) NOT NULL DEFAULT '' COMMENT '远程提取码',
    `label` varchar(120) NOT NULL DEFAULT '立即下载' COMMENT '按钮显示名',
    `file_size` bigint NOT NULL DEFAULT 0 COMMENT '字节',
    `sort` int NOT NULL DEFAULT 0 COMMENT '排序',
    `status` tinyint NOT NULL DEFAULT 1 COMMENT '0禁用 1启用',
    `download_count` int unsigned NOT NULL DEFAULT 0 COMMENT '下载次数',
    `link_check_status` varchar(16) NOT NULL DEFAULT 'unknown' COMMENT 'unknown/ok/warn/fail',
    `link_check_http_code` int NOT NULL DEFAULT 0 COMMENT '最近 HTTP 状态码',
    `link_check_message` varchar(255) NOT NULL DEFAULT '' COMMENT '巡检说明',
    `link_check_at` datetime DEFAULT NULL COMMENT '最近巡检时间',
    `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    PRIMARY KEY (`id`),
    KEY `idx_dl_item_bundle` (`bundle_id`),
    KEY `idx_dl_item_status` (`status`),
    KEY `idx_dl_item_link_check` (`source_type`, `link_check_status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='下载插件资源项';

CREATE TABLE IF NOT EXISTS `{{prefix}}weapp_doc_bundle_purchases` (
    `id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
    `user_id` int unsigned NOT NULL DEFAULT 0 COMMENT '会员用户 ID',
    `bundle_id` int unsigned NOT NULL DEFAULT 0 COMMENT '资源包 ID',
    `amount` decimal(10,2) NOT NULL DEFAULT 0.00 COMMENT '实付金额',
    `status` tinyint NOT NULL DEFAULT 1 COMMENT '1有效 0作废',
    `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '购买时间',
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_dl_purchase_user_bundle` (`user_id`, `bundle_id`),
    KEY `idx_dl_purchase_bundle` (`bundle_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='下载插件购买记录';

CREATE TABLE IF NOT EXISTS `{{prefix}}weapp_doc_bundle_point_unlocks` (
    `id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
    `user_id` int unsigned NOT NULL DEFAULT 0 COMMENT '会员用户 ID',
    `bundle_id` int unsigned NOT NULL DEFAULT 0 COMMENT '资源包 ID',
    `points_cost` int unsigned NOT NULL DEFAULT 0 COMMENT '实际扣除积分',
    `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '解锁时间',
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_dl_point_unlock` (`user_id`, `bundle_id`),
    KEY `idx_dl_point_unlock_bundle` (`bundle_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='下载插件积分解锁记录';

CREATE TABLE IF NOT EXISTS `{{prefix}}weapp_doc_bundle_logs` (
    `id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
    `item_id` int unsigned NOT NULL DEFAULT 0 COMMENT '下载项ID',
    `bundle_id` int unsigned NOT NULL DEFAULT 0 COMMENT '资源包ID',
    `document_id` int unsigned NOT NULL DEFAULT 0 COMMENT '文档ID',
    `user_id` int unsigned NOT NULL DEFAULT 0 COMMENT '前台用户ID，0为游客',
    `ip` varchar(45) NOT NULL DEFAULT '' COMMENT '客户端IP',
    `user_agent` varchar(500) NOT NULL DEFAULT '' COMMENT 'UA摘要',
    `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '下载时间',
    PRIMARY KEY (`id`),
    KEY `idx_dl_log_item` (`item_id`),
    KEY `idx_dl_log_user` (`user_id`),
    KEY `idx_dl_log_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='下载插件审计日志';

CREATE TABLE IF NOT EXISTS `{{prefix}}weapp_doc_bundle_tokens` (
    `id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
    `item_id` int unsigned NOT NULL DEFAULT 0 COMMENT '下载项ID',
    `token` char(64) NOT NULL DEFAULT '' COMMENT '一次性令牌',
    `expires_at` datetime NOT NULL COMMENT '过期时间',
    `used_at` datetime DEFAULT NULL COMMENT '使用时间',
    `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_dl_token` (`token`),
    KEY `idx_dl_token_item` (`item_id`),
    KEY `idx_dl_token_expires` (`expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='下载插件短时令牌';