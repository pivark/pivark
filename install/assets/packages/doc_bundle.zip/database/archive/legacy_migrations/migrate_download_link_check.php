<?php
/**
 * 元舟 PivArk — 企业全域原子化数字资产中枢
 * (c) 2024-2026 pivark.com. All rights reserved.
 * Author: Angelo
 * 未经允许，不可用于商业用途。
 */
/**
 * 下载项远程链接巡检字段
 * 用法: php devtools/daily/database/migrate_doc_bundle_link_check.php
 */
declare(strict_types=1);

require_once dirname(__DIR__, 4) . '/app/database/migrations/_migration_bootstrap.php';

$name = 'migrate_doc_bundle_link_check';

function migration_down(PDO $pdo, string $pfx, string $db): void {
    // no-op structural rollback
}

migration_entry($name, static function (PDO $pdo, string $pfx, string $db): void {
    $items    = $pfx . 'weapp_doc_bundle_items';
    $colExists = migration_column_exists($db);
    $cols      = [
        'link_check_status'    => "ADD COLUMN `link_check_status` varchar(16) NOT NULL DEFAULT 'unknown' COMMENT 'unknown/ok/warn/fail' AFTER `download_count`",
        'link_check_http_code' => "ADD COLUMN `link_check_http_code` int NOT NULL DEFAULT 0 COMMENT '最近 HTTP 状态码' AFTER `link_check_status`",
        'link_check_message'   => "ADD COLUMN `link_check_message` varchar(255) NOT NULL DEFAULT '' COMMENT '巡检说明' AFTER `link_check_http_code`",
        'link_check_at'        => "ADD COLUMN `link_check_at` datetime DEFAULT NULL COMMENT '最近巡检时间' AFTER `link_check_message`",
    ];
    
    foreach ($cols as $col => $sqlPart) {
        if (!$colExists($pdo, $pfx, 'weapp_doc_bundle_items', $col)) {
            $pdo->exec("ALTER TABLE `{$items}` {$sqlPart}");
            echo "  + column {$col}\n";
        }
    }
    
    $idxStmt = $pdo->prepare(
        'SELECT COUNT(*) FROM information_schema.STATISTICS
         WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND INDEX_NAME = ?'
    );
    $idxStmt->execute([$items, 'idx_dl_item_link_check']);
    if ((int) $idxStmt->fetchColumn() === 0) {
        $pdo->exec("ALTER TABLE `{$items}` ADD KEY `idx_dl_item_link_check` (`source_type`, `link_check_status`)");
        echo "  + index idx_dl_item_link_check\n";
    }
});
