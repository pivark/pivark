<?php
/**
 * 元舟 PivArk — 企业全域原子化数字资产中枢
 * (c) 2024-2026 pivark.com. All rights reserved.
 * Author: Angelo
 * 未经允许，不可用于商业用途。
 */
/**
 * 下载插件：bundle + 多资源（本地/远程/提取码/付费预留）
 * 用法: php devtools/daily/database/migrate_doc_bundle_list.php
 */
declare(strict_types=1);

require_once dirname(__DIR__, 4) . '/app/database/migrations/_migration_bootstrap.php';

$name = 'migrate_doc_bundle_list';

function migration_down(PDO $pdo, string $pfx, string $db): void {
    // no-op structural rollback
}

migration_entry($name, static function (PDO $pdo, string $pfx, string $db): void {
    $tableExists = static function (PDO $pdo, string $pfx, string $table): bool {
        $stmt = $pdo->prepare(
            'SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = ?'
        );
        $stmt->execute([$pfx . $table]);
    
        return (int) $stmt->fetchColumn() > 0;
    };
    
    $columnExists = migration_column_exists($db);
    
    $bundles = "{$pfx}weapp_doc_bundle_bundles";
    $items   = "{$pfx}weapp_doc_bundle_items";
    $legacy  = "{$pfx}weapp_doc_bundle_files";
    
    $pdo->exec("CREATE TABLE IF NOT EXISTS `{$bundles}` (
            `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
            `document_id` int unsigned NOT NULL DEFAULT 0 COMMENT '关联文档 ID',
            `title` varchar(200) NOT NULL DEFAULT '' COMMENT '下载标题',
            `access_mode` varchar(20) NOT NULL DEFAULT 'free' COMMENT 'free/login/member/paid/member_paid',
            `price` decimal(10,2) NOT NULL DEFAULT 0.00 COMMENT '购买价格（预留支付插件）',
            `member_level_id` int unsigned NOT NULL DEFAULT 0 COMMENT '指定会员等级 ID',
            `sort` int NOT NULL DEFAULT 0 COMMENT '排序',
            `status` tinyint NOT NULL DEFAULT 1 COMMENT '0禁用 1启用',
            `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`),
            KEY `idx_dl_bundle_document` (`document_id`),
            KEY `idx_dl_bundle_status` (`status`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='下载插件资源包'");
    
        $pdo->exec("CREATE TABLE IF NOT EXISTS `{$items}` (
            `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
            `bundle_id` int unsigned NOT NULL DEFAULT 0 COMMENT '资源包 ID',
            `source_type` varchar(10) NOT NULL DEFAULT 'local' COMMENT 'local/remote',
            `file_path` varchar(500) NOT NULL DEFAULT '' COMMENT '本地文件路径',
            `remote_url` varchar(1000) NOT NULL DEFAULT '' COMMENT '远程下载地址',
            `extract_code` varchar(64) NOT NULL DEFAULT '' COMMENT '远程提取码',
            `label` varchar(120) NOT NULL DEFAULT '立即下载' COMMENT '链接显示名',
            `file_size` bigint NOT NULL DEFAULT 0 COMMENT '字节',
            `sort` int NOT NULL DEFAULT 0 COMMENT '排序',
            `status` tinyint NOT NULL DEFAULT 1 COMMENT '0禁用 1启用',
            `download_count` int unsigned NOT NULL DEFAULT 0 COMMENT '下载次数',
            `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`),
            KEY `idx_dl_item_bundle` (`bundle_id`),
            KEY `idx_dl_item_status` (`status`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='下载插件资源项'");
    echo "  bundles + items tables OK\n";
    
    if ($tableExists($pdo, $pfx, 'weapp_doc_bundle_files')) {
        $hasBundles = (int) $pdo->query("SELECT COUNT(*) FROM `{$bundles}`")->fetchColumn();
        if ($hasBundles === 0) {
            $docCol = $columnExists($pdo, $pfx, 'weapp_doc_bundle_files', 'document_id') ? 'document_id' : 'article_id';
            $rows = $pdo->query("SELECT * FROM `{$legacy}` ORDER BY `id` ASC")->fetchAll(PDO::FETCH_ASSOC);
            foreach ($rows as $row) {
                $now = migration_now();
                $access = (int) ($row['require_login'] ?? 0) === 1 ? 'login' : 'free';
                $pdo->prepare("INSERT INTO `{$bundles}`
                    (`document_id`,`title`,`access_mode`,`price`,`member_level_id`,`sort`,`status`,`created_at`,`updated_at`)
                    VALUES (?,?,?,?,?,?,?,?,?)")
                    ->execute([
                        (int) ($row[$docCol] ?? 0),
                        (string) ($row['title'] ?? ''),
                        $access,
                        0,
                        0,
                        (int) ($row['sort'] ?? 0),
                        (int) ($row['status'] ?? 1) ? 1 : 0,
                        (string) ($row['created_at'] ?? $now),
                        (string) ($row['updated_at'] ?? $now),
                    ]);
                $bundleId = (int) $pdo->lastInsertId();
                $pdo->prepare("INSERT INTO `{$items}`
                    (`bundle_id`,`source_type`,`file_path`,`remote_url`,`extract_code`,`label`,`file_size`,`sort`,`status`,`download_count`,`created_at`,`updated_at`)
                    VALUES (?,?,?,?,?,?,?,?,?,?,?,?)")
                    ->execute([
                        $bundleId,
                        'local',
                        (string) ($row['file_path'] ?? ''),
                        '',
                        '',
                        '立即下载',
                        (int) ($row['file_size'] ?? 0),
                        0,
                        (int) ($row['status'] ?? 1) ? 1 : 0,
                        (int) ($row['download_count'] ?? 0),
                        (string) ($row['created_at'] ?? $now),
                        (string) ($row['updated_at'] ?? $now),
                    ]);
            }
            echo '  migrated legacy weapp_doc_bundle_files → bundles/items: ' . count($rows) . "\n";
        }
    }
});
