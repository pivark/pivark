<?php
/**
 * 元舟 PivArk — 企业全域原子化数字资产中枢
 * (c) 2024-2026 pivark.com. All rights reserved.
 * Author: Angelo
 * 未经允许，不可用于商业用途。
 */
/**
 * 下载插件增强：审计日志、下载令牌、install 注释修复登记
 * 用法: php devtools/daily/database/migrate_doc_bundle_enhancements.php
 */
declare(strict_types=1);

require_once dirname(__DIR__, 4) . '/app/database/migrations/_migration_bootstrap.php';

$name = 'migrate_doc_bundle_enhancements';

function migration_down(PDO $pdo, string $pfx, string $db): void {
    // no-op structural rollback
}

migration_entry($name, static function (PDO $pdo, string $pfx, string $db): void {
    $create = static function (PDO $pdo, string $db, string $pfx, string $table, string $sql): void {
        $full = $pfx . $table;
        $stmt = $pdo->prepare('SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ?');
        $stmt->execute([$db, $full]);
        if ((int) $stmt->fetchColumn() === 0) {
            $pdo->exec(str_replace('{{prefix}}', $pfx, $sql));
            echo "  + table {$table}\n";
        }
    };
    
    $create($pdo, $db, $pfx, 'weapp_doc_bundle_logs', "CREATE TABLE `{{prefix}}weapp_doc_bundle_logs` (
        `id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
        `item_id` int unsigned NOT NULL DEFAULT 0 COMMENT '下载项ID',
        `bundle_id` int unsigned NOT NULL DEFAULT 0 COMMENT '资源包ID',
        `document_id` int unsigned NOT NULL DEFAULT 0 COMMENT '文档ID',
        `user_id` int unsigned NOT NULL DEFAULT 0 COMMENT '前台用户ID，0为游客',
        `ip` varchar(45) NOT NULL DEFAULT '' COMMENT '客户端IP',
        `user_agent` varchar(500) NOT NULL DEFAULT '' COMMENT 'UAժҪ',
        `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '下载时间',
        PRIMARY KEY (`id`),
        KEY `idx_dl_log_item` (`item_id`),
        KEY `idx_dl_log_user` (`user_id`),
        KEY `idx_dl_log_created` (`created_at`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='下载插件审计日志'");
    
    $create($pdo, $db, $pfx, 'weapp_doc_bundle_tokens', "CREATE TABLE `{{prefix}}weapp_doc_bundle_tokens` (
        `id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
        `item_id` int unsigned NOT NULL DEFAULT 0 COMMENT '下载项ID',
        `token` char(64) NOT NULL DEFAULT '' COMMENT '一次性令牌',
        `expires_at` datetime NOT NULL COMMENT '过期时间',
        `used_at` datetime DEFAULT NULL COMMENT '使用时间',
        `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
        PRIMARY KEY (`id`),
        UNIQUE KEY `uk_dl_token` (`token`),
        KEY `idx_dl_token_item` (`item_id`),
        KEY `idx_dl_token_expires` (`expires_at`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='下载插件短时令牌'");
});
