<?php
/**
 * 元舟 PivArk — 企业全域原子化数字资产中枢
 * (c) 2024-2026 pivark.com. All rights reserved.
 * Author: Angelo
 * 未经允许，不可用于商业用途。
 */
/**
 * 下载插件：资源包积分下载（points_cost + 解锁记录表）
 * 用法: php devtools/daily/database/migrate_doc_bundle_points.php
 */
declare(strict_types=1);

require_once dirname(__DIR__, 4) . '/app/database/migrations/_migration_bootstrap.php';

$name = 'migrate_doc_bundle_points';

function migration_down(PDO $pdo, string $pfx, string $db): void {
    // no-op structural rollback
}

migration_entry($name, static function (PDO $pdo, string $pfx, string $db): void {
    $columnExists = migration_column_exists($db);
    $bundlesTable = 'weapp_doc_bundle_bundles';
    $fullBundles  = $pfx . $bundlesTable;
    
    if (!$columnExists($pdo, $pfx, $bundlesTable, 'points_cost')) {
        $pdo->exec("ALTER TABLE `{$fullBundles}`
            ADD COLUMN `points_cost` int unsigned NOT NULL DEFAULT 0
            COMMENT '积分下载消耗（access_mode=points）' AFTER `price`");
        echo "  + column weapp_doc_bundle_bundles.points_cost\n";
    }
    
    $unlocks = "{$pfx}weapp_doc_bundle_point_unlocks";
    $stmt    = $pdo->prepare(
        'SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ?'
    );
    $stmt->execute([$db, $unlocks]);
    if ((int) $stmt->fetchColumn() === 0) {
        $pdo->exec("CREATE TABLE `{$unlocks}` (
            `id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
            `user_id` int unsigned NOT NULL DEFAULT 0 COMMENT '会员用户 ID',
            `bundle_id` int unsigned NOT NULL DEFAULT 0 COMMENT '资源包 ID',
            `points_cost` int unsigned NOT NULL DEFAULT 0 COMMENT '实际扣除积分',
            `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '解锁时间',
            PRIMARY KEY (`id`),
            UNIQUE KEY `uk_dl_point_unlock` (`user_id`, `bundle_id`),
            KEY `idx_dl_point_unlock_bundle` (`bundle_id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='下载插件积分解锁记录'");
        echo "  + table weapp_doc_bundle_point_unlocks\n";
    }
});
