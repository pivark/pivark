<?php
/**
 * 元舟 PivArk — 企业全域原子化数字资产中枢
 * (c) 2024-2026 pivark.com. All rights reserved.
 * Author: Angelo
 * 未经允许，不可用于商业用途。
 */
/**
 * 下载插件购买记录表
 * 用法: php devtools/daily/database/migrate_doc_bundle_purchases.php
 */
declare(strict_types=1);

require_once dirname(__DIR__, 4) . '/app/database/migrations/_migration_bootstrap.php';

$name = 'migrate_doc_bundle_purchases';

function migration_down(PDO $pdo, string $pfx, string $db): void {
    // no-op structural rollback
}

migration_entry($name, static function (PDO $pdo, string $pfx, string $db): void {
    $full = $pfx . 'weapp_doc_bundle_purchases';
    $stmt = $pdo->prepare('SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ?');
    $stmt->execute([$db, $full]);
    if ((int) $stmt->fetchColumn() === 0) {
        $pdo->exec(str_replace('{{prefix}}', $pfx, "CREATE TABLE `{{prefix}}weapp_doc_bundle_purchases` (
            `id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
            `user_id` int unsigned NOT NULL DEFAULT 0 COMMENT '会员用户 ID',
            `bundle_id` int unsigned NOT NULL DEFAULT 0 COMMENT '资源包 ID',
            `amount` decimal(10,2) NOT NULL DEFAULT 0.00 COMMENT '实付金额',
            `status` tinyint NOT NULL DEFAULT 1 COMMENT '1有效 0作废',
            `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '购买时间',
            PRIMARY KEY (`id`),
            UNIQUE KEY `uk_dl_purchase_user_bundle` (`user_id`, `bundle_id`),
            KEY `idx_dl_purchase_bundle` (`bundle_id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='下载插件购买记录'"));
        echo "  + table weapp_doc_bundle_purchases\n";
    }
});
