-- download 插件卸载（purge=data/full）
DROP TABLE IF EXISTS `{{prefix}}weapp_doc_bundle_point_unlocks`;
DROP TABLE IF EXISTS `{{prefix}}weapp_doc_bundle_tokens`;
DROP TABLE IF EXISTS `{{prefix}}weapp_doc_bundle_logs`;
DROP TABLE IF EXISTS `{{prefix}}weapp_doc_bundle_purchases`;
DROP TABLE IF EXISTS `{{prefix}}weapp_doc_bundle_items`;
DROP TABLE IF EXISTS `{{prefix}}weapp_doc_bundle_bundles`;
