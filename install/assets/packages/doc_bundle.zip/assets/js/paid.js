/** PivArk weapp — download paid
 * @namespace PV.modules.downloadPaid
 */
(function (PV, pvUrl) {
  'use strict';
  PV = PV || {};
  PV.modules = PV.modules || {};

    var API_PREVIEW = pvUrl('apiDownloadPaidPreview', '/api/v1/plugins/doc_bundle/paid-preview/');
    var API_CREATE = pvUrl('apiDownloadPaidCreate', '/api/v1/plugins/doc_bundle/paid-create/');

    function qs(sel, root) {
        return (root || document).querySelector(sel);
    }


    function restOk(body) {
        return body && typeof body === 'object' && !body.error && Object.prototype.hasOwnProperty.call(body, 'data');
    }

    function restData(body) {
        if (!body || typeof body !== 'object') {
            return {};
        }
        if (restOk(body)) {
            var d = body.data;
            return d && typeof d === 'object' && !Array.isArray(d) ? d : {};
        }
        return body;
    }

    function restMsg(body, fallback) {
        if (body && body.error && body.error.message) {
            return String(body.error.message);
        }
        if (body && body.meta && body.meta.message) {
            return String(body.meta.message);
        }
        return fallback || '';
    }

    function restLoginUrl(body) {
        var d = restData(body);
        if (d.login_url) {
            return d.login_url;
        }
        if (body && body.login_url) {
            return body.login_url;
        }
        return '';
    }

    function restAlreadyUnlocked(body) {
        var d = restData(body);
        return !!(d.already_unlocked || restMsg(body, '') === 'already_unlocked');
    }

    function payPayload(body) {
        var d = restData(body);
        if (body && body.redirect && !d.redirect) {
            d.redirect = body.redirect;
        }
        return d;
    }

    function fetchJson(url, options) {
        return fetch(url, Object.assign({
            credentials: 'same-origin',
            headers: { Accept: 'application/json', 'X-Requested-With': 'XMLHttpRequest' },
        }, options || {})).then(function (res) {
            return res.json().then(function (body) {
                return { ok: res.ok, status: res.status, body: body };
            });
        });
    }

    function ensureModal() {
        var el = document.getElementById('pvPaidUnlockModal');
        if (el) {
            return el;
        }
        el = document.createElement('div');
        el.id = 'pvPaidUnlockModal';
        el.className = 'modal fade';
        el.setAttribute('tabindex', '-1');
        el.setAttribute('aria-hidden', 'true');
        el.innerHTML =
            '<div class="modal-dialog modal-dialog-centered">' +
            '<div class="modal-content">' +
            '<div class="modal-header">' +
            '<h5 class="modal-title">付费下载确认</h5>' +
            '<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="关闭"></button>' +
            '</div>' +
            '<div class="modal-body pv-paid-unlock-body"></div>' +
            '<div class="modal-footer flex-wrap gap-2">' +
            '<button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">取消</button>' +
            '<button type="button" class="btn btn-outline-primary pv-paid-pay-alipay">支付宝支付</button>' +
            '<button type="button" class="btn btn-outline-success pv-paid-pay-wechat">微信支付</button>' +
            '</div></div></div>';
        document.body.appendChild(el);
        return el;
    }

    function channelVisible(channels, ch) {
        if (!Array.isArray(channels)) {
            return false;
        }
        return channels.indexOf(ch) >= 0;
    }

    function syncPayButtons(modalEl, channels) {
        var btnAli = qs('.pv-paid-pay-alipay', modalEl);
        var btnWx = qs('.pv-paid-pay-wechat', modalEl);
        if (btnAli) {
            btnAli.style.display = channelVisible(channels, 'alipay') ? '' : 'none';
        }
        if (btnWx) {
            btnWx.style.display = channelVisible(channels, 'wechat') ? '' : 'none';
        }
    }

    function paidApiMessage(msg) {
        var m = String(msg || '').trim();
        var map = {
            not_paid_bundle: '该资源未配置付费下载，请联系站点管理员',
            payment_disabled: '支付功能未启用，暂无法购买',
            price_invalid: '资源价格无效，无法下单',
            already_unlocked: '您已购买过该资源，可直接下载',
            login_required: '请先登录会员账号',
        };
        if (map[m]) {
            return map[m];
        }
        if (m.indexOf('not_paid') >= 0) {
            return '该资源未开启付费下载';
        }
        return m || '操作失败';
    }

    function toast(msg, type) {
        var box = document.getElementById('pvPaidToast');
        if (!box) {
            box = document.createElement('div');
            box.id = 'pvPaidToast';
            box.className = 'pv-points-toast alert alert-' + (type || 'success');
            box.setAttribute('role', 'alert');
            document.body.appendChild(box);
        }
        box.className = 'pv-points-toast alert alert-' + (type || 'success');
        box.textContent = msg;
        box.style.display = 'block';
        clearTimeout(box._timer);
        box._timer = setTimeout(function () {
            box.style.display = 'none';
        }, 6000);
    }

    function escapeHtml(s) {
        return String(s)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;');
    }

    function markCardPurchased(card) {
        if (window.pvDownloadUi && window.pvDownloadUi.celebrateUnlock) {
            window.pvDownloadUi.celebrateUnlock(card);
        }
        card.setAttribute('data-paid-unlocked', '1');
        var badge = qs('.pv-doc-download-card__access', card);
        if (badge) {
            badge.textContent = '已购买';
        }
        var dl = qs('.pv-doc-download-card__btn--dl', card);
        var dlUrl = card.getAttribute('data-download-url') || '';
        if (dl) {
            dl.textContent = '下载';
            dl.classList.remove('pv-dl-paid-purchase');
            dl.removeAttribute('data-dl-action');
            if (dlUrl) {
                dl.setAttribute('href', dlUrl);
            }
        }
        var remote = card.getAttribute('data-remote-url') || '';
        var openBtn = qs('.pv-doc-download-card__btn--open', card);
        if (openBtn && remote) {
            openBtn.setAttribute('href', remote);
            card.setAttribute('data-show-open', '1');
        }
        card.setAttribute('data-show-dl', dlUrl ? '1' : '0');
    }

    function showWechatPayQr(codeUrl, orderNo) {
        var el = document.getElementById('pvWechatPayQrModal');
        if (!el) {
            el = document.createElement('div');
            el.id = 'pvWechatPayQrModal';
            el.className = 'modal fade';
            el.setAttribute('tabindex', '-1');
            el.setAttribute('aria-hidden', 'true');
            el.innerHTML =
                '<div class="modal-dialog modal-dialog-centered modal-sm">' +
                '<div class="modal-content">' +
                '<div class="modal-header">' +
                '<h5 class="modal-title">微信扫码支付</h5>' +
                '<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="关闭"></button>' +
                '</div>' +
                '<div class="modal-body text-center">' +
                '<img class="pv-wechat-pay-qr mb-3" alt="微信支付二维码" width="200" height="200" />' +
                '<p class="text-muted small mb-0 pv-wechat-pay-order"></p>' +
                '<p class="text-muted small mt-2 mb-0">支付完成后请刷新页面或重新点击下载。</p>' +
                '</div></div></div>';
            document.body.appendChild(el);
        }
        var img = qs('.pv-wechat-pay-qr', el);
        var orderEl = qs('.pv-wechat-pay-order', el);
        if (img) {
            img.src =
                'https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=' +
                encodeURIComponent(codeUrl);
        }
        if (orderEl) {
            orderEl.textContent = orderNo ? '订单号：' + orderNo : '';
        }
        bootstrap.Modal.getOrCreateInstance(el).show();
    }

    function handlePayResult(card, body) {
        if (!body || body.error) {
            if (body && body.error) {
                toast(restMsg(body, '下单失败'), 'danger');
            }
            return;
        }
        body = payPayload(body);
        if (body.type === 'demo' || body.demo) {
            if (body.redirect) {
                window.location.href = body.redirect;
                return;
            }
            markCardPurchased(card);
            toast('支付成功，现在可以下载了。');
            return;
        }
        if (body.redirect) {
            window.location.href = body.redirect;
            return;
        }
        if (body.form_html) {
            var wrap = document.createElement('div');
            wrap.innerHTML = body.form_html;
            document.body.appendChild(wrap);
            var form = wrap.querySelector('form');
            if (form) {
                form.submit();
            }
            return;
        }
        if (body.code_url) {
            showWechatPayQr(body.code_url, body.order_no || '');
            return;
        }
        markCardPurchased(card);
        toast(body.message || '订单已创建');
    }

    function openPurchaseModal(card, bundleId, preview) {
        var modalEl = ensureModal();
        var body = qs('.pv-paid-unlock-body', modalEl);
        var btnAli = qs('.pv-paid-pay-alipay', modalEl);
        var btnWx = qs('.pv-paid-pay-wechat', modalEl);
        var d = (preview && preview.data) || {};
        var title = d.bundle_title || '该资源';
        var priceText = d.price_text || d.price || '0.00';

        if (d.unlocked) {
            markCardPurchased(card);
            toast('您已购买过「' + title + '」，可直接下载。');
            return;
        }
        if (!d.logged_in) {
            if (d.login_url) {
                window.location.href = d.login_url;
            }
            return;
        }

        var channels = Array.isArray(d.channels) ? d.channels : [];
        body.innerHTML =
            '<p>资源：<strong>' + escapeHtml(title) + '</strong></p>' +
            '<p class="mb-2">需支付 <strong class="text-primary">¥' + escapeHtml(priceText) + '</strong> 获取下载权限。</p>' +
            (d.demo_mode
                ? '<p class="text-muted small mb-0">当前为演示支付模式，确认后将自动完成入账。</p>'
                : channels.length
                    ? '<p class="text-muted small mb-0">请选择已开通的支付通道完成付款。</p>'
                    : '<p class="text-warning small mb-0">未配置在线支付通道，请联系管理员。</p>');

        syncPayButtons(modalEl, channels);

        var modal = bootstrap.Modal.getOrCreateInstance(modalEl);

        function pay(channel) {
            btnAli.disabled = true;
            btnWx.disabled = true;
            var fd = new FormData();
            fd.append('channel', channel);
            if (window.pvDownloadSecurity) {
                window.pvDownloadSecurity.appendWriteFields(fd, 'paid-create');
            }
            fetchJson(API_CREATE + bundleId, {
                method: 'POST',
                body: fd,
                headers: window.pvDownloadSecurity ? window.pvDownloadSecurity.postHeaders() : {},
            })
                .then(function (res) {
                    var b = res.body || {};
                    if (restOk(b) || restAlreadyUnlocked(b)) {
                        modal.hide();
                        if (restData(b).already_unlocked) {
                            markCardPurchased(card);
                            toast('您已购买过该资源，可直接下载。');
                            return;
                        }
                        handlePayResult(card, payPayload(b));
                        return;
                    }
                    if (restLoginUrl(b)) {
                        window.location.href = restLoginUrl(b);
                        return;
                    }
                    toast(paidApiMessage(restMsg(b, '')) || '下单失败', 'danger');
                })
                .catch(function () {
                    toast('网络错误，请稍后重试', 'danger');
                })
                .finally(function () {
                    btnAli.disabled = false;
                    btnWx.disabled = false;
                });
        }

        btnAli.onclick = function () {
            pay('alipay');
        };
        btnWx.onclick = function () {
            pay('wechat');
        };
        modal.show();
    }

    function onDlClick(ev) {
        var btn = ev.currentTarget;
        var card = btn.closest('.pv-doc-download-card');
        if (!card) {
            return;
        }
        var action = btn.getAttribute('data-dl-action') || card.getAttribute('data-dl-action');
        if (action !== 'paid_unlock') {
            return;
        }
        ev.preventDefault();
        var bundleId = parseInt(card.getAttribute('data-bundle-id') || '0', 10);
        if (bundleId < 1) {
            return;
        }
        if (card.getAttribute('data-paid-unlocked') === '1') {
            return;
        }
        fetchJson(API_PREVIEW + bundleId)
            .then(function (res) {
                var b = res.body || {};
                if (restOk(b)) {
                    openPurchaseModal(card, bundleId, b);
                } else if (restLoginUrl(b)) {
                    window.location.href = restLoginUrl(b);
                } else {
                    toast(paidApiMessage(restMsg(b, '')) || '无法获取付费信息', 'danger');
                }
            })
            .catch(function () {
                toast('网络错误，请稍后重试', 'danger');
            });
    }

    function init() {
        var section = document.querySelector('.pv-doc-downloads');
        if (!section) {
            return;
        }
        section.querySelectorAll('.pv-doc-download-card').forEach(function (card) {
            if (card.getAttribute('data-paid-unlocked') === '1') {
                markCardPurchased(card);
            }
            var dl = qs('.pv-doc-download-card__btn--dl', card);
            if (!dl) {
                return;
            }
            if (
                card.getAttribute('data-access-mode') === 'paid' ||
                card.getAttribute('data-access-mode') === 'member_paid' ||
                dl.getAttribute('data-dl-action') === 'paid_unlock' ||
                (dl.getAttribute('href') || '').indexOf('#pv-paid-unlock') === 0
            ) {
                dl.classList.add('pv-dl-paid-purchase');
                if (!dl.getAttribute('data-dl-action')) {
                    dl.setAttribute('data-dl-action', 'paid_unlock');
                }
                dl.addEventListener('click', onDlClick);
            }
        });
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

  PV.modules.downloadPaid = PV.modules.downloadPaid || {};
})(window.PV = window.PV || {}, window.pvUrl);

