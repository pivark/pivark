/** PivArk weapp — download points
 * @namespace PV.modules.downloadPoints
 */
(function (PV, pvUrl) {
  'use strict';
  PV = PV || {};
  PV.modules = PV.modules || {};

    var API_PREVIEW = pvUrl('apiDownloadPointsPreview', '/api/v1/plugins/doc_bundle/points-preview/');
    var API_UNLOCK = pvUrl('apiDownloadPointsUnlock', '/api/v1/plugins/doc_bundle/points-unlock/');

    function qs(sel, root) {
        return (root || document).querySelector(sel);
    }


    function restOk(body) {
        return body && typeof body === 'object' && !body.error && Object.prototype.hasOwnProperty.call(body, 'data');
    }

    function restData(body) {
        if (!body || typeof body !== 'object') {
            return {};
        }
        if (restOk(body)) {
            var d = body.data;
            return d && typeof d === 'object' && !Array.isArray(d) ? d : {};
        }
        return body;
    }

    function restMsg(body, fallback) {
        if (body && body.error && body.error.message) {
            return String(body.error.message);
        }
        if (body && body.meta && body.meta.message) {
            return String(body.meta.message);
        }
        return fallback || '';
    }

    function restLoginUrl(body) {
        var d = restData(body);
        if (d.login_url) {
            return d.login_url;
        }
        if (body && body.login_url) {
            return body.login_url;
        }
        return '';
    }

    function restAlreadyUnlocked(body) {
        var d = restData(body);
        return !!(d.already_unlocked || restMsg(body, '') === 'already_unlocked');
    }

    function payPayload(body) {
        var d = restData(body);
        if (body && body.redirect && !d.redirect) {
            d.redirect = body.redirect;
        }
        return d;
    }

    function fetchJson(url, options) {
        return fetch(url, Object.assign({
            credentials: 'same-origin',
            headers: { Accept: 'application/json', 'X-Requested-With': 'XMLHttpRequest' },
        }, options || {})).then(function (res) {
            return res.json().then(function (body) {
                return { ok: res.ok, status: res.status, body: body };
            });
        });
    }

    function ensureModal() {
        var el = document.getElementById('pvPointsUnlockModal');
        if (el) {
            return el;
        }
        el = document.createElement('div');
        el.id = 'pvPointsUnlockModal';
        el.className = 'modal fade';
        el.setAttribute('tabindex', '-1');
        el.setAttribute('aria-hidden', 'true');
        el.innerHTML =
            '<div class="modal-dialog modal-dialog-centered">' +
            '<div class="modal-content">' +
            '<div class="modal-header">' +
            '<h5 class="modal-title">积分购买确认</h5>' +
            '<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="关闭"></button>' +
            '</div>' +
            '<div class="modal-body pv-points-unlock-body"></div>' +
            '<div class="modal-footer">' +
            '<button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">取消</button>' +
            '<button type="button" class="btn btn-primary pv-points-unlock-confirm">确认购买</button>' +
            '</div></div></div>';
        document.body.appendChild(el);
        return el;
    }

    function toast(msg, type) {
        var box = document.getElementById('pvPointsToast');
        if (!box) {
            box = document.createElement('div');
            box.id = 'pvPointsToast';
            box.className = 'pv-points-toast alert alert-' + (type || 'success');
            box.setAttribute('role', 'alert');
            document.body.appendChild(box);
        }
        box.className = 'pv-points-toast alert alert-' + (type || 'success');
        box.textContent = msg;
        box.style.display = 'block';
        clearTimeout(box._timer);
        box._timer = setTimeout(function () {
            box.style.display = 'none';
        }, 5000);
    }

    function markCardPurchased(card) {
        if (window.pvDownloadUi && window.pvDownloadUi.celebrateUnlock) {
            window.pvDownloadUi.celebrateUnlock(card);
        }
        card.setAttribute('data-points-unlocked', '1');
        var badge = qs('.pv-doc-download-card__access', card);
        if (badge) {
            badge.textContent = '已购买';
            badge.setAttribute('data-mode', 'points');
        }
        var dl = qs('.pv-doc-download-card__btn--dl', card);
        var dlUrl = card.getAttribute('data-download-url') || '';
        if (dl) {
            dl.textContent = '下载';
            dl.classList.remove('pv-dl-points-purchase');
            dl.removeAttribute('data-dl-action');
            if (dlUrl) {
                dl.setAttribute('href', dlUrl);
            }
        }
        var remote = card.getAttribute('data-remote-url') || '';
        var openBtn = qs('.pv-doc-download-card__btn--open', card);
        if (openBtn && remote) {
            openBtn.setAttribute('href', remote);
            card.setAttribute('data-show-open', '1');
        }
        card.setAttribute('data-show-dl', dlUrl ? '1' : '0');
    }

    function updateCardAfterPurchase(card, data) {
        markCardPurchased(card);
        var name = (data && data.points_name) || '积分';
        var after = data && typeof data.balance_after === 'number' ? data.balance_after : null;
        if (data && data.already_unlocked) {
            toast('您已购买过该资源，可直接下载。 + (after !== null ? ' 褰撳墠' + name + '，? + after : ''));
            return;
        }
        var before = data && typeof data.balance_before === 'number' ? data.balance_before : null;
        var cost = data && typeof data.points_cost === 'number' ? data.points_cost : null;
        var msg = '购买成功！';
        if (before !== null && cost !== null && after !== null) {
            msg += ' 已扣除 ' + cost + ' ' + name + '，当前余额 ' + after + ' ' + name + '（购买前 ' + before + '）。';
        } else if (after !== null) {
            msg += ' 褰撳墠' + name + '，? + after;
        }
        toast(msg);
    }

    function openPurchaseModal(card, bundleId, preview) {
        var modalEl = ensureModal();
        var body = qs('.pv-points-unlock-body', modalEl);
        var confirmBtn = qs('.pv-points-unlock-confirm', modalEl);
        var d = (preview && preview.data) || {};
        var name = d.points_name || '积分';
        var cost = d.points_cost || 0;
        var balance = typeof d.balance === 'number' ? d.balance : 0;
        var title = d.bundle_title || '该资源';

        if (d.unlocked) {
            markCardPurchased(card);
            toast('您已购买过「' + title + '」，可直接下载。');
            return;
        }
        if (!d.logged_in) {
            if (d.login_url) {
                window.location.href = d.login_url;
            }
            return;
        }
        if (!d.can_afford) {
            body.innerHTML =
                '<p>资源：<strong>' + escapeHtml(title) + '</strong></p>' +
                '<p class="text-danger mb-0">您的' + escapeHtml(name) + '不足。需要 <strong>' + cost + '</strong> ' +
                escapeHtml(name) + '，屽綋鍓嶄粎鏈?<strong>' + balance + '</strong> ' + escapeHtml(name) + '。</p>';
            confirmBtn.disabled = true;
        } else {
            body.innerHTML =
                '<p>是否使用 <strong>' + cost + '</strong> ' + escapeHtml(name) + ' 购买「<strong>' +
                escapeHtml(title) + '</strong>」的下载权限？</p>' +
                '<p class="mb-0 text-muted">当前' + escapeHtml(name) + '：<strong>' + balance + '</strong>，? +
                '购买后预计剩余：<strong>' + (balance - cost) + '</strong> ' + escapeHtml(name) + '。</p>';
            confirmBtn.disabled = false;
        }

        var modal = bootstrap.Modal.getOrCreateInstance(modalEl);
        confirmBtn.onclick = function () {
            if (confirmBtn.disabled) {
                return;
            }
            confirmBtn.disabled = true;
            var fd = new FormData();
            if (window.pvDownloadSecurity) {
                window.pvDownloadSecurity.appendWriteFields(fd, 'points-unlock');
            }
            fetchJson(API_UNLOCK + bundleId, {
                method: 'POST',
                body: fd,
                headers: window.pvDownloadSecurity ? window.pvDownloadSecurity.postHeaders() : {},
            })
                .then(function (res) {
                    var b = res.body || {};
                    if (restOk(b) || restAlreadyUnlocked(b)) {
                        modal.hide();
                        updateCardAfterPurchase(card, restData(b));
                        var dl = qs('.pv-doc-download-card__btn--dl', card);
                        if (dl && dl.href && dl.href.indexOf('#') !== 0) {
                            return;
                        }
                    } else if (restLoginUrl(b)) {
                        window.location.href = restLoginUrl(b);
                    } else {
                        toast(restMsg(b, '购买失败'), 'danger');
                    }
                })
                .catch(function () {
                    toast('网络错误，请稍后重试', 'danger');
                })
                .finally(function () {
                    confirmBtn.disabled = false;
                });
        };
        modal.show();
    }

    function escapeHtml(s) {
        return String(s)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;');
    }

    function onDlClick(ev) {
        var btn = ev.currentTarget;
        var card = btn.closest('.pv-doc-download-card');
        if (!card) {
            return;
        }
        var action = btn.getAttribute('data-dl-action') || card.getAttribute('data-dl-action');
        if (action !== 'points_unlock') {
            return;
        }
        ev.preventDefault();
        var bundleId = parseInt(card.getAttribute('data-bundle-id') || '0', 10);
        if (bundleId < 1) {
            return;
        }
        if (card.getAttribute('data-points-unlocked') === '1') {
            return;
        }
        fetchJson(API_PREVIEW + bundleId)
            .then(function (res) {
                var b = res.body || {};
                if (restOk(b)) {
                    openPurchaseModal(card, bundleId, b);
                } else if (restLoginUrl(b)) {
                    window.location.href = restLoginUrl(b);
                } else {
                    toast(restMsg(b, '无法获取购买信息'), 'danger');
                }
            })
            .catch(function () {
                toast('网络错误，请稍后重试', 'danger');
            });
    }

    function init() {
        var section = document.querySelector('.pv-doc-downloads');
        if (!section) {
            return;
        }
        section.querySelectorAll('.pv-doc-download-card').forEach(function (card) {
            if (card.getAttribute('data-points-unlocked') === '1') {
                markCardPurchased(card);
            }
            var dl = qs('.pv-doc-download-card__btn--dl', card);
            if (!dl) {
                return;
            }
            if (
                card.getAttribute('data-access-mode') === 'points' ||
                dl.getAttribute('data-dl-action') === 'points_unlock' ||
                (dl.getAttribute('href') || '').indexOf('#pv-points-unlock') === 0
            ) {
                dl.classList.add('pv-dl-points-purchase');
                if (!dl.getAttribute('data-dl-action')) {
                    dl.setAttribute('data-dl-action', 'points_unlock');
                }
                dl.addEventListener('click', onDlClick);
            }
        });
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

  PV.modules.downloadPoints = PV.modules.downloadPoints || {};
})(window.PV = window.PV || {}, window.pvUrl);

