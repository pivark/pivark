/** PivArk weapp — download core
 * @namespace PV.modules.download
 */
(function (PV, pvUrl) {
  'use strict';
  PV = PV || {};
  PV.modules = PV.modules || {};

    function toast(msg, type) {
        var box = document.getElementById('pvDlToast');
        if (!box) {
            box = document.createElement('div');
            box.id = 'pvDlToast';
            box.setAttribute('role', 'alert');
            document.body.appendChild(box);
        }
        box.className = 'pv-dl-toast alert alert-' + (type || 'success');
        box.textContent = msg;
        box.style.display = 'block';
        clearTimeout(box._timer);
        box._timer = setTimeout(function () {
            box.style.display = 'none';
        }, 3200);
    }

    function copyText(text) {
        if (!text) {
            return Promise.reject(new Error('empty'));
        }
        if (navigator.clipboard && navigator.clipboard.writeText) {
            return navigator.clipboard.writeText(text);
        }
        return new Promise(function (resolve, reject) {
            var ta = document.createElement('textarea');
            ta.value = text;
            ta.setAttribute('readonly', '');
            ta.style.position = 'fixed';
            ta.style.left = '-9999px';
            document.body.appendChild(ta);
            ta.select();
            try {
                document.execCommand('copy') ? resolve() : reject(new Error('copy'));
            } catch (e) {
                reject(e);
            } finally {
                document.body.removeChild(ta);
            }
        });
    }

    function onCopyClick(ev) {
        var btn = ev.currentTarget;
        var card = btn.closest('.pv-doc-download-card');
        var text = btn.getAttribute('data-copy-text')
            || (card && card.getAttribute('data-copy-text'))
            || '';
        if (!text.trim()) {
            toast('暂无可复制内容', 'warning');
            return;
        }
        copyText(text)
            .then(function () {
                var old = btn.textContent;
                btn.classList.add('is-copied');
                btn.textContent = '已复制';
                toast('链接与提取码已复制', 'success');
                setTimeout(function () {
                    btn.classList.remove('is-copied');
                    btn.textContent = old;
                }, 1600);
            })
            .catch(function () {
                toast('复制失败，请手动选择', 'danger');
            });
    }

    function celebrateUnlock(card) {
        if (!card) {
            return;
        }
        card.classList.add('pv-doc-download-card--unlocked');
        setTimeout(function () {
            card.classList.remove('pv-doc-download-card--unlocked');
        }, 1400);
    }

    window.pvDownloadUi = {
        toast: toast,
        celebrateUnlock: celebrateUnlock,
    };

    function ensureQrModal() {
        var el = document.getElementById('pvDlQrModal');
        if (el) {
            return el;
        }
        el = document.createElement('div');
        el.id = 'pvDlQrModal';
        el.className = 'modal fade';
        el.setAttribute('tabindex', '-1');
        el.setAttribute('aria-hidden', 'true');
        el.innerHTML =
            '<div class="modal-dialog modal-dialog-centered modal-sm">' +
            '<div class="modal-content">' +
            '<div class="modal-header">' +
            '<h5 class="modal-title">手机扫码打开</h5>' +
            '<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="关闭"></button>' +
            '</div>' +
            '<div class="modal-body text-center">' +
            '<img class="pv-dl-qr-img mb-2" alt="网盘链接二维码" width="200" height="200" />' +
            '<p class="text-muted small mb-0 pv-dl-qr-hint">使用手机网盘 App 扫码打开链接</p>' +
            '</div></div></div>';
        document.body.appendChild(el);
        return el;
    }

    function onQrClick(ev) {
        var url = (ev.currentTarget.getAttribute('data-qr-url') || '').trim();
        if (!url) {
            toast('暂无链接可生成二维码', 'warning');
            return;
        }
        var modalEl = ensureQrModal();
        var img = modalEl.querySelector('.pv-dl-qr-img');
        if (img) {
            img.src =
                'https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=' +
                encodeURIComponent(url);
        }
        if (typeof bootstrap !== 'undefined' && bootstrap.Modal) {
            bootstrap.Modal.getOrCreateInstance(modalEl).show();
        } else {
            window.open(url, '_blank', 'noopener,noreferrer');
        }
    }

    function bindCopyButtons(root) {
        root.querySelectorAll('[data-pv-dl-copy]').forEach(function (btn) {
            if (btn.getAttribute('data-pv-dl-bound') === '1') {
                return;
            }
            btn.setAttribute('data-pv-dl-bound', '1');
            btn.addEventListener('click', onCopyClick);
        });
    }

    function bindQrButtons(root) {
        root.querySelectorAll('[data-pv-dl-qr]').forEach(function (btn) {
            if (btn.getAttribute('data-pv-dl-qr-bound') === '1') {
                return;
            }
            btn.setAttribute('data-pv-dl-qr-bound', '1');
            btn.addEventListener('click', onQrClick);
        });
    }

    function init() {
        var section = document.querySelector('.pv-doc-downloads');
        if (!section) {
            return;
        }
        bindCopyButtons(section);
        bindQrButtons(section);
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

    window.pvDownloadSecurity = {
        csrfField: '__token',
        csrfToken: function () {
            var el = document.getElementById('pv-front-csrf-token');
            if (el && el.value) {
                return el.value;
            }
            var node = document.querySelector('meta[name="pv-csrf-token"]');
            return node ? node.getAttribute('content') || '' : '';
        },
        idempotencyKey: function (prefix) {
            return String(prefix || 'dl') + '-' + Date.now() + '-' + Math.random().toString(36).slice(2, 11);
        },
        postHeaders: function () {
            var token = window.pvDownloadSecurity.csrfToken();
            return {
                Accept: 'application/json',
                'X-Requested-With': 'XMLHttpRequest',
                'X-CSRF-Token': token,
            };
        },
        appendWriteFields: function (fd, prefix) {
            var sec = window.pvDownloadSecurity;
            fd.append(sec.csrfField, sec.csrfToken());
            fd.append('__idempotency_key', sec.idempotencyKey(prefix));
            return fd;
        },
    };

  var mod = PV.modules.download;
  mod.ui = window.pvDownloadUi;
  mod.security = window.pvDownloadSecurity;
  PV.modules.download = mod;
})(window.PV = window.PV || {}, window.pvUrl);


