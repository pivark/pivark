<?php
/**
 * 元舟 PivArk — 企业全域原子化数字资产中枢
 * (c) 2024-2026 pivark.com. All rights reserved.
 * Author: Angelo
 * 未经允许，不可用于商业用途。
 */
declare(strict_types=1);

namespace weapp\doc_ask\model;


use app\common\model\Document;
use think\Model;
use think\model\relation\BelongsTo;

/**
 * Class weapp\doc_ask\model\WeappDocAskItem
 *
 * @property int $document_id 关联文档 ID
 * @property int $hub_essence 站点问答精华
 * @property int $hub_pinned 站点问答置顶
 * @property int $hub_show 展示于站点问答页
 * @property int $id 主键
 * @property int $sort 排序
 * @property int $status 状态：0待审/禁用 1已发布
 * @property string $answer 回答
 * @property string $asker_name 提问人昵称
 * @property string $created_at 创建时间
 * @property string $question 问题
 * @property string $source official|user
 * @property string $updated_at 更新时间
 * @property int $user_id 提问会员 ID
 *  */
class WeappDocAskItem extends Model
{
    protected $name = 'weapp_doc_ask_items';

        protected $type = [
        'document_id' => 'integer',
        'id' => 'integer',
        'sort' => 'integer',
        'status' => 'integer',
        'hub_show' => 'integer',
        'hub_pinned' => 'integer',
        'hub_essence' => 'integer',
        'user_id' => 'integer',
    ];

    protected $autoWriteTimestamp = false;

    public function document(): BelongsTo
    {
        return $this->belongsTo(Document::class, 'document_id');
    }
}
