# 问答（`doc_ask`）

> **用户文档 SSOT：** 本目录 `README.md`（`## 功能介绍` · `## 使用说明` · `## 升级日志` · `## 安装与开发`） · v1.0.2 · `pivark/doc_ask`；后台与市场直读，改完即生效。

## 功能介绍

<h3>这个插件能帮你做什么？</h3>
<p>站点<strong>独立问答中心</strong>：官方维护 FAQ，访客可在前台 <code>/faq</code> 提交提问；站长回复并发布后公开展示。需要时也可把少量 FAQ <strong>可选挂到单篇文档</strong>。</p>
<p class="pv-tip">主路径是广场 / Hub；用户提问先进待答队列，不是多人讨论区（讨论可用评论/社区）。</p>

<h3>典型场景</h3>
<figure class="pv-guide-figure">
    <img src="guide-scenarios.svg" alt="FAQ 广场、帮助中心、可选文档挂载" loading="lazy" width="720" />
    <figcaption>独立条目进广场；个别产品页可按需挂载。</figcaption>
</figure>

<h3>什么时候会生效？</h3>
<table>
    <thead><tr><th>情况</th><th>行为</th></tr></thead>
    <tbody>
        <tr><td>插件启用 + FAQ 广场开启</td><td>前台 <code>/faq</code>（模板 <code>list_page_faq</code>）列出已发布「进广场」条目</td></tr>
        <tr><td>允许访客提问开启</td><td><code>/faq</code> 显示提问表单；POST <code>/api/v1/plugins/doc_ask/submit</code></td></tr>
        <tr><td>用户提问待答</td><td>后台条目状态「待答」；填写回答并启用后进广场</td></tr>
        <tr><td>条目文档 ID = 0 且进广场</td><td>独立问答，不依赖任何文章</td></tr>
        <tr><td>发布页展现 = 隐藏（默认）</td><td>文档编辑器不出现问答面板</td></tr>
        <tr><td>模板含 <code>{pv:doc_ask}</code> 且文档有挂载条目</td><td>详情页输出该文档 FAQ</td></tr>
    </tbody>
</table>

<h3>站长怎么用？</h3>
<figure class="pv-guide-figure">
    <img src="guide-admin-flow.svg" alt="启用、条目管理、广场、可选挂载" loading="lazy" width="720" />
</figure>
<ol>
    <li>插件中心启用「问答」。</li>
    <li>「条目管理」写官方 FAQ，或回复访客在 <code>/faq</code> 提交的待答问题。</li>
    <li>「基础设置」：确认 FAQ 广场与「允许访客提问」开启。</li>
    <li>前台打开 <code>/faq</code> 验收列表与提问表单。</li>
</ol>

<h3>与正文的分工</h3>
<p>复杂排版、图片教程写在文档正文；FAQ 保持简洁，便于折叠扫描。独立条目 <code>document_id=0</code>；挂载条目才关联具体文档。</p>

<h3>常见问题</h3>
<ul>
    <li><strong>/faq 空白？</strong> 确认广场开关、条目「进广场」、模板为 <code>list_page_faq</code>。</li>
    <li><strong>后台建不了条目？</strong> 用「新建独立问答」，不要依赖文档发布页（默认已隐藏）。</li>
</ul>

## 使用说明

<h3>功能简介（前端向）</h3>
<p>主入口：站点页 <code>/faq</code> 展示广场问答。可选：详情页通过 <code>{pv:doc_ask}</code> 输出单篇挂载 FAQ。</p>

<figure class="pv-guide-figure">
    <img src="usage-template-wireframe.svg" alt="FAQ 广场与详情挂载位置" loading="lazy" width="640" />
</figure>

<h3>广场（推荐）</h3>
<p>单页模板使用 <code>list_page_faq</code>；内核注入 <code>ask_hub_items</code> 等变量。演示种子会写入多条 <code>document_id=0</code> 样例。</p>

<h3>文档挂载（可选）</h3>
<pre class="pv-weapp-code">{pv:doc_ask id="$document_id"}</pre>

<h3>自定义循环模板</h3>
<pre class="pv-weapp-code">{pv:doc_ask id="$document_id"}
&lt;details class="pv-ask-item"&gt;
  &lt;summary&gt;{$field.question}&lt;/summary&gt;
  &lt;div class="pv-ask-answer"&gt;{$field.answer}&lt;/div&gt;
&lt;/details&gt;
{/pv:doc_ask}</pre>

<h3>可用字段</h3>
<table>
    <thead><tr><th>字段</th><th>说明</th><th>示例</th></tr></thead>
    <tbody>
        <tr><td><code>{$field.question}</code></td><td>问题标题</td><td>折叠 summary 内</td></tr>
        <tr><td><code>{$field.answer}</code></td><td>回答正文</td><td>details 内容区</td></tr>
        <tr><td><code>{$field.sort}</code></td><td>排序值</td><td>后台排序</td></tr>
    </tbody>
</table>

<h3>后台配置要点</h3>
<ol>
    <li>「基础设置」：插件开关、FAQ 广场、可选发布页展现（默认隐藏）。</li>
    <li>「条目管理」：新建/编辑独立问答；文档 ID=0 进广场。</li>
</ol>

<h3>前台效果示意</h3>
<figure class="pv-guide-figure">
    <img src="usage-front-mockup.svg" alt="折叠 FAQ 列表效果" loading="lazy" width="640" />
</figure>

<p class="pv-tip">默认折叠样式打包在 <code>weapp/doc_ask/assets/css/ask.css</code>，经 <code>{pv:frontassets /}</code> 按需加载；主题勿复制整套 FAQ CSS，可在 frontassets 之后覆写颜色/间距。</p>

## 升级日志

### 1.0.2 · 2026-07-17

- 访客可在 <code>/faq</code> 提交提问（CSRF）；条目 <code>source=user</code> 待答
- Schema v2：<code>source</code> / <code>asker_name</code> / <code>user_id</code>
- 后台来源筛选、回复用户提问流；设置项「允许访客提问」
- API：<code>POST /api/v1/plugins/doc_ask/submit</code>

### 1.0.1 · 2026-07-17

- 产品叙事改为「独立问答中心为主」；后台首页进条目管理
- 文档编辑器 slot 默认 hidden；设置文案对齐 Hub
- 条目列表支持新建/编辑；允许 <code>document_id=0</code>
- 前台 <code>list_page_faq</code> + InstallDemo 偏广场灌数

### 1.0.0 · 2026-01-15

- 文档 FAQ 问答条目后台维护
- 文档编辑器 inline 问答 Tab
- 前台 `{pv:doc_ask}` 折叠展示

## 安装与开发

### 目录

```text
weapp/doc_ask/
├── plugin.json
├── Plugin.php
├── api/controller/   # 前台 submit
├── service/          # 业务 ONLY HERE
├── admin/            # 后台 API / UI（@weapp-doc-ask alias）
└── database/
```

### 说明

问答中心；业务在 `service/AskService.php` / `AskHubService.php`；内核桥接 handler 为 `service/AskDocumentAddonBridge.php`（经 `PluginExtensionRegistry` + `DocumentAddonBridgeAccess` 调用，**不在** `app/common/service/` 写 per-plugin 壳）。

### 超级搜索

`plugin.json` → `document_search.bridge.fetch: listForDocument`；内核 `DocumentAddonSearchRegistry` 经 `DocumentAddonBridgeAccess` 拉取问答条目，`DocumentAddonPlainTextCollector` 采集 `question` / `answer` 写入 `documents.search_text`。见 [文档扩展插件-超级搜索接入.md](../../docs/06-插件/文档扩展插件-超级搜索接入.md)

### 标装进度

| 项 | 状态 |
|----|------|
| `PluginApiRegistry` 对外 API | ✅ `AskPublic`（`listForDocument`） |
| 前台用户提问 API | ✅ `POST /api/v1/plugins/doc_ask/submit` |
| `DocumentAddonBridgeHandler` | ✅ `AskDocumentAddonBridge` |
| 前台默认 CSS | ✅ `weapp/doc_ask/assets/css/ask.css` + `{pv:frontassets}` |
| Admin UI SSOT | ✅ `weapp/doc_ask/admin/ui/`（admin views 仅 re-export） |
| `composer.json` | ✅ `pivark/weapp-ask` |

### 禁止

- 在 `app/common/service/` 写 `DocumentAskService` 等业务 extends 壳（weapp-zero：桥接在插件内 handler）
- 插件内引用 `app/common/service/{Plugin}*` 业务空壳
