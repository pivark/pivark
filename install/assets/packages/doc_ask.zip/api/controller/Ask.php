<?php
declare(strict_types=1);

namespace weapp\doc_ask\api\controller;

use app\common\service\weapp\WeappFrontGateway;
use app\common\service\weapp\WeappSupportGateway;
use think\facade\Request;
use think\response\Json;
use weapp\doc_ask\service\AskService;

/** 问答插件前台 API（用户提问） */
class Ask
{
    public function submit(): Json
    {
        AskService::ensureAutoload();
        if (!Request::isPost()) {
            return app(WeappSupportGateway::class)->apiMethodNotAllowed('请使用 POST 提交');
        }
        $token = (string) Request::post(app(WeappFrontGateway::class)->frontCsrfFieldName(), '');
        $header = Request::header('X-CSRF-Token');
        if (!app(WeappFrontGateway::class)->frontCsrfValidateRequest($token, is_string($header) ? $header : null)) {
            return app(WeappSupportGateway::class)->apiCsrfExpired();
        }

        $result = AskService::submitUserQuestion(Request::post());
        if ($result->isOk()) {
            app(WeappFrontGateway::class)->frontCsrfRotateAfterSuccess();
        }

        return app(WeappSupportGateway::class)->apiFromServiceResult($result);
    }
}
