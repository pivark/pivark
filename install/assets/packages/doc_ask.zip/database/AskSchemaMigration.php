<?php
declare(strict_types=1);

namespace weapp\doc_ask\database;

use app\common\contract\WeappSchemaMigration;
use think\facade\Db;

/**
 * doc_ask schema：用户提问字段（官方 FAQ 与用户提问并存）
 */
final class AskSchemaMigration extends WeappSchemaMigration
{
    public static function identifier(): string
    {
        return 'doc_ask';
    }

    public static function version(): int
    {
        return 2;
    }

    public static function up(): void
    {
        $table = self::prefix() . 'weapp_doc_ask_items';
        self::ensureColumn(
            $table,
            'source',
            "ALTER TABLE `{$table}` ADD COLUMN `source` varchar(16) NOT NULL DEFAULT 'official' COMMENT 'official|user' AFTER `hub_essence`"
        );
        self::ensureColumn(
            $table,
            'asker_name',
            "ALTER TABLE `{$table}` ADD COLUMN `asker_name` varchar(80) NOT NULL DEFAULT '' COMMENT '提问人昵称' AFTER `source`"
        );
        self::ensureColumn(
            $table,
            'user_id',
            "ALTER TABLE `{$table}` ADD COLUMN `user_id` int unsigned NOT NULL DEFAULT 0 COMMENT '提问会员 ID' AFTER `asker_name`"
        );
    }

    private static function ensureColumn(string $table, string $column, string $alterSql): void
    {
        $safeCol = str_replace(['\\', "'", '%', '_'], ['\\\\', "\\'", '\\%', '\\_'], $column);
        $rows = Db::query("SHOW COLUMNS FROM `{$table}` LIKE '{$safeCol}'");
        if ($rows !== []) {
            return;
        }
        Db::execute($alterSql);
    }
}
