<?php
/**
 * 元舟 PivArk — 企业全域原子化数字资产中枢
 * (c) 2024-2026 pivark.com. All rights reserved.
 * Author: Angelo
 * 未经允许，不可用于商业用途。
 */
declare(strict_types=1);

require_once dirname(__DIR__, 4) . '/app/database/migrations/_migration_bootstrap.php';

$name = 'migrate_weapp_doc_ask_hub';

function migration_down(PDO $pdo, string $pfx, string $db): void {
    // no-op structural rollback
}

migration_entry($name, static function (PDO $pdo, string $pfx, string $db) use ($name): void {
    if (migration_skip_when_table_missing($pdo, $pfx, $db, $name, 'weapp_doc_ask_items')) {
        migration_exit(0);
    }
    
    
    $table = "{$pfx}weapp_doc_ask_items";
    $cols = [
        'hub_show'    => "ADD COLUMN `hub_show` tinyint NOT NULL DEFAULT 1 COMMENT '展示于站点问答页' AFTER `status`",
        'hub_pinned'  => "ADD COLUMN `hub_pinned` tinyint NOT NULL DEFAULT 0 COMMENT '站点问答置顶' AFTER `hub_show`",
        'hub_essence' => "ADD COLUMN `hub_essence` tinyint NOT NULL DEFAULT 0 COMMENT '站点问答精华' AFTER `hub_pinned`",
    ];
    
    foreach ($cols as $col => $ddl) {
        $exists = (int) $pdo->query(
            "SELECT COUNT(*) FROM information_schema.COLUMNS
             WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = " . $pdo->quote($table) . "
               AND COLUMN_NAME = " . $pdo->quote($col)
        )->fetchColumn();
        if ($exists > 0) {
            echo "  exists: {$col}\n";
            continue;
        }
        $pdo->exec("ALTER TABLE `{$table}` {$ddl}");
        echo "  added: {$col}\n";
    }
    
    $pdo->exec("UPDATE `{$table}` SET `hub_show` = 1 WHERE `status` = 1 AND `hub_show` = 0");
});
