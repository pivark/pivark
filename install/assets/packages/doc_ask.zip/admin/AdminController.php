<?php
declare(strict_types=1);

namespace weapp\doc_ask\admin;

use app\common\service\weapp\WeappPluginGateway;
use app\common\service\weapp\WeappSupportGateway;
use app\common\contract\PluginAdminBaseTrait;
use app\common\contract\PluginAdminUsageTrait;
use think\facade\Request;
use think\Response;
use weapp\doc_ask\service\AskService;
use weapp\doc_ask\service\AskConfigService;

/** 文档问答 后台 */
class AdminController
{
    use PluginAdminBaseTrait;
    use PluginAdminUsageTrait;

    public function __construct()
    {
        $this->pluginIdentifier = 'doc_ask';
    }

    public function index(): Response
    {
        if (!$this->entitled()) {
            return $this->renderDisabled();
        }
        AskService::ensureAutoload();
        $manifest = app(WeappPluginGateway::class)->pluginReadManifest('doc_ask') ?? [];

        return $this->renderPluginView('index', array_merge(
            $this->pluginContext($manifest),
            [
                'cfg'   => AskConfigService::all(),
                'stats' => AskService::statsAdmin(),
            ]
        ));
    }

    public function list(): Response
    {
        if (!$this->entitled()) {
            return $this->renderDisabled();
        }
        AskService::ensureAutoload();
        $manifest = app(WeappPluginGateway::class)->pluginReadManifest('doc_ask') ?? [];
        if (Request::isAjax()) {
            $page = max(1, (int) Request::get('page', 1));
            $filters = [
                'status'  => Request::get('status', ''),
                'keyword' => (string) Request::get('keyword', ''),
                'source'  => (string) Request::get('source', ''),
            ];
            $docRaw = Request::get('document_id', null);
            if ($docRaw !== null && $docRaw !== '') {
                $filters['document_id'] = (int) $docRaw;
            }

            return app(WeappSupportGateway::class)->apiFromServiceResult(AskService::listAdmin($filters, $page));
        }

        return $this->renderPluginView('list', array_merge(
            $this->pluginContext($manifest, 'items'),
            ['stats' => AskService::statsAdmin()]
        ));
    }

    public function configSave(): Response
    {
        if (!Request::isPost()) {
            return app(WeappSupportGateway::class)->apiMethodNotAllowed();
        }
        if (!$this->entitled()) {
            return app(WeappSupportGateway::class)->apiFromServiceResult(app(WeappSupportGateway::class)->resultForbidden('插件未授权'));
        }

        return app(WeappSupportGateway::class)->apiFromServiceResult(AskConfigService::saveAdmin(Request::post()));
    }

    public function save(): Response
    {
        if (!Request::isPost()) {
            return app(WeappSupportGateway::class)->apiMethodNotAllowed();
        }
        AskService::ensureAutoload();

        return app(WeappSupportGateway::class)->apiFromServiceResult(AskService::saveAdmin(Request::post()));
    }

    public function delete(): Response
    {
        if (!Request::isPost()) {
            return app(WeappSupportGateway::class)->apiMethodNotAllowed();
        }
        AskService::ensureAutoload();

        return app(WeappSupportGateway::class)->apiFromServiceResult(AskService::deleteAdmin((int) Request::post('id', 0)));
    }

    public function status(): Response
    {
        if (!Request::isPost()) {
            return app(WeappSupportGateway::class)->apiMethodNotAllowed();
        }
        AskService::ensureAutoload();

        return app(WeappSupportGateway::class)->apiFromServiceResult(AskService::statusAdmin((int) Request::post('id', 0), (int) Request::post('status', 1)));
    }
}