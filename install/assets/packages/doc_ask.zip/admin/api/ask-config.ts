import {
  pivarkRestListPayload,
  type PivarkRestEnvelope,
} from '#/api/pivark-rest';
import { resolveAdminRestUrl } from '#/api/admin-rest-url';
import {requestClient} from '#/api/request';

import { pivarkMutation } from '#/api/pivark/core/mutation';

export type AskListRow = {
  answer: string;
  asker_name?: string;
  document_id: number;
  document_title?: string;
  hub_essence?: number;
  hub_pinned?: number;
  hub_show?: number;
  id: number;
  question: string;
  sort: number;
  source?: string;
  source_label?: string;
  status: number;
  status_label?: string;
};

export async function saveAskConfigApi(cfg: {
  ask_document_editor_slot: string;
  ask_hub_open?: string;
  ask_open: string;
  ask_user_ask_open?: string;
}) {
  return pivarkMutation('/weapp/doc_ask/configSave', {
    ask_document_editor_slot: cfg.ask_document_editor_slot,
    ask_open: cfg.ask_open === '1' ? '1' : '0',
    ask_hub_open: cfg.ask_hub_open === '1' ? '1' : '0',
    ask_user_ask_open: cfg.ask_user_ask_open === '1' ? '1' : '0',
  });
}

export async function fetchAskListApi(params: {
  document_id?: number;
  keyword?: string;
  page?: number;
  pageSize?: number;
  source?: string;
  status?: string;
}) {
  const query: Record<string, string | number> = {
    page: params.page ?? 1,
    limit: params.pageSize ?? 20,
    status: params.status ?? '',
    source: params.source ?? '',
  };
  if (params.keyword) {
    query.keyword = params.keyword;
  }
  if (params.document_id !== undefined && params.document_id !== null) {
    query.document_id = params.document_id;
  }
  const body = await requestClient.get<PivarkRestEnvelope>(
    resolveAdminRestUrl('/weapp/doc_ask/list'),
    {
      params: query,
      responseReturn: 'body',
      withCredentials: true,
    },
  );

  const payload = pivarkRestListPayload(body);
  return {
    list: payload.list as AskListRow[],
    total: payload.total,
  };
}

export async function saveAskItemApi(data: {
  answer: string;
  document_id: number;
  hub_essence?: number;
  hub_pinned?: number;
  hub_show?: number;
  id?: number;
  question: string;
  sort: number;
  status: number;
}) {
  const payload: Record<string, unknown> = {
    document_id: data.document_id,
    question: data.question,
    answer: data.answer,
    sort: data.sort,
    status: data.status === 1 ? '1' : '0',
    hub_show: data.hub_show === 1 ? '1' : '0',
    hub_pinned: data.hub_pinned === 1 ? '1' : '0',
    hub_essence: data.hub_essence === 1 ? '1' : '0',
  };
  if (data.id && data.id > 0) {
    payload.id = data.id;
  }
  return pivarkMutation('/weapp/doc_ask/save', payload);
}

export async function deleteAskItemApi(id: number) {
  return pivarkMutation('/weapp/doc_ask/delete', { id });
}
