import type { AskListRow } from '../data';

import type { VxeTableGridOptions } from '#/adapter/vxe-table';

import { shallowRef } from 'vue';

import { deleteAskItemApi } from '@weapp-doc-ask/api/ask-config';
import { confirmAdminRowDelete } from '#/composables/use-admin-batch-actions';
import {
  PV_ADMIN_LIST_GRID_CLASS,
  PV_ADMIN_LIST_GRID_OPTIONS,
  usePvAdminListGrid,
} from '#/composables/use-pv-admin-list-grid';

import {
  fetchAskListPage,
  useDocAskGridColumns,
  useDocAskListGridFormOptions,
} from '../data';

type DocAskListHandlers = {
  onAdd: () => void;
  onEdit: (row: AskListRow) => void;
};

export function useDocAskList(handlers: DocAskListHandlers) {
  const gridApiRef = shallowRef<
    ReturnType<typeof usePvAdminListGrid<AskListRow>>['gridApi'] | null
  >(null);

  function getGridApi() {
    return gridApiRef.value!;
  }

  async function refreshGrid() {
    await getGridApi().query();
  }

  async function handleDelete(row: AskListRow) {
    await confirmAdminRowDelete({
      message: '确定删除该问答条目？',
      title: '删除',
      action: async () => {
        await deleteAskItemApi(Number(row.id));
        await refreshGrid();
      },
      successMessage: '已删除',
    });
  }

  function onActionClick(e: { code: string; row: AskListRow }) {
    if (e.code === 'edit') {
      handlers.onEdit(e.row);
      return;
    }
    if (e.code === 'delete') {
      void handleDelete(e.row);
    }
  }

  const { Grid, gridApi } = usePvAdminListGrid<AskListRow>(() => ({
    formOptions: useDocAskListGridFormOptions(),
    gridClass: PV_ADMIN_LIST_GRID_CLASS,
    gridOptions: {
      ...PV_ADMIN_LIST_GRID_OPTIONS,
      columns: useDocAskGridColumns(onActionClick),
      proxyConfig: {
        ...PV_ADMIN_LIST_GRID_OPTIONS.proxyConfig,
        ajax: {
          query: async ({ page }, formValues) => {
            return fetchAskListPage(page, formValues ?? {});
          },
        },
      },
      rowConfig: {
        keyField: 'id',
      },
    } as VxeTableGridOptions,
  }));

  gridApiRef.value = gridApi;

  return {
    Grid,
    onAdd: handlers.onAdd,
    refreshGrid,
  };
}
