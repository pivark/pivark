<script lang="ts" setup>
import type { AskListRow } from './data';

import { reactive, ref } from 'vue';

import { ElMessage } from 'element-plus';
import { Plus } from '@pivark/icons';

import { saveAskItemApi } from '@weapp-doc-ask/api/ask-config';
import PvAdminGridLoadingSkeleton from '#/components/pivark/PvAdminGridLoadingSkeleton.vue';
import WeappPluginShell from '#/components/pivark/weapp/WeappPluginShell.vue';

import { DOC_ASK_LIST_HINT } from './data';
import { useDocAskList } from './list/use-ask-list';

defineOptions({ name: 'WeappDocAskList' });

const saving = ref(false);
const dialogVisible = ref(false);
const form = reactive({
  answer: '',
  asker_name: '',
  document_id: 0,
  hub_essence: 0,
  hub_pinned: 0,
  hub_show: 1,
  id: 0,
  question: '',
  sort: 0,
  source: 'official',
  status: 1,
});

function resetForm(row?: AskListRow) {
  form.id = Number(row?.id ?? 0);
  form.document_id = Number(row?.document_id ?? 0);
  form.question = String(row?.question ?? '');
  form.answer = String(row?.answer ?? '');
  form.sort = Number(row?.sort ?? 0);
  form.status = Number(row?.status ?? 1) === 1 ? 1 : 0;
  form.hub_show = Number(row?.hub_show ?? 1) === 1 ? 1 : 0;
  form.hub_pinned = Number(row?.hub_pinned ?? 0) === 1 ? 1 : 0;
  form.hub_essence = Number(row?.hub_essence ?? 0) === 1 ? 1 : 0;
  form.source = String(row?.source ?? 'official') === 'user' ? 'user' : 'official';
  form.asker_name = String(row?.asker_name ?? '');
}

function openCreate() {
  resetForm();
  dialogVisible.value = true;
}

function openEdit(row: AskListRow) {
  resetForm(row);
  dialogVisible.value = true;
}

const { Grid, onAdd, refreshGrid } = useDocAskList({
  onAdd: openCreate,
  onEdit: openEdit,
});

async function saveItem() {
  if (!form.question.trim()) {
    ElMessage.warning('请填写问题');
    return;
  }
  if (form.status === 1 && !form.answer.trim()) {
    ElMessage.warning('发布前请填写回答');
    return;
  }
  if (Number(form.document_id) < 0) {
    ElMessage.warning('文档 ID 无效');
    return;
  }
  saving.value = true;
  try {
    await saveAskItemApi({
      id: form.id > 0 ? form.id : undefined,
      document_id: Number(form.document_id) || 0,
      question: form.question.trim(),
      answer: form.answer.trim(),
      sort: Number(form.sort) || 0,
      status: form.status,
      hub_show: form.hub_show,
      hub_pinned: form.hub_pinned,
      hub_essence: form.hub_essence,
    });
    ElMessage.success('已保存');
    dialogVisible.value = false;
    await refreshGrid();
  } finally {
    saving.value = false;
  }
}
</script>

<template>
  <WeappPluginShell plugin-id="doc_ask" nav-key="list">
    <Grid table-title="问答条目" :table-title-help="DOC_ASK_LIST_HINT">
      <template #loading>
        <PvAdminGridLoadingSkeleton fill />
      </template>
      <template #toolbar-tools>
        <el-button type="primary" :icon="Plus" @click="onAdd">
          新建独立问答
        </el-button>
      </template>
      <template #empty>
        <el-empty description="还没有问答。用户可在 /faq 提问；也可点「新建独立问答」写官方 FAQ。">
          <el-button type="primary" :icon="Plus" @click="onAdd">
            新建独立问答
          </el-button>
          <el-button @click="$router.push('/weapp/host/doc_ask/settings')">
            去基础设置
          </el-button>
        </el-empty>
      </template>
    </Grid>

    <el-dialog
      v-model="dialogVisible"
      :title="
        form.id > 0
          ? form.source === 'user'
            ? '回复用户提问'
            : '编辑问答'
          : '新建独立问答'
      "
      width="640px"
    >
      <el-form label-position="top">
        <el-alert
          v-if="form.source === 'user'"
          class="mb-3"
          type="info"
          :closable="false"
          :title="`用户提问 · ${form.asker_name || '匿名'}`"
          description="填写回答后打开「启用」即可发布到 /faq。"
        />
        <el-form-item label="问题" required>
          <el-input v-model="form.question" placeholder="访客看到的问题标题" />
        </el-form-item>
        <el-form-item label="回答" :required="form.status === 1">
          <el-input
            v-model="form.answer"
            type="textarea"
            :rows="6"
            placeholder="支持简单 HTML；用户提问待答时可先留空"
          />
        </el-form-item>
        <div class="grid grid-cols-2 gap-3">
          <el-form-item label="文档 ID（0=独立广场）">
            <el-input-number
              v-model="form.document_id"
              :min="0"
              class="w-full"
              controls-position="right"
            />
          </el-form-item>
          <el-form-item label="排序">
            <el-input-number
              v-model="form.sort"
              :min="0"
              class="w-full"
              controls-position="right"
            />
          </el-form-item>
        </div>
        <div class="flex flex-wrap gap-4">
          <el-form-item label="启用/发布">
            <el-switch
              v-model="form.status"
              :active-value="1"
              :inactive-value="0"
            />
          </el-form-item>
          <el-form-item label="进广场 /faq">
            <el-switch
              v-model="form.hub_show"
              :active-value="1"
              :inactive-value="0"
            />
          </el-form-item>
          <el-form-item label="置顶">
            <el-switch
              v-model="form.hub_pinned"
              :active-value="1"
              :inactive-value="0"
            />
          </el-form-item>
          <el-form-item label="精华">
            <el-switch
              v-model="form.hub_essence"
              :active-value="1"
              :inactive-value="0"
            />
          </el-form-item>
        </div>
      </el-form>
      <template #footer>
        <el-button @click="dialogVisible = false">取消</el-button>
        <el-button :loading="saving" type="primary" @click="saveItem">
          保存
        </el-button>
      </template>
    </el-dialog>
  </WeappPluginShell>
</template>
