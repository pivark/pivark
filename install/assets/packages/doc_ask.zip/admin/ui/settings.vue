<script lang="ts" setup>
import { computed, onMounted, ref } from 'vue';
import { useRouter } from 'vue-router';

import { ElMessage } from 'element-plus';

import { saveAskConfigApi } from '@weapp-doc-ask/api/ask-config';
import { fetchSpaWeappPluginMetaApi } from '#/api/pivark/core/spa';
import { useWeappPluginId } from '#/composables/use-weapp-plugin-settings';
import WeappPluginKpiRow from '#/components/pivark/weapp/WeappPluginKpiRow.vue';
import WeappPluginPageCard from '#/components/pivark/weapp/WeappPluginPageCard.vue';
import WeappPluginShell from '#/components/pivark/weapp/WeappPluginShell.vue';
import WeappPluginSlotCards from '#/components/pivark/weapp/WeappPluginSlotCards.vue';
import PvModuleSection from '#/components/pivark/shell/PvModuleSection.vue';
import {
  useWeappPluginDisabledCount,
  useWeappSettingsLoading,
  type WeappSlotCard,
} from '#/composables/use-weapp-plugin-settings';

defineOptions({ name: 'WeappDocAskSettings' });

type AskMeta = {
  cfg?: Record<string, string>;
  stats?: { total?: number; enabled?: number };
  slotCards?: WeappSlotCard[];
  editorSlot?: string;
};

const router = useRouter();
const pluginId = useWeappPluginId();
const { loading, saving, withLoading, withSaving } = useWeappSettingsLoading();

const askOpen = ref(true);
const hubOpen = ref(true);
const userAskOpen = ref(true);
const editorSlot = ref('hidden');
const slotCards = ref<WeappSlotCard[]>([]);
const stats = ref({ total: 0, enabled: 0 });

const disabledCount = useWeappPluginDisabledCount(stats);

const kpiItems = computed(() => [
  { label: '问答总数', value: stats.value.total },
  { label: '已启用', value: stats.value.enabled },
  { label: '已停用', value: disabledCount.value },
]);

async function loadMeta() {
  await withLoading(async () => {
    const meta = await fetchSpaWeappPluginMetaApi<AskMeta>(pluginId.value);
    const c = meta.cfg ?? {};
    askOpen.value = String(c.ask_open ?? '1') === '1';
    hubOpen.value = String(c.ask_hub_open ?? '1') === '1';
    userAskOpen.value = String(c.ask_user_ask_open ?? '1') === '1';
    editorSlot.value = String(
      c.ask_document_editor_slot ?? meta.editorSlot ?? 'hidden',
    );
    slotCards.value = meta.slotCards ?? [];
    stats.value = {
      total: Number(meta.stats?.total ?? 0),
      enabled: Number(meta.stats?.enabled ?? 0),
    };
  });
}

async function handleSave() {
  await withSaving(async () => {
    await saveAskConfigApi({
      ask_open: askOpen.value ? '1' : '0',
      ask_hub_open: hubOpen.value ? '1' : '0',
      ask_user_ask_open: userAskOpen.value ? '1' : '0',
      ask_document_editor_slot: editorSlot.value,
    });
    ElMessage.success('保存成功');
    await loadMeta();
  });
}

function goList() {
  router.push('/weapp/host/doc_ask/list');
}

onMounted(loadMeta);
</script>

<template>
  <WeappPluginShell :plugin-id="pluginId" nav-key="settings">
    <WeappPluginPageCard :loading="loading" title="基础设置">
      <template #actions>
        <el-button @click="goList">条目管理</el-button>
        <el-button :loading="saving" type="primary" @click="handleSave">
          保存配置
        </el-button>
      </template>

      <WeappPluginKpiRow :items="kpiItems" />

      <PvModuleSection title="问答中心（主能力）">
        <el-switch
          v-model="askOpen"
          active-text="启用"
          inactive-text="关闭"
        />
        <p class="pv-weapp-hint mt-2">
          关闭后前台 FAQ 页与模板标签均不输出。日常请在「条目管理」维护独立问答。
        </p>
        <div class="mt-3">
          <el-switch
            v-model="hubOpen"
            active-text="开放 FAQ 广场"
            inactive-text="关闭广场"
          />
          <p class="pv-weapp-hint mt-2">
            开启后，标记「进广场」的条目汇总到前台
            <code>/faq</code>（常见问题页）。独立条目请用文档 ID =
            0，不必挂文章。
          </p>
        </div>
        <div class="mt-3">
          <el-switch
            v-model="userAskOpen"
            active-text="允许访客提问"
            inactive-text="仅官方 FAQ"
          />
          <p class="pv-weapp-hint mt-2">
            开启后前台 <code>/faq</code> 显示提问表单；提交进入「待答」，站长回复并启用后公开展示。
          </p>
        </div>
      </PvModuleSection>

      <PvModuleSection title="可选：挂到单篇文档">
        <p class="pv-weapp-hint mb-3">
          默认不在文档发布页露出问答面板。仅当某篇产品/帮助页需要页内
          FAQ 时，再改为 Tab / 嵌入。
        </p>
        <WeappPluginSlotCards v-model="editorSlot" :cards="slotCards" />
      </PvModuleSection>
    </WeappPluginPageCard>
  </WeappPluginShell>
</template>
