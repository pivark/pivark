import type { AskListRow } from '@weapp-doc-ask/api/ask-config';

import type { PvFormSchema } from '#/adapter/form';
import type {
  OnActionClickFn,
  VxeTableGridColumns,
} from '#/adapter/vxe-table';

import { fetchAskListApi } from '@weapp-doc-ask/api/ask-config';
import {
  PV_COL_FLAG,
  PV_COL_ID,
  PV_COL_NUM,
  PV_COL_OPS,
  PV_COL_TEXT,
} from '#/composables/pv-admin-list-column-presets';
import { usePvAdminListSearchFormOptions } from '#/composables/pv-admin-list-form-layout';

export type { AskListRow };

export const DOC_ASK_LIST_HINT =
  '独立问答：文档 ID=0 进广场；用户提问待答后填写回答并启用即可出现在 /faq。';

const ASK_STATUS_OPTIONS = [
  { label: '已发布', value: '1' },
  { label: '待答/禁用', value: '0' },
];

const ASK_SOURCE_OPTIONS = [
  { label: '官方', value: 'official' },
  { label: '用户提问', value: 'user' },
];

export function useDocAskGridFormSchema(): PvFormSchema[] {
  return [
    {
      component: 'Input',
      fieldName: 'keyword',
      label: '关键词',
      componentProps: {
        clearable: true,
        placeholder: '问题 / 答案 / 提问人',
      },
    },
    {
      component: 'Input',
      fieldName: 'document_id',
      label: '文档 ID',
      componentProps: {
        clearable: true,
        placeholder: '0=独立广场；空=全部',
      },
    },
    {
      component: 'Select',
      fieldName: 'status',
      label: '状态',
      componentProps: {
        clearable: true,
        options: ASK_STATUS_OPTIONS,
      },
    },
    {
      component: 'Select',
      fieldName: 'source',
      label: '来源',
      componentProps: {
        clearable: true,
        options: ASK_SOURCE_OPTIONS,
      },
    },
  ];
}

export function useDocAskListGridFormOptions() {
  return usePvAdminListSearchFormOptions(useDocAskGridFormSchema());
}

export function useDocAskGridColumns(
  onActionClick: OnActionClickFn<AskListRow>,
): VxeTableGridColumns<AskListRow> {
  return [
    {
      field: 'id',
      title: 'ID',
      width: 72,
      ...PV_COL_ID,
    },
    {
      field: 'question',
      title: '问题',
      minWidth: 180,
      ...PV_COL_TEXT,
    },
    {
      field: 'source',
      title: '来源',
      width: 100,
      ...PV_COL_FLAG,
      cellRender: {
        name: 'CellTag',
        options: [
          { type: 'warning', label: '用户问', value: 'user' },
          { type: 'info', label: '官方', value: 'official' },
        ],
      },
    },
    {
      field: 'asker_name',
      title: '提问人',
      width: 100,
      ...PV_COL_TEXT,
    },
    {
      field: 'document_title',
      title: '所属文档',
      minWidth: 140,
      ...PV_COL_TEXT,
      formatter: ({ row }) => {
        const did = Number(row.document_id ?? 0);
        if (did < 1) {
          return '独立广场';
        }
        return String(row.document_title ?? `文档 #${did}`);
      },
    },
    {
      field: 'status',
      title: '状态',
      width: 96,
      ...PV_COL_FLAG,
      cellRender: {
        name: 'CellTag',
        options: [
          { type: 'success', label: '已发布', value: 1 },
          { type: 'warning', label: '待答', value: 0 },
        ],
      },
    },
    {
      field: 'hub_show',
      title: '进广场',
      width: 88,
      ...PV_COL_FLAG,
      cellRender: {
        name: 'CellTag',
        options: [
          { type: 'success', label: '是', value: 1 },
          { type: 'info', label: '否', value: 0 },
        ],
      },
    },
    {
      field: 'hub_pinned',
      title: '置顶',
      width: 72,
      ...PV_COL_FLAG,
      cellRender: {
        name: 'CellTag',
        options: [
          { type: 'warning', label: '置顶', value: 1 },
          { type: 'info', label: '—', value: 0 },
        ],
      },
    },
    {
      field: 'hub_essence',
      title: '精华',
      width: 72,
      ...PV_COL_FLAG,
      cellRender: {
        name: 'CellTag',
        options: [
          { type: 'danger', label: '精华', value: 1 },
          { type: 'info', label: '—', value: 0 },
        ],
      },
    },
    {
      field: 'sort',
      title: '排序',
      width: 88,
      ...PV_COL_NUM,
    },
    {
      ...PV_COL_OPS,
      cellRender: {
        attrs: {
          nameField: 'question',
          nameTitle: '问答',
          onClick: onActionClick,
        },
        name: 'CellOperation',
        options: [
          { code: 'edit', text: '编辑' },
          { code: 'delete', text: '删除', type: 'danger' },
        ],
      },
    },
  ];
}

export async function fetchAskListPage(
  page: { currentPage: number; pageSize: number },
  formValues: Record<string, unknown>,
) {
  const rawDoc = formValues.document_id;
  let documentId: number | undefined;
  if (rawDoc !== undefined && rawDoc !== null && String(rawDoc).trim() !== '') {
    documentId = Number(rawDoc);
  }

  const result = await fetchAskListApi({
    page: page.currentPage,
    pageSize: page.pageSize,
    keyword: String(formValues.keyword ?? ''),
    document_id: documentId,
    status: String(formValues.status ?? ''),
    source: String(formValues.source ?? ''),
  });

  return {
    items: result.list,
    total: result.total,
  };
}
