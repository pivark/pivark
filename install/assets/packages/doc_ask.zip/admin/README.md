# ask 后台 UI（SSOT）

Vue SFC：`weapp/doc_ask/admin/ui/`。

**零外放**：禁止 junction；glob pageMap + `/weapp/host/ask/{page}` 通用 Host 加载。路由见 `AskAdminSpaRoutes`。
