<?php
/**
 * 元舟 PivArk — 企业全域原子化数字资产中枢
 * (c) 2024-2026 pivark.com. All rights reserved.
 * Author: Angelo
 * 未经允许，不可用于商业用途。
 */
declare(strict_types=1);

namespace weapp\doc_ask\service;

use app\common\service\weapp\WeappSupportGateway;

final class AskDocumentAddonSync
{
    /** @param list<array<string, mixed>> $rows */
    public static function syncForDocument(int $documentId, array $rows)
    {
        $bridge = new AskDocumentAddonBridge();
        if (!$bridge->isEnabled()) {
            return app(WeappSupportGateway::class)->resultOk(null, 'ok');
        }

        return $bridge->syncForDocument($documentId, $rows);
    }
}