<?php
declare(strict_types=1);

namespace weapp\doc_ask\service;



use weapp\doc_ask\model\WeappDocAskItem;
use app\common\service\weapp\WeappEntitlementGateway;
use app\common\service\weapp\WeappFrontGateway;
use app\common\service\weapp\WeappSearchGateway;
use app\common\service\weapp\WeappSupportGateway;
use app\common\service\weapp\WeappTemplateGateway;
use app\common\support\ServiceResult;
use think\facade\Db;

/** 文档问答 业务逻辑 */
class AskService
{
    public static function ensureAutoload(): void
    {
        // no-op; class loaded by Plugin::boot or bridge
    }

    public static function isActive(): bool
    {
        return app(WeappEntitlementGateway::class)->entitlementCan('doc_ask') && AskConfigService::isOpen();
    }

    /**
     * @param array<string, mixed> $attrs
     * @param array<string, mixed> $pageVars
     */
    public static function resolveDocumentId(array $attrs, array $pageVars): int
    {
        return (int) ($attrs['id'] ?? $attrs['aid'] ?? $attrs['document_id'] ?? $pageVars['document_id'] ?? 0);
    }

    /** @return list<array<string,mixed>> */
    public static function listForDocument(int $documentId): array
    {
        if (!self::isActive() || $documentId < 1) {
            return [];
        }

        return array_values(WeappDocAskItem::where('document_id', $documentId)
            ->where('status', 1)
            ->order(['sort' => 'asc', 'id' => 'asc'])
            ->select()
            ->toArray());
    }

    /**
     * 挂有 FAQ 条目的文档 ID（arclist has=doc_ask）。
     *
     * @return list<int>
     */
    public static function documentIdsWithPublicAvailability(): array
    {
        if (!self::isActive()) {
            return [];
        }
        try {
            $ids = WeappDocAskItem::where('status', 1)
                ->where('document_id', '>', 0)
                ->distinct(true)
                ->column('document_id');
        } catch (\Throwable $e) {
            app(WeappSupportGateway::class)->kernelOpsLog('ask_document_ids_availability_failed', [
                'msg' => $e->getMessage(),
            ]);

            return [];
        }

        return array_values(array_unique(array_filter(array_map('intval', $ids ?: []), static fn (int $id): bool => $id > 0)));
    }

    /**
     * @param array<string, mixed> $attrs
     * @param array<string, mixed> $pageVars
     */
    public static function renderTag(array $attrs, array $pageVars, string $tpl): string
    {
        if (!self::isActive()) {
            return '';
        }
        $documentId = self::resolveDocumentId($attrs, $pageVars);
        if ($documentId < 1) {
            return '';
        }
        $rows = self::listForDocument($documentId);
        if ($rows === []) {
            return '';
        }
        AskFrontAssets::registerFaq();
        // answer 经 htmlSanitizeArticle 入库；须 |raw 与 Hub 模板一致（禁二次转义成源码）
        $defaultTpl = '<details class="pv-ask-item" id="pv-ask-{$field.id}"><summary>{$field.question}</summary><div class="pv-ask-answer">{$field.answer|raw}</div></details>';
        $tpl = trim($tpl) !== '' ? $tpl : $defaultTpl;
        $items = array_map([self::class, 'formatPublic'], $rows);

        return app(WeappTemplateGateway::class)->templateRenderItemLoop($tpl, $items, $pageVars);
    }

    /**
     * @param array<string, mixed> $row
     * @return array<string, mixed>
     */
    public static function formatPublic(array $row): array
    {
        return [
            'id' => (int) ($row['id'] ?? 0),
            'question' => (string) ($row['question'] ?? ''),
            'answer' => (string) ($row['answer'] ?? ''),
            'hub_pinned' => (int) ($row['hub_pinned'] ?? 0),
            'hub_essence' => (int) ($row['hub_essence'] ?? 0),
        ];
    }

    public static function publicUrl(string $path): string
    {
        $path = trim($path);
        if ($path === '') {
            return '';
        }
        if (str_starts_with($path, 'http://') || str_starts_with($path, 'https://') || str_starts_with($path, '//')) {
            return $path;
        }

        if (str_starts_with($path, '/')) {
            return $path;
        }
        if (str_starts_with($path, 'uploads/')) {
            return '/' . $path;
        }

        return '/uploads/' . ltrim($path, '/');
    }

    /** @return array{total:int,enabled:int} */
    public static function statsAdmin(): array
    {
        if (!app(WeappEntitlementGateway::class)->entitlementCan('doc_ask')) {
            return ['total' => 0, 'enabled' => 0];
        }
        $total   = (int) WeappDocAskItem::count();
        $enabled = (int) WeappDocAskItem::where('status', 1)->count();

        return ['total' => $total, 'enabled' => $enabled];
    }

    /** @param array<string,mixed> $filters */
    public static function listAdmin(array $filters = [], int $page = 1, int $pageSize = 20)
    {
        if (!app(WeappEntitlementGateway::class)->entitlementCan('doc_ask')) {
            return app(WeappSupportGateway::class)->resultFail('问答插件未启用或无权访问');
        }
        $page = max(1, $page);
        $pageSize = max(10, min(100, $pageSize));
        $query = WeappDocAskItem::with(['document' => static function ($documentQuery): void {
            $documentQuery->field('id,title');
        }]);
        if (array_key_exists('document_id', $filters) && $filters['document_id'] !== '' && $filters['document_id'] !== null) {
            $query->where('document_id', (int) $filters['document_id']);
        }
        $status = $filters['status'] ?? '';
        if ($status !== '') {
            $query->where('status', (int) $status);
        }
        $source = trim((string) ($filters['source'] ?? ''));
        if ($source === 'official' || $source === 'user') {
            $query->where('source', $source);
        }
        $keyword = trim((string) ($filters['keyword'] ?? ''));
        if ($keyword !== '') {
            $query->whereLike('question|answer|asker_name', app(WeappSearchGateway::class)->searchLikePattern($keyword));
        }
        $total = (int) (clone $query)->count();
        $rows  = app(WeappSupportGateway::class)->modelRelationMapBelongsTo(
            $query->order('id', 'desc')->page($page, $pageSize)->select(),
            'document',
            ['title' => 'document_title'],
        );
        foreach ($rows as &$row) {
            $src = (string) ($row['source'] ?? 'official');
            $st  = (int) ($row['status'] ?? 0);
            if ($st === 1) {
                $row['status_label'] = '已发布';
            } elseif ($src === 'user') {
                $row['status_label'] = '待答';
            } else {
                $row['status_label'] = '禁用';
            }
            $row['source'] = $src === 'user' ? 'user' : 'official';
            $row['source_label'] = $row['source'] === 'user' ? '用户提问' : '官方';
            $row['asker_name'] = (string) ($row['asker_name'] ?? '');
            $row['hub_show'] = (int) ($row['hub_show'] ?? 1);
            $row['hub_pinned'] = (int) ($row['hub_pinned'] ?? 0);
            $row['hub_essence'] = (int) ($row['hub_essence'] ?? 0);
            if ((int) ($row['document_id'] ?? 0) < 1) {
                $row['document_title'] = '独立广场';
            }
        }
        unset($row);

        return app(WeappSupportGateway::class)->resultList($rows, $total);
    }

    /**
     * 前台用户提问：写入待答条目（status=0），站长回复并启用后出现在 /faq。
     *
     * @param array<string, mixed> $payload
     */
    public static function submitUserQuestion(array $payload): ServiceResult
    {
        if (!self::isActive() || !AskConfigService::isUserAskOpen()) {
            return app(WeappSupportGateway::class)->resultFail('暂未开放提问');
        }
        $question = trim((string) ($payload['question'] ?? ''));
        if ($question === '' || mb_strlen($question) > 500) {
            return app(WeappSupportGateway::class)->resultFail('问题须为 1~500 字');
        }
        $member = app(WeappFrontGateway::class)->frontCurrent();
        $userId = $member !== null ? (int) ($member['id'] ?? 0) : 0;
        $asker  = $member !== null
            ? trim((string) ($member['nickname'] ?? $member['username'] ?? ''))
            : trim((string) ($payload['asker_name'] ?? ''));
        if ($asker === '' || mb_strlen($asker) > 80) {
            return app(WeappSupportGateway::class)->resultFail('请填写昵称（80 字以内）');
        }
        $now = app(WeappSupportGateway::class)->appTimeNow();
        $newId = (int) WeappDocAskItem::insertGetId([
            'document_id' => 0,
            'question'    => $question,
            'answer'      => '',
            'sort'        => 0,
            'status'      => 0,
            'hub_show'    => 1,
            'hub_pinned'  => 0,
            'hub_essence' => 0,
            'source'      => 'user',
            'asker_name'  => $asker,
            'user_id'     => $userId,
            'created_at'  => $now,
            'updated_at'  => $now,
        ]);

        return app(WeappSupportGateway::class)->resultOk(
            ['id' => $newId, 'pending' => 1],
            '已提交，站长回复后将在问答页展示'
        );
    }

    /** @param array<string,mixed> $data */
    public static function saveAdmin(array $data)
    {
        if (!app(WeappEntitlementGateway::class)->entitlementCan('doc_ask')) {
            return app(WeappSupportGateway::class)->resultFail('问答插件未启用或无权访问');
        }
        $id = (int) ($data['id'] ?? 0);
        // document_id=0：独立问答中心（/faq）；>0：可选挂到单篇文档
        $documentId = (int) ($data['document_id'] ?? 0);
        if ($documentId < 0) {
            return app(WeappSupportGateway::class)->resultFail('文档 ID 无效');
        }
        $status = !empty($data['status']) ? 1 : 0;
        $answer = app(WeappSupportGateway::class)->htmlSanitizeArticle(trim((string) ($data['answer'] ?? '')));
        $payload = [
            'document_id' => $documentId,
            'question' => trim((string) ($data['question'] ?? '')),
            'answer' => $answer,
            'sort'        => (int) ($data['sort'] ?? 0),
            'status'      => $status,
            'updated_at'  => app(WeappSupportGateway::class)->appTimeNow(),
        ];
        $existing = null;
        if ($id > 0) {
            $existing = self::askItemRow(WeappDocAskItem::where('id', $id)->find());
            if ($existing !== null) {
                $payload['hub_show'] = array_key_exists('hub_show', $data)
                    ? (!empty($data['hub_show']) ? 1 : 0)
                    : (int) ($existing['hub_show'] ?? 1);
                $payload['hub_pinned'] = array_key_exists('hub_pinned', $data)
                    ? (!empty($data['hub_pinned']) ? 1 : 0)
                    : (int) ($existing['hub_pinned'] ?? 0);
                $payload['hub_essence'] = array_key_exists('hub_essence', $data)
                    ? (!empty($data['hub_essence']) ? 1 : 0)
                    : (int) ($existing['hub_essence'] ?? 0);
            }
        } else {
            $payload['hub_show'] = array_key_exists('hub_show', $data) ? (!empty($data['hub_show']) ? 1 : 0) : 1;
            $payload['hub_pinned'] = !empty($data['hub_pinned']) ? 1 : 0;
            $payload['hub_essence'] = !empty($data['hub_essence']) ? 1 : 0;
            $payload['source'] = 'official';
            $payload['asker_name'] = '';
            $payload['user_id'] = 0;
        }
        if ($payload['question'] === '') {
            return app(WeappSupportGateway::class)->resultFail('请填写问题');
        }
        // 已发布必须有回答；待答/禁用允许空答（用户提问待站长回复）
        if ($status === 1 && $payload['answer'] === '') {
            return app(WeappSupportGateway::class)->resultFail('发布前请填写回答');
        }

        if ($id > 0) {
            WeappDocAskItem::where('id', $id)->update($payload);

            return app(WeappSupportGateway::class)->resultOk(['id' => $id], '更新成功');
        }
        $payload['created_at'] = app(WeappSupportGateway::class)->appTimeNow();
        $newId = (int) WeappDocAskItem::insertGetId($payload);

        return app(WeappSupportGateway::class)->resultOk(['id' => $newId], '添加成功');
    }

    public static function deleteAdmin(int $id)
    {
        if (!app(WeappEntitlementGateway::class)->entitlementCan('doc_ask') || $id < 1) {
            return app(WeappSupportGateway::class)->resultFail('条目不存在或无权操作');
        }
        WeappDocAskItem::where('id', $id)->delete();

        return app(WeappSupportGateway::class)->resultOk(null, 'ok');
    }

    public static function statusAdmin(int $id, int $status)
    {
        if (!app(WeappEntitlementGateway::class)->entitlementCan('doc_ask') || $id < 1) {
            return app(WeappSupportGateway::class)->resultFail('条目不存在或无权操作');
        }
        WeappDocAskItem::where('id', $id)->update([
            'status'     => $status === 1 ? 1 : 0,
            'updated_at' => app(WeappSupportGateway::class)->appTimeNow(),
        ]);

        return app(WeappSupportGateway::class)->resultOk(null, 'ok');
    }

    /** @param list<array<string, mixed>> $items @return mixed */
    public static function syncForDocument(int $documentId, array $items)
    {
        if (!app(WeappEntitlementGateway::class)->entitlementCan('doc_ask') || $documentId < 1) {
            return app(WeappSupportGateway::class)->resultFail('参数错误');
        }
        Db::startTrans();
        try {
            $keepIds = [];
            $sort    = 0;
            foreach ($items as $row) {
                $question = trim((string) ($row['question'] ?? ''));
                $answer   = trim((string) ($row['answer'] ?? ''));
                if ($question === '' || $answer === '') {
                    continue;
                }
                $res = self::saveAdmin([
                    'id'          => (int) ($row['id'] ?? 0),
                    'document_id' => $documentId,
                    'question'    => $question,
                    'answer'      => $answer,
                    'sort'        => (int) ($row['sort'] ?? $sort),
                    'status'      => array_key_exists('status', $row) ? (!empty($row['status']) ? 1 : 0) : 1,
                ]);
                if (!$res->isOk()) {
                    Db::rollback();

                    return app(WeappSupportGateway::class)->resultFail((string) $res->message());
                }
                $newId = (int) ($res['id'] ?? 0);
                if ($newId > 0) {
                    $keepIds[] = $newId;
                }
                $sort++;
            }
            if ($keepIds === []) {
                WeappDocAskItem::where('document_id', $documentId)->delete();
            } else {
                WeappDocAskItem::where('document_id', $documentId)
                    ->whereNotIn('id', $keepIds)
                    ->delete();
            }
            Db::commit();
        } catch (\Throwable $e) {
            Db::rollback();
            app(WeappSupportGateway::class)->kernelOpsLog('ask_sync_for_document_failed', [
                'document_id' => $documentId,
                'msg'         => $e->getMessage(),
            ]);

            return app(WeappSupportGateway::class)->resultFail('同步失败');
        }

        return app(WeappSupportGateway::class)->resultOk(null, 'ok');
    }

    public static function purgeForDocument(int $documentId): void
    {
        if ($documentId > 0) {
            WeappDocAskItem::where('document_id', $documentId)->delete();
        }
    }

    /**
     * @return array<string, mixed>|null
     */
    private static function askItemRow(mixed $found): ?array
    {
        if ($found instanceof WeappDocAskItem) {
            return $found->toArray();
        }

        return is_array($found) ? $found : null;
    }
}