<?php
declare(strict_types=1);

namespace weapp\doc_ask\service;

use app\common\contract\PluginApiCallableTrait;
use app\common\contract\PluginApiInterface;

/** 问答插件对外 API（跨插件经 PluginApiRegistry 调用） */
final class AskPublicApi implements PluginApiInterface
{
    use PluginApiCallableTrait;

    public function pluginIdentifier(): string
    {
        return 'doc_ask';
    }

    public function isActive(): bool
    {
        AskService::ensureAutoload();

        return AskService::isActive();
    }

    /** @return list<array<string, scalar>> */
    public function listForDocument(int $documentId): array
    {
        AskService::ensureAutoload();
        $rows = AskService::listForDocument($documentId);

        return array_map(static fn (array $row): array => AskService::formatPublic($row), $rows);
    }
}
