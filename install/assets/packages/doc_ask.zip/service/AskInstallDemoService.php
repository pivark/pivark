<?php
declare(strict_types=1);

namespace weapp\doc_ask\service;

use app\common\service\weapp\WeappConfigGateway;
use app\common\service\weapp\WeappInstallDemoService;
use app\common\service\weapp\WeappPluginGateway;
use think\facade\Db;

/**
 * 问答插件：安装向导 / 演示种子。
 * 独立 Hub（document_id=0）为主；文档挂载仅作可选样例。
 */
final class AskInstallDemoService
{
    public static function seed(): void
    {
        if (!WeappInstallDemoService::tableReady('weapp_doc_ask_items')) {
            return;
        }

        app(WeappConfigGateway::class)->configSet('ask_open', '1');
        app(WeappConfigGateway::class)->configSet('ask_hub_open', '1');
        app(WeappPluginGateway::class)->pluginEditorSaveSiteSlot('doc_ask', 'hidden');

        self::seedHubPrimary();
        self::seedOptionalDocumentSample();
        app(WeappConfigGateway::class)->installDemoRefreshTagUseCounts();
    }

    /** 广场主数据：document_id=0 + hub_show=1 */
    private static function seedHubPrimary(): void
    {
        $now  = WeappInstallDemoService::now();
        $rows = [
            [
                'q' => '如何快速找到适合的测控方案？',
                'a' => '<p>可先浏览产品频道与案例图集，或在本页按问题关键词扫读；复杂工况建议提交选型咨询，应用工程师 1 个工作日内回复。</p>',
                'hub_pinned' => 1,
                'hub_essence' => 1,
            ],
            [
                'q' => 'HY-810 与 HY-820 量程如何选择？',
                'a' => '<p>请根据过程压力、介质与精度等级对照选型手册第 2 章；不确定时可联系应用工程师确认过载与静压裕量。</p>',
                'hub_pinned' => 0,
                'hub_essence' => 1,
            ],
            [
                'q' => '是否支持 HART 与 Modbus 双输出？',
                'a' => '<p>标准型号二选一，双输出为定制选项，请联系销售工程师确认交期与认证型号。</p>',
                'hub_pinned' => 0,
                'hub_essence' => 0,
            ],
            [
                'q' => '质保与校准周期是多久？',
                'a' => '<p>整机质保 18 个月；建议每 12 个月送检或现场标定一次。全国服务热线 400-800-6688。</p>',
                'hub_pinned' => 0,
                'hub_essence' => 1,
            ],
            [
                'q' => '订货与交付周期？',
                'a' => '<p>常规型号 3~7 个工作日发货；定制量程或防爆规格以合同交期为准。大宗项目可签署框架协议分批供货。</p>',
                'hub_pinned' => 0,
                'hub_essence' => 0,
            ],
            [
                'q' => '是否提供现场校准与售后？',
                'a' => '<p>华北、华东、华南设有服务中心，可预约上门校准、故障诊断与年度巡检。</p>',
                'hub_pinned' => 0,
                'hub_essence' => 0,
            ],
            [
                'q' => 'HY-900 通道数如何选？',
                'a' => '<p>12/24/48 路按测点数量与后续扩展裕量选型；防爆场合请核对合格证型号。</p>',
                'hub_pinned' => 1,
                'hub_essence' => 1,
            ],
            [
                'q' => '是否提供 FAT/SAT？',
                'a' => '<p>Turnkey 与改造项目可按合同提供 FAT/SAT 与培训交付。</p>',
                'hub_pinned' => 0,
                'hub_essence' => 1,
            ],
        ];

        Db::name('weapp_doc_ask_items')->where('document_id', 0)->delete();
        $sort = 1;
        foreach ($rows as $row) {
            Db::name('weapp_doc_ask_items')->insert([
                'document_id' => 0,
                'question'    => $row['q'],
                'answer'      => $row['a'],
                'sort'        => $sort++,
                'status'      => 1,
                'hub_show'    => 1,
                'hub_pinned'  => $row['hub_pinned'],
                'hub_essence' => $row['hub_essence'],
                'created_at'  => $now,
                'updated_at'  => $now,
            ]);
        }
    }

    /** 可选：一篇演示文档挂载（默认不进广场、编辑器 slot=hidden） */
    private static function seedOptionalDocumentSample(): void
    {
        $cfg     = app(WeappConfigGateway::class);
        $tagSlug = 'pv-demo-ask';
        $tagIds  = [
            $tagSlug => $cfg->installDemoUpsertTag([
                'slug'        => $tagSlug,
                'name'        => '文档问答样例',
                'tpl'         => 'list_document.php',

                'nav_sort'    => 0,
                'description' => '可选：单篇文档挂载 FAQ 样例（独立 Hub 为主）',
                'url_path'    => 'faq-demo',
            ]),
        ];
        $docId = $cfg->installDemoUpsertDocument(
            'pv-demo-ask-01',
            '产品选型常见问题（文档挂载样例）',
            '可选挂载演示：日常请用独立问答中心（/faq）。',
            '<p>本页仅演示「可选挂到单篇文档」。站点主入口请走前台 <code>/faq</code> 问答中心。</p>',
        );
        $cfg->installDemoLinkDocumentTags($docId, [$tagSlug], $tagIds);
        if ($docId < 1) {
            return;
        }
        $now = WeappInstallDemoService::now();
        Db::name('weapp_doc_ask_items')->where('document_id', $docId)->delete();
        Db::name('weapp_doc_ask_items')->insert([
            'document_id' => $docId,
            'question'    => '本页 FAQ 与 /faq 广场有何区别？',
            'answer'      => '<p>广场是站点级独立问答；本页是可选挂载到单篇文档的补充，默认不在编辑器露出。</p>',
            'sort'        => 1,
            'status'      => 1,
            'hub_show'    => 0,
            'hub_pinned'  => 0,
            'hub_essence' => 0,
            'created_at'  => $now,
            'updated_at'  => $now,
        ]);
    }
}
