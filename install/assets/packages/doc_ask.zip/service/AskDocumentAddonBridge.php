<?php
/**
 * 元舟 PivArk — document-addon bridge handler（weapp SSOT）
 */
declare(strict_types=1);

namespace weapp\doc_ask\service;

use app\common\contract\DocumentAddonBridgeHandlerInterface;
use app\common\contract\WeappPluginBridgeTrait;
use app\common\service\weapp\WeappSupportGateway;


final class AskDocumentAddonBridge implements DocumentAddonBridgeHandlerInterface
{
    use WeappPluginBridgeTrait;

    
    

    public function isEnabled(): bool
    {
        return $this->bridgeEnabled('doc_ask');
    }

    public function identifier(): string
    {
        return 'doc_ask';
    }
    /** @return array<string, mixed> */
    public function documentEditorSpaPayload(int $documentId): array
    {
        return [
            'save_field' => 'ask_json',
            'items'      => $documentId > 0 ? $this->listForDocument($documentId) : [],
        ];
    }

    /** @return list<array<string, mixed>> */
    public function listForDocument(int $documentId): array
    {
        if (!$this->isEnabled() || $documentId < 1) {
            return [];
        }
        $this->ensurePluginLoaded();

        return \weapp\doc_ask\service\AskService::listForDocument($documentId);
    }

    /**
     * @param list<array<string, mixed>> $items
     * @return mixed
     */
    public function syncForDocument(int $documentId, array $items)
    {
        if (!$this->isEnabled() || $documentId < 1) {
            return app(WeappSupportGateway::class)->resultFail('参数错误');
        }
        $this->ensurePluginLoaded();

        return \weapp\doc_ask\service\AskService::syncForDocument($documentId, $items);
    }

    public function purgeForDocument(int $documentId): void
    {
        if (!$this->isEnabled() || $documentId < 1) {
            return;
        }
        $this->ensurePluginLoaded();
        \weapp\doc_ask\service\AskService::purgeForDocument($documentId);
    }

    /** 模板 flag document_has_doc_ask */
    public function hasAvailabilityForDocument(int $documentId): bool
    {
        if (!$this->isEnabled() || $documentId < 1) {
            return false;
        }
        $this->ensurePluginLoaded();

        return \weapp\doc_ask\service\AskService::listForDocument($documentId) !== [];
    }

    /**
     * @return list<int>
     */
    public function documentIdsWithAvailability(): array
    {
        if (!$this->isEnabled()) {
            return [];
        }
        $this->ensurePluginLoaded();

        return \weapp\doc_ask\service\AskService::documentIdsWithPublicAvailability();
    }

    public function isHubActive(): bool
    {
        if (!$this->isEnabled()) {
            return false;
        }
        $this->ensurePluginLoaded();

        return \weapp\doc_ask\service\AskService::isActive()
            && \weapp\doc_ask\service\AskConfigService::isHubOpen();
    }

    /** @return array{list:list<array<string,mixed>>,total:int} */
    public function listHubPublic(array $opts = []): array
    {
        if (!$this->isHubActive()) {
            return ['list' => [], 'total' => 0, 'user_ask_open' => 0];
        }
        $this->ensurePluginLoaded();

        return \weapp\doc_ask\service\AskHubService::listPublic($opts);
    }

    /** @return list<array<string,mixed>> */
    public function hubHotTags(int $limit = 8): array
    {
        if (!$this->isHubActive()) {
            return [];
        }
        $this->ensurePluginLoaded();

        return \weapp\doc_ask\service\AskHubService::hotTags($limit);
    }

    /** @return list<array<string,mixed>> */
    public function hubBoards(int $limit = 8): array
    {
        if (!$this->isHubActive()) {
            return [];
        }
        $this->ensurePluginLoaded();

        return \weapp\doc_ask\service\AskHubService::boards($limit);
    }

    public function countHubItems(int $documentId): int
    {
        if (!$this->isEnabled() || $documentId < 1) {
            return 0;
        }
        $this->ensurePluginLoaded();

        return AskWwwSeedService::countHubItems($documentId);
    }

    public function purgeDocumentItems(int $documentId): void
    {
        if (!$this->isEnabled() || $documentId < 1) {
            return;
        }
        $this->ensurePluginLoaded();
        AskWwwSeedService::purgeDocumentItems($documentId);
    }

    public function purgeAlienHubItems(int $hubDocumentId): int
    {
        if (!$this->isEnabled() || $hubDocumentId < 1) {
            return 0;
        }
        $this->ensurePluginLoaded();

        return AskWwwSeedService::purgeAlienHubItems($hubDocumentId);
    }

    /**
     * @param list<array<string,mixed>> $items
     */
    public function seedHubItems(int $documentId, array $items): int
    {
        if (!$this->isEnabled() || $documentId < 1 || $items === []) {
            return 0;
        }
        $this->ensurePluginLoaded();

        return AskWwwSeedService::seedHubItems($documentId, $items);
    }

    private function ensurePluginLoaded(): void
    {
        $this->registerWeappAutoload('doc_ask');
        \weapp\doc_ask\service\AskService::ensureAutoload();
    }
}
