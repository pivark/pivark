<?php
declare(strict_types=1);

namespace weapp\doc_ask\service;

use app\common\service\weapp\WeappDocumentGateway;
use app\common\service\weapp\WeappSupportGateway;
use app\common\service\weapp\WeappTagGateway;
use weapp\doc_ask\model\WeappDocAskItem;

/** 站点问答聚合（/faq 等前台列表） */
final class AskHubService
{
    /**
     * @param array<string, mixed> $opts
     * @return array{list: list<array<string, mixed>>, total: int}
     */
    public static function listPublic(array $opts = []): array
    {
        if (!AskService::isActive() || !AskConfigService::isHubOpen()) {
            return ['list' => [], 'total' => 0, 'user_ask_open' => 0];
        }
        AskFrontAssets::registerFaq();

        $docGw   = app(WeappDocumentGateway::class);
        $sort    = trim((string) ($opts['sort'] ?? 'latest'));
        $page    = max(1, (int) ($opts['page'] ?? 1));
        $hubHtml = trim((string) ($opts['hub_html_name'] ?? ''));
        $cap     = $hubHtml !== '' ? 300 : 50;
        $limit   = max(1, min($cap, (int) ($opts['limit'] ?? 30)));
        $keyword = trim((string) ($opts['keyword'] ?? ''));

        // 独立 Hub：document_id=0 为主；可选把勾选「进广场」且挂文档的条目一并聚合
        if ($hubHtml !== '') {
            $docIds = $docGw->documentPublishedIds($hubHtml);
            if ($docIds === []) {
                $docIds = [0];
            }
        } else {
            $docIds = array_values(array_unique(array_merge([0], $docGw->documentPublishedIds())));
        }

        $query = WeappDocAskItem::where('status', 1)
            ->where('hub_show', 1)
            ->where('answer', '<>', '')
            ->whereIn('document_id', $docIds);

        if ($keyword !== '') {
            $pattern = '%' . addcslashes($keyword, '%_\\') . '%';
            $titleDocIds = $docGw->documentPublishedIdsWithTitleLike($keyword);
            $query->where(function ($sub) use ($pattern, $titleDocIds): void {
                $sub->whereLike('question|answer', $pattern);
                if ($titleDocIds !== []) {
                    $sub->whereOr('document_id', 'in', $titleDocIds);
                }
            });
        }

        $total = (int) (clone $query)->count();

        $order = match ($sort) {
            'essence' => ['hub_pinned' => 'desc', 'hub_essence' => 'desc', 'updated_at' => 'desc', 'id' => 'desc'],
            default => ['hub_pinned' => 'desc', 'updated_at' => 'desc', 'id' => 'desc'],
        };

        $rows = $query->order($order)->page($page, $limit)->select()->toArray();
        $rows = self::attachDocumentFields($rows);

        $list = [];
        foreach ($rows as $row) {
            $list[] = self::formatHubRow($row);
        }

        return [
            'list' => $list,
            'total' => $total,
            'user_ask_open' => AskConfigService::isUserAskOpen() ? 1 : 0,
        ];
    }

    /**
     * @param list<array<string, mixed>> $rows
     * @return list<array<string, mixed>>
     */
    private static function attachDocumentFields(array $rows): array
    {
        $docGw = app(WeappDocumentGateway::class);
        $ids = [];
        foreach ($rows as $row) {
            $id = (int) ($row['document_id'] ?? 0);
            if ($id > 0) {
                $ids[] = $id;
            }
        }
        $docMap = [];
        foreach ($docGw->documentRowsByIds($ids, 'id,title,html_name') as $doc) {
            $docMap[(int) ($doc['id'] ?? 0)] = $doc;
        }
        foreach ($rows as &$row) {
            $did = (int) ($row['document_id'] ?? 0);
            if ($did > 0 && isset($docMap[$did])) {
                $row['document_title']     = (string) ($docMap[$did]['title'] ?? '');
                $row['document_html_name'] = (string) ($docMap[$did]['html_name'] ?? '');
            }
        }
        unset($row);

        return $rows;
    }

    /**
     * @param array<string, mixed> $row
     * @return array<string, mixed>
     */
    public static function formatHubRow(array $row): array
    {
        $docGw      = app(WeappDocumentGateway::class);
        $supportGw  = app(WeappSupportGateway::class);
        $tagGw      = app(WeappTagGateway::class);
        $documentId = (int) ($row['document_id'] ?? 0);
        $itemId     = (int) ($row['id'] ?? 0);
        $docUrl     = $documentId > 0
            ? $supportGw->siteUrlDocument($documentId, (string) ($row['document_html_name'] ?? ''))
            : $supportGw->siteUrlPageByTpl('faq');

        $tag = null;
        if ($documentId > 0) {
            $docRow = $docGw->documentRowById($documentId, false);
            if ($docRow !== null) {
                $tag = $tagGw->tagPrimaryFromDocument($docRow);
            }
        }

        $tagName = trim((string) ($tag['name'] ?? ''));
        $tagSlug = trim((string) ($tag['slug'] ?? ''));
        $tagUrl  = $tagSlug !== '' ? $supportGw->siteUrlTag($tagSlug) : $docUrl;

        return [
            'id'               => $itemId,
            'question'         => (string) ($row['question'] ?? ''),
            'answer'           => (string) ($row['answer'] ?? ''),
            'document_id'      => $documentId,
            'document_title'   => (string) ($row['document_title'] ?? ''),
            'document_url'     => $docUrl,
            'url'              => $docUrl . '#pv-ask-' . $itemId,
            'hub_pinned'       => (int) ($row['hub_pinned'] ?? 0),
            'hub_essence'      => (int) ($row['hub_essence'] ?? 0),
            'source'           => ((string) ($row['source'] ?? 'official')) === 'user' ? 'user' : 'official',
            'is_user'          => ((string) ($row['source'] ?? 'official')) === 'user' ? 1 : 0,
            'asker_name'       => (string) ($row['asker_name'] ?? ''),
            'tag_name'         => $tagName !== '' ? $tagName : '常见问题',
            'tag_slug'         => $tagSlug,
            'tag_url'          => $tagUrl,
            'updated_at'       => (string) ($row['updated_at'] ?? ''),
        ];
    }

    /** @return list<array{label:string,url:string}> */
    public static function hotTags(int $limit = 8): array
    {
        if (!AskService::isActive() || !AskConfigService::isHubOpen()) {
            return [];
        }

        $docGw      = app(WeappDocumentGateway::class);
        $supportGw  = app(WeappSupportGateway::class);
        $tagGw      = app(WeappTagGateway::class);
        $docIds = $docGw->documentPublishedIds();
        if ($docIds === []) {
            return [];
        }

        $hubDocIds = WeappDocAskItem::where('status', 1)
            ->where('hub_show', 1)
            ->whereIn('document_id', $docIds)
            ->group('document_id')
            ->column('document_id');

        if ($hubDocIds === []) {
            return [];
        }

        $tags = [];
        foreach ($hubDocIds as $docId) {
            $docRow = $docGw->documentRowById((int) $docId, false);
            if ($docRow === null) {
                continue;
            }
            $tag = $tagGw->tagPrimaryFromDocument($docRow);
            if ($tag === null) {
                continue;
            }
            $slug = trim((string) ($tag['slug'] ?? ''));
            if ($slug === '') {
                continue;
            }
            $tags[$slug] = [
                'label' => (string) ($tag['name'] ?? $slug),
                'url'   => $supportGw->siteUrlTag($slug),
            ];
        }

        return array_slice(array_values($tags), 0, max(1, $limit));
    }

    /** @return list<array{label:string,url:string}> */
    public static function boards(int $limit = 8): array
    {
        $tags = self::hotTags($limit);

        return array_map(static fn (array $row): array => [
            'label' => $row['label'],
            'url'   => $row['url'],
        ], $tags);
    }
}
