<?php
declare(strict_types=1);

namespace weapp\doc_ask\service;

use app\common\service\weapp\WeappSupportGateway;
use weapp\doc_ask\model\WeappDocAskItem;

/** FAQ hub 条目写入助手（经 AskDocumentAddonBridge；官网整包种子已退役） */
final class AskWwwSeedService
{
    public static function countHubItems(int $documentId): int
    {
        if ($documentId < 1) {
            return 0;
        }

        return (int) WeappDocAskItem::where('document_id', $documentId)
            ->where('status', 1)
            ->where('hub_show', 1)
            ->count();
    }

    public static function purgeDocumentItems(int $documentId): void
    {
        if ($documentId < 1) {
            return;
        }
        WeappDocAskItem::where('document_id', $documentId)->delete();
    }

    public static function purgeAlienHubItems(int $hubDocumentId): int
    {
        if ($hubDocumentId < 1) {
            return 0;
        }

        return (int) WeappDocAskItem::where('hub_show', 1)
            ->where('document_id', '<>', $hubDocumentId)
            ->update(['hub_show' => 0, 'updated_at' => app(WeappSupportGateway::class)->appTimeNow()]);
    }

    /**
     * @param list<array<string,mixed>> $items
     */
    public static function seedHubItems(int $documentId, array $items): int
    {
        if ($documentId < 1 || $items === []) {
            return 0;
        }
        $now = app(WeappSupportGateway::class)->appTimeNow();
        $count = 0;
        $sort = 0;
        foreach ($items as $item) {
            WeappDocAskItem::insert([
                'document_id'  => $documentId,
                'question'     => (string) ($item['q'] ?? ''),
                'answer'       => (string) ($item['a'] ?? ''),
                'sort'         => $sort,
                'status'       => 1,
                'hub_show'     => 1,
                'hub_pinned'   => (int) ($item['pinned'] ?? ($sort === 0 ? 1 : 0)),
                'hub_essence'  => (int) ($item['essence'] ?? ($sort < 8 ? 1 : 0)),
                'created_at'   => $now,
                'updated_at'   => $now,
            ]);
            $count++;
            $sort++;
        }

        return $count;
    }
}
