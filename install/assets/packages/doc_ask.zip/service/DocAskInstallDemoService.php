<?php
declare(strict_types=1);

namespace weapp\doc_ask\service;

use app\common\service\weapp\WeappConfigGateway;
use app\common\service\weapp\WeappInstallDemoService;
use think\facade\Db;

/**
 * 问答插件：安装向导首次装插件时的默认演示数据。
 * 类名 DocAsk* 对齐 WeappInstallDemoService 对 identifier=doc_ask 的解析。
 */
final class DocAskInstallDemoService
{
    public static function seed(): void
    {
        AskInstallDemoService::seed();
    }
}
