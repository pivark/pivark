<?php
declare(strict_types=1);

namespace weapp\doc_ask\service;

use app\common\service\weapp\WeappFrontGateway;

/** 问答 FAQ 前台默认样式（经 {pv:frontassets} 按需输出） */
final class AskFrontAssets
{
    public static function registerFaq(): void
    {
        app(WeappFrontGateway::class)->frontAssetRegisterWeappStylesheet(
            'doc_ask',
            'pv-ask-css',
            'assets/css/ask.css',
        );
    }
}
