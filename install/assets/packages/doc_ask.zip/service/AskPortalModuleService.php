<?php
/**
 * 元舟 PivArk — 企业全域原子化数字资产中枢
 * (c) 2024-2026 pivark.com. All rights reserved.
 * Author: Angelo
 * 未经允许，不可用于商业用途。
 */
declare(strict_types=1);

namespace weapp\doc_ask\service;

/** 门户 / 开发者主页 ask 模块开关（SSOT · 替代 PlatformPortalWidgetService 内 ask 分支） */
final class AskPortalModuleService
{
    public static function isActive(): bool
    {
        AskService::ensureAutoload();

        return AskService::isActive();
    }

    /** @return array{ask:bool} */
    public static function moduleFlags(): array
    {
        return ['doc_ask' => self::isActive()];
    }
}
