<?php
declare(strict_types=1);

namespace weapp\doc_ask\service;


use app\common\service\weapp\WeappConfigGateway;
use app\common\service\weapp\WeappPluginGateway;
use app\common\service\weapp\WeappSupportGateway;

/** 文档问答 全局配置 */
class AskConfigService
{
    /** @return list<string> */
    public static function keys(): array
    {
        return ['ask_open', 'ask_document_editor_slot', 'ask_hub_open', 'ask_user_ask_open'];
    }

    /** @return array<string, string> */
    public static function all(): array
    {
        $out = [];
        foreach (self::keys() as $key) {
            $out[$key] = (string) app(WeappConfigGateway::class)->configGet($key, self::defaultFor($key));
        }
        $out['ask_document_editor_slot'] = app(WeappPluginGateway::class)->pluginEditorResolveSlot('doc_ask');

        return $out;
    }

    public static function defaultFor(string $key): string
    {
        return match ($key) {
            'ask_open' => '1',
            'ask_hub_open' => '1',
            'ask_user_ask_open' => '1',
            'ask_document_editor_slot' => app(WeappPluginGateway::class)->pluginEditorManifestDefaultSlot('doc_ask'),
            default => '',
        };
    }

    public static function isOpen(): bool
    {
        return (string) app(WeappConfigGateway::class)->configGet('ask_open', '1') === '1';
    }

    public static function isHubOpen(): bool
    {
        return self::isOpen() && (string) app(WeappConfigGateway::class)->configGet('ask_hub_open', '1') === '1';
    }

    /** 前台访客/会员是否可提交提问 */
    public static function isUserAskOpen(): bool
    {
        return self::isHubOpen()
            && (string) app(WeappConfigGateway::class)->configGet('ask_user_ask_open', '1') === '1';
    }

    /** @param array<string, mixed> $post @return mixed */
    public static function saveAdmin(array $post)
    {
        app(WeappConfigGateway::class)->configSet('ask_open', !empty($post['ask_open']) ? '1' : '0');
        if (array_key_exists('ask_hub_open', $post)) {
            app(WeappConfigGateway::class)->configSet('ask_hub_open', !empty($post['ask_hub_open']) ? '1' : '0');
        }
        if (array_key_exists('ask_user_ask_open', $post)) {
            app(WeappConfigGateway::class)->configSet('ask_user_ask_open', !empty($post['ask_user_ask_open']) ? '1' : '0');
        }
        if (array_key_exists('ask_document_editor_slot', $post)) {
            $slotRes = app(WeappPluginGateway::class)->pluginEditorSaveSiteSlot(
                'doc_ask',
                (string) ($post['ask_document_editor_slot'] ?? '')
            );
            if (!$slotRes->isOk()) {
                return $slotRes;
            }
        }

        app(WeappPluginGateway::class)->pluginAfterConfigSaved(
            'meta'
        );

        return app(WeappSupportGateway::class)->resultOk(null, '保存成功');
    }
}
