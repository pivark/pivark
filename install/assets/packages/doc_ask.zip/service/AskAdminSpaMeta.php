<?php
declare(strict_types=1);

namespace weapp\doc_ask\service;

use app\common\service\weapp\WeappPluginGateway;

final class AskAdminSpaMeta
{
    /** @param array<string, mixed> $ctx @return array<string, mixed> */
    public static function build(array $ctx): array
    {
        AskService::ensureAutoload();

        return [
            'cfg'        => AskConfigService::all(),
            'stats'      => AskService::statsAdmin(),
            'slotCards'  => app(WeappPluginGateway::class)->pluginEditorSurfaceSlotCards('doc_ask'),
            'editorSlot' => app(WeappPluginGateway::class)->pluginEditorResolveSlot('doc_ask'),
            'plugin'     => app(WeappPluginGateway::class)->pluginPresentationForAdmin('doc_ask'),
        ];
    }
}