<?php
declare(strict_types=1);

namespace weapp\doc_ask\service;

use app\common\service\weapp\WeappAdminGateway;

final class AskAdminSpaRoutes
{
    public static function register(): void
    {
        $gw = app(WeappAdminGateway::class);
        $id = 'doc_ask';

        $gw->adminSpaHostRegisterPluginPage($id,
            'settings',
            'WeappDocAskSettings',
            ['title' => '基础设置'],
        );
        $gw->adminSpaHostRegisterPluginPage($id,
            'list',
            'WeappDocAskList',
            ['title' => '条目管理'],
        );

        foreach (['usage' => ['WeappDocAskUsage', '使用说明', '/weapp/usage/index'], 'guide' => ['WeappDocAskGuide', '功能介绍', '/weapp/guide/index']] as $seg => [$name, $title, $component]) {
            $path = $gw->adminSpaHostPath($id, $seg);
            $gw->adminSpaExplicitRouteRegister($path, [
                'name'      => $name,
                'path'      => $path,
                'component' => $component,
                'meta'      => ['pivarkWeapp' => $id, 'title' => $title],
            ]);
        }

        $gw->adminSpaRouteIconRegister($gw->adminSpaHostPath($id, 'settings'), 'lucide:help-circle');
        $gw->adminSpaRouteIconRegister($gw->adminSpaHostPath($id, 'list'), 'lucide:list');
        $gw->adminWeappNavTabsRegister($id, [
            $gw->adminWeappNavTab('settings', '基础设置', 'settings'),
            $gw->adminWeappNavTab('list', '条目管理', 'list'),
        ]);
    }
}
