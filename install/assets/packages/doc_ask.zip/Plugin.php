<?php
declare(strict_types=1);

namespace weapp\doc_ask;

use weapp\doc_ask\service\AskAdminSpaMeta;
use app\common\service\weapp\WeappAdminGateway;
use app\common\service\weapp\WeappEntitlementGateway;
use app\common\service\weapp\WeappFrontGateway;
use app\common\service\weapp\WeappPluginGateway;
use app\common\service\weapp\WeappSiteGateway;
use app\common\service\weapp\WeappTemplateGateway;
use weapp\doc_ask\service\AskPublicApi;
use weapp\doc_ask\service\AskService;
use weapp\doc_ask\service\AskAdminSpaRoutes;
use weapp\doc_ask\service\AskDocumentAddonBridge;
use weapp\doc_ask\service\AskFrontAssets;

/** 官方 问答 插件（独立 Hub 为主，文档挂载可选） */
class Plugin
{
    public function install(): void
    {
        app(WeappEntitlementGateway::class)->entitlementGrantFreeInstall('doc_ask');
    }

    public function enable(): void
    {
    }

    public function disable(): void
    {
    }

    public function boot(): void
    {
        $admin = app(WeappAdminGateway::class);
        $plugin = app(WeappPluginGateway::class);
        $admin->adminSpaMetaRegister('doc_ask', 'doc_ask', [AskAdminSpaMeta::class, 'build']);
        AskAdminSpaRoutes::register();
        $perm = 'plugin.doc_ask.use';
        $admin->adminPermissionExtensionRegisterMap('doc_ask', [
            'index'      => $perm,
            'list'       => $perm,
            'usage'      => $perm,
            'configsave' => $perm,
            'save'       => $perm,
            'delete'     => $perm,
            'status'     => $perm,
        ]);
        $plugin->pluginLogicalTableRegister('doc_ask', [
            'items' => 'weapp_doc_ask_items',
        ]);
        $plugin->pluginExtensionRegisterDocumentAddonBridge(
            'doc_ask',
            new AskDocumentAddonBridge(),
            100,
            ['document_availability' => 'doc_ask'],
        );
        AskService::ensureAutoload();
        app(WeappFrontGateway::class)->frontAssetHandlerRegister('doc_ask', 'faq', [AskFrontAssets::class, 'registerFaq']);
        $plugin->pluginApiRegistryRegister('AskPublic', new AskPublicApi());
        app(WeappTemplateGateway::class)->templateRegisterExtensionTag('doc_ask', [AskService::class, 'renderTag']);
        app(WeappSiteGateway::class)->hubCapabilityRegisterAskHub('doc_ask');
        $plugin->pluginRouteRegister(
            'post',
            'api/v1/plugins/doc_ask/submit',
            '\\weapp\\doc_ask\\api\\controller\\Ask@submit'
        );
    }
}
